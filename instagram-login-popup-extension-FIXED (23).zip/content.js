/* ==========================================================================
   IG 2FA AUTOMATION PRO v4.0.0
   100% English UI • Unstoppable Auto-Login & Meta Horizon Auto-Select
   1. Automatically detects & submits the "Log in" button (Screenshot 2)
   2. Automatically detects & clicks the "Meta Horizon" card (Screenshot 1)
   3. Step-by-step sequential execution (One after another)
   4. Native TouchEvents + PointerEvents + Form.requestSubmit()
   ========================================================================== */

(function() {
  'use strict';

  if (window.__IG_PRO_LOADED) {
    return;
  }
  window.__IG_PRO_LOADED = true;

  var isTopFrame = false;
  try {
    isTopFrame = (window.top === window.self);
  } catch(e) {
    isTopFrame = false;
  }

  /* ========== 0. EMBEDDED STYLES FOR STANDALONE & EXTENSION INJECTION ========== */
  function ensureStylesInjected() {
    if (!isTopFrame) return;
    if (document.getElementById('IG_PRO_CSS_STYLES')) return;
    try {
      var styleEl = document.createElement('style');
      styleEl.id = 'IG_PRO_CSS_STYLES';
      styleEl.textContent = "/* ============================================================\n   IG 2FA AUTOMATION PRO v4.0.0 - EXACT SCREENSHOT 3-TAB UI\n   100% English \u2022 Responsive Screen-Fitting \u2022 Modern Dark Theme\n   ============================================================ */\n\n/* 1. Floating Launch Button */\n#IG_FLOAT_BTN {\n  position: fixed !important;\n  width: 48px !important;\n  height: 48px !important;\n  min-width: 48px !important;\n  min-height: 48px !important;\n  border-radius: 50% !important;\n  background: linear-gradient(135deg, #833AB4 0%, #FD1D1D 50%, #F77737 100%) !important;\n  border: 2px solid rgba(255, 255, 255, 0.9) !important;\n  box-shadow: 0 4px 18px rgba(0, 0, 0, 0.4), 0 2px 8px rgba(225, 48, 108, 0.35) !important;\n  cursor: pointer !important;\n  z-index: 2147483646 !important;\n  display: flex !important;\n  align-items: center !important;\n  justify-content: center !important;\n  user-select: none !important;\n  -webkit-user-select: none !important;\n  touch-action: none !important;\n  transition: transform 0.15s ease, filter 0.15s ease !important;\n}\n\n#IG_FLOAT_BTN:hover {\n  filter: brightness(1.1) !important;\n  transform: scale(1.05) !important;\n}\n\n#IG_FLOAT_BTN:active {\n  filter: brightness(0.92) !important;\n  transform: scale(0.95) !important;\n}\n\n/* 2. Minimized Floating Pill */\n#IG_MINI_PILL {\n  --ig-pill-bottom: 20px;\n  position: fixed !important;\n  bottom: var(--ig-pill-bottom, 20px) !important;\n  left: 50% !important;\n  transform: translateX(-50%) !important;\n  height: 38px !important;\n  padding: 0 16px !important;\n  background: rgba(18, 18, 26, 0.94) !important;\n  backdrop-filter: blur(16px) !important;\n  -webkit-backdrop-filter: blur(16px) !important;\n  border: 1px solid rgba(255, 255, 255, 0.14) !important;\n  border-radius: 20px !important;\n  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.6) !important;\n  z-index: 2147483647 !important;\n  display: none;\n  align-items: center !important;\n  gap: 10px !important;\n  cursor: pointer !important;\n  color: #fff !important;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, sans-serif !important;\n  font-size: 11px !important;\n  font-weight: 600 !important;\n  user-select: none !important;\n  white-space: nowrap !important;\n  transition: bottom 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important;\n}\n\n/* 3. Main Floating Popup Panel (Exact Screenshot_2026-10-06-13-35-58) */\n#IG_POPUP_PAN {\n  --ig-pan-bottom: 14px;\n  --ig-pan-top: auto;\n  --ig-pan-max-height: 84vh;\n  position: fixed !important;\n  top: var(--ig-pan-top, auto) !important;\n  bottom: var(--ig-pan-bottom, 14px) !important;\n  left: 50% !important;\n  transform: translate3d(-50%, 0, 0) !important;\n  -webkit-transform: translate3d(-50%, 0, 0) !important;\n  width: min(350px, calc(100vw - 20px)) !important;\n  max-width: 350px !important;\n  max-height: var(--ig-pan-max-height, 84vh) !important;\n  overflow-y: auto !important;\n  -webkit-overflow-scrolling: touch !important;\n  will-change: transform, opacity !important;\n  background: rgba(16, 16, 23, 0.98) !important;\n  backdrop-filter: blur(24px) !important;\n  -webkit-backdrop-filter: blur(24px) !important;\n  border-radius: 18px !important;\n  border: 1px solid rgba(255, 255, 255, 0.12) !important;\n  box-shadow: 0 16px 50px rgba(0, 0, 0, 0.85) !important;\n  z-index: 2147483647 !important;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, sans-serif !important;\n  display: none;\n  opacity: 0;\n  transition: opacity 0.12s ease !important;\n  color: #fff !important;\n  box-sizing: border-box !important;\n}\n\n#IG_POPUP_PAN * {\n  box-sizing: border-box !important;\n}\n\n/* Header */\n#IG_POPUP_HEADER {\n  user-select: none !important;\n  -webkit-user-select: none !important;\n}\n\n/* Slim scrollbar */\n#IG_POPUP_PAN::-webkit-scrollbar { width: 4px; }\n#IG_POPUP_PAN::-webkit-scrollbar-track { background: transparent; }\n#IG_POPUP_PAN::-webkit-scrollbar-thumb { background: #323242; border-radius: 2px; }\n\n/* 4. Overlay Backdrop */\n#IG_OVERLAY_BG {\n  position: fixed !important;\n  inset: 0 !important;\n  background: rgba(0, 0, 0, 0.6) !important;\n  backdrop-filter: blur(2px) !important;\n  -webkit-backdrop-filter: blur(2px) !important;\n  z-index: 2147483645 !important;\n  display: none;\n  opacity: 0;\n  transition: opacity 0.12s ease !important;\n}\n\n/* 5. Sleek Modern Pill Toast Notification */\n#__ig_t {\n  position: fixed !important;\n  bottom: 24px !important;\n  left: 50% !important;\n  transform: translateX(-50%) translateY(12px) !important;\n  background: rgba(18, 18, 26, 0.95) !important;\n  color: #fff !important;\n  padding: 8px 18px !important;\n  border-radius: 24px !important;\n  font-size: 12px !important;\n  font-weight: 700 !important;\n  z-index: 2147483647 !important;\n  font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, sans-serif !important;\n  transition: opacity 0.22s ease, transform 0.22s cubic-bezier(0.16, 1, 0.3, 1) !important;\n  opacity: 0;\n  pointer-events: none !important;\n  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.65) !important;\n  border: 1px solid rgba(255, 255, 255, 0.16) !important;\n  white-space: nowrap !important;\n  display: flex !important;\n  align-items: center !important;\n  gap: 8px !important;\n  backdrop-filter: blur(12px) !important;\n  -webkit-backdrop-filter: blur(12px) !important;\n}\n\n/* 6. Tabs Styling (Exact Screenshot_2026-10-06-13-35-58) */\n.ig-tab-bar {\n  display: flex;\n  background: #14141c;\n  border-bottom: 1px solid rgba(255, 255, 255, 0.08);\n  padding: 3px 6px;\n  gap: 4px;\n}\n\n.ig-tab-btn {\n  flex: 1;\n  padding: 7px 4px;\n  background: none;\n  border: none;\n  border-radius: 8px;\n  color: #888899;\n  font-size: 11px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: all 0.18s ease;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 5px;\n}\n\n.ig-tab-btn:hover {\n  color: #eee;\n  background: rgba(255, 255, 255, 0.04);\n}\n\n.ig-tab-btn.active {\n  color: #fff;\n  background: rgba(255, 255, 255, 0.1);\n  font-weight: 700;\n}\n\n/* 7. Form Inputs & Controls */\n.ig-input-group {\n  margin-bottom: 6px;\n  padding: 0 12px;\n}\n\n.ig-label {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  font-size: 9px;\n  font-weight: 700;\n  color: #9999aa;\n  margin-bottom: 3px;\n  letter-spacing: 0.5px;\n}\n\n.ig-textarea, .ig-text-input {\n  width: 100%;\n  padding: 7px 10px;\n  border-radius: 8px;\n  border: 1px solid #282834;\n  background: #14141c;\n  color: #f0f0f5;\n  font-size: 11px;\n  outline: none;\n  transition: border-color 0.18s, box-shadow 0.18s;\n  font-family: inherit;\n}\n\n.ig-textarea:focus, .ig-text-input:focus {\n  border-color: #833AB4;\n  box-shadow: 0 0 0 2px rgba(131, 58, 180, 0.2);\n}\n\n/* 8. Action Buttons */\n.ig-btn {\n  padding: 7px 10px;\n  border-radius: 8px;\n  border: none;\n  font-size: 11px;\n  font-weight: 700;\n  cursor: pointer;\n  transition: filter 0.15s, transform 0.1s;\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 6px;\n  user-select: none;\n}\n\n.ig-btn:hover {\n  filter: brightness(1.12);\n}\n\n.ig-btn:active {\n  transform: scale(0.97);\n}\n\n.ig-btn-primary {\n  background: linear-gradient(135deg, #833AB4 0%, #FD1D1D 50%, #F77737 100%);\n  color: #fff;\n  box-shadow: 0 3px 12px rgba(225, 48, 108, 0.35);\n}\n\n.ig-btn-success {\n  background: linear-gradient(135deg, #059669 0%, #10b981 100%);\n  color: #fff;\n}\n\n.ig-btn-secondary {\n  background: #1e1e28;\n  color: #ccc;\n  border: 1px solid #30303e;\n}\n\n.ig-btn-warning {\n  background: #d97706;\n  color: #fff;\n}\n\n.ig-btn-danger {\n  background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);\n  color: #fff;\n}\n\n/* 9. Record Cards */\n.ig-record-card {\n  background: #14141c;\n  border: 1px solid #242430;\n  border-radius: 7px;\n  padding: 6px 8px;\n  margin-bottom: 5px;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 6px;\n}\n\n.ig-record-key {\n  font-family: monospace;\n  font-size: 10px;\n  color: #a78bfa;\n  background: rgba(139, 92, 246, 0.12);\n  padding: 2px 6px;\n  border-radius: 4px;\n}\n\n/* 10. Detected Card Pulse Animation */\n@keyframes igPulseGlow {\n  0% {\n    outline-color: #10b981;\n    box-shadow: 0 0 15px rgba(16, 185, 129, 0.8);\n  }\n  50% {\n    outline-color: #34d399;\n    box-shadow: 0 0 30px rgba(52, 211, 153, 1);\n  }\n  100% {\n    outline-color: #10b981;\n    box-shadow: 0 0 15px rgba(16, 185, 129, 0.8);\n  }\n}\n\n.ig-detected-card-pulse {\n  outline: 3px solid #10b981 !important;\n  outline-offset: 3px !important;\n  box-shadow: 0 0 25px rgba(16, 185, 129, 0.9) !important;\n  animation: igPulseGlow 1.2s infinite ease-in-out !important;\n}\n\n/* 11. Inline Boxes */\n.ig-inline-box {\n  background: #181824;\n  border: 1px solid #2e2e42;\n  border-radius: 10px;\n  padding: 10px 12px;\n  margin-bottom: 8px;\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n\n@media (max-width: 360px) {\n  #IG_POPUP_PAN {\n    width: calc(100vw - 12px) !important;\n    bottom: var(--ig-pan-bottom, 8px) !important;\n    max-height: var(--ig-pan-max-height, 86vh) !important;\n    border-radius: 14px !important;\n  }\n}\n";
      (document.head || document.documentElement).appendChild(styleEl);
    } catch(e) {}
  }


  /* ========== 1. SAFE STORAGE & SYNCHRONIZATION ========= */
  var Store = {
    get: function(k, d) {
      try {
        var v = localStorage.getItem('ig_v10_' + k);
        return v ? JSON.parse(v) : d;
      } catch(e) {
        return d;
      }
    },
    set: function(k, v) {
      try {
        localStorage.setItem('ig_v10_' + k, JSON.stringify(v));
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          var o = {};
          o['ig_v10_' + k] = v;
          chrome.storage.local.set(o);
        }
        return true;
      } catch(e) {
        return false;
      }
    },
    del: function(k) {
      try {
        localStorage.removeItem('ig_v10_' + k);
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.remove('ig_v10_' + k);
        }
      } catch(e) {}
    },

    getEmails: function() {
      var raw = this.get('em', '') || '';
      return raw.split(/\r?\n/).map(function(e) { return e.trim(); }).filter(Boolean);
    },
    getPass: function() {
      var p = this.get('pw', '');
      return typeof p === 'string' ? p.replace(/\r$/, '') : '';
    },
    getState: function() { return this.get('st', { done: [], skip: [], cur: null }); },
    setState: function(s) { return this.set('st', s); },
    getCSV: function() { return this.get('csv', []); },
    setCSV: function(d) { return this.set('csv', d); },
    isOn: function() { return this.get('en', true) !== false; },
    setOn: function(v) {
      this.set('en', v);
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ extensionEnabled: v });
      }
      return v;
    },
    getPos: function() { return this.get('pos'); },
    setPos: function(p) { return this.set('pos', p); },

    getSettings: function() {
      var s = this.get('cfg', null);
      if (!s || typeof s !== 'object') {
        s = { autoLogin: true, autoMetaHorizon: true, autoAdvance: true };
        this.set('cfg', s);
      }
      if (s.autoLogin === undefined) s.autoLogin = true;
      if (s.autoMetaHorizon === undefined) s.autoMetaHorizon = true;
      return s;
    },
    setSettings: function(s) { return this.set('cfg', s); },

    getCurrentEmail: function() {
      var ems = this.getEmails();
      if (!ems.length) return '';
      var st = this.getState();
      if (st.cur && ems.indexOf(st.cur) !== -1) return st.cur;
      for (var i = 0; i < ems.length; i++) {
        if (st.done.indexOf(ems[i]) === -1 && st.skip.indexOf(ems[i]) === -1) {
          st.cur = ems[i];
          this.setState(st);
          return st.cur;
        }
      }
      return ems[0];
    },

    addRecord: function(username, key) {
      if (!key || typeof key !== 'string' || key.trim().length < 8) return this.getCSV();
      var u = (username || '').trim();
      var k = key.trim();
      var records = this.getCSV();
      var exists = records.some(function(r) {
        return (r.a === u || r.columnA === u) && (r.c === k || r.columnC === k);
      });
      if (!exists) {
        records.unshift({
          a: u,
          columnA: u,
          c: k,
          columnC: k,
          time: new Date().toLocaleTimeString()
        });
        this.setCSV(records);
      }
      return records;
    }
  };

  // Sync extensionEnabled from chrome.storage if changed in popup
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener(function(changes, area) {
      if (area === 'local' && changes.extensionEnabled) {
        var en = changes.extensionEnabled.newValue !== false;
        Store.set('en', en);
        updatePowerUI(en);
      }
    });
  }

  /* ========== 2. TOAST NOTIFICATION ========= */
  function toast(m, c) {
    if (!isTopFrame) return;
    var t = document.getElementById('__ig_t');
    if (!t) {
      t = document.createElement('div');
      t.id = '__ig_t';
      t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(12px);background:rgba(18,18,26,0.94);color:#fff;padding:8px 20px;border-radius:30px;font-size:12px;font-weight:700;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,sans-serif;transition:opacity 0.22s ease, transform 0.22s cubic-bezier(0.16,1,0.3,1);opacity:0;pointer-events:none;box-shadow:0 8px 30px rgba(0,0,0,0.65);border:1px solid rgba(255,255,255,0.15);white-space:nowrap;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);display:flex;align-items:center;gap:8px;';
      document.body.appendChild(t);
    }
    t.textContent = m;
    if (c) {
      t.style.borderColor = c;
      t.style.boxShadow = '0 8px 30px rgba(0,0,0,0.65), 0 0 16px ' + c + '55';
    } else {
      t.style.borderColor = 'rgba(255,255,255,0.15)';
      t.style.boxShadow = '0 8px 30px rgba(0,0,0,0.65)';
    }
    clearTimeout(t._t);
    requestAnimationFrame(function() {
      t.style.opacity = '1';
      t.style.transform = 'translateX(-50%) translateY(0)';
    });
    t._t = setTimeout(function() {
      t.style.opacity = '0';
      t.style.transform = 'translateX(-50%) translateY(12px)';
    }, 2200);
  }

  function esc(s) {
    var d = document.createElement('div');
    d.textContent = s || '';
    return d.innerHTML;
  }

  function safeCopy(text, successMsg) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function() {
        toast(successMsg || 'Copied to clipboard!', '#8b5cf6');
      }).catch(function() {
        fallbackCopy(text, successMsg);
      });
    } else {
      fallbackCopy(text, successMsg);
    }
  }

  function fallbackCopy(text, successMsg) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      toast(successMsg || 'Copied to clipboard!', '#8b5cf6');
    } catch(e) {
      toast('Failed to copy', '#ef4444');
    }
  }

  /* ========== 3. NATIVE MOBILE TOUCH & CLICK DISPATCHER ========= */
  function makeTouch(el, x, y) {
    if (typeof Touch !== 'undefined') {
      try {
        return new Touch({
          identifier: Math.floor(Math.random() * 100000) + 1,
          target: el,
          clientX: x,
          clientY: y,
          screenX: x,
          screenY: y,
          pageX: x + (window.scrollX || 0),
          pageY: y + (window.scrollY || 0)
        });
      } catch(e) {}
    }
    if (document.createTouch) {
      try {
        return document.createTouch(window, el, Date.now(), x, y, x, y);
      } catch(e) {}
    }
    return {
      target: el,
      clientX: x,
      clientY: y,
      screenX: x,
      screenY: y,
      pageX: x + (window.scrollX || 0),
      pageY: y + (window.scrollY || 0)
    };
  }

  function dispatchTouchEvent(type, el, touch) {
    var touches = (type === 'touchend' || type === 'touchcancel') ? [] : [touch];
    if (typeof TouchEvent !== 'undefined') {
      try {
        var evt = new TouchEvent(type, {
          bubbles: true,
          cancelable: true,
          composed: true,
          view: window,
          touches: touches,
          targetTouches: touches,
          changedTouches: [touch]
        });
        el.dispatchEvent(evt);
        return true;
      } catch(e) {}
    }
    try {
      var uevt = document.createEvent('UIEvent');
      uevt.initUIEvent(type, true, true, window, 1);
      uevt.touches = touches;
      uevt.targetTouches = touches;
      uevt.changedTouches = [touch];
      el.dispatchEvent(uevt);
      return true;
    } catch(e) {}
    return false;
  }

  function triggerRealTouchAndClick(el) {
    if (!el) return false;

    try {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch(e) {}

    var rect = el.getBoundingClientRect();
    var cx = rect.width > 0 ? (rect.left + rect.width / 2) : (window.innerWidth / 2);
    var cy = rect.height > 0 ? (rect.top + rect.height / 2) : (window.innerHeight / 2);

    var pointerOpts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: cx,
      clientY: cy,
      screenX: cx,
      screenY: cy,
      pointerId: 1,
      pointerType: 'touch',
      isPrimary: true,
      width: 24,
      height: 24,
      pressure: 0.5
    };

    var mouseOpts = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: cx,
      clientY: cy,
      screenX: cx,
      screenY: cy,
      button: 0,
      buttons: 1
    };

    // 1. Pointer over & enter
    if (window.PointerEvent) {
      try { el.dispatchEvent(new PointerEvent('pointerover', pointerOpts)); } catch(e){}
      try { el.dispatchEvent(new PointerEvent('pointerenter', pointerOpts)); } catch(e){}
      try { el.dispatchEvent(new PointerEvent('pointerdown', pointerOpts)); } catch(e){}
    }

    // 2. Real Touch start
    var touch = makeTouch(el, cx, cy);
    dispatchTouchEvent('touchstart', el, touch);

    // 3. Mouse down
    try { el.dispatchEvent(new MouseEvent('mousedown', mouseOpts)); } catch(e){}

    // 4. Release touch & pointer
    if (window.PointerEvent) {
      try { el.dispatchEvent(new PointerEvent('pointerup', pointerOpts)); } catch(e){}
    }
    dispatchTouchEvent('touchend', el, touch);

    mouseOpts.buttons = 0;
    try { el.dispatchEvent(new MouseEvent('mouseup', mouseOpts)); } catch(e){}
    try { el.dispatchEvent(new MouseEvent('click', mouseOpts)); } catch(e){}

    if (typeof el.click === 'function') {
      try { el.click(); } catch(e){}
    }

    return true;
  }

  /* ========== 4. BULLETPROOF REACT INPUT VALUE SETTER ========= */
  function setReactInputValue(input, val) {
    if (!input) return false;
    try {
      input.focus();
      var descriptor = Object.getOwnPropertyDescriptor(input, 'value');
      var prototype = Object.getPrototypeOf(input);
      var protoDescriptor = Object.getOwnPropertyDescriptor(prototype, 'value');

      if (protoDescriptor && protoDescriptor.set && descriptor !== protoDescriptor) {
        protoDescriptor.set.call(input, val);
      } else if (descriptor && descriptor.set) {
        descriptor.set.call(input, val);
      } else {
        input.value = val;
      }

      var tracker = input._valueTracker;
      if (tracker) {
        tracker.setValue(val + '_diff');
      }

      input.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
      input.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
      return true;
    } catch(e) {
      input.value = val;
      try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch(err) {}
      return true;
    }
  }

  
  /* ========== 4B. ACCOUNT CREATION & INPUT DISCOVERY HELPERS ========== */
  function findEmailInputField() {
    var selectors = [
      'input[name="email"]',
      'input[type="email"]',
      'input[name="emailOrPhone"]',
      'input[aria-label*="email" i]',
      'input[placeholder*="email" i]'
    ];
    for (var i = 0; i < selectors.length; i++) {
      var el = document.querySelector(selectors[i]);
      if (el && !isExtensionElement(el) && isVisible(el)) return el;
    }
    return null;
  }

  function findPasswordInputField() {
    var selectors = [
      'input[name="password"]',
      'input[type="password"]',
      'input[aria-label*="password" i]',
      'input[placeholder*="password" i]'
    ];
    for (var i = 0; i < selectors.length; i++) {
      var el = document.querySelector(selectors[i]);
      if (el && !isExtensionElement(el) && isVisible(el)) return el;
    }
    return null;
  }

  function findNextOrSubmitButton() {
    var submit = document.querySelector('form button[type="submit"]') || document.querySelector('button[type="submit"]');
    if (submit && !isExtensionElement(submit) && isVisible(submit)) return submit;

    var allBtns = document.querySelectorAll('button, [role="button"], div[tabindex="0"]');
    for (var i = 0; i < allBtns.length; i++) {
      if (isExtensionElement(allBtns[i])) continue;
      var txt = (allBtns[i].textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (txt === 'next' || txt === 'sign up' || txt === 'continue' || txt === 'log in' || txt === 'login') {
        if (isVisible(allBtns[i])) return allBtns[i];
      }
    }
    return null;
  }

  function quickFillActiveField() {
    var active = document.activeElement;
    var curEm = Store.getCurrentEmail();
    var curPw = Store.getPass();

    // 1. If an input is currently focused
    if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA') && !isExtensionElement(active)) {
      var type = (active.type || '').toLowerCase();
      var name = (active.name || '').toLowerCase();
      if (type === 'password' || name.includes('password')) {
        if (curPw) {
          setReactInputValue(active, curPw);
          toast('🔑 Password filled!', '#10b981');
          return true;
        }
      } else {
        if (curEm) {
          setReactInputValue(active, curEm);
          toast('📧 Email filled!', '#10b981');
          return true;
        }
      }
    }

    // 2. If password field exists on page
    var pwField = findPasswordInputField();
    if (pwField && curPw && (!pwField.value || pwField.value !== curPw)) {
      setReactInputValue(pwField, curPw);
      toast('🔑 Password filled!', '#10b981');
      return true;
    }

    // 3. If email field exists on page
    var emField = findEmailInputField();
    if (emField && curEm && (!emField.value || emField.value !== curEm)) {
      setReactInputValue(emField, curEm);
      toast('📧 Email filled!', '#10b981');
      return true;
    }

    toast('⚠️ No matching input field', '#f59e0b');
    return false;
  }

  /* ========== 5. TEXT-BASED BUTTON FINDER: "LOG IN" (Screenshot 2) ========= */
  function isExtensionElement(el) {
    if (!el) return false;
    try {
      if (el.nodeType === Node.TEXT_NODE) el = el.parentElement;
      if (!el || !el.closest) return false;
      return !!el.closest('#IG_POPUP_PAN, #IG_FLOAT_BTN, #IG_MINI_PILL, #IG_OVERLAY_BG, #__ig_t');
    } catch(e) {
      return false;
    }
  }

  function isVisible(el) {
    if (!el) return false;
    try {
      if (isExtensionElement(el)) return false;
      if (el.offsetParent !== null) return true;
      var r = el.getBoundingClientRect();
      return (r.width > 0 && r.height > 0);
    } catch(e) {
      return true;
    }
  }

  function findLoginButtonByText() {
    var formSubmitBtn = document.querySelector('form button[type="submit"]') ||
                        document.querySelector('form button') ||
                        document.querySelector('button[type="submit"]');
    if (formSubmitBtn && !isExtensionElement(formSubmitBtn) && isVisible(formSubmitBtn)) {
      return { button: formSubmitBtn, textEl: formSubmitBtn };
    }

    try {
      var walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT, null, false);
      var node;
      while ((node = walker.nextNode())) {
        if (isExtensionElement(node)) continue;
        var val = (node.nodeValue || '').replace(/\s+/g, ' ').trim();
        if (/^log\s*in$/i.test(val) || /^login$/i.test(val)) {
          var textEl = node.parentElement;
          if (textEl && !isExtensionElement(textEl)) {
            var btnEl = textEl.closest('button, [role="button"], div[tabindex]') || textEl;
            if (!isExtensionElement(btnEl)) {
              return { button: btnEl, textEl: textEl };
            }
          }
        }
      }
    } catch(e) {}

    var allBtns = document.querySelectorAll('button, [role="button"], div[tabindex="0"]');
    for (var i = 0; i < allBtns.length; i++) {
      if (isExtensionElement(allBtns[i])) continue;
      var txt = (allBtns[i].textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (txt === 'log in' || txt === 'login') {
        return { button: allBtns[i], textEl: allBtns[i] };
      }
    }

    return null;
  }

  /* ========== 6. TEXT-BASED CARD FINDER: "META HORIZON" (Screenshot 1) ========= */
  function findCardContainerFromChild(node) {
    if (!node || node === document.body) return null;
    if (isExtensionElement(node)) return null;
    var curr = node;
    var best = node;

    while (curr && curr !== document.body && curr !== document.documentElement) {
      if (isExtensionElement(curr)) return null;
      var txt = (curr.textContent || '').replace(/\s+/g, ' ');

      if (/no instagram account found|the login info you entered|find account/i.test(txt)) {
        break;
      }

      best = curr;

      var isRoleBtn = curr.getAttribute('role') === 'button' || curr.getAttribute('tabindex') !== null;
      var hasRadius = false;
      try {
        var cs = window.getComputedStyle(curr);
        var br = parseFloat(cs.borderRadius) || 0;
        if (br >= 6) hasRadius = true;
      } catch(e) {}

      if ((isRoleBtn || hasRadius) && curr.children.length >= 2) {
        return curr;
      }

      curr = curr.parentElement;
    }

    return best;
  }

  function findMetaHorizonByText() {
    var rootDocs = [document];
    try {
      var iframes = document.querySelectorAll('iframe');
      for (var f = 0; f < iframes.length; f++) {
        try {
          if (iframes[f].contentDocument) {
            rootDocs.push(iframes[f].contentDocument);
          }
        } catch(e) {}
      }
    } catch(e) {}

    for (var d = 0; d < rootDocs.length; d++) {
      var doc = rootDocs[d];

      try {
        var walker = doc.createTreeWalker(doc.body || doc.documentElement, NodeFilter.SHOW_TEXT, null, false);
        var node;
        while ((node = walker.nextNode())) {
          if (isExtensionElement(node)) continue;
          var val = (node.nodeValue || '').replace(/\s+/g, ' ').trim();
          if (/horizon/i.test(val) && val.length < 50) {
            var textEl = node.parentElement;
            if (isExtensionElement(textEl)) continue;
            var card = findCardContainerFromChild(textEl) || textEl;
            if (isExtensionElement(card)) continue;
            return { card: card, textEl: textEl, doc: doc };
          }
        }
      } catch(e) {}

      try {
        var walker2 = doc.createTreeWalker(doc.body || doc.documentElement, NodeFilter.SHOW_TEXT, null, false);
        var node2;
        while ((node2 = walker2.nextNode())) {
          if (isExtensionElement(node2)) continue;
          var val2 = (node2.nodeValue || '').replace(/\s+/g, ' ').trim();
          if (/imran/i.test(val2) && val2.length < 50) {
            var nameEl = node2.parentElement;
            if (isExtensionElement(nameEl)) continue;
            var card2 = findCardContainerFromChild(nameEl) || nameEl;
            if (isExtensionElement(card2)) continue;
            return { card: card2, textEl: nameEl, doc: doc };
          }
        }
      } catch(e) {}

      var all = doc.querySelectorAll('*');
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        if (isExtensionElement(el)) continue;
        var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
        if (/^or$/i.test(t) && el.children.length === 0) {
          var p = el;
          while (p && p !== doc.body) {
            var sib = p.nextElementSibling;
            if (sib && !isExtensionElement(sib)) {
              var sTxt = (sib.textContent || '').replace(/\s+/g, ' ');
              if (/horizon|imran|meta/i.test(sTxt) || sib.querySelector('svg, img, [role="button"]')) {
                var c = findCardContainerFromChild(sib) || sib;
                if (!isExtensionElement(c)) {
                  return { card: c, textEl: sib, doc: doc };
                }
              }
            }
            p = p.parentElement;
          }
        }
      }

      var dialog = doc.querySelector('[role="dialog"], div[aria-modal="true"], div[style*="fixed"]');
      if (dialog && !isExtensionElement(dialog)) {
        var dTxt = (dialog.textContent || '').replace(/\s+/g, ' ');
        if (/no instagram account found|matched an existing meta account/i.test(dTxt)) {
          var inside = dialog.querySelectorAll('*');
          for (var k = 0; k < inside.length; k++) {
            if (isExtensionElement(inside[k])) continue;
            var it = (inside[k].textContent || '').replace(/\s+/g, ' ').trim();
            if (/horizon/i.test(it) && it.length < 60) {
              var card3 = findCardContainerFromChild(inside[k]) || inside[k];
              if (!isExtensionElement(card3)) {
                return { card: card3, textEl: inside[k], doc: doc };
              }
            }
          }
        }
      }
    }

    return null;
  }

  /* ========== 7. UNSTOPPABLE LOGIN SUBMISSION (STEP 1) ========= */
  var lastLoginClickToast = 0;

  function clickLoginButton() {
    var found = findLoginButtonByText();
    if (!found) return false;

    var btnEl = found.button;
    var textEl = found.textEl;
    var form = btnEl.closest('form') || document.querySelector('form');

    try {
      btnEl.disabled = false;
      btnEl.removeAttribute('disabled');
      btnEl.setAttribute('aria-disabled', 'false');
    } catch(e) {}

    try {
      btnEl.style.outline = '3px solid #2563eb';
      btnEl.style.boxShadow = '0 0 16px rgba(37, 99, 235, 0.8)';
    } catch(e) {}

    console.log('[IG Auto] Step 1: Submitting "Log in" button...', btnEl);

    triggerRealTouchAndClick(textEl);
    if (btnEl !== textEl) {
      triggerRealTouchAndClick(btnEl);
    }

    if (typeof btnEl.click === 'function') {
      try { btnEl.click(); } catch(e) {}
    }

    if (form) {
      try {
        if (typeof form.requestSubmit === 'function') {
          try {
            form.requestSubmit(btnEl);
          } catch(err1) {
            form.requestSubmit();
          }
        } else {
          form.submit();
        }
      } catch(e) {
        try { form.submit(); } catch(err2) {}
      }
    }

    if (Date.now() - lastLoginClickToast > 4000) {
      lastLoginClickToast = Date.now();
      toast('✔ Step 1 Completed: "Log in" submitted!', '#10b981');
    }

    return true;
  }

  /* ========== 8. CLICK HANDLER: "META HORIZON" CARD (STEP 2) ========= */
  var lastMetaClickToast = 0;

  function clickMetaHorizonCard(metaInfo) {
    var info = metaInfo || findMetaHorizonByText();
    if (!info || !info.card) return false;

    var card = info.card;
    var textEl = info.textEl;

    try {
      card.classList.add('ig-detected-card-pulse');
      card.style.outline = '3px solid #10b981';
      card.style.outlineOffset = '2px';
      card.style.boxShadow = '0 0 25px rgba(16, 185, 129, 0.9)';
    } catch(e) {}

    var targets = [card];
    if (textEl && targets.indexOf(textEl) === -1) {
      targets.push(textEl);
    }

    try {
      var inner = card.querySelectorAll('[role="button"], button, a, svg, div[tabindex]');
      for (var i = 0; i < inner.length; i++) {
        targets.push(inner[i]);
      }
      for (var c = 0; c < card.children.length; c++) {
        targets.push(card.children[c]);
      }
    } catch(e) {}

    console.log('[IG Auto] Step 2: Clicking Meta Horizon with ' + targets.length + ' targets...', card);

    targets.forEach(function(el, idx) {
      setTimeout(function() {
        triggerRealTouchAndClick(el);
      }, idx * 20);
    });

    if (Date.now() - lastMetaClickToast > 4000) {
      lastMetaClickToast = Date.now();
      toast('✔ Step 2 Completed: "Meta Horizon" selected!', '#10b981');
    }

    return true;
  }

  /* ========== 9. SEQUENTIAL FLOW: STEP 1 ➔ STEP 2 ========== */
  var sequentialWatcherTimer = null;
  var metaClickCount = 0;

  function startSequentialWatcher() {
    if (sequentialWatcherTimer) clearInterval(sequentialWatcherTimer);
    metaClickCount = 0;

    var startTime = Date.now();
    var maxWait = 25000;

    sequentialWatcherTimer = setInterval(function() {
      if (Date.now() - startTime > maxWait) {
        clearInterval(sequentialWatcherTimer);
        sequentialWatcherTimer = null;
        return;
      }

      var info = findMetaHorizonByText();
      if (info && info.card && isVisible(info.card)) {
        metaClickCount++;
        clickMetaHorizonCard(info);

        if (metaClickCount >= 6) {
          clearInterval(sequentialWatcherTimer);
          sequentialWatcherTimer = null;
        }
      } else {
        if (metaClickCount > 0) {
          clearInterval(sequentialWatcherTimer);
          sequentialWatcherTimer = null;
        }
      }
    }, 400);
  }

  function executeSequentialFlow(email, password) {
    var em = email || Store.getCurrentEmail();
    var pw = password || Store.getPass();

    var passField = findPasswordInputField();
    var userField = findEmailInputField() ||
                    document.querySelector('input[name="username"]') ||
                    document.querySelector('input[aria-label*="username" i]') ||
                    document.querySelector('input[aria-label*="phone" i]') ||
                    Array.from(document.querySelectorAll('input[type="text"]')).find(function(el) {
                      var n = (el.getAttribute('name') || '').toLowerCase();
                      var a = (el.getAttribute('aria-label') || '').toLowerCase();
                      var p = (el.getAttribute('placeholder') || '').toLowerCase();
                      if (n.includes('name') && !n.includes('user')) return false;
                      if (a.includes('name') && !a.includes('user')) return false;
                      if (p.includes('name') && !p.includes('user')) return false;
                      return isVisible(el);
                    });

    if (userField && em && (!userField.value || userField.value !== em)) {
      setReactInputValue(userField, em);
    }
    if (passField && pw && (!passField.value || passField.value !== pw)) {
      setReactInputValue(passField, pw);
    }

    var alreadyMeta = findMetaHorizonByText();
    if (alreadyMeta && alreadyMeta.card && isVisible(alreadyMeta.card)) {
      clickMetaHorizonCard(alreadyMeta);
      startSequentialWatcher();
      return true;
    }

    setTimeout(function() {
      var clicked = clickLoginButton();
      if (!clicked) {
        toast('⚠️ "Log in" button not found', '#f59e0b');
      }

      var cfg = Store.getSettings();
      if (cfg.autoMetaHorizon !== false) {
        setTimeout(function() {
          startSequentialWatcher();
        }, 500);
      }
    }, 450);

    return true;
  }

  function startAutomationFlow() {
    var emInput = document.getElementById('IG_EMS');
    var pwInput = document.getElementById('IG_PW');
    if (emInput) Store.set('em', emInput.value);
    if (pwInput) Store.set('pw', pwInput.value);
    Store.setOn(true);
    updatePowerUI(true);

    var curEmail = Store.getCurrentEmail();
    var passVal = Store.getPass();

    if (!curEmail) {
      toast('⚠️ Enter email first', '#f59e0b');
      return false;
    }

    closePan();
    toast('🚀 Automation Started', '#8b5cf6');

    executeSequentialFlow(curEmail, passVal);
    return true;
  }

  /* ========== 10. ENHANCED 2FA KEY SCANNER ========= */
  function scanPageFor2FAKey() {
    // 1. Inputs and code elements
    var codeEls = document.querySelectorAll('code, pre, [data-testid*="key" i], [aria-label*="key" i], input[readonly]');
    for (var i = 0; i < codeEls.length; i++) {
      var t = (codeEls[i].value || codeEls[i].textContent || '').replace(/\s+/g, '').trim().toUpperCase();
      if (/^[A-Z2-7]{16,32}$/.test(t)) {
        return t;
      }
    }

    // 2. Grouped key in text (e.g. ABCD EFGH 1234 5678)
    var allText = document.body ? document.body.textContent : '';
    var grouped = allText.match(/\b([A-Z2-7]{4}\s+[A-Z2-7]{4}\s+[A-Z2-7]{4}\s+[A-Z2-7]{4}(?:\s+[A-Z2-7]{4})*)\b/i);
    if (grouped && grouped[1]) {
      var cleaned = grouped[1].replace(/\s+/g, '').toUpperCase();
      if (cleaned.length >= 16 && cleaned.length <= 32) return cleaned;
    }

    // 3. Standalone Base32 key
    var standalone = allText.match(/\b([A-Z2-7]{16,32})\b/);
    if (standalone && standalone[1]) {
      var cand = standalone[1].toUpperCase();
      var knownWords = ['AUTHENTICATION', 'SECURITYSETTINGS', 'CONFIDENTIALITY', 'TWOFACTORAUTHENTICATION'];
      if (knownWords.indexOf(cand) === -1) {
        return cand;
      }
    }
    return null;
  }

  /* ========== REFS & STATE ========= */
  var btn = null;
  var pan = null;
  var ovr = null;
  var miniPill = null;
  var open = false;
  var lastOpenTime = 0;
  var lastToggleTime = 0;

  function updatePowerUI(en) {
    var tr = document.getElementById('IG_PWR');
    var th = document.querySelector('#IG_PWR span');
    var st = document.getElementById('IG_STS');
    if (tr) tr.style.background = en ? '#16a34a' : '#4b5563';
    if (th) {
      th.style.left = en ? '25px' : '2px';
      th.textContent = en ? '✓' : '✕';
      th.style.color = en ? '#16a34a' : '#9ca3af';
    }
    if (st) {
      st.style.background = en ? 'rgba(34,197,94,0.14)' : 'rgba(239,68,68,0.14)';
      st.style.color = en ? '#4ade80' : '#fca5a5';
      st.textContent = en ? 'ACTIVE' : 'OFF';
    }
  }

  /* ========== 11. FLOATING LAUNCH BUTTON (SEPARATE DRAG & TAP) ========== */
  var lastDragEndTime = 0;

  function createButton() {
    if (!isTopFrame) return null;

    var existing = document.getElementById('IG_FLOAT_BTN');
    if (existing) {
      btn = existing;
      if (open || (miniPill && miniPill.style.display === 'flex')) {
        btn.style.setProperty('display', 'none', 'important');
      } else {
        btn.style.setProperty('display', Store.isOn() ? 'flex' : 'none', 'important');
      }
      return existing;
    }

    var host = window.location.hostname.toLowerCase();
    if (!host.includes('instagram') && !host.includes('meta.com')) {
      return null;
    }

    btn = document.createElement('div');
    btn.id = 'IG_FLOAT_BTN';

    var count = Store.getCSV().length;

    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="white" width="26" height="26" style="pointer-events:none"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg><span id="IG_BADGE" style="position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;background:#16a34a;color:white;font-size:10px;font-weight:700;border-radius:9px;display:flex;align-items:center;justify-content:center;border:2px solid #111;font-family:sans-serif;"><span>' + count + '</span></span>';

    var pos = Store.getPos();
    var leftVal = (pos && pos.left) ? pos.left : 'calc(100vw - 64px)';
    var topVal = (pos && pos.top) ? pos.top : '220px';

    btn.style.left = leftVal;
    btn.style.top = topVal;

    if (open || (miniPill && miniPill.style.display === 'flex')) {
      btn.style.setProperty('display', 'none', 'important');
    } else {
      btn.style.setProperty('display', Store.isOn() ? 'flex' : 'none', 'important');
    }

    document.body.appendChild(btn);

    setupButtonDragAndTap(btn);
    return btn;
  }

  /* ========== 12. MINIMIZED FLOATING PILL ========== */
  function createMiniPill() {
    if (!isTopFrame) return null;

    if (document.getElementById('IG_MINI_PILL')) {
      miniPill = document.getElementById('IG_MINI_PILL');
      return miniPill;
    }

    miniPill = document.createElement('div');
    miniPill.id = 'IG_MINI_PILL';
    miniPill.innerHTML = '<span style="color:#fbbf24">⚡</span><span id="IG_PILL_TXT">IG Pro Active</span><span style="font-size:10px;opacity:0.6;margin-left:4px">↗ Expand</span>';

    document.body.appendChild(miniPill);

    miniPill.onclick = function(e) {
      if (e) e.stopPropagation();
      miniPill.style.display = 'none';
      showPan();
    };

    return miniPill;
  }

      /* ========== 13. ULTRA-SMOOTH NATIVE DRAG & 0MS INSTANT TAP ========== */
  function setupButtonDragAndTap(element) {
    if (!element) return;
    
    var sx = 0, sy = 0, il = 0, it = 0;
    var drag = false, moved = false;
    var lastTapTime = 0;
    
    function down(e) {
      if (e.type === 'mousedown' && e.button !== 0) return;
      var p = e.touches ? e.touches[0] : e;
      sx = p.clientX;
      sy = p.clientY;
      il = element.offsetLeft;
      it = element.offsetTop;
      drag = false;
      moved = false;
      element.style.cursor = 'grabbing';
      element.style.transition = 'none';

      // Attach move & up ONLY when active touch/mouse down occurs!
      window.addEventListener('touchmove', move, { passive: false });
      window.addEventListener('touchend', up, { passive: false });
      window.addEventListener('touchcancel', up, { passive: true });
      window.addEventListener('mousemove', move);
      window.addEventListener('mouseup', up);
    }

    function move(e) {
      var p = e.touches ? e.touches[0] : e;
      var dx = p.clientX - sx;
      var dy = p.clientY - sy;

      if (!moved) {
        // 14px touch-slop threshold: eliminates false drag on thumb taps
        if (Math.hypot(dx, dy) > 14) {
          moved = true;
          drag = true;
        } else {
          return;
        }
      }

      if (drag) {
        if (e.cancelable) e.preventDefault();
        var nl = il + dx;
        var nt = it + dy;
        var maxW = Math.max(0, (window.innerWidth || 360) - 52);
        var maxH = Math.max(0, (window.innerHeight || 640) - 52);
        nl = Math.max(0, Math.min(maxW, nl));
        nt = Math.max(0, Math.min(maxH, nt));
        element.style.left = nl + 'px';
        element.style.top = nt + 'px';
      }
    }

    function up(e) {
      // Immediately detach window listeners so the page has 0 touch-blocking overhead!
      window.removeEventListener('touchmove', move);
      window.removeEventListener('touchend', up);
      window.removeEventListener('touchcancel', up);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);

      element.style.cursor = 'pointer';
      element.style.transition = '';

      if (moved) {
        Store.setPos({ left: element.style.left, top: element.style.top });
        element.dataset.drag = '1';
        setTimeout(function() {
          if (element) delete element.dataset.drag;
        }, 400);
      } else {
        // Stationary tap: open panel INSTANTLY with 0ms delay!
        lastTapTime = Date.now();
        if (e && e.cancelable) e.preventDefault();
        showPan();
      }
      drag = false;
      moved = false;
    }
    
    element.addEventListener('mousedown', down);
    element.addEventListener('touchstart', down, { passive: true });

    element.onclick = function(e) {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      if (Date.now() - lastTapTime < 450 || element.dataset.drag === '1' || moved) {
        return false;
      }
      lastTapTime = Date.now();
      showPan();
      return false;
    };
  }

  
    /* ========== 13B. ADAPTIVE KEYBOARD & VIEWPORT DOCKING ========== */
  function updateViewportAdaptation() {
    if (!isTopFrame || !pan) return;

    var vv = window.visualViewport;
    var winH = window.innerHeight || (document.documentElement ? document.documentElement.clientHeight : 800);
    var visibleH = vv ? vv.height : winH;
    var offsetTop = (vv && vv.offsetTop) ? vv.offsetTop : 0;

    var bottomOcclusion = Math.max(0, winH - (visibleH + offsetTop));
    var activeEl = document.activeElement;
    var activeTag = activeEl ? (activeEl.tagName || '').toLowerCase() : '';
    var isInputActive = (activeTag === 'input' || activeTag === 'textarea' || (activeEl && activeEl.isContentEditable));
    var isKeyboardOpen = (bottomOcclusion > 90) || (isInputActive && bottomOcclusion > 40);

    if (isKeyboardOpen) {
      // Keyboard is open: Dock at top of screen and scale height so page is visible!
      pan.style.setProperty('top', '8px', 'important');
      pan.style.setProperty('bottom', 'auto', 'important');
      var maxH = Math.max(160, Math.round(visibleH - 18));
      pan.style.setProperty('max-height', maxH + 'px', 'important');

      if (miniPill) {
        miniPill.style.setProperty('top', '8px', 'important');
        miniPill.style.setProperty('bottom', 'auto', 'important');
      }
    } else {
      // Normal state: Dock at bottom
      pan.style.setProperty('top', 'auto', 'important');
      pan.style.setProperty('bottom', '14px', 'important');
      pan.style.setProperty('max-height', 'min(580px, 84vh)', 'important');

      if (miniPill) {
        miniPill.style.setProperty('top', 'auto', 'important');
        miniPill.style.setProperty('bottom', '20px', 'important');
      }
    }
  }

  function ensureInteractiveWidgetMeta() {
    try {
      var meta = document.querySelector('meta[name="viewport"]');
      if (meta) {
        var c = meta.getAttribute('content') || '';
        if (!c.includes('interactive-widget')) {
          meta.setAttribute('content', c + ', interactive-widget=resizes-content');
        }
      } else {
        var m = document.createElement('meta');
        m.name = 'viewport';
        m.content = 'width=device-width, initial-scale=1.0, interactive-widget=resizes-content';
        document.head.appendChild(m);
      }
    } catch(e) {}
  }

  var isViewportTrackingInit = false;
  var vpThrottleTimer = null;

  function scheduleViewportAdaptation() {
    if (vpThrottleTimer) return;
    vpThrottleTimer = setTimeout(function() {
      vpThrottleTimer = null;
      updateViewportAdaptation();
    }, 60);
  }

  function initViewportTracking() {
    if (!isTopFrame || isViewportTrackingInit) return;
    isViewportTrackingInit = true;

    // 1. Visual Viewport events - ONLY resize (NEVER scroll to prevent high CPU load!)
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', scheduleViewportAdaptation, { passive: true });
    }

    // 2. Standard window resize & orientation change
    window.addEventListener('resize', scheduleViewportAdaptation, { passive: true });
    window.addEventListener('orientationchange', function() {
      setTimeout(scheduleViewportAdaptation, 120);
    }, { passive: true });

    // 3. Focus / Blur events to catch keyboard open/close transitions smoothly
    document.addEventListener('focusin', function(e) {
      scheduleViewportAdaptation();
      setTimeout(scheduleViewportAdaptation, 180);

      // If focused inside our popup, ensure it is scrolled into view inside the panel
      if (e.target && pan && pan.contains(e.target)) {
        setTimeout(function() {
          try {
            if (typeof e.target.scrollIntoView === 'function') {
              e.target.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
          } catch(err) {}
        }, 220);
      }
    }, true);

    document.addEventListener('focusout', function() {
      setTimeout(scheduleViewportAdaptation, 150);
    }, true);
  }

  /* ========== 14. POPUP WINDOW PANEL CREATION (EXACT SCREENSHOT 3-TAB UI) ========== */
  function createPanel() {
    if (!isTopFrame) return null;
    ensureStylesInjected();

    if (document.getElementById('IG_POPUP_PAN')) {
      pan = document.getElementById('IG_POPUP_PAN');
      return pan;
    }

    var en = Store.isOn();
    var ems = (Store.get('em', '') || '').split(/\r?\n/).map(function(e) { return e.trim(); }).filter(Boolean).join('\n');
    var pw = Store.getPass();
    var curEmail = Store.getCurrentEmail();
    var emsList = Store.getEmails();
    var curIndex = emsList.indexOf(curEmail) + 1;
    var totalEmails = emsList.length;
    var cfg = Store.getSettings();

    ovr = document.getElementById('IG_OVERLAY_BG');
    if (!ovr) {
      ovr = document.createElement('div');
      ovr.id = 'IG_OVERLAY_BG';
      // Handled in handleOverlayClick with 600ms guard
      ovr.onclick = handleOverlayClick;
      ovr.ontouchend = handleOverlayClick;
      document.body.appendChild(ovr);
    }

    pan = document.createElement('div');
    pan.id = 'IG_POPUP_PAN';
    pan.onclick = function(e) { if (e) e.stopPropagation(); };
    pan.ontouchend = function(e) { if (e) e.stopPropagation(); };

    pan.innerHTML = [
      // HEADER
      '<div id="IG_POPUP_HEADER" style="display:flex;justify-content:space-between;align-items:center;padding:9px 12px;border-bottom:1px solid rgba(255,255,255,0.08);background:#14141c;user-select:none;-webkit-user-select:none">',
        '<div style="display:flex;align-items:center;gap:8px">',
          '<div style="width:26px;height:26px;border-radius:8px;background:linear-gradient(135deg,#833AB4,#FD1D1D,#F77737);display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(225,48,108,0.35)"><svg viewBox="0 0 24 24" fill="white" width="13" height="13"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069z"/></svg></div>',
          '<div>',
            '<div style="color:#fff;font-size:12px;font-weight:800;letter-spacing:-0.2px">IG 2FA Automation Pro</div>',
            '<div id="IG_SUB_STATUS" style="color:#a1a1b5;font-size:9px">v4.0.0 • Auto-Flow • ' + (totalEmails ? (curIndex || 1) + '/' + totalEmails : 'No Emails') + '</div>',
          '</div>',
        '</div>',
        '<div style="display:flex;align-items:center;gap:6px">',
          '<button id="IG_MINIMIZE" title="Minimize" style="width:24px;height:24px;border-radius:50%;border:none;background:#242430;color:#bbb;font-size:11px;font-weight:bold;cursor:pointer;display:flex;align-items:center;justify-content:center">_</button>',
          '<button id="IG_CLOSE" title="Close" style="width:24px;height:24px;border-radius:50%;border:none;background:#242430;color:#bbb;font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center">✕</button>',
        '</div>',
      '</div>',

      // POWER CARD & PROGRESS TRACK (Exact Screenshot_2026-10-06-13-35-58)
      '<div style="margin:6px 12px 5px;padding:7px 10px;background:rgba(250,204,21,0.04);border-radius:10px;border:1px solid rgba(250,204,21,0.16)">',
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">',
          '<div style="font-size:9px;font-weight:800;color:#fbbf24;letter-spacing:1px">⚡ POWER CONTROL</div>',
          '<div id="IG_STS" style="display:inline-flex;align-items:center;gap:4px;padding:2px 7px;border-radius:8px;font-size:9px;font-weight:700;' + (en ? 'background:rgba(34,197,94,0.14);color:#4ade80' : 'background:rgba(239,68,68,0.14);color:#fca5a5') + '">' + (en ? 'ACTIVE' : 'OFF') + '</div>',
        '</div>',
        '<div style="display:flex;align-items:center;justify-content:space-between">',
          '<button id="IG_PWR" data-on="' + en + '" style="position:relative;display:inline-block;width:46px;height:22px;border-radius:11px;border:none;cursor:pointer;padding:0;background:' + (en ? '#16a34a' : '#4b5563') + ';transition:background 0.2s"><span style="position:absolute;top:2px;' + (en ? 'left:25px' : 'left:2px') + ';width:18px;height:18px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:bold;color:' + (en ? '#16a34a' : '#9ca3af') + ';transition:left 0.2s">' + (en ? '✓' : '✕') + '</span></button>',
          '<div style="flex:1;margin-left:10px;text-align:right">',
            '<div id="IG_CURR_EMAIL_LBL" style="font-size:10px;color:#eee;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:160px">' + esc(curEmail || 'No Active Account') + '</div>',
            '<div id="IG_PROG_TXT" style="font-size:9px;color:#888;margin-top:1px">' + (totalEmails ? 'Acc ' + curIndex + ' of ' + totalEmails : '0 Emails') + '</div>',
          '</div>',
        '</div>',
        '<div style="margin-top:5px;height:3px;background:#252530;border-radius:2px;overflow:hidden">',
          '<div id="IG_PROGRESS_BAR" style="height:100%;width:' + (totalEmails ? Math.round((curIndex / totalEmails) * 100) : 0) + '%;background:linear-gradient(90deg,#833AB4,#FD1D1D,#10b981);transition:width 0.3s"></div>',
        '</div>',
      '</div>',

      // TABS (Exact Screenshot_2026-10-06-13-35-58)
      '<div class="ig-tab-bar">',
        '<button class="ig-tab-btn active" data-tab="auto"><span>⚡</span> Automation</button>',
        '<button class="ig-tab-btn" data-tab="records"><span>🔐</span> Records ( <span id="IG_TAB_CCNT">' + Store.getCSV().length + '</span> )</button>',
        '<button class="ig-tab-btn" data-tab="tools"><span>🛠️</span> Tools</button>',
      '</div>',

      // TAB 1: AUTOMATION
      '<div id="IG_PANE_AUTO" style="display:block;padding-top:7px">',
        // Email Textarea
        '<div class="ig-input-group">',
          '<div class="ig-label"><span>📧 EMAILS (one per line)</span><span id="IG_EMAIL_CNT_BADGE" style="color:#a78bfa;font-size:9px">' + totalEmails + ' loaded</span></div>',
          '<textarea id="IG_EMS" class="ig-textarea" style="height:46px;font-family:monospace;resize:none" placeholder="paste emails here...">' + esc(ems) + '</textarea>',
        '</div>',

        // Password Input
        '<div class="ig-input-group" style="position:relative">',
          '<div class="ig-label"><span>🔑 PASSWORD</span><span>Default</span></div>',
          '<input type="password" id="IG_PW" class="ig-text-input" value="' + esc(pw) + '" placeholder="Enter login password" style="padding-right:30px">',
          '<button type="button" id="IG_SHPW" style="position:absolute;right:20px;top:22px;background:none;border:none;color:#777;cursor:pointer;font-size:12px">👁️</button>',
        '</div>',

        // PRIMARY ACTION BUTTON: Auto-Flow (Exact Screenshot_2026-10-06-13-35-58)
        '<div style="padding:0 12px 5px">',
          '<button id="IG_AUTOFILL_NOW" class="ig-btn ig-btn-primary" style="width:100%;padding:8px 12px;font-size:11px;box-shadow:0 3px 14px rgba(225,48,108,0.35)"><span>⚡</span> Auto-Flow: "Log in" ➔ "Meta Horizon"</button>',
        '</div>',

        // Action Buttons Row: Individual triggers
        '<div style="padding:0 12px 6px;display:flex;gap:6px">',
          '<button id="IG_CLICK_LOGIN_NOW" class="ig-btn" style="flex:1;padding:7px 6px;background:rgba(37,99,235,0.18);border:1px solid #2563eb;color:#93c5fd;font-size:10px"><span>🔵</span> Click "Log in"</button>',
          '<button id="IG_CLICK_META_NOW" class="ig-btn" style="flex:1.4;padding:7px 6px;background:rgba(16,185,129,0.18);border:1px solid #10b981;color:#6ee7b7;font-size:10px"><span>👉</span> Click "Meta Horizon"</button>',
        '</div>',

        // Navigation Row
        '<div style="padding:0 12px 6px;display:flex;gap:6px;align-items:center">',
          '<button id="IG_PREV" class="ig-btn ig-btn-secondary" style="flex:1;padding:6px 6px">⬅️ Prev</button>',
          '<div id="IG_NAV_INDICATOR" style="flex:1.2;text-align:center;font-size:10px;font-weight:700;color:#ccc">' + (totalEmails ? curIndex + ' / ' + totalEmails : '0 / 0') + '</div>',
          '<button id="IG_NEXT" class="ig-btn ig-btn-secondary" style="flex:1;padding:6px 6px">Next ➡️</button>',
          '<button id="IG_SKIP" class="ig-btn ig-btn-warning" style="padding:6px 8px" title="Skip current email">⏭️</button>',
        '</div>',

        // Automation Options Toggles
        '<div style="margin:0 12px 8px;padding:6px 10px;background:#14141c;border-radius:8px;border:1px solid #232330;display:flex;flex-direction:column;gap:5px">',
          '<label style="display:flex;align-items:center;justify-content:space-between;font-size:9px;color:#bbb;cursor:pointer">',
            '<span>🔵 Auto-Click "Log in" Button</span>',
            '<input type="checkbox" id="IG_OPT_SUBMIT"' + (cfg.autoLogin !== false ? ' checked' : '') + ' style="accent-color:#2563eb;cursor:pointer">',
          '</label>',
          '<label style="display:flex;align-items:center;justify-content:space-between;font-size:9px;color:#bbb;cursor:pointer">',
            '<span>👤 Auto-Click "Meta Horizon" Card</span>',
            '<input type="checkbox" id="IG_OPT_META"' + (cfg.autoMetaHorizon !== false ? ' checked' : '') + ' style="accent-color:#10b981;cursor:pointer">',
          '</label>',
        '</div>',
      '</div>',

      // TAB 2: RECORDS
      '<div id="IG_PANE_RECORDS" style="display:none;padding:8px 12px 10px">',
        '<div style="margin-bottom:6px">',
          '<input type="text" id="IG_SEARCH_BOX" class="ig-text-input" placeholder="🔍 Search email or 2FA key..." style="font-size:10px">',
        '</div>',

        '<div style="display:flex;gap:6px;margin-bottom:6px">',
          '<button id="IG_DLCV" class="ig-btn ig-btn-success" style="flex:1;padding:6px 6px;font-size:10px"><span>📥</span> CSV</button>',
          '<button id="IG_COPY_ALL" class="ig-btn ig-btn-secondary" style="flex:1;padding:6px 6px;font-size:10px"><span>📋</span> Copy All</button>',
          '<button id="IG_MANUAL_ADD_TOGGLE" class="ig-btn ig-btn-secondary" style="flex:1;padding:6px 6px;font-size:10px"><span>➕</span> Add</button>',
        '</div>',

        // Inline Add Record Form
        '<div id="IG_ADD_RECORD_BOX" class="ig-inline-box" style="display:none">',
          '<div style="font-size:10px;font-weight:700;color:#a78bfa">➕ Add Record</div>',
          '<input type="text" id="IG_INLINE_USER" class="ig-text-input" placeholder="Username / Email">',
          '<input type="text" id="IG_INLINE_KEY" class="ig-text-input" placeholder="2FA Secret Key">',
          '<div style="display:flex;gap:6px;margin-top:2px">',
            '<button id="IG_INLINE_SAVE_BTN" class="ig-btn ig-btn-success" style="flex:1;padding:5px 6px;font-size:10px">Save</button>',
            '<button id="IG_INLINE_CANCEL_BTN" class="ig-btn ig-btn-secondary" style="flex:1;padding:5px 6px;font-size:10px">Cancel</button>',
          '</div>',
        '</div>',

        '<button id="IG_GRAB_2FA_PAGE" class="ig-btn" style="width:100%;margin-bottom:6px;background:rgba(139,92,246,0.15);border:1px solid rgba(139,92,246,0.3);color:#c4b5fd;font-size:10px;padding:6px 8px">🔍 Snatch 2FA Key from Current Page</button>',

        '<div id="IG_RECORDS_LIST" style="max-height:160px;overflow-y:auto;border-radius:8px"></div>',
      '</div>',

      // TAB 3: TOOLS
      '<div id="IG_PANE_TOOLS" style="display:none;padding:8px 12px 10px">',
        '<div style="display:flex;flex-direction:column;gap:6px">',
          // Inline Bulk Import Box
          '<div id="IG_IMPORT_BOX" class="ig-inline-box" style="display:none">',
            '<div style="font-size:10px;font-weight:700;color:#6ee7b7">📥 Bulk Import (Email:Pass)</div>',
            '<textarea id="IG_IMPORT_TEXTAREA" class="ig-textarea" placeholder="example@gmail.com:pass123&#10;user2@mail.com:pass456" style="height:60px"></textarea>',
            '<div style="display:flex;gap:6px">',
              '<button id="IG_IMPORT_DO_BTN" class="ig-btn ig-btn-success" style="flex:1;padding:5px 6px;font-size:10px">Import</button>',
              '<button id="IG_IMPORT_CANCEL_BTN" class="ig-btn ig-btn-secondary" style="flex:1;padding:5px 6px;font-size:10px">Cancel</button>',
            '</div>',
          '</div>',

          '<button id="IG_TOOL_CLEAR_SESSION" class="ig-btn ig-btn-secondary" style="width:100%;justify-content:flex-start;font-size:10px;padding:6px 8px"><span>🧹</span> Clear Instagram Session / Cookies</button>',
          '<button id="IG_TOOL_IMPORT_BULK" class="ig-btn ig-btn-secondary" style="width:100%;justify-content:flex-start;font-size:10px;padding:6px 8px"><span>📥</span> Bulk Import Accounts (Email:Pass)</button>',
          '<button id="IG_RST" class="ig-btn ig-btn-warning" style="width:100%;justify-content:flex-start;font-size:10px;padding:6px 8px"><span>🔄</span> Reset Progress (Start from Account 1)</button>',
          '<button id="IG_CLRBX" class="ig-btn ig-btn-secondary" style="width:100%;justify-content:flex-start;font-size:10px;padding:6px 8px"><span>🗑️</span> Clear Email & Password Boxes</button>',
          '<button id="IG_DELALL" class="ig-btn ig-btn-danger" style="width:100%;justify-content:flex-start;font-size:10px;padding:6px 8px"><span>💀</span> Delete All Saved 2FA Records</button>',
        '</div>',

        '<div style="margin-top:8px;padding:7px 9px;background:#14141c;border-radius:8px;border:1px solid #232330;font-size:9px;color:#888;line-height:1.4">',
          '💡 <strong>Step-by-Step Automation:</strong><br>',
          '1. Automatically clicks the blue <strong>"Log in"</strong> button.<br>',
          '2. When the popup appears, it detects and clicks <strong>"Meta Horizon"</strong>.',
        '</div>',
      '</div>',

      // FOOTER
      '<div style="text-align:center;padding:6px 12px;border-top:1px solid rgba(255,255,255,0.06);background:#121218;font-size:9px;color:#666">',
        'IG 2FA Automation Pro v4.0.0 • Step-by-Step Auto-Clicker',
      '</div>'
    ].join('');

    document.body.appendChild(pan);

    bindEvents();
    renderRecordsList();
    updateProgressUI();

    return pan;
  }

  /* ========== 15. RENDER RECORDS LIST (EXACT INDEX DELETION) ========== */
  function renderRecordsList(query) {
    var container = document.getElementById('IG_RECORDS_LIST');
    if (!container) return;

    var allRecords = Store.getCSV();
    var displayRecords = allRecords;

    if (query && query.trim()) {
      var q = query.trim().toLowerCase();
      displayRecords = allRecords.filter(function(r) {
        var u = (r.a || r.columnA || '').toLowerCase();
        var k = (r.c || r.columnC || '').toLowerCase();
        return u.includes(q) || k.includes(q);
      });
    }

    if (!displayRecords.length) {
      container.innerHTML = '<div style="padding:12px;text-align:center;color:#666;font-size:10px;background:#14141c;border-radius:8px">📭 ' + (query ? 'No matching records' : 'No 2FA records saved yet') + '</div>';
      return;
    }

    var html = '';
    displayRecords.forEach(function(rec, idx) {
      var origIndex = allRecords.indexOf(rec);
      var user = esc(rec.a || rec.columnA || 'Unknown');
      var key = esc(rec.c || rec.columnC || 'No Key');
      html += [
        '<div class="ig-record-card">',
          '<div style="flex:1;overflow:hidden">',
            '<div style="font-size:10px;font-weight:700;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">#' + (idx + 1) + ' ' + user + '</div>',
            '<div style="display:flex;align-items:center;gap:4px;margin-top:2px">',
              '<span class="ig-record-key">' + key + '</span>',
            '</div>',
          '</div>',
          '<div style="display:flex;align-items:center;gap:4px">',
            '<button class="ig-btn ig-btn-secondary" onclick="window.__COPY_KEY(\'' + key + '\')" style="padding:3px 7px;font-size:10px">📋</button>',
            '<button class="ig-btn ig-btn-danger" onclick="window.__DEL_SINGLE(' + origIndex + ')" style="padding:3px 6px;font-size:10px">✕</button>',
          '</div>',
        '</div>'
      ].join('');
    });

    container.innerHTML = html;
  }

  /* ========== 16. UPDATE PROGRESS UI ========== */
  function updateProgressUI() {
    var ems = Store.getEmails();
    var cur = Store.getCurrentEmail();
    var idx = ems.indexOf(cur) + 1;
    var total = ems.length;
    var count = Store.getCSV().length;

    var sub = document.getElementById('IG_SUB_STATUS');
    if (sub) {
      sub.textContent = 'v4.0.0 • Auto-Flow • ' + (total ? idx + '/' + total : 'No Emails');
    }

    var pillTxt = document.getElementById('IG_PILL_TXT');
    if (pillTxt) {
      pillTxt.textContent = 'Acc ' + (total ? idx + '/' + total : '0');
    }

    var badge = document.getElementById('IG_EMAIL_CNT_BADGE');
    if (badge) {
      badge.textContent = total + ' loaded';
    }

    var curLbl = document.getElementById('IG_CURR_EMAIL_LBL');
    if (curLbl) {
      curLbl.textContent = cur || 'No Active Account';
    }

    var compactEmTxt = document.getElementById('IG_COMPACT_EM_TXT');
    if (compactEmTxt) {
      compactEmTxt.textContent = cur ? (cur.length > 20 ? cur.substring(0, 18) + '...' : cur) : 'Copy Email';
    }

    var progTxt = document.getElementById('IG_PROG_TXT');
    if (progTxt) {
      progTxt.textContent = total ? 'Acc ' + idx + ' of ' + total : '0 Emails';
    }

    var navInd = document.getElementById('IG_NAV_INDICATOR');
    if (navInd) {
      navInd.textContent = total ? idx + ' / ' + total : '0 / 0';
    }

    var progBar = document.getElementById('IG_PROGRESS_BAR');
    if (progBar) {
      var pct = total ? Math.round((idx / total) * 100) : 0;
      progBar.style.width = pct + '%';
    }

    var tabCnt = document.getElementById('IG_TAB_CCNT');
    if (tabCnt) tabCnt.textContent = count;

    var btnBadge = document.querySelector('#IG_BADGE span');
    if (btnBadge) btnBadge.textContent = count;
  }

  /* ========== 17. GLOBAL ACTION HANDLERS ========= */
  window.__COPY_KEY = function(key) {
    safeCopy(key, '📋 2FA Key copied!');
  };

  window.__DEL_SINGLE = function(idx) {
    var records = Store.getCSV();
    if (records[idx]) {
      records.splice(idx, 1);
      Store.setCSV(records);
      renderRecordsList();
      updateProgressUI();
      toast('🗑️ Deleted Record', '#ef4444');
    }
  };

  /* ========== 18. POPUP SHOW / HIDE (ZERO CLICK-THROUGH AUTO-CLOSE) ========== */
  function handleOverlayClick(e) {
    // Crucial: Ignore any overlay clicks within 600ms of opening to block phantom click-through!
    if (Date.now() - lastOpenTime < 600) {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      return false;
    }
    closePan();
  }

  function showPan() {
    if (!pan) createPanel();
    if (miniPill) miniPill.style.display = 'none';

    lastOpenTime = Date.now();
    open = true;

    // Immediately hide floating circular button
    if (btn) {
      btn.style.setProperty('display', 'none', 'important');
    }

    updateViewportAdaptation();

    // Instant show overlay and panel with crisp 0ms delay!
    if (ovr) {
      ovr.style.pointerEvents = 'none';
      ovr.style.display = 'block';
      ovr.style.opacity = '1';
    }

    if (pan) {
      pan.style.pointerEvents = 'auto';
      pan.style.display = 'block';
      pan.style.opacity = '1';
      pan.style.transform = 'translate3d(-50%, 0, 0)';
    }

    setTimeout(function() {
      if (ovr && open) {
        ovr.style.pointerEvents = 'auto';
      }
    }, 350);

    updateProgressUI();
  }

  function closePan() {
    if (!open) return;
    open = false;
    if (ovr) ovr.style.opacity = '0';
    if (pan) {
      pan.style.opacity = '0';
      pan.style.transform = 'translate3d(-50%, 8px, 0)';
    }

    setTimeout(function() {
      if (!open) {
        if (ovr) ovr.style.display = 'none';
        if (pan) pan.style.display = 'none';
        // RE-SHOW FLOATING CIRCULAR BUTTON WHEN MAIN MENU CLOSES!
        if (btn && Store.isOn()) {
          btn.style.setProperty('display', 'flex', 'important');
        }
      }
    }, 120);
  }

  function minimizePan() {
    closePan();
    if (btn) {
      btn.style.setProperty('display', 'none', 'important');
    }
    if (!miniPill) createMiniPill();
    miniPill.style.display = 'flex';
    updateViewportAdaptation();
    toast('↘ Minimized to pill', '#6366f1');
  }

  function toggle() {
    if (Date.now() - lastToggleTime < 450) return;
    lastToggleTime = Date.now();
    if (open) closePan();
    else showPan();
  }

  /* ========== 19. BIND ALL CONTROLS ========== */
  function bindEvents() {
    try {
      var cl = document.getElementById('IG_CLOSE');
      if (cl) cl.onclick = function(e) {
        if (e) e.stopPropagation();
        closePan();
      };

      var min = document.getElementById('IG_MINIMIZE');
      if (min) min.onclick = function(e) {
        if (e) e.stopPropagation();
        minimizePan();
      };



      var tabBtns = document.querySelectorAll('.ig-tab-btn');
      tabBtns.forEach(function(btnEl) {
        btnEl.onclick = function(e) {
          if (e) e.stopPropagation();
          tabBtns.forEach(function(b) { b.classList.remove('active'); });
          btnEl.classList.add('active');
          var tabName = btnEl.getAttribute('data-tab');
          document.getElementById('IG_PANE_AUTO').style.display = (tabName === 'auto' ? 'block' : 'none');
          document.getElementById('IG_PANE_RECORDS').style.display = (tabName === 'records' ? 'block' : 'none');
          document.getElementById('IG_PANE_TOOLS').style.display = (tabName === 'tools' ? 'block' : 'none');
          if (tabName === 'records') renderRecordsList();
        };
      });

      var pw = document.getElementById('IG_PWR');
      function doPwr(e) {
        if (e) e.stopPropagation();
        var n = !Store.isOn();
        Store.setOn(n);
        updatePowerUI(n);
        toast(n ? '🔥 Automation ON' : '💤 Automation OFF', n ? '#16a34a' : '#ef4444');
      }
      if (pw) pw.onclick = doPwr;

      // 1-Click Auto-Flow: "Log in" ➔ "Meta Horizon"
      var autoBtn = document.getElementById('IG_AUTOFILL_NOW');
      if (autoBtn) {
        autoBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          startAutomationFlow();
        };
      }

      // Quick Trigger: Click "Log in" button now
      var loginQuickBtn = document.getElementById('IG_CLICK_LOGIN_NOW');
      if (loginQuickBtn) {
        loginQuickBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          var clicked = clickLoginButton();
          if (!clicked) toast('⚠️ "Log in" button not found', '#f59e0b');
        };
      }

      // Quick Trigger: Click "Meta Horizon" card now
      var metaQuickBtn = document.getElementById('IG_CLICK_META_NOW');
      if (metaQuickBtn) {
        metaQuickBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          var clicked = clickMetaHorizonCard();
          if (clicked) {
            startSequentialWatcher();
          } else {
            toast('⚠️ "Meta Horizon" card not found', '#f59e0b');
          }
        };
      }

      var optSub = document.getElementById('IG_OPT_SUBMIT');
      if (optSub) {
        optSub.onchange = function(e) {
          if (e) e.stopPropagation();
          var cfg = Store.getSettings();
          cfg.autoLogin = optSub.checked;
          Store.setSettings(cfg);
        };
      }

      var optMeta = document.getElementById('IG_OPT_META');
      if (optMeta) {
        optMeta.onchange = function(e) {
          if (e) e.stopPropagation();
          var cfg = Store.getSettings();
          cfg.autoMetaHorizon = optMeta.checked;
          Store.setSettings(cfg);
        };
      }

      var pv = document.getElementById('IG_PREV');
      if (pv) {
        pv.onclick = function(e) {
          if (e) e.stopPropagation();
          var ems = Store.getEmails();
          var st = Store.getState();
          var cur = Store.getCurrentEmail();
          var idx = ems.indexOf(cur);
          if (idx <= 0) return toast('⚠️ First Account', '#f59e0b');
          st.cur = ems[idx - 1];
          Store.setState(st);
          updateProgressUI();
          toast('⬅️ Previous: ' + st.cur, '#3b82f6');
        };
      }

      var nx = document.getElementById('IG_NEXT');
      if (nx) {
        nx.onclick = function(e) {
          if (e) e.stopPropagation();
          var ems = Store.getEmails();
          var st = Store.getState();
          var cur = Store.getCurrentEmail();
          var idx = ems.indexOf(cur);
          if (idx >= ems.length - 1) return toast('⚠️ Last Account', '#f59e0b');
          st.cur = ems[idx + 1];
          Store.setState(st);
          updateProgressUI();
          toast('➡️ Next: ' + st.cur, '#3b82f6');
        };
      }

      var sk = document.getElementById('IG_SKIP');
      if (sk) {
        sk.onclick = function(e) {
          if (e) e.stopPropagation();
          var ems = Store.getEmails();
          var st = Store.getState();
          var cur = Store.getCurrentEmail();
          if (cur && st.skip.indexOf(cur) === -1) {
            st.skip.push(cur);
          }
          var idx = ems.indexOf(cur);
          st.cur = (idx < ems.length - 1) ? ems[idx + 1] : ems[0];
          Store.setState(st);
          updateProgressUI();
          toast('⏭️ Skipped: ' + cur, '#f59e0b');
        };
      }

      var sh = document.getElementById('IG_SHPW');
      if (sh) {
        sh.onclick = function(e) {
          if (e) e.stopPropagation();
          var i = document.getElementById('IG_PW');
          if (i.type === 'password') {
            i.type = 'text';
            sh.textContent = '🙈';
          } else {
            i.type = 'password';
            sh.textContent = '👁️';
          }
        };
      }

      var sBox = document.getElementById('IG_SEARCH_BOX');
      if (sBox) {
        sBox.oninput = function() {
          renderRecordsList(sBox.value);
        };
      }

      var grabBtn = document.getElementById('IG_GRAB_2FA_PAGE');
      if (grabBtn) {
        grabBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          var foundKey = scanPageFor2FAKey();
          if (foundKey) {
            var curEmail = Store.getCurrentEmail() || 'user_' + Date.now();
            Store.addRecord(curEmail, foundKey);

            var st = Store.getState();
            if (st.done.indexOf(curEmail) === -1) st.done.push(curEmail);
            Store.setState(st);

            renderRecordsList();
            updateProgressUI();
            toast('🎉 2FA Key Saved', '#10b981');
          } else {
            toast('⚠️ No 2FA key detected on page yet', '#f59e0b');
          }
        };
      }

      // INLINE ADD RECORD
      var addBox = document.getElementById('IG_ADD_RECORD_BOX');
      var manAddToggle = document.getElementById('IG_MANUAL_ADD_TOGGLE');
      if (manAddToggle && addBox) {
        manAddToggle.onclick = function(e) {
          if (e) e.stopPropagation();
          addBox.style.display = (addBox.style.display === 'none' ? 'flex' : 'none');
          if (addBox.style.display === 'flex') {
            document.getElementById('IG_INLINE_USER').focus();
          }
        };
      }

      var inlineCancelBtn = document.getElementById('IG_INLINE_CANCEL_BTN');
      if (inlineCancelBtn && addBox) {
        inlineCancelBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          addBox.style.display = 'none';
        };
      }

      var inlineSaveBtn = document.getElementById('IG_INLINE_SAVE_BTN');
      if (inlineSaveBtn && addBox) {
        inlineSaveBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          var u = document.getElementById('IG_INLINE_USER').value.trim();
          var k = document.getElementById('IG_INLINE_KEY').value.trim();
          if (!u || !k) {
            return toast('⚠️ Enter username and key', '#f59e0b');
          }
          Store.addRecord(u, k);
          document.getElementById('IG_INLINE_USER').value = '';
          document.getElementById('IG_INLINE_KEY').value = '';
          addBox.style.display = 'none';
          renderRecordsList();
          updateProgressUI();
          toast('✅ Saved Record', '#10b981');
        };
      }

      // COPY ALL
      var cpAll = document.getElementById('IG_COPY_ALL');
      if (cpAll) {
        cpAll.onclick = function(e) {
          if (e) e.stopPropagation();
          var records = Store.getCSV();
          if (!records.length) return toast('⚠️ No records to copy', '#f59e0b');
          var text = records.map(function(r) {
            return (r.a || r.columnA || '') + ':' + (r.c || r.columnC || '');
          }).join('\n');
          safeCopy(text, '📋 Copied all ' + records.length + ' records!');
        };
      }

      // DOWNLOAD CSV
      var dl = document.getElementById('IG_DLCV');
      if (dl) {
        dl.onclick = function(e) {
          if (e) e.stopPropagation();
          var d = Store.getCSV();
          if (!d.length) return toast('⚠️ Records list is empty', '#f59e0b');
          var csv = 'Username,,2FA_Key\r\n';
          d.forEach(function(r) {
            csv += '"' + (r.a || r.columnA || '').replace(/"/g, '""') + '",,"' + (r.c || r.columnC || '').replace(/"/g, '""') + '"\r\n';
          });
          var b = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
          var u = URL.createObjectURL(b);
          var a = document.createElement('a');
          a.href = u;
          a.download = 'IG_2FA_Records_' + Date.now() + '.csv';
          a.click();
          URL.revokeObjectURL(u);
          toast('📥 Downloaded CSV (' + d.length + ')', '#10b981');
        };
      }

      // INLINE BULK IMPORT
      var impBox = document.getElementById('IG_IMPORT_BOX');
      var impToggle = document.getElementById('IG_TOOL_IMPORT_BULK');
      if (impToggle && impBox) {
        impToggle.onclick = function(e) {
          if (e) e.stopPropagation();
          impBox.style.display = (impBox.style.display === 'none' ? 'flex' : 'none');
          if (impBox.style.display === 'flex') {
            document.getElementById('IG_IMPORT_TEXTAREA').focus();
          }
        };
      }

      var impCancelBtn = document.getElementById('IG_IMPORT_CANCEL_BTN');
      if (impCancelBtn && impBox) {
        impCancelBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          impBox.style.display = 'none';
        };
      }

      var impDoBtn = document.getElementById('IG_IMPORT_DO_BTN');
      if (impDoBtn && impBox) {
        impDoBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          var raw = document.getElementById('IG_IMPORT_TEXTAREA').value.trim();
          if (!raw) return toast('⚠️ Please paste account lines', '#f59e0b');
          var lines = raw.split(/\r?\n/);
          var emList = [];
          var lastPass = '';
          lines.forEach(function(line) {
            var parts = line.includes(':') ? line.split(':') : line.split(',');
            if (parts[0] && parts[0].includes('@')) {
              emList.push(parts[0].trim());
              if (parts[1]) lastPass = parts[1].trim();
            }
          });
          if (emList.length) {
            var exist = Store.getEmails();
            var merged = exist.concat(emList).filter(function(v, i, a) { return a.indexOf(v) === i; });
            Store.set('em', merged.join('\n'));
            if (lastPass) Store.set('pw', lastPass);
            document.getElementById('IG_EMS').value = merged.join('\n');
            if (lastPass) document.getElementById('IG_PW').value = lastPass;
            document.getElementById('IG_IMPORT_TEXTAREA').value = '';
            impBox.style.display = 'none';
            updateProgressUI();
            toast('✅ Imported ' + emList.length + ' accounts', '#10b981');
          } else {
            toast('⚠️ No valid emails found in text', '#f59e0b');
          }
        };
      }

      // CLEAR SESSION (TWO-TAP INLINE CONFIRMATION)
      var clearSessBtn = document.getElementById('IG_TOOL_CLEAR_SESSION');
      var clearConfirmTimer = null;
      if (clearSessBtn) {
        clearSessBtn.onclick = function(e) {
          if (e) e.stopPropagation();
          if (!clearSessBtn.dataset.confirming) {
            clearSessBtn.dataset.confirming = '1';
            clearSessBtn.innerHTML = '<span>⚠️</span> <strong>Tap again to Confirm Clear</strong>';
            clearSessBtn.style.background = '#dc2626';
            clearSessBtn.style.color = '#fff';
            clearConfirmTimer = setTimeout(function() {
              delete clearSessBtn.dataset.confirming;
              clearSessBtn.innerHTML = '<span>🧹</span> Clear Instagram Session / Cookies';
              clearSessBtn.style.background = '#1e1e28';
              clearSessBtn.style.color = '#ccc';
            }, 3000);
            return;
          }

          clearTimeout(clearConfirmTimer);
          delete clearSessBtn.dataset.confirming;
          clearSessBtn.innerHTML = '<span>🧹</span> Clearing...';

          if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ action: 'CLEAR_DATA' }, function(res) {
              toast('🧹 Session cleared! Reloading...', '#3b82f6');
              setTimeout(function() { location.href = 'https://www.instagram.com/accounts/login/'; }, 700);
            });
          } else {
            try { sessionStorage.clear(); localStorage.clear(); } catch(err) {}
            toast('🧹 Storage cleared! Reloading...', '#3b82f6');
            setTimeout(function() { location.reload(); }, 700);
          }
        };
      }

      // RESET PROGRESS (TWO-TAP INLINE CONFIRMATION)
      var rs = document.getElementById('IG_RST');
      var resetTimer = null;
      if (rs) {
        rs.onclick = function(e) {
          if (e) e.stopPropagation();
          if (!rs.dataset.confirming) {
            rs.dataset.confirming = '1';
            rs.innerHTML = '<span>⚠️</span> <strong>Tap again to Confirm Reset</strong>';
            rs.style.background = '#b45309';
            resetTimer = setTimeout(function() {
              delete rs.dataset.confirming;
              rs.innerHTML = '<span>🔄</span> Reset Progress (Start from Account 1)';
              rs.style.background = '#d97706';
            }, 3000);
            return;
          }
          clearTimeout(resetTimer);
          delete rs.dataset.confirming;
          rs.innerHTML = '<span>🔄</span> Reset Progress (Start from Account 1)';
          rs.style.background = '#d97706';
          Store.del('st');
          updateProgressUI();
          toast('🔄 Progress Reset', '#f59e0b');
        };
      }

      // CLEAR BOXES (TWO-TAP INLINE CONFIRMATION)
      var cb = document.getElementById('IG_CLRBX');
      var clrTimer = null;
      if (cb) {
        cb.onclick = function(e) {
          if (e) e.stopPropagation();
          if (!cb.dataset.confirming) {
            cb.dataset.confirming = '1';
            cb.innerHTML = '<span>⚠️</span> <strong>Tap again to Clear Inputs</strong>';
            cb.style.background = '#dc2626';
            clrTimer = setTimeout(function() {
              delete cb.dataset.confirming;
              cb.innerHTML = '<span>🗑️</span> Clear Email & Password Boxes';
              cb.style.background = '#1e1e28';
            }, 3000);
            return;
          }
          clearTimeout(clrTimer);
          delete cb.dataset.confirming;
          cb.innerHTML = '<span>🗑️</span> Clear Email & Password Boxes';
          cb.style.background = '#1e1e28';
          Store.del('em');
          Store.del('pw');
          document.getElementById('IG_EMS').value = '';
          document.getElementById('IG_PW').value = '';
          updateProgressUI();
          toast('🗑️ Inputs Cleared', '#f59e0b');
        };
      }

      // DELETE ALL (TWO-TAP INLINE CONFIRMATION)
      var da = document.getElementById('IG_DELALL');
      var delTimer = null;
      if (da) {
        da.onclick = function(e) {
          if (e) e.stopPropagation();
          if (!da.dataset.confirming) {
            da.dataset.confirming = '1';
            da.innerHTML = '<span>💀</span> <strong>Tap again to DELETE ALL RECORDS</strong>';
            delTimer = setTimeout(function() {
              delete da.dataset.confirming;
              da.innerHTML = '<span>💀</span> Delete All Saved 2FA Records';
            }, 3000);
            return;
          }
          clearTimeout(delTimer);
          delete da.dataset.confirming;
          da.innerHTML = '<span>💀</span> Delete All Saved 2FA Records';
          Store.setCSV([]);
          renderRecordsList();
          updateProgressUI();
          toast('💀 All Records Deleted', '#ef4444');
        };
      }

      // Draft inputs saving
      var emI = document.getElementById('IG_EMS');
      var pwI = document.getElementById('IG_PW');
      var dT;
      function draft() {
        clearTimeout(dT);
        dT = setTimeout(function() {
          if (emI) Store.set('em', emI.value);
          if (pwI) Store.set('pw', pwI.value);
          updateProgressUI();
        }, 300);
      }
      if (emI) emI.oninput = draft;
      if (pwI) pwI.oninput = draft;

    } catch(e) {
      console.error('[IG] Binding error:', e);
    }
  }

  /* ========== 20. CHROME MESSAGE LISTENER ========== */
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener(function(req, snd, res) {
      if (req.action === 'TOGGLE_STATE') {
        Store.setOn(req.enabled);
        updatePowerUI(req.enabled);
        if (btn) {
          if (open || (miniPill && miniPill.style.display === 'flex')) {
            btn.style.setProperty('display', 'none', 'important');
          } else {
            btn.style.setProperty('display', req.enabled ? 'flex' : 'none', 'important');
          }
        }
        if (!req.enabled && open) closePan();
        res({ ok: true });
      }
      if (req.action === 'OPEN_PANEL') {
        if (!open) showPan();
        res({ ok: true });
      }
      return true;
    });
  }

  /* ========== 21. CONTINUOUS STATE-MACHINE WATCHER ========== */
  function init() {
    if (!document.body) {
      requestAnimationFrame(init);
      return;
    }

    function ensureUI() {
      if (isTopFrame) {
        createButton();
        createPanel();
        createMiniPill();
        if (btn) {
          if (open || (miniPill && miniPill.style.display === 'flex')) {
            btn.style.setProperty('display', 'none', 'important');
          } else {
            btn.style.setProperty('display', Store.isOn() ? 'flex' : 'none', 'important');
          }
        }
      }
    }

    ensureStylesInjected();
    ensureInteractiveWidgetMeta();
    initViewportTracking();

    ensureUI();
    setTimeout(ensureUI, 250);
    setTimeout(ensureUI, 1000);
    setInterval(ensureUI, 4000);

    // Lightweight Continuous Monitor (Throttled to 1500ms to eliminate CPU lag)
    setInterval(function() {
      if (!Store.isOn()) return;
      var cfg = Store.getSettings();
      var host = window.location.hostname.toLowerCase();
      var href = window.location.href.toLowerCase();

      // Step 2: Only check Meta Horizon card when on relevant Meta or Accounts Center pages
      if (cfg.autoMetaHorizon !== false && (host.includes('meta.com') || href.includes('accountscenter') || href.includes('auth'))) {
        var metaInfo = findMetaHorizonByText();
        if (metaInfo && metaInfo.card && isVisible(metaInfo.card)) {
          clickMetaHorizonCard(metaInfo);
          return;
        }
      }

      // Auto-detect 2FA key on page (uses fast textContent instead of innerText)
      var is2FAScreen = href.includes('two_factor') ||
                        href.includes('two-factor') ||
                        href.includes('2fa') ||
                        href.includes('challenge') ||
                        href.includes('accountscenter') ||
                        href.includes('auth.meta.com') ||
                        /two[- ]?factor|authenticator|security key|authentication code/i.test(document.body ? document.body.textContent : '');

      if (is2FAScreen) {
        var key = scanPageFor2FAKey();
        if (key) {
          var curEmail = Store.getCurrentEmail() || 'user_' + Date.now();
          var existingRecords = Store.getCSV();
          var alreadyExists = existingRecords.some(function(r) { return r.key === key; });
          if (!alreadyExists) {
            Store.addRecord(curEmail, key);
            updateProgressUI();
            toast('🔑 2FA Key Auto-Saved: ' + key.substring(0, 8) + '...', '#10b981');
          }
        }
      }
    }, 1500);
  }

  init();
})();
