// Background Service Worker - IG 2FA Automation Pro v4.0

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_COOKIES") {
    chrome.cookies.getAll({ domain: ".instagram.com" }, (cookies) => {
      sendResponse({ success: true, cookies: cookies || [] });
    });
    return true;
  }
  
  if (request.action === "CLEAR_DATA") {
    chrome.browsingData.remove({
      origins: ["https://www.instagram.com"]
    }, {
      cookies: true,
      localStorage: true,
      sessionStorage: true,
      cacheStorage: true
    }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === "GET_STATUS") {
    chrome.storage.local.get(["extensionEnabled"], (result) => {
      sendResponse({ enabled: result.extensionEnabled !== false });
    });
    return true;
  }
  
  if (request.action === "TOGGLE_EXTENSION") {
    chrome.storage.local.get(["extensionEnabled"], (result) => {
      const newState = result.extensionEnabled === false;
      chrome.storage.local.set({ extensionEnabled: newState }, () => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.url && tab.url.includes("instagram.com")) {
              chrome.tabs.sendMessage(tab.id, { action: "TOGGLE_STATE", enabled: newState }).catch(() => {});
            }
          });
        });
        sendResponse({ enabled: newState });
      });
    });
    return true;
  }

  if (request.action === "SAVE_DATA") {
    chrome.storage.local.set({ [request.key]: request.data }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === "GET_DATA") {
    chrome.storage.local.get([request.key], (result) => {
      sendResponse({ data: result[request.key] || null });
    });
    return true;
  }
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  if (tab.url && tab.url.includes("instagram.com")) {
    chrome.storage.local.get(["extensionEnabled"], (result) => {
      const newState = result.extensionEnabled === false;
      chrome.storage.local.set({ extensionEnabled: newState });
      chrome.tabs.sendMessage(tab.id, { action: "TOGGLE_STATE", enabled: newState }).catch(() => {});
    });
  }
});

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    extensionEnabled: true,
    installTime: new Date().toISOString()
  });
  console.log("🔥 IG 2FA Automation Pro v4.0 Installed!");
});
