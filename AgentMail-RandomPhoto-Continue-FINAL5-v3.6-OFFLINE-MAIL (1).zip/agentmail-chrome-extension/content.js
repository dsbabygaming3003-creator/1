(() => {
  const AGENTMAIL_SCRIPT_VERSION = "3.6.0";

  function clearOldAgentmailTimers() {
    // Older versions had local setInterval IDs that were not stored on window.
    // Clear timers in this extension isolated world so old click loops stop.
    try {
      const maxTimerId = setTimeout(() => {}, 0);
      clearTimeout(maxTimerId);
      const startId = Math.max(1, maxTimerId - 2500);
      for (let id = startId; id <= maxTimerId; id += 1) {
        clearTimeout(id);
        clearInterval(id);
      }
    } catch (error) {}
  }

  if (window.__agentmailDynamicMenuLoaded && window.__agentmailDynamicMenuVersion === AGENTMAIL_SCRIPT_VERSION) {
    window.__agentmailRunMetaAutomation?.(true);
    return;
  }

  // If an older content script is already injected in this tab, do not return.
  // Clear old timers/observers so the updated rules can take over immediately.
  if (window.__agentmailDynamicMenuLoaded && window.__agentmailDynamicMenuVersion !== AGENTMAIL_SCRIPT_VERSION) {
    clearOldAgentmailTimers();
    try { clearInterval(window.__agentmailNamePoller); } catch (error) {}
    try { clearInterval(window.__agentmailEmailPoller); } catch (error) {}
    try { clearInterval(window.__agentmailMetaClickLoopTimer); } catch (error) {}
    try { window.__agentmailMetaObserver?.disconnect(); } catch (error) {}
    window.__agentmailNamePoller = null;
    window.__agentmailEmailPoller = null;
    window.__agentmailMetaClickLoopTimer = null;
    window.__agentmailMetaObserver = null;
    window.__agentmailAuthStuckWatchdogStarted = false;
    window.__agentmailMetaClickLoopRunning = false;
    window.__agentmailLanguageRedirecting = false;
    window.__agentmailFloatingMiniMenuStarted = false;
    try { document.getElementById("agentmail-floating-widget-host")?.remove(); } catch (error) {}
  }

  window.__agentmailDynamicMenuLoaded = true;
  window.__agentmailDynamicMenuVersion = AGENTMAIL_SCRIPT_VERSION;

  function sleep(ms) {
    const wait = isHiddenView() ? Math.min(ms, 80) : ms;
    return new Promise((resolve) => setTimeout(resolve, wait));
  }

  // ================================================================
  // BUTTER ENGINE v1.9.0
  // Cached DOM scans, frame-perfect waits and event-driven detection.
  // Same behaviour as before - just smooth, instant and error-proof.
  // ================================================================
  const SMOOTH = {
    domVersion: 0,
    dirty: false,
    queryCache: new Map(),
    rectCache: new WeakMap(),
    styleCache: new WeakMap(),
    rafQueue: new Set(),
    textCache: new Map(),
    maxQueryNodes: 4000,
    pageText: { version: -1, at: 0, text: "" }
  };

  function invalidateDomCache() {
    SMOOTH.dirty = false;
    SMOOTH.domVersion += 1;
  }

  function markDomDirty() {
    SMOOTH.dirty = true;
  }

  function ensureFreshCache() {
    if (SMOOTH.dirty) {
      SMOOTH.dirty = false;
      SMOOTH.domVersion += 1;
    }
  }

  function isHiddenView() {
    try { return document.visibilityState === "hidden"; } catch (error) { return false; }
  }

  // v3.0 LITE: the frame (rAF / FPS) layer is GONE. Every wait below is a plain
  // timer, so the page never pays for a repaint just because we wanted a tick.
  function nextFrame(cb) {
    return setTimeout(cb, 0);
  }

  function microWait(steps = 1) {
    const total = Math.max(1, Math.min(3, steps));
    // v3.0 LITE: 1 ms per step instead of one animation frame (16.7 ms).
    return new Promise((resolve) => setTimeout(resolve, total));
  }

  // Soft beat: a millisecond, never a whole frame.
  function humanDelay(steps = 1) {
    return microWait(steps);
  }

  // Collapse bursty triggers (observer + timer + message) into ONE callback.
  function scheduleCoalesced(key, fn) {
    const run = () => {
      SMOOTH.rafQueue.delete(key);
      try { fn(); } catch (error) {}
    };
    if (isHiddenView()) { run(); return true; }
    if (SMOOTH.rafQueue.has(key)) return false;
    SMOOTH.rafQueue.add(key);
    nextFrame(run);
    return true;
  }

  function getRect(el) {
    if (!el) return null;
    const cached = SMOOTH.rectCache.get(el);
    if (cached && cached.version === SMOOTH.domVersion) return cached.rect;
    let rect = null;
    try { rect = el.getBoundingClientRect(); } catch (error) { rect = null; }
    if (rect) SMOOTH.rectCache.set(el, { version: SMOOTH.domVersion, rect });
    return rect;
  }

  function getCachedStyle(el) {
    if (!el) return null;
    const cached = SMOOTH.styleCache.get(el);
    if (cached && cached.version === SMOOTH.domVersion) return cached.style;
    let style = null;
    try { style = window.getComputedStyle(el); } catch (error) { style = null; }
    if (style) SMOOTH.styleCache.set(el, { version: SMOOTH.domVersion, style });
    return style;
  }

  // Reading body.innerText forces a layout. Cache it per DOM version so the
  // ~30 page checks share a single read instead of one layout each.
  function getPageTextFast() {
    const now = Date.now();
    const cached = SMOOTH.pageText;
    if (cached.version === SMOOTH.domVersion && now - cached.at < 140) return cached.text;
    let raw = "";
    try { raw = document.body?.innerText || document.body?.textContent || ""; } catch (error) { raw = ""; }
    const text = String(raw).replace(/\s+/g, " ").trim().toLowerCase();
    SMOOTH.pageText = { version: SMOOTH.domVersion, at: now, text };
    return text;
  }

  // Event-driven wait: resolves the instant the condition turns true instead of
  // burning fixed sleeps. MutationObserver keeps it instant in hidden tabs too.
  function waitFor(check, options = {}) {
    const timeoutMs = options.timeout ?? 1500;
    const poll = options.poll ?? 35;

    let initial = null;
    try { initial = check(); } catch (error) { initial = null; }
    if (initial) return Promise.resolve(initial);

    return new Promise((resolve) => {
      let done = false;
      let timer = 0;
      let deadline = 0;
      let observer = null;

      const read = () => {
        try { return check(); } catch (error) { return null; }
      };

      const finish = () => {
        if (done) return;
        done = true;
        try { observer?.disconnect(); } catch (error) {}
        clearInterval(timer);
        clearTimeout(deadline);
        resolve(read());
      };

      const attempt = () => {
        if (read()) finish();
      };

      try {
        observer = new MutationObserver(attempt);
        const root = document.documentElement || document.body;
        if (root) observer.observe(root, { childList: true, subtree: true, attributes: true });
      } catch (error) { observer = null; }

      timer = setInterval(attempt, poll);
      deadline = setTimeout(finish, timeoutMs);
    });
  }

  function queryAllDeepRaw(selector, root) {
    const results = [];
    try {
      results.push(...root.querySelectorAll(selector));
      const all = root.querySelectorAll("*");
      for (const el of all) {
        if (el.shadowRoot) results.push(...queryAllDeepRaw(selector, el.shadowRoot));
      }
    } catch (error) {
      // Ignore restricted roots.
    }
    return results;
  }

  function queryAllDeep(selector, root = document) {
    // One cached scan per DOM version: the 100ms sweep no longer re-walks the
    // whole tree (and every shadow root) dozens of times per second.
    if (root === document) {
      ensureFreshCache();
      const cached = SMOOTH.queryCache.get(selector);
      if (cached && cached.version === SMOOTH.domVersion) return cached.nodes;
    }
    const nodes = queryAllDeepRaw(selector, root);
    if (root === document && nodes.length <= SMOOTH.maxQueryNodes) {
      SMOOTH.queryCache.set(selector, { version: SMOOTH.domVersion, nodes });
    }
    return nodes;
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = getRect(el);
    if (!rect || rect.width <= 0 || rect.height <= 0) return false;
    // Native checkVisibility when available (fast path), CSS check otherwise.
    if (typeof el.checkVisibility === "function") {
      try {
        return el.checkVisibility({ checkOpacity: false, checkVisibilityCSS: true });
      } catch (error) { /* fall through to the CSS check */ }
    }
    const style = getCachedStyle(el);
    if (!style) return true;
    return style.visibility !== "hidden" && style.display !== "none";
  }

  function normalizeText(text) {
    if (text == null) return "";
    const str = typeof text === "string" ? text : String(text);
    const cached = SMOOTH.textCache.get(str);
    if (cached !== undefined) return cached;
    const out = str.replace(/\s+/g, " ").trim().toLowerCase();
    if (str.length < 12000 && SMOOTH.textCache.size < 240) SMOOTH.textCache.set(str, out);
    return out;
  }

  function rectArea(el) {
    const rect = getRect(el);
    return rect ? rect.width * rect.height : 0;
  }

  function isMetaAuthPage() {
    return window.location.hostname.toLowerCase() === "auth.meta.com";
  }

  const META_AI_HOME_URL = "https://www.meta.ai/";

  const CODE_PAGE_REDIRECT_URL = "https://auth.meta.com/?waterfall_id=43439df0-2e2d-499a-a067-fd148cbfc329&redirect_uri=https%3A%2F%2Fauth.meta.com%2Foidc%2F%3Fapp_id%3D1522763855472543%26redirect_uri%3Dhttps%253A%252F%252Fauth.meta.ai%252Fecto%26response_type%3Dcode%26scope%3Dopenid%252Blinking%26state%3DeyJjc3JmX3Rva2VuIjoia0FpbWJDX2JvUnVEU3p4cjFVUjdqc2ZMM3hYSFNNUEVLV3VRTEVqR2ZDRSIsInJlZGlyZWN0X3RvIjoiaHR0cHM6Ly93d3cubWV0YS5haS9vaWRjL2NhbGxiYWNrIiwic3RhcnRlZF9hdCI6MTc4NzM4ODQ3MjcyMSwid2F0ZXJmYWxsX2lkIjoiNDM0MzlkZjAtMmUyZC00OTlhLWEwNjctZmQxNDhjYmZjMzI5In0%253D%26waterfall_id%3D43439df0-2e2d-499a-a067-fd148cbfc329%26code_challenge%3DczTb3mBuOFgn2XHZT2sbINOQv4bEdMZwOnR27PTh8Uc%26code_challenge_method%3DS256&source_app_id=1522763855472543&force_reauth=0&rcs=AToJ9_sn3hbKj9zIJ8tczAsW-DPBffTze3xHYU7gZrBZeeZJSZgr_LJ6m8nsUHQKnB-ykoKYX0FcAKE4DkFVODO-_yLoicnxVKRJhIc-g95tt_f9UxSN9rbGWMhanlcVhKi8JMtlYfO11vJxavSJTdP0pGK1GDoxQR3MDWYBncrLk_fpIWkOtxD9TL8";

  const AUTH_META_START_URL = "https://auth.meta.com/?waterfall_id=43439df0-2e2d-499a-a067-fd148cbfc329&redirect_uri=https%3A%2F%2Fauth.meta.com%2Foidc%2F%3Fapp_id%3D1522763855472543%26redirect_uri%3Dhttps%253A%252F%252Fauth.meta.ai%252Fecto%26response_type%3Dcode%26scope%3Dopenid%252Blinking%26state%3DeyJjc3JmX3Rva2VuIjoia0FpbWJDX2JvUnVEU3p4cjFVUjdqc2ZMM3hYSFNNUEVLV3VRTEVqR2ZDRSIsInJlZGlyZWN0X3RvIjoiaHR0cHM6Ly93d3cubWV0YS5haS9vaWRjL2NhbGxiYWNrIiwic3RhcnRlZF9hdCI6MTc4NzM4ODQ3MjcyMSwid2F0ZXJmYWxsX2lkIjoiNDM0MzlkZjAtMmUyZC00OTlhLWEwNjctZmQxNDhjYmZjMzI5In0%253D%26waterfall_id%3D43439df0-2e2d-499a-a067-fd148cbfc329%26code_challenge%3DczTb3mBuOFgn2XHZT2sbINOQv4bEdMZwOnR27PTh8Uc%26code_challenge_method%3DS256&source_app_id=1522763855472543&force_reauth=0&rcs=AToJ9_sn3hbKj9zIJ8tczAsW-DPBffTze3xHYU7gZrBZeeZJSZgr_LJ6m8nsUHQKnB-ykoKYX0FcAKE4DkFVODO-_yLoicnxVKRJhIc-g95tt_f9UxSN9rbGWMhanlcVhKi8JMtlYfO11vJxavSJTdP0pGK1GDoxQR3MDWYBncrLk_fpIWkOtxD9TL8";

  function isMetaAccountsCenterPage() {
    const host = window.location.hostname.toLowerCase();
    return host === "accountscenter.meta.com" || host === "accountcenter.meta.com";
  }

  function isMetaAccountsCenterLandingPage() {
    if (!isMetaAccountsCenterPage()) return false;
    const pageText = getPageTextFast();
    return (
      (pageText.includes("accounts centre") || pageText.includes("accounts center")) &&
      (
        pageText.includes("manage your connected experiences") ||
        pageText.includes("account settings") ||
        pageText.includes("profiles and personal details") ||
        pageText.includes("password and security") ||
        pageText.includes("manage accounts")
      )
    );
  }

  function redirectAccountsCenterToAuthStart(force = false) {
    if (!isMetaAccountsCenterPage()) return { ok: false, message: "Not Accounts Centre." };
    if (!force && window.__agentmailAccountsCenterRedirecting) {
      return { ok: true, message: "Accounts Centre redirect already queued." };
    }
    if (!force && !isMetaAccountsCenterLandingPage()) {
      return { ok: false, message: "Accounts Centre landing page not found yet." };
    }

    window.__agentmailAccountsCenterRedirecting = true;
    setTimeout(() => {
      try { window.location.replace(AUTH_META_START_URL); }
      catch (error) { window.location.href = AUTH_META_START_URL; }
    }, 120);
    return { ok: true, message: "Accounts Centre detected; going to auth.meta.com start." };
  }

  function startAccountsCenterRedirectWatcher() {
    if (!isMetaAccountsCenterPage() || window.__agentmailAccountsCenterWatcherStarted) return;
    window.__agentmailAccountsCenterWatcherStarted = true;
    redirectAccountsCenterToAuthStart(false);
    const timer = setInterval(() => {
      if (!isMetaAccountsCenterPage()) { clearInterval(timer); return; }
      const result = redirectAccountsCenterToAuthStart(false);
      if (result.ok) clearInterval(timer);
    }, 250);
    setTimeout(() => clearInterval(timer), 30000);
  }

  function textScore(el, words) {
    const haystack = normalizeText([
      el.type,
      el.name,
      el.id,
      el.autocomplete,
      el.placeholder,
      el.getAttribute("aria-label"),
      el.getAttribute("data-testid"),
      el.getAttribute("role")
    ].filter(Boolean).join(" "));

    return words.reduce((score, word) => score + (haystack.includes(word) ? 1 : 0), 0);
  }

  function getEditableValue(el) {
    if (!el) return "";
    if (el.isContentEditable) return el.textContent || "";
    return el.value || "";
  }

  function bestInput(kind) {
    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el));

    if (kind === "password") {
      return inputs.find((el) => el.tagName === "INPUT" && el.type === "password") || null;
    }

    const emailExact = inputs.find((el) => el.tagName === "INPUT" && el.type === "email");
    if (emailExact) return emailExact;

    const emailWords = ["email", "mail", "e-mail", "username", "login", "user", "mobile", "phone"];
    const ranked = inputs
      .filter((el) => {
        if (el.isContentEditable) return true;
        const type = (el.type || "text").toLowerCase();
        return ["text", "search", "email", "tel", "url", ""].includes(type) || el.tagName === "TEXTAREA";
      })
      .map((el) => ({ el, score: textScore(el, emailWords) }))
      .sort((a, b) => b.score - a.score);

    return ranked[0]?.el || null;
  }

  function dispatchInputEvents(element, value, previousValue = "") {
    const tracker = element._valueTracker;
    if (tracker) tracker.setValue(previousValue);

    try {
      element.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: "insertText",
        data: value
      }));
    } catch (error) {
      element.dispatchEvent(new Event("beforeinput", { bubbles: true, cancelable: true, composed: true }));
    }

    try {
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: false,
        composed: true,
        inputType: "insertText",
        data: value
      }));
    } catch (error) {
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }

    element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key: "a", code: "KeyA", which: 65 }));
    element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key: "a", code: "KeyA", which: 65 }));
    element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));

    // No blur() churn here: blurring right after each field made Meta re-render
    // (and stole focus from the next field). input + change is all React needs.
    invalidateDomCache();
  }

  // Content scripts live in an ISOLATED WORLD: expando properties added by the
  // page (React's node._valueTracker) are invisible to us and vice versa, so the
  // classic "poke the tracker" trick silently does nothing in a real browser.
  // The one lever we DO have: fire an input event carrying the value that is
  // already on screen - React then adopts it, and our next write is a real
  // change instead of a duplicate React ignores. It can never change anything
  // the user can see, because that value is already displayed.
  function nudgeReactTracker(element) {
    try {
      if (!element || element.isContentEditable || typeof element.value === "undefined") return;
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    } catch (error) {}
  }

  function setNativeValue(element, value) {
    if (!element) return;
    const text = value == null ? "" : String(value);
    const previous = element.isContentEditable ? (element.textContent || "") : (element.value || "");

    try { element.focus({ preventScroll: true }); } catch (error) { try { element.focus?.(); } catch (inner) {} }

    if (element.isContentEditable) {
      if (previous !== text) element.textContent = text;
      dispatchInputEvents(element, text, previous);
      return;
    }

    nudgeReactTracker(element);   // let the page's tracker catch up with the old value

    const prototype = Object.getPrototypeOf(element);
    const protoSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    // One clean write through the native setter - no execCommand, no select(),
    // no element.click(). Those three caused caret jumps and double inserts.
    if (protoSetter) protoSetter.call(element, text);
    else element.value = text;

    dispatchInputEvents(element, text, previous);

    // Single safety pass, only if a controlled input rewrote the value once.
    if ((element.value || "") !== text) {
      const stuck = element.value || "";
      // Re-sync the page's tracker with what is on screen, then write for real.
      // Both steps stay in one tick: React handles each dispatched event sync.
      if (protoSetter) protoSetter.call(element, stuck);
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      if (protoSetter) protoSetter.call(element, text);
      else element.value = text;
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      invalidateDomCache();
    }
  }

  function flash(element) {
    if (!element?.style) return;
    // Cheap glow: outline only (no box-shadow repaint) and one shared timer, so
    // rapid fill/click sequences stay perfectly smooth.
    try {
      if (element.__agentmailFlashTimer) clearTimeout(element.__agentmailFlashTimer);
      else element.__agentmailFlashPrev = {
        outline: element.style.outline,
        offset: element.style.outlineOffset
      };
      element.style.outline = "2px solid #6d5dfc";
      element.style.outlineOffset = "1px";
      element.__agentmailFlashTimer = setTimeout(() => {
        element.style.outline = element.__agentmailFlashPrev?.outline || "";
        element.style.outlineOffset = element.__agentmailFlashPrev?.offset || "";
        element.__agentmailFlashTimer = null;
      }, 420);
    } catch (error) {}
  }

  function fill(kind, value) {
    const input = bestInput(kind);
    if (!input) {
      return { ok: false, message: `${kind} input not found on this page.` };
    }
    setNativeValue(input, value);
    flash(input);
    return {
      ok: true,
      message: `${kind} filled.`,
      matched: {
        tag: input.tagName,
        type: input.type || "",
        name: input.name || "",
        id: input.id || "",
        placeholder: input.placeholder || ""
      }
    };
  }

  function getClickableTarget(el) {
    let node = el;
    const maxArea = Math.max(rectArea(el) * 10, 200000);

    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;

      const role = (node.getAttribute("role") || "").toLowerCase();
      const tag = node.tagName;
      const style = getCachedStyle(node);
      const clickable =
        tag === "BUTTON" ||
        tag === "A" ||
        role === "button" ||
        node.tabIndex >= 0 ||
        style.cursor === "pointer" ||
        typeof node.onclick === "function";

      if (clickable && rectArea(node) <= maxArea) return node;
    }

    return el;
  }

  function emailChoicePhrases() {
    return [
      "use mobile number or email address",
      "use mobile number or email",
      "mobile number or email address",
      "mobile number or email"
    ];
  }

  function isBadSocialChoiceText(text) {
    return text.includes("continue with facebook") ||
      text.includes("continue with instagram") ||
      text.includes("facebook") ||
      text.includes("instagram");
  }

  function findMetaEmailChoiceButton() {
    const phrases = emailChoicePhrases();

    // IMPORTANT: return the exact email text/row only. Never return a parent
    // container that also contains Facebook/Instagram options.
    const candidates = queryAllDeep("button, a, [role='button'], div, span, p")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        const matchedPhrase = phrases.find((phrase) => text === phrase) || phrases.find((phrase) => text.includes(phrase));
        const role = (el.getAttribute("role") || "").toLowerCase();
        const tag = el.tagName;
        return {
          el,
          text,
          area: rect.width * rect.height,
          top: rect.top,
          left: rect.left,
          width: rect.width,
          height: rect.height,
          matchedPhrase,
          exact: Boolean(matchedPhrase && text === matchedPhrase),
          interactive: tag === "BUTTON" || tag === "A" || role === "button" || el.tabIndex >= 0
        };
      })
      .filter((item) => item.matchedPhrase)
      .filter((item) => !item.text.includes("edit email"))
      .filter((item) => !isBadSocialChoiceText(item.text))
      .filter((item) => item.text.length <= 95 && item.area > 25 && item.area < 190000)
      .sort((a, b) => {
        if (a.exact !== b.exact) return a.exact ? -1 : 1;
        if (a.interactive !== b.interactive) return a.interactive ? -1 : 1;
        // Prefer the lowest matching email option if text fragments duplicate.
        return a.area - b.area || b.top - a.top;
      });

    return candidates[0]?.el || null;
  }

  function getEmailChoiceRowFromLabel(labelEl) {
    if (!labelEl) return null;
    const phrases = emailChoicePhrases();
    let row = labelEl;
    const labelRect = labelEl.getBoundingClientRect();
    const labelCenterY = labelRect.top + labelRect.height / 2;

    for (let node = labelEl, depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute("aria-label"));
      if (!phrases.some((phrase) => text.includes(phrase))) break;
      if (isBadSocialChoiceText(text)) break;

      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const looksLikeOptionRow =
        rect.width >= window.innerWidth * 0.48 &&
        rect.height >= 38 && rect.height <= 170 &&
        area < 210000 &&
        labelCenterY >= rect.top && labelCenterY <= rect.bottom;

      if (looksLikeOptionRow) row = node;
    }

    const rowText = normalizeText(row.innerText || row.textContent || row.getAttribute("aria-label"));
    if (isBadSocialChoiceText(rowText) || !phrases.some((phrase) => rowText.includes(phrase))) return labelEl;
    return row;
  }

  function getMetaInitialOptionRows() {
    if (!isMetaAuthPage()) return [];
    const pageText = getPageTextFast();
    if (!pageText.includes("log in or create an account")) return [];

    const optionTexts = [
      "continue with facebook",
      "continue with instagram",
      "use mobile number or email address",
      "use mobile number or email"
    ];

    const rows = queryAllDeep("button, a, [role='button'], div")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        return { el, text, rect, area: rect.width * rect.height };
      })
      .filter((item) => optionTexts.some((phrase) => item.text.includes(phrase)))
      .filter((item) => item.rect.width >= window.innerWidth * 0.45)
      .filter((item) => item.rect.height >= 42 && item.rect.height <= 150)
      .filter((item) => item.area > 4000 && item.area < 190000)
      .sort((a, b) => (a.rect.top - b.rect.top) || (b.area - a.area));

    const unique = [];
    for (const item of rows) {
      const itemY = item.rect.top + item.rect.height / 2;
      const existing = unique.find((u) => Math.abs((u.rect.top + u.rect.height / 2) - itemY) < 18);
      if (!existing) unique.push(item);
      else if (item.rect.width > existing.rect.width) {
        unique[unique.indexOf(existing)] = item;
      }
    }
    return unique;
  }

  function findMetaInitialFirstOptionRow() {
    const unique = getMetaInitialOptionRows();
    const facebook = unique.find((item) => item.text.includes("continue with facebook"));
    return (facebook || unique[0])?.el || null;
  }

  function clickInitialFirstOptionOnly(row) {
    if (!row) return false;
    row.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    row.focus?.();
    flash(row);

    const tap = (index = 0) => {
      const rect = row.getBoundingClientRect(); // recompute after scroll
      const y = rect.top + rect.height / 2;
      const xList = [
        rect.left + rect.width * 0.48, // text area in 1st row
        rect.left + rect.width * 0.20, // icon/text-left area
        rect.right - Math.min(52, rect.width * 0.09) // right control/radio
      ];
      let x = xList[index] || xList[0];
      x = Math.max(rect.left + 12, Math.min(rect.right - 12, x));

      let target = document.elementFromPoint(x, y);
      if (!target || !(target === row || row.contains(target))) target = row;

      const mouseInit = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: window.screenX + x,
        screenY: window.screenY + y,
        button: 0,
        buttons: 1
      };
      const pointerInit = { ...mouseInit, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;
      try {
        const touch = new Touch({ identifier: 1, target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y, pageX: window.scrollX + x, pageY: window.scrollY + y, radiusX: 8, radiusY: 8, force: 0.8 });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch (error) {}
      target.dispatchEvent(new Pointer("pointerover", pointerInit));
      target.dispatchEvent(new Pointer("pointerenter", pointerInit));
      target.dispatchEvent(new Pointer("pointerdown", pointerInit));
      target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
      target.dispatchEvent(new Pointer("pointerup", { ...pointerInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...mouseInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...mouseInit, buttons: 0 }));
      // Single activation: the click event above already fires the handler, so
      // calling .click() again would double-trigger Meta's row handler.
      if (target !== row && !row.contains(target)) {
        try { row.click?.(); } catch (error) {}
      }
      invalidateDomCache();
    };

    // Butter stagger: three taps in ~120ms instead of ~360ms (all at once hidden).
    [0, 1, 2].forEach((index) => {
      if (index === 0 || isHiddenView()) tap(index);
      else setTimeout(() => tap(index), index * 60);
    });
    return true;
  }

  function findMetaInitialThirdEmailOptionRow() {
    if (!isMetaAuthPage()) return null;
    const pageText = getPageTextFast();
    if (!pageText.includes("log in or create an account")) return null;

    const optionTexts = [
      "continue with facebook",
      "continue with instagram",
      "use mobile number or email address",
      "use mobile number or email"
    ];

    const rows = queryAllDeep("button, a, [role='button'], div")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        return { el, text, rect, area: rect.width * rect.height };
      })
      .filter((item) => optionTexts.some((phrase) => item.text.includes(phrase)))
      .filter((item) => item.rect.width >= window.innerWidth * 0.45)
      .filter((item) => item.rect.height >= 42 && item.rect.height <= 150)
      .filter((item) => item.area > 4000 && item.area < 190000)
      .sort((a, b) => (a.rect.top - b.rect.top) || (b.area - a.area));

    // Deduplicate nested text/row elements by vertical overlap, keeping the widest row.
    const unique = [];
    for (const item of rows) {
      const existing = unique.find((u) => Math.abs((u.rect.top + u.rect.height / 2) - (item.rect.top + item.rect.height / 2)) < 18);
      if (!existing) unique.push(item);
      else if (item.rect.width > existing.rect.width) {
        const index = unique.indexOf(existing);
        unique[index] = item;
      }
    }

    const emailRow = unique.find((item) =>
      item.text.includes("use mobile number or email address") ||
      item.text.includes("use mobile number or email")
    );
    // User requested: only Use mobile number or email address, never Facebook/Instagram.
    return emailRow?.el || null;
  }

  function clickInitialThirdEmailOptionOnly(row) {
    if (!row) return false;
    let rowText = normalizeText(row.innerText || row.textContent || row.getAttribute("aria-label"));
    if (isBadSocialChoiceText(rowText) || !(rowText.includes("use mobile number or email address") || rowText.includes("use mobile number or email"))) return false;

    row.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    row.focus?.();
    flash(row);

    const tap = (index = 0) => {
      const rect = row.getBoundingClientRect(); // recompute AFTER scroll; stale coords clicked wrong rows before.
      rowText = normalizeText(row.innerText || row.textContent || row.getAttribute("aria-label"));
      if (isBadSocialChoiceText(rowText) || !(rowText.includes("use mobile number or email address") || rowText.includes("use mobile number or email"))) return;

      const y = rect.top + rect.height / 2;
      const xList = [
        rect.left + rect.width * 0.46, // text area in 3rd row
        rect.left + rect.width * 0.24, // icon/text-left area in 3rd row
        rect.right - Math.min(52, rect.width * 0.09) // right control, still inside 3rd row
      ];
      let x = xList[index] || xList[0];
      x = Math.max(rect.left + 12, Math.min(rect.right - 12, x));

      let target = document.elementFromPoint(x, y);
      if (!target || !(target === row || row.contains(target))) target = row;
      const targetText = normalizeText(target.innerText || target.textContent || target.getAttribute?.("aria-label"));
      if (isBadSocialChoiceText(targetText)) target = row;

      const mouseInit = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: window.screenX + x,
        screenY: window.screenY + y,
        button: 0,
        buttons: 1
      };
      const pointerInit = { ...mouseInit, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;
      try {
        const touch = new Touch({ identifier: 1, target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y, pageX: window.scrollX + x, pageY: window.scrollY + y, radiusX: 8, radiusY: 8, force: 0.8 });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch (error) {}
      target.dispatchEvent(new Pointer("pointerover", pointerInit));
      target.dispatchEvent(new Pointer("pointerenter", pointerInit));
      target.dispatchEvent(new Pointer("pointerdown", pointerInit));
      target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
      target.dispatchEvent(new Pointer("pointerup", { ...pointerInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...mouseInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...mouseInit, buttons: 0 }));
      // Single activation only - no duplicate .click().
      if (target !== row && !row.contains(target)) {
        try { row.click?.(); } catch (error) {}
      }
      invalidateDomCache();
    };

    // Butter stagger: three taps in ~120ms instead of ~440ms (all at once hidden).
    [0, 1, 2].forEach((index) => {
      if (index === 0 || isHiddenView()) tap(index);
      else setTimeout(() => tap(index), index * 60);
    });
    return true;
  }

  function fireEmailChoiceClick(labelOrRow) {
    if (!labelOrRow) return false;

    const emailRow = getEmailChoiceRowFromLabel(labelOrRow) || labelOrRow;
    let rowText = normalizeText(emailRow.innerText || emailRow.textContent || emailRow.getAttribute("aria-label"));
    if (isBadSocialChoiceText(rowText)) return false;

    emailRow.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    emailRow.focus?.();
    flash(emailRow);

    let labelRect = labelOrRow.getBoundingClientRect();
    let rowRect = emailRow.getBoundingClientRect();
    let clickY = Math.max(rowRect.top + 8, Math.min(rowRect.bottom - 8, labelRect.top + labelRect.height / 2));

    const sendEvents = (target, x, y) => {
      // Clamp to the email row rectangle, so it cannot hit Facebook/Instagram rows.
      x = Math.max(rowRect.left + 8, Math.min(rowRect.right - 8, x));
      y = Math.max(rowRect.top + 8, Math.min(rowRect.bottom - 8, y));

      if (!target || !(target === emailRow || emailRow.contains(target))) target = emailRow;
      const targetText = normalizeText(target.innerText || target.textContent || target.getAttribute?.("aria-label"));
      if (isBadSocialChoiceText(targetText)) target = emailRow;

      const mouseInit = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: window.screenX + x,
        screenY: window.screenY + y,
        button: 0,
        buttons: 1
      };
      const pointerInit = { ...mouseInit, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;

      try {
        const touch = new Touch({ identifier: 1, target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y, pageX: window.scrollX + x, pageY: window.scrollY + y, radiusX: 8, radiusY: 8, force: 0.7 });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch (error) {}

      target.dispatchEvent(new Pointer("pointerover", pointerInit));
      target.dispatchEvent(new Pointer("pointerenter", pointerInit));
      target.dispatchEvent(new Pointer("pointerdown", pointerInit));
      target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
      target.dispatchEvent(new Pointer("pointerup", { ...pointerInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...mouseInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...mouseInit, buttons: 0 }));
      invalidateDomCache();
    };

    // Find controls inside the email row only whose vertical center matches the email row.
    const controls = [emailRow, ...emailRow.querySelectorAll?.("input, button, [role='radio'], [role='button'], [tabindex], div, span") || []]
      .filter((el) => isVisible(el) && (el === emailRow || emailRow.contains(el)))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        return { el, rect, text, area: rect.width * rect.height };
      })
      .filter((item) => !isBadSocialChoiceText(item.text))
      .filter((item) => item.rect.top >= rowRect.top - 4 && item.rect.bottom <= rowRect.bottom + 4)
      .sort((a, b) => {
        const rightA = a.rect.left > rowRect.left + rowRect.width * 0.70 ? 0 : 1;
        const rightB = b.rect.left > rowRect.left + rowRect.width * 0.70 ? 0 : 1;
        if (rightA !== rightB) return rightA - rightB;
        const inputA = a.el.tagName === "INPUT" || (a.el.getAttribute("role") || "").toLowerCase() === "radio" ? 0 : 1;
        const inputB = b.el.tagName === "INPUT" || (b.el.getAttribute("role") || "").toLowerCase() === "radio" ? 0 : 1;
        if (inputA !== inputB) return inputA - inputB;
        return a.area - b.area;
      });

    // First click text center (safest), then row right-side radio/control inside same row.
    const labelCenterX = labelRect.left + labelRect.width / 2;
    const plans = [
      { target: labelOrRow, x: labelCenterX, y: clickY },
      { target: emailRow, x: rowRect.left + rowRect.width * 0.52, y: clickY }
    ];
    if (controls[0]) {
      const r = controls[0].rect;
      plans.push({ target: controls[0].el, x: r.left + r.width / 2, y: r.top + r.height / 2 });
    }
    plans.push({ target: emailRow, x: rowRect.right - Math.min(44, rowRect.width * 0.08), y: clickY });

    plans.forEach((plan, index) => {
      if (index === 0 || isHiddenView()) sendEvents(plan.target, plan.x, plan.y);
      else setTimeout(() => sendEvents(plan.target, plan.x, plan.y), index * 55);
    });
    return true;
  }

  function isMetaEmailEntryPage() {
    const pageText = getPageTextFast();
    // Confirmation page has "Edit mobile number or email address" text, but it is NOT
    // the email-entry page. Never paste a new mail or click that edit link here.
    if (
      pageText.includes("confirm your account") ||
      pageText.includes("we sent a code") ||
      pageText.includes("look for an email") ||
      pageText.includes("send code again") ||
      pageText.includes("edit mobile number or email address") ||
      pageText.includes("edit email address")
    ) {
      return false;
    }

    const looksLikeEmailText =
      pageText.includes("what's your mobile number or email address") ||
      pageText.includes("what’s your mobile number or email address") ||
      pageText.includes("enter your mobile number or email address") ||
      pageText.includes("mobile number or email address to log in") ||
      pageText.includes("mobile number or email address") ||
      pageText.includes("email address or mobile number") ||
      pageText.includes("email or mobile number") ||
      pageText.includes("phone number or email") ||
      pageText.includes("email or phone") ||
      pageText.includes("enter your email") ||
      pageText.includes("email address");

    if (looksLikeEmailText) {
      // Avoid treating later account-creation forms as the email page.
      const definitelyOtherStep =
        pageText.includes("first name") ||
        pageText.includes("surname") ||
        pageText.includes("last name") ||
        pageText.includes("date of birth") ||
        pageText.includes("create a password") ||
        pageText.includes("confirmation code") ||
        pageText.includes("confirm your account") ||
        pageText.includes("we sent a code") ||
        pageText.includes("look for an email") ||
        pageText.includes("send code again") ||
        pageText.includes("edit mobile number or email address") ||
        pageText.includes("edit email address") ||
        pageText.includes("upload a verification selfie");
      if (!definitelyOtherStep) return true;
    }

    return queryAllDeep("input, textarea, [contenteditable='true']").some((el) => {
      const nearby = normalizeText([
        el.type,
        el.name,
        el.id,
        el.autocomplete,
        el.placeholder,
        el.getAttribute("aria-label"),
        el.getAttribute("data-testid"),
        el.getAttribute("aria-describedby"),
        el.closest("label")?.innerText,
        el.parentElement?.innerText,
        el.parentElement?.parentElement?.innerText
      ].filter(Boolean).join(" "));
      return nearby.includes("mobile number or email") || nearby.includes("email address") || nearby.includes("email or mobile") || nearby.includes("email or phone");
    });
  }

  function findMetaEmailInput() {
    // v3.3 LUX: on the Meta AI details page the only text box is the NAME box.
    if (isMetaAuthPage() && isMetaAiDetailsConfirmPage()) return null;
    // v3.3 LUX smoothness: this runs on every sweep and the ranking reads parent
    // text (layout work). Reuse the answer for 250 ms unless the DOM moved.
    const pageLooksLikeEmail = isMetaEmailEntryPage();
    const memo = window.__agentmailEmailInputMemo;
    if (memo && memo.version === SMOOTH.domVersion && Date.now() - memo.at < 250 &&
        memo.el && memo.el.isConnected !== false && isVisible(memo.el)) {
      return memo.el;
    }
    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el))
      .filter((el) => {
        if (el.isContentEditable) return true;
        const type = (el.type || "text").toLowerCase();
        return ["email", "text", "tel", "search", "", "url"].includes(type) || el.tagName === "TEXTAREA";
      })
      .filter((el) => {
        // v3.5: the email may never land in a field that is about something else.
        const own = normalizeText([
          el.name, el.id, el.placeholder, el.getAttribute("aria-label"),
          el.getAttribute("autocomplete"), el.getAttribute("data-testid"), el.getAttribute("title")
        ].filter(Boolean).join(" "));
        if (!own) return true;
        if (/\b(password|passcode|pwd|pass word)\b/.test(own)) return false;
        if (/\b(first name|last name|full name|name \(optional\)|name\(optional\))\b/.test(own)) return false;
        // Meta labels its email/login field autocomplete="username". Only reject
        // that ambiguous hint off the email-entry page and when no email clue is
        // present; otherwise the wrong-mail safety filter would hide the right box.
        if (/\b(username|user name|handle)\b/.test(own) && !pageLooksLikeEmail &&
            !/\b(email|e-mail|mail|mobile number|phone|identifier)\b/.test(own)) return false;
        if (/\b(year|birth|birthday|dob|date of birth)\b/.test(own)) return false;
        if (/\b(code|otp|verification|token|confirm)\b/.test(own)) return false;
        return true;
      });

    const phrases = [
      "mobile number or email address",
      "mobile number or email",
      "email address or mobile number",
      "email or mobile number",
      "phone number or email",
      "email or phone",
      "email address",
      "email",
      "mobile number"
    ];

    if (!inputs.length) return null;

    const ranked = inputs
      .map((el) => {
        const nearby = normalizeText([
          el.type,
          el.name,
          el.id,
          el.autocomplete,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.getAttribute("aria-describedby"),
          el.getAttribute("role"),
          el.closest("label")?.innerText,
          el.parentElement?.innerText,
          el.parentElement?.parentElement?.innerText
        ].filter(Boolean).join(" "));
        const matched = phrases.some((phrase) => nearby.includes(phrase));
        const type = (el.type || "text").toLowerCase();
        const rect = el.getBoundingClientRect();
        let score = 0;

        if (matched) score += 80;
        if (type === "email") score += 45;
        if (type === "tel") score += 25;
        if (pageLooksLikeEmail && ["email", "text", "tel", "search", "", "url"].includes(type)) score += 35;
        if (normalizeText(el.placeholder).includes("mobile number or email")) score += 45;
        if (normalizeText(el.getAttribute("aria-label")).includes("mobile number or email")) score += 45;
        if (rect.top > 0 && rect.top < window.innerHeight) score += 8;
        if ((el.value || "").includes("@")) score += 5;
        return { el, score, matched, rectTop: rect.top };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => (b.score - a.score) || (a.rectTop - b.rectTop));

    const best = ranked[0];
    if (best && (pageLooksLikeEmail || best.matched || best.el.type === "email")) {
      window.__agentmailEmailInputMemo = { version: SMOOTH.domVersion, at: Date.now(), el: best.el };
      return best.el;
    }

    // Last-resort for Meta email page after cookie popup: if the visible page text
    // says email/mobile and there is only one visible editable field, use it.
    if (pageLooksLikeEmail && inputs.length === 1) return inputs[0];
    return null;
  }

  function findContinueButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "continue" || item.text.includes("continue"))
      .filter((item) => item.area > 80 && item.area < 250000)
      .sort((a, b) => a.area - b.area);

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function findMetaCreateNewAccountButton() {
    const pageText = getPageTextFast();
    const looksLikeCreatePage =
      pageText.includes("create a new meta account") ||
      pageText.includes("we can't find a meta account") ||
      pageText.includes("we can’t find a meta account");

    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "create new account" || item.text.includes("create new account"))
      .filter((item) => item.area > 80 && item.area < 250000)
      .sort((a, b) => {
        const exactA = a.text === "create new account" ? 0 : 1;
        const exactB = b.text === "create new account" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    if (!looksLikeCreatePage && candidates[0].text !== "create new account") return null;
    return getClickableTarget(candidates[0].el);
  }

  function findNextButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "next" || item.text.includes("next"))
      .filter((item) => item.area > 80 && item.area < 250000)
      .sort((a, b) => {
        const exactA = a.text === "next" ? 0 : 1;
        const exactB = b.text === "next" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  const AGENTMAIL_FIRST_NAMES = [
    "Ayan", "Rayhan", "Hasan", "Sami", "Nabil", "Rafi", "Tanvir", "Fahim",
    "Imran", "Asif", "Rohan", "Sajid", "Arman", "Naim", "Rifat", "Adnan",
    "Zayan", "Farhan", "Tuhin", "Sohan", "Mahir", "Shayan", "Rakib", "Sakib"
  ];

  const AGENTMAIL_LAST_NAMES = [
    "Ahmed", "Hasan", "Rahman", "Hossain", "Karim", "Khan", "Islam", "Chowdhury",
    "Mahmud", "Sarker", "Talukder", "Miah", "Uddin", "Kabir", "Haque", "Azad",
    "Molla", "Sheikh", "Bari", "Rashid", "Amin", "Noor", "Siddiq", "Jaman"
  ];

  function randomIndex(max) {
    const bytes = new Uint32Array(1);
    crypto.getRandomValues(bytes);
    return bytes[0] % max;
  }

  function getGeneratedMetaName() {
    if (window.__agentmailGeneratedMetaName) return window.__agentmailGeneratedMetaName;

    let first = AGENTMAIL_FIRST_NAMES[randomIndex(AGENTMAIL_FIRST_NAMES.length)];
    let last = AGENTMAIL_LAST_NAMES[randomIndex(AGENTMAIL_LAST_NAMES.length)];
    if (first === last) last = AGENTMAIL_LAST_NAMES[(randomIndex(AGENTMAIL_LAST_NAMES.length - 1) + 1) % AGENTMAIL_LAST_NAMES.length];

    window.__agentmailGeneratedMetaName = { first, last };
    try {
      sessionStorage.setItem("agentmail_meta_first_name", first);
      sessionStorage.setItem("agentmail_meta_last_name", last);
    } catch (error) {
      // Ignore storage errors.
    }
    return window.__agentmailGeneratedMetaName;
  }

  function isMetaNamePage() {
    const pageText = getPageTextFast();

    // Mobile Meta sometimes uses curly apostrophes or renders labels outside of
    // input attributes. So detect by the visible screen text too.
    if (
      pageText.includes("your name") ||
      pageText.includes("first name") ||
      pageText.includes("surname") ||
      pageText.includes("last name") ||
      pageText.includes("name cannot contain") ||
      pageText.includes("account recovery")
    ) {
      return true;
    }

    const attrs = queryAllDeep("input, textarea, [contenteditable='true']")
      .map((el) => normalizeText([
        el.name,
        el.id,
        el.placeholder,
        el.getAttribute("aria-label"),
        el.getAttribute("data-testid"),
        el.autocomplete
      ].filter(Boolean).join(" ")))
      .join(" ");

    return attrs.includes("first") || attrs.includes("surname") || attrs.includes("family-name") || attrs.includes("given-name");
  }

  function findNameInputs() {
    if (!isMetaNamePage()) return { first: null, last: null };

    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el))
      .filter((el) => {
        if (el.isContentEditable) return true;
        const type = (el.type || "text").toLowerCase();
        return ["text", "", "search"].includes(type) || el.tagName === "TEXTAREA";
      })
      .sort((a, b) => {
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        return (ra.top - rb.top) || (ra.left - rb.left);
      });

    if (inputs.length < 2) return { first: inputs[0] || null, last: null };

    const directText = (el) => normalizeText([
      el.name,
      el.id,
      el.placeholder,
      el.getAttribute("aria-label"),
      el.getAttribute("data-testid"),
      el.autocomplete
    ].filter(Boolean).join(" "));

    const localText = (el) => {
      const label = el.closest("label")?.innerText || "";
      const parent = el.parentElement;
      const parentText = parent && parent.children.length <= 3 ? (parent.innerText || parent.textContent || "") : "";
      const text = normalizeText([label, parentText].filter(Boolean).join(" "));
      const hasFirst = text.includes("first name") || text.includes("firstname") || text.includes("given-name");
      const hasLast = text.includes("surname") || text.includes("last name") || text.includes("lastname") || text.includes("family-name");
      // If a broad container contains both labels, don't use it for matching;
      // that was causing first and last to resolve to the same input.
      if (hasFirst && hasLast) return "";
      return text;
    };

    const scoreInput = (el, kind) => {
      const direct = directText(el);
      const local = localText(el);
      let score = 0;
      if (kind === "first") {
        if (direct.includes("first name") || direct.includes("firstname") || direct.includes("given-name") || direct.includes("given")) score += 100;
        if (local.includes("first name") || local.includes("firstname") || local.includes("given-name") || local.includes("given")) score += 45;
      } else {
        if (direct.includes("surname") || direct.includes("last name") || direct.includes("lastname") || direct.includes("family-name") || direct.includes("family")) score += 100;
        if (local.includes("surname") || local.includes("last name") || local.includes("lastname") || local.includes("family-name") || local.includes("family")) score += 45;
      }
      return score;
    };

    const rankedFirst = inputs
      .map((el, index) => ({ el, index, score: scoreInput(el, "first") }))
      .sort((a, b) => (b.score - a.score) || (a.index - b.index));
    const rankedLast = inputs
      .map((el, index) => ({ el, index, score: scoreInput(el, "last") }))
      .sort((a, b) => (b.score - a.score) || (a.index - b.index));

    let first = rankedFirst[0]?.score > 0 ? rankedFirst[0].el : null;
    let last = rankedLast[0]?.score > 0 ? rankedLast[0].el : null;

    // If label matching gives the same field or is ambiguous, use visible order:
    // first visible input = First name, second visible input = Surname/last name.
    if (!first || !last || first === last) {
      first = inputs[0];
      last = inputs.find((el) => el !== first) || inputs[1] || null;
    }

    return { first, last };
  }

  function valueLooksLikeName(value) {
    return /^[A-Za-z]{2,24}$/.test((value || "").trim());
  }

  function setTypingValue(element, value, previousValue = "") {
    if (element.isContentEditable) {
      element.textContent = value;
    } else {
      const prototype = Object.getPrototypeOf(element);
      const protoSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (protoSetter) protoSetter.call(element, value);
      else element.value = value;
    }

    const tracker = element._valueTracker;
    if (tracker) tracker.setValue(previousValue);

    try {
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: value.slice(-1)
      }));
    } catch (error) {
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }
  }

  async function typeLikeHuman(element, textValue) {
    if (!element) return;
    // Butter path: write once, verify on the next frame, done. No per-character
    // typing, no repeated rewrites, so first/last fields never get mixed.
    try { element.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
    try { element.focus({ preventScroll: true }); } catch (error) { try { element.focus?.(); } catch (inner) {} }

    const target = textValue == null ? "" : String(textValue);
    if (getEditableValue(element).trim() === target) {
      flash(element);
      return;
    }

    setNativeValue(element, "");
    setNativeValue(element, target);

    if (getEditableValue(element).trim() !== target) {
      await humanDelay(1);
      setTypingValue(element, target, getEditableValue(element));
      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      invalidateDomCache();
    }

    flash(element);
  }

  async function clickNextAfterName() {
    const startedAt = Date.now();
    let attempts = 0;
    while (Date.now() - startedAt < 1400) {
      const button = findNextButton();
      if (button && (!isDisabledLike(button) || attempts > 3)) {
        flash(button);
        await humanDelay(1);
        await clickStrong(button, { kind: "next-name", pageId: POWER.lastPage.id });
        return true;
      }
      attempts += 1;
      if (button) await waitFor(() => !isDisabledLike(button), { timeout: 320, poll: 30 });
      else await waitFor(() => Boolean(findNextButton()), { timeout: 160, poll: 30 });
    }
    return false;
  }

  async function autoFillMetaNamePage(force = false) {
    if (!isMetaAuthPage() || !isMetaNamePage()) return { ok: false, message: "Name page not found." };

    // Never run two name fillers at the same time. Background retries can call
    // this page many times; overlapping typing caused the glitch/rewrite issue.
    if (window.__agentmailNameAutomationRunning) {
      return { ok: true, message: "Name automation already running." };
    }

    const { first, last } = findNameInputs();
    if (!first || !last || first === last) return { ok: false, message: "Two distinct name inputs not found yet." };

    window.__agentmailNameAutomationRunning = true;
    try {
      const name = getGeneratedMetaName();
      const firstValue = getEditableValue(first).trim();
      const lastValue = getEditableValue(last).trim();
      const alreadyFilledByUs =
        window.__agentmailNameFilledOnce && firstValue === name.first && lastValue === name.last;

      if (alreadyFilledByUs && !force) {
        await clickNextAfterName();
        return { ok: true, message: "Name already filled; Next click queued." };
      }

      // If Meta/old script put both names in one box, clear and set both fields correctly.
      if (force || firstValue !== name.first || !valueLooksLikeName(firstValue) || firstValue.includes(" ")) {
        if (!(await fillStrong(first, name.first, { kind: "first-name" }))) {
          await typeLikeHuman(first, name.first);
        }
      }

      const latestLastValue = getEditableValue(last).trim();
      if (force || latestLastValue !== name.last || !valueLooksLikeName(latestLastValue) || latestLastValue.includes(" ")) {
        if (!(await fillStrong(last, name.last, { kind: "last-name" }))) {
          await typeLikeHuman(last, name.last);
        }
      }

      // Final exact verification before Next. Do not click Next with swapped/mixed names.
      const finalFirst = getEditableValue(first).trim();
      const finalLast = getEditableValue(last).trim();
      if (finalFirst !== name.first || finalLast !== name.last) {
        await fillStrong(first, name.first, { kind: "first-name" });
        await fillStrong(last, name.last, { kind: "last-name" });
      }

      window.__agentmailNameFilledOnce = true;
      await sleep(20);
      await clickNextAfterName();
      return { ok: true, message: `Name filled fast: ${name.first} ${name.last}` };
    } finally {
      window.__agentmailNameAutomationRunning = false;
    }
  }

  const MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  function isMetaDobPage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("date of birth") ||
      pageText.includes("what's your date of birth") ||
      pageText.includes("what is your date of birth") ||
      pageText.includes("use your own date of birth")
    );
  }

  function getGeneratedMetaDob() {
    // User requested: Day select kora lagbe na; only Year 1999 select korbe.
    if (window.__agentmailGeneratedMetaDob) return window.__agentmailGeneratedMetaDob;

    const day = null;
    const year = 1999;

    window.__agentmailGeneratedMetaDob = { day, year };
    try {
      sessionStorage.removeItem("agentmail_meta_dob_day");
      sessionStorage.setItem("agentmail_meta_dob_year", "1999");
    } catch (error) {
      // Ignore storage errors.
    }

    return window.__agentmailGeneratedMetaDob;
  }

  function selectOptionNumbers(select) {
    return [...(select.options || [])]
      .map((option) => parseInt(normalizeText(option.textContent || option.label || option.value), 10))
      .filter((num) => Number.isFinite(num));
  }

  function findDobSelects() {
    const selects = queryAllDeep("select").filter((select) => !select.disabled);
    const result = { day: null, month: null, year: null };

    for (const select of selects) {
      const attrs = normalizeText([
        select.name,
        select.id,
        select.getAttribute("aria-label"),
        select.getAttribute("data-testid"),
        select.getAttribute("title"),
        select.closest("label")?.innerText,
        select.parentElement?.innerText
      ].filter(Boolean).join(" "));

      const numbers = selectOptionNumbers(select);
      const min = numbers.length ? Math.min(...numbers) : null;
      const max = numbers.length ? Math.max(...numbers) : null;
      const optionText = normalizeText([...(select.options || [])].slice(0, 20).map((option) => option.textContent || option.label || option.value).join(" "));
      const hasMonthNames = MONTH_NAMES.some((month) => optionText.includes(month.toLowerCase()));

      if (!result.day && (attrs.includes("day") || (numbers.length >= 28 && min >= 1 && max <= 31))) {
        result.day = select;
        continue;
      }

      if (!result.year && (attrs.includes("year") || (numbers.length >= 40 && min <= 1980 && max >= 1999))) {
        result.year = select;
        continue;
      }

      if (!result.month && (attrs.includes("month") || hasMonthNames)) {
        result.month = select;
      }
    }

    return result;
  }

  function setSelectValue(select, wantedValue) {
    if (!select) return false;
    try { select.focus({ preventScroll: true }); } catch (error) {}
    const wanted = String(wantedValue).toLowerCase();
    const option = [...(select.options || [])].find((opt) =>
      normalizeText(opt.value) === wanted ||
      normalizeText(opt.textContent || opt.label) === wanted
    ) || [...(select.options || [])].find((opt) =>
      normalizeText(opt.textContent || opt.label || opt.value).includes(wanted)
    );

    if (!option) return false;

    const previous = select.value;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")?.set;
    if (setter) setter.call(select, option.value);
    else select.value = option.value;
    select.selectedIndex = option.index;

    // React keeps its own "last seen value" in _valueTracker. If it already holds
    // 1999 from an earlier attempt, React would see "no change" and ignore us -
    // so store a value that can never match, forcing a real onChange.
    const tracker = select._valueTracker;
    if (tracker) { try { tracker.setValue("__agentmail__"); } catch (error) { try { tracker.setValue(previous); } catch (error2) {} } }

    select.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    select.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    flash(select);
    return true;
  }

  function findDobControl(label) {
    const lowerLabel = label.toLowerCase();
    const candidates = queryAllDeep("button, [role='button'], [role='combobox'], div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        role: normalizeText(el.getAttribute("role")),
        area: rectArea(el)
      }))
      .filter((item) => item.text.includes(lowerLabel))
      // Containers (long text / many numbers / nested controls) are never the control itself.
      .filter((item) => item.text.length <= 60)
      .filter((item) => (item.text.match(/\b(19|20)\d{2}\b/g) || []).length <= 1)
      .filter((item) => item.role !== "option" && item.role !== "listbox")
      .filter((item) => item.area > 100 && item.area < 260000)
      .sort((a, b) => a.area - b.area);

    if (!candidates.length) return null;
    const best = candidates[0].el;
    const role = (best.getAttribute("role") || "").toLowerCase();
    const realControl =
      best.tagName === "SELECT" || best.tagName === "BUTTON" ||
      ["combobox", "button", "textbox"].includes(role) ||
      best.hasAttribute("tabindex") || best.hasAttribute("aria-haspopup") || best.hasAttribute("aria-expanded");
    return realControl ? best : getClickableTarget(best);
  }

  async function chooseDropdownOption(control, wantedValue) {
    if (!control) return false;
    const wanted = String(wantedValue).toLowerCase();
    const numericWanted = Number(wantedValue);
    const isYear = Number.isFinite(numericWanted) && numericWanted >= 1900;

    const optionSelector = "button, [role='option'], [role='button'], div, span, li";
    const getNodes = (scope = document) => {
      if (scope === document) return queryAllDeep(optionSelector);
      try { return [...scope.querySelectorAll(optionSelector)]; }
      catch (error) { return []; }
    };

    const findOption = (scope = document) => getNodes(scope)
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          el,
          text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
          area: rect.width * rect.height,
          top: rect.top,
          height: rect.height
        };
      })
      .filter((item) => item.text === wanted)
      .filter((item) => item.area > 20 && item.area < 240000)
      .sort((a, b) => a.area - b.area)[0];

    const clickFound = (scope = document) => {
      const option = findOption(scope);
      if (!option) return false;
      fireRealisticClick(getClickableTarget(option.el));
      flash(option.el);
      return true;
    };

    const sendKey = (target, key) => {
      const code = key.startsWith("Arrow") ? key : (/^\d$/.test(key) ? `Digit${key}` : key);
      target.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key, code }));
      if (/^\d$/.test(key)) target.dispatchEvent(new KeyboardEvent("keypress", { bubbles: true, composed: true, key, code }));
      target.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key, code }));
    };

    // Open dropdown and try visible/typeahead immediately.
    control.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    control.focus?.();
    fireRealisticClick(control);
    await sleep(5);
    if (clickFound()) return true;

    const active = document.activeElement || control;
    for (const char of String(wantedValue)) sendKey(active, char);
    sendKey(active, "Enter");
    await sleep(8);
    if (clickFound()) return true;

    const scrollables = () => queryAllDeep("div, ul, ol, [role='listbox']")
      .filter((el) => isVisible(el) && el.scrollHeight > el.clientHeight + 20)
      .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));

    const list = scrollables()[0];
    if (list) {
      const getVisibleNumbers = () => getNodes(list)
        .filter((el) => isVisible(el))
        .map((el) => {
          const textValue = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
          const number = Number((textValue.match(/\d{1,4}/) || [])[0]);
          const rect = el.getBoundingClientRect();
          return { el, number, top: rect.top, height: rect.height || 40, text: textValue };
        })
        .filter((item) => Number.isFinite(item.number))
        .sort((a, b) => a.top - b.top);

      if (isYear) {
        // Exact jump: estimate item height and scroll straight to 1999 instead of slow sweeping.
        for (let pass = 0; pass < 4; pass += 1) {
          const visible = getVisibleNumbers().filter((item) => item.number >= 1900 && item.number <= 2100);
          if (clickFound(list) || clickFound()) return true;
          if (visible.length) {
            const topYear = visible[0].number;
            const second = visible.find((item) => item.number !== topYear);
            const stepByRect = second ? Math.abs(second.top - visible[0].top) : 0;
            const itemHeight = Math.max(28, Math.min(72, stepByRect || visible[0].height || 44));
            // Most Meta year lists are descending, current year to older years.
            const direction = visible.length > 1 && visible[1].number > visible[0].number ? -1 : 1;
            list.scrollTop += direction * (topYear - numericWanted) * itemHeight;
          } else {
            list.scrollTop = Math.max(0, list.scrollTop + 1150);
          }
          list.dispatchEvent(new Event("scroll", { bubbles: true }));
          await sleep(12);
        }
      }

      const max = Math.max(0, list.scrollHeight - list.clientHeight);
      const positions = isYear
        ? [900, 1050, 1200, 1350, 1500, Math.floor(max * 0.22), Math.floor(max * 0.28)]
        : [0, 60, 120, 180, 240, 360];

      for (const pos of positions) {
        list.scrollTop = Math.max(0, Math.min(max, pos));
        list.dispatchEvent(new Event("scroll", { bubbles: true }));
        await sleep(6);
        if (clickFound(list) || clickFound()) return true;
      }
    } else {
      for (let attempt = 0; attempt < 5; attempt += 1) {
        window.scrollBy(0, isYear ? 520 : 160);
        await sleep(6);
        if (clickFound()) return true;
      }
    }

    return false;
  }

  function numberFromText(text, min, max) {
    const nums = String(text || "").match(/\d{1,4}/g) || [];
    for (const value of nums) {
      const num = Number(value);
      if (num >= min && num <= max) return num;
    }
    return null;
  }

  function dispatchKey(target, key) {
    const code = key.startsWith("Arrow") ? key : (/^\d$/.test(key) ? `Digit${key}` : key);
    target.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key, code }));
    target.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key, code }));
  }

  async function chooseYearKeyboardFast(control, wantedYear) {
    if (!control) return false;
    const wanted = String(wantedYear);
    const current = numberFromText(control.innerText || control.textContent || control.getAttribute("aria-label"), 1900, 2100) || 2026;
    const diff = Math.min(70, Math.abs(current - wantedYear));

    const tryDirection = async (direction) => {
      control.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      control.focus?.();
      fireRealisticClick(control);
      await sleep(4);
      const target = document.activeElement || control || document.body;
      for (const char of wanted) dispatchKey(target, char);
      dispatchKey(target, "Enter");
      await sleep(8);
      let nowText = normalizeText(control.innerText || control.textContent || control.getAttribute("aria-label"));
      if (nowText.includes(wanted)) return true;

      fireRealisticClick(control);
      await sleep(4);
      for (let i = 0; i < diff; i += 1) dispatchKey(document.activeElement || target, direction);
      dispatchKey(document.activeElement || target, "Enter");
      await sleep(16);
      nowText = normalizeText(control.innerText || control.textContent || control.getAttribute("aria-label"));
      return nowText.includes(wanted);
    };

    if (await tryDirection("ArrowDown")) return true;
    if (await tryDirection("ArrowUp")) return true;
    return false;
  }

  function getYearFromControl(control) {
    if (!control) return null;
    return numberFromText(control.innerText || control.textContent || control.getAttribute?.("aria-label") || control.value, 1900, 2100);
  }

  function findDobYearControl() {
    // 1) LABEL-FIRST (what real Meta pages need): start at the visible "Year"
    //    label and take the control inside that same field. No scoring can beat
    //    this, because it is the field the user actually sees.
    try {
      const field = dobYearFieldRoot();
      if (field) {
        const inner = field.querySelector?.("select, [role='combobox'], [aria-haspopup], [aria-expanded], button, [tabindex]");
        if (inner && isVisible(inner)) return inner;
        if (isVisible(field)) return field;
      }
    } catch (error) {}

    // 2) scoring fallback (used when there is no readable "Year" label)
    const candidates = queryAllDeep("button, [role='button'], [role='combobox'], [tabindex], div, span")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const role = normalizeText(el.getAttribute("role"));
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        const parentText = normalizeText([
          el.parentElement?.innerText,
          el.parentElement?.parentElement?.innerText,
          el.closest("label")?.innerText
        ].filter(Boolean).join(" "));
        const yearNumber = numberFromText(text, 1900, 2100);
        let score = 0;
        if (text === "year" || text.includes("year")) score += 100;
        if (parentText.includes("year")) score += 60;
        if (yearNumber) score += 85;
        if (role === "combobox" || role === "button" || el.tagName === "BUTTON" || el.tabIndex >= 0) score += 35;
        // A real dropdown announces itself - trust that over geometry.
        if (el.hasAttribute?.("aria-haspopup") || el.hasAttribute?.("aria-expanded")) score += 45;
        if (rect.height >= 28 && rect.height <= 90) score += 25;
        if (rect.height > 24 && rect.height < 120 && rect.width >= 40) score += 13;
        if (rect.width >= 50 && rect.width <= Math.max(420, window.innerWidth * 0.9)) score += 10;
        if (text.includes("day") || text.includes("month")) score -= 80;
        // Only a TALL full-width element is a container; a full-width row control is not.
        if ((rect.width > window.innerWidth * 0.95 && rect.height > 120) || rect.height > 180) score -= 80;

        // --- container / option guards (this is what used to pick the whole
        // page wrapper that merely CONTAINS the years, so the dropdown never
        // opened and the wrong year could get committed) ---
        const yearMentions = (text.match(/\b(19|20)\d{2}\b/g) || []).length;
        if (yearMentions >= 2) score -= 160;
        if (text.length > 60) score -= 80;
        if (role === "option" || role === "listbox") score -= 220;
        try {
          if (el.querySelector?.("[role='combobox'], [role='listbox'], select, [aria-haspopup], [aria-expanded]")) score -= 140;
        } catch (error) {}
        return { el, text, score, area: rect.width * rect.height, top: rect.top };
      })
      .filter((item) => item.score > 60 && item.area > 60 && item.area < 180000)
      .sort((a, b) => (b.score - a.score) || (a.area - b.area) || (a.top - b.top));

    if (!candidates.length) return findDobControl("year");

    const best = candidates[0].el;
    const role = (best.getAttribute("role") || "").toLowerCase();
    const realControl =
      best.tagName === "SELECT" ||
      best.tagName === "BUTTON" ||
      role === "combobox" ||
      role === "button" ||
      role === "textbox" ||
      best.hasAttribute("tabindex") ||
      best.hasAttribute("aria-haspopup") ||
      best.hasAttribute("aria-expanded");
    // A dropdown control must be clicked itself. Walking up to a wrapper used to
    // hit the whole form container, which is why the year list never opened.
    return realControl ? best : getClickableTarget(best);
  }

  // ================================================================
  // STRONG YEAR SELECT
  // Commits 1999 DIRECTLY - never selects a wrong year first, and never
  // presses Next until the control really reads 1999.
  // ================================================================
  // Walks up the tree: hidden / aria-hidden / inline display:none anywhere above
  // the node means it is not on screen - even when the browser does not tell us.
  // v2.9 SUN: the raw walk. Kept separate so the answer can be remembered.
  function computeHasHiddenAncestor(el) {
    try {
      for (let node = el, depth = 0; node && depth < 24; node = node.parentElement, depth += 1) {
        if (node.hasAttribute?.("hidden") || node.hidden) return true;
        if (node.getAttribute?.("aria-hidden") === "true") return true;
        const style = node.getAttribute?.("style");
        if (style && /display\s*:\s*none/i.test(style)) return true;
        const cls = node.getAttribute?.("class");
        if (cls && /(^|\s)(hidden|is-hidden|d-none|hidden-element)(\s|$)/.test(cls)) return true;
      }
    } catch (error) {}
    return false;
  }

  let hiddenAncestorCache = new WeakMap();
  let hiddenAncestorCacheAt = 0;
  let hiddenAncestorCacheVersion = -1;

  function hasHiddenAncestor(el) {
    try {
      const now = Date.now();
      // 16 ms: a list that opens between two ticks must never be remembered as
      // hidden (that stale "hidden" used to cost the SUN path its first chance).
      if (now - hiddenAncestorCacheAt > 16 || SMOOTH.domVersion !== hiddenAncestorCacheVersion) {
        hiddenAncestorCache = new WeakMap();
        hiddenAncestorCacheAt = now;
        hiddenAncestorCacheVersion = SMOOTH.domVersion;
      }
      const cached = hiddenAncestorCache.get(el);
      if (cached !== undefined) return cached;
      const answer = computeHasHiddenAncestor(el);
      hiddenAncestorCache.set(el, answer);
      return answer;
    } catch (error) {
      return computeHasHiddenAncestor(el);
    }
  }

  function yearOptionsInList(list) {
    if (!list) return [];
    try {
      const out = [];
      const nodes = list.querySelectorAll("button, [role='option'], [role='button'], li, div, span");
      for (const el of nodes) {
        if (el.hidden || el.hasAttribute?.("hidden")) continue;
        if (el.getAttribute?.("aria-hidden") === "true") continue;
        // ---- v2.9 SUN: cheap skips first ------------------------------------
        // A year row has at most one child element and its text carries the
        // digits; everything else is dropped before the ancestor walk and the
        // layout reads below. The result is identical to the old filter chain.
        if (el.childElementCount > 1) continue;
        const raw = String(el.textContent || "") + " " + String(el.getAttribute?.("aria-label") || "");
        if (!/\d{4}/.test(raw)) continue;
        if (hasHiddenAncestor(el)) continue;
        if (!isVisible(el) || isInsideAgentmailFloatingWidget(el)) continue;
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        const year = /^\d{4}$/.test(text) ? Number(text) : numberFromText(text, 1900, 2100);
        if (!Number.isFinite(year) || year < 1900 || year > 2100) continue;
        const area = rect.width * rect.height;
        if (!(area > 20 && area < 240000)) continue;
        out.push({ el, year, text, area, top: rect.top });
      }
      return out;
    } catch (error) {
      return [];
    }
  }

  function highlightedYearOption(list) {
    if (!list) return null;
    try {
      const el = list.querySelector("[aria-selected='true'], [data-selected='true'], .selected, [class*='selected'], [class*='focused']");
      if (!el || !isVisible(el)) return null;
      const year = numberFromText(el.innerText || el.textContent || "", 1900, 2100);
      return Number.isFinite(year) ? { el, year } : null;
    } catch (error) {
      return null;
    }
  }

  function pickYearOption(list, wantedYear) {
    const options = yearOptionsInList(list).filter((item) => item.year === wantedYear);
    if (!options.length) return null;
    const exact = options.filter((item) => /^\d{4}$/.test(item.text));
    const pool = exact.length ? exact : options;
    return pool.sort((a, b) => a.area - b.area || a.top - b.top)[0];
  }

  async function scrollListToYear(list, wantedYear, attempts = 8) {
    if (!list) return false;

    const readWindow = () => {
      const items = yearOptionsInList(list).sort((a, b) => a.top - b.top);
      if (!items.length) return null;
      const years = items.map((item) => item.year);
      const min = Math.min(...years);
      const max = Math.max(...years);
      let step = 0;
      const gaps = [];
      for (let i = 1; i < items.length; i += 1) gaps.push(items[i].top - items[i - 1].top);
      const positive = gaps.filter((gap) => gap > 2).sort((a, b) => a - b);
      if (positive.length) step = positive[Math.floor(positive.length / 2)];
      if (!step) {
        const rect = getRect(items[0].el);
        step = Math.max(1, rect ? rect.height : 1);
      }
      return {
        items, min, max, step,
        firstYear: items[0].year,
        lastYear: items[items.length - 1].year,
        consecutive: (max - min + 1) === items.length
      };
    };

    const maxScroll = Math.max(0, list.scrollHeight - list.clientHeight);
    if (!maxScroll) return yearOptionsInList(list).some((item) => item.year === wantedYear);

    for (let i = 0; i < attempts; i += 1) {
      const win = readWindow();
      if (win && win.items.some((item) => item.year === wantedYear)) return true;

      if (!win) {
        if (list.scrollTop >= maxScroll) break;
        list.scrollTop = Math.min(maxScroll, list.scrollTop + Math.max(40, list.clientHeight * 0.9));
      } else if (win.consecutive && win.step > 0) {
        // Uniform rows (virtualized lists): jump straight to the offset that holds
        // the wanted year instead of guessing and bouncing around.
        const descending = win.firstYear >= win.lastYear;
        const index = descending ? (win.max - wantedYear) : (wantedYear - win.min);
        const target = index * win.step - Math.max(0, (list.clientHeight - win.step) / 2);
        const next = Math.max(0, Math.min(maxScroll, target));
        if (Math.abs(next - list.scrollTop) < 2) {
          list.scrollTop = Math.max(0, Math.min(maxScroll, list.scrollTop + (index >= 0 ? win.step : -win.step)));
        } else {
          list.scrollTop = next;
        }
      } else {
        const span = Math.max(1, win.max - win.min);
        const ratio = Math.max(0, Math.min(1, (win.max - wantedYear) / span));
        const target = ratio * maxScroll;
        const next = Math.abs(target - list.scrollTop) < 4
          ? Math.max(0, Math.min(maxScroll, list.scrollTop + (wantedYear < win.min ? list.clientHeight : -list.clientHeight)))
          : target;
        list.scrollTop = Math.max(0, Math.min(maxScroll, next));
      }

      try { list.dispatchEvent(new Event("scroll", { bubbles: true })); } catch (error) {}
      await sleep(30);
    }

    const done = readWindow();
    return Boolean(done && done.items.some((item) => item.year === wantedYear));
  }

  // Click a list row SAFELY: never press a point that belongs to a different year
  // (that is how the wrong year got committed before).
  function optionIsSafelyClickable(el) {
    try {
      if (!el || el.isConnected === false) return false;   // stale node from an old screen
      if (!dobStepStillActive()) return false;
      const rect = getRect(el);
      if (!rect || !rect.width || !rect.height) return false;
      const x = rect.left + rect.width * (0.42 + Math.random() * 0.16);
      const y = rect.top + rect.height * (0.42 + Math.random() * 0.16);
      const hit = document.elementFromPoint(x, y);
      if (!hit || hit === el || el.contains(hit) || (hit.contains && hit.contains(el))) return true;
      const hitRole = hit.getAttribute?.("role") || "";
      const hitText = normalizeText(hit.textContent || "");
      const hitIsOtherYear = hitRole === "option" || /^(19|20)\d{2}$/.test(hitText) || /^(19|20)\d{2}$/.test(normalizeText(hit.innerText || ""));
      return !hitIsOtherYear;
    } catch (error) {
      return false;
    }
  }

  // ------------------------------------------------------------------
  // YEAR ENGINE (v2.2): the ONLY truth is what the page actually SHOWS.
  // Real Meta pages render a visible label + value ("Year  2026") and may keep
  // a hidden/controlled <select> in sync via React state. Reading the hidden
  // select alone lied to us, so the page submitted with 2026 and Meta answered
  // "Select a valid option.". Now we read the visible field, commit, and verify.
  // ------------------------------------------------------------------
  function dobYearFieldRoot() {
    try {
      const labels = queryAllDeep("label, span, div, p")
        .filter((el) => isVisible(el))
        .filter((el) => /^year$/.test(normalizeText(el.textContent || el.getAttribute?.("aria-label") || "")));
      for (const label of labels) {
        let node = label.parentElement;
        for (let up = 0; node && up < 5; up += 1, node = node.parentElement) {
          const text = normalizeText(node.innerText || node.textContent || "");
          if (text.length > 260) break;
          const hasControl = Boolean(node.querySelector?.("select, [role='combobox'], [aria-haspopup], [aria-expanded], button"));
          const nums = text.match(/\\b(19|20)\\d{2}\\b/g) || [];
          if (hasControl && nums.length <= 2) return node;
        }
      }
    } catch (error) {}
    return null;
  }

  function readVisibleYearState() {
    const state = { root: null, shown: null, control: null, nativeSelect: null, nativeYear: null, errorText: "" };
    try {
      state.root = dobYearFieldRoot();
      if (state.root) {
        const text = normalizeText(state.root.innerText || state.root.textContent || "");
        state.shown = numberFromText(text, 1900, 2100);
        const sel = state.root.querySelector?.("select") || null;
        if (sel) {
          state.nativeSelect = sel;
          state.nativeYear = numberFromText(sel.options?.[sel.selectedIndex]?.textContent || sel.value, 1900, 2100);
        }
        state.control = state.root.querySelector?.("[role='combobox'], [aria-haspopup], [aria-expanded]") || sel || state.root;
      } else {
        const selects = findDobSelects();
        const sel = selects && selects.year;
        if (sel) {
          state.nativeSelect = sel;
          state.nativeYear = numberFromText(sel.options?.[sel.selectedIndex]?.textContent || sel.value, 1900, 2100);
          state.shown = state.nativeYear;
          state.control = sel;
        }
      }
      let pageText = "";
      try { pageText = normalizeText(typeof getPageTextFast === "function" ? getPageTextFast() : document.body.innerText); } catch (error) {}
      const match = pageText.match(/select a valid option|please select a valid|enter a valid option|invalid date of birth/i);
      state.errorText = match ? match[0] : "";
    } catch (error) {}
    return state;
  }

  // Meta keeps hidden error nodes around too, so only VISIBLE error text counts.
  function dobErrorText() {
    try {
      const pattern = /select a valid option|please select a valid|enter a valid option|invalid date of birth/i;
      for (const el of queryAllDeep("div, span, p")) {
        if (el.hasAttribute?.("hidden") || el.hidden) continue;
        if (el.getAttribute?.("aria-hidden") === "true") continue;
        if (hasHiddenAncestor(el)) continue;
        if (isInsideAgentmailFloatingWidget(el)) continue;   // our own HUD text is not page text
        if (!isVisible(el)) continue;
        const text = normalizeText(el.innerText || el.textContent || "");
        if (!text || text.length > 90) continue;
        const match = text.match(pattern);
        if (match) return match[0];
      }
    } catch (error) {}
    return "";
  }

  // A controlled form can flash the right value and revert it a tick later, so a
  // single read is not proof. The year must HOLD for a moment before we submit.
  async function yearConfirmedStable(wanted = 1999, holdMs = 260) {
    // Pre-submit check: keep the full hold only on pages that have actually been
    // seen snapping back; a normal page is confirmed in half the time.
    if (!ultraSawSnapback) holdMs = Math.min(holdMs, 150);
    if (!yearUiShows(wanted)) return false;
    const startedAt = Date.now();
    while (Date.now() - startedAt < holdMs) {
      await sleep(65);
      if (!yearUiShows(wanted)) return false;
    }
    return true;
  }

  // True only while this really is still the birth-year step.
  function dobStepStillActive() {
    try {
      if (isMetaDobPage()) return true;
      return yearFieldExists();
    } catch (error) {
      return false;
    }
  }

  function yearFieldExists() {
    try {
      const field = dobYearFieldRoot();
      if (field && isVisible(field)) return true;
      const selects = findDobSelects();
      if (selects && selects.year && isVisible(selects.year)) return true;
      const state = readVisibleYearState();
      return Boolean(state.nativeSelect || state.control);
    } catch (error) {
      return false;
    }
  }

  // v2.8 ORDER: the FIELD itself says 1999. This deliberately ignores the
  // "(N years old)" text - that hint can lag a moment behind the field, and this
  // check only decides when the password may be pasted, not what gets submitted.
  function dobYearOnScreen(wanted = 1999) {
    try {
      const state = readVisibleYearState();
      if (state.shown === wanted) return true;
      if (state.shown === null && state.nativeYear === wanted) return true;
    } catch (error) {}
    return false;
  }

  // v2.8 ORDER fail-open: when the hold below starts. It exists so a page that
  // resists every year strategy can never hard-stall the whole flow.
  let __agentmailPwdHoldSince = 0;
  const AGENTMAIL_PWD_HOLD_MAX_MS = 20000;

  // True while the password must stay untouched: this is the birth-date step and
  // the year on screen is not 1999 yet. Deliberately synchronous - it must never
  // stall a sweep (the year engine has its own path and its own budget).
  function dobPasswordHeldForYear() {
    try {
      if (!isMetaAuthPage()) return false;
      if (dobYearOnScreen(1999)) { __agentmailPwdHoldSince = 0; return false; }
      // No year control on this step at all (plain "Create a password" screen):
      // there is nothing to wait for - fail open immediately.
      if (!yearFieldExists()) { __agentmailPwdHoldSince = 0; return false; }
      const now = Date.now();
      if (!__agentmailPwdHoldSince) __agentmailPwdHoldSince = now;
      // Safety valve: 1999 lands in well under a second in every tested mode; if
      // the box resists every strategy for 20 s, release rather than stall.
      if (now - __agentmailPwdHoldSince > AGENTMAIL_PWD_HOLD_MAX_MS) {
        __agentmailPwdHoldSince = 0;
        return false;
      }
      return true;
    } catch (error) {
      return false;
    }
  }

  function yearUiShows(wanted) {
    const state = readVisibleYearState();
    const shownOk = state.shown === wanted || (state.shown === null && state.nativeYear === wanted);
    // Meta prints "(N years old)" next to "Date of birth". A child's age there means
    // the page's own state still holds a wrong birth year - never accept that.
    const age = dobAgeHint();
    if (Number.isFinite(age) && age < 13) {
      // EXCEPT when the FIELD was changed by a real click: that runs the page's own
      // handler, so its state has moved and only the printed age text lags behind.
      // A silent native write gets no such trust.
      if (!(shownOk && window.__agentmailYearViaClick)) return false;
    }
    return shownOk;
  }

  // React-safe native commit: fake a real user selection and then WATCH the value
  // for a moment - a controlled select snaps back to state if the event was missed.
  async function reactResyncSelect(select) {
    // Same isolated-world trick for a <select>: tell the page what it is already
    // showing, wait a tick so React stores it, then our real change is accepted.
    try {
      const current = select.value;
      select.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      await sleep(16);
      select.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      await sleep(16);
      if (select.value !== current) {   // a controlled parent re-rendered meanwhile
        select.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        await sleep(12);
      }
    } catch (error) {}
  }

  async function commitYearNative(select, wanted) {
    if (!select || select.tagName !== "SELECT") return false;
    const readValue = () => numberFromText(select.options?.[select.selectedIndex]?.textContent || select.value, 1900, 2100);

    for (let attempt = 0; attempt < 3; attempt += 1) {
      try { select.focus({ preventScroll: true }); } catch (error) {}

      // Attempt 0: a clean programmatic selection (works when React is healthy).
      // Attempt 1: only if the page ignored us, re-announce what it already shows
      //            (tracker resync) and then write for real.
      // Attempt 2: last resort - pick the option by index and re-fire the events.
      if (attempt === 0) {
        setSelectValue(select, wanted);
      } else if (attempt === 1) {
        await reactResyncSelect(select);
        setSelectValue(select, wanted);
      }

      if (attempt === 2 && readValue() !== wanted) {
        const option = [...(select.options || [])].find((opt) =>
          numberFromText(opt.textContent || opt.label || opt.value, 1900, 2100) === wanted);
        if (!option) return false;
        try {
          const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")?.set;
          if (setter) setter.call(select, option.value);
          else select.value = option.value;
        } catch (error) {}
        option.selected = true;
        select.selectedIndex = option.index;
        try { if (select._valueTracker) select._valueTracker.setValue("__agentmail__"); } catch (error) {}
        select.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
        select.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      }

      let stable = true;
      for (const wait of [40, 120, 240]) {
        await sleep(wait);
        if (readValue() !== wanted) { stable = false; break; }
      }
      if (stable) return true;
    }
    return readValue() === wanted;
  }

  // One call that guarantees the birth year: native select first, then the visible
  // dropdown picker, retried, and every time verified against the on-screen value.
  async function ensureYearSelected(wantedYear = 1999) {
    const wanted = Number(wantedYear);
    const startedAt = Date.now();
    let state = readVisibleYearState();
    if (state.shown === wanted && !state.errorText) return true;

    for (let attempt = 0; attempt < 3; attempt += 1) {
      if (!dobStepStillActive()) {
        powerLog("Year step already finished - stopping");
        return yearUiShows(wanted);
      }
      if (Date.now() - startedAt > 6500) {
        powerLog("Year selection budget reached - handing back to the sweep");
        break;
      }
      try { window.__agentmailChainBeat = Date.now(); } catch (error) {}
      // v2.5: ULTRA first - press the visible Year box (the circled area), then
      // commit 1999 instantly. This is the click the user asked to see.
      try {
        if (await ultraSetYear(wanted)) {
          const afterUltra = readVisibleYearState();
          if (afterUltra.shown === wanted || afterUltra.shown === null) return true;
        }
      } catch (error) {}

      const selects = findDobSelects();
      const natives = [state.nativeSelect, selects && selects.year].filter(Boolean);
      for (const select of natives) {
        if (await commitYearNative(select, wanted)) {
          const after = readVisibleYearState();
          if (after.shown === wanted || after.shown === null) return true;
        }
      }

      try {
        if (await chooseYearStrong(wanted)) {
          const after = readVisibleYearState();
          if (after.shown === wanted || after.shown === null) return true;
        }
      } catch (error) {}

      await sleep(50 + randomIndex(50));
      state = readVisibleYearState();
      if (state.shown === wanted) return true;
    }
    return readVisibleYearState().shown === wanted;
  }

  // Meta showed "Select a valid option." -> the field is wrong, so fix it and only
  // then press Next again (max 3 healing submits, never a Next-spam loop).
  async function healDobValidationError(force = false) {
    const state = readVisibleYearState();
    if (!state.errorText) { window.__agentmailDobNextRetries = 0; return false; }
    if (window.__agentmailDobHealRunning) return false;
    window.__agentmailDobHealRunning = true;
    try {
      powerLog("Date-of-birth check rejected by the page - fixing the year again");
      const fixed = await ensureYearSelected(1999);
      if (!fixed || !yearUiShows(1999)) return false;
      if ((window.__agentmailDobNextRetries || 0) >= 3) return false;
      window.__agentmailDobNextRetries = (window.__agentmailDobNextRetries || 0) + 1;
      await sleep(140 + randomIndex(160));
      await clickNextAfterDob();
      return true;
    } catch (error) {
      return false;
    } finally {
      window.__agentmailDobHealRunning = false;
    }
  }

  // ------------------------------------------------------------------
  // v2.3 DRAG PICKER: the real mobile page shows an INLINE list of years right
  // under the field (2026, 2025, ... 1905). Programmatic scrolling is not
  // always honoured there, so the engine DRAGS the list like a finger - and the
  // moment 1999 is on screen it taps that exact row. Meta even prints the age
  // ("Date of birth (2 years old)") which tells us instantly when a year is wrong.
  // ------------------------------------------------------------------
  function dobAgeHint() {
    try {
      const text = normalizeText(getPageTextFast());
      const match = text.match(/date of birth\s*\((\d{1,3})\s*years?\s*old\)/) || text.match(/\((\d{1,3})\s*years?\s*old\)/);
      return match ? Number(match[1]) : null;
    } catch (error) {
      return null;
    }
  }

  function yearRowMatches(el, wanted) {
    if (!el) return false;
    const wantedText = String(wanted);
    try {
      for (let node = el, depth = 0; node && depth < 3; node = node.parentElement, depth += 1) {
        const text = normalizeText(node.innerText || node.textContent || "");
        if (text === wantedText) return true;
      }
      const child = el.querySelector?.("span, div, p");
      return Boolean(child && normalizeText(child.textContent || "") === wantedText);
    } catch (error) {
      return false;
    }
  }

  function dispatchGesture(el, x, y, kind, withClick = true) {
    if (!el) return;
    const init = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y,
      button: 0, buttons: kind === "up" ? 0 : 1,
      pointerId: 1, pointerType: "touch", isPrimary: true
    };
    try {
      const Pointer = window.PointerEvent || window.MouseEvent;
      if (kind === "down") {
        el.dispatchEvent(new Pointer("pointerdown", init));
        el.dispatchEvent(new MouseEvent("mousedown", init));
      } else if (kind === "move") {
        el.dispatchEvent(new Pointer("pointermove", init));
        el.dispatchEvent(new MouseEvent("mousemove", init));
      } else {
        el.dispatchEvent(new Pointer("pointerup", init));
        el.dispatchEvent(new MouseEvent("mouseup", init));
        // Only a TAP may click. Emitting a click at the end of a swipe selected
        // whatever row the finger happened to stop on - the wrong-year bug.
        if (withClick) el.dispatchEvent(new MouseEvent("click", init));
      }
    } catch (error) {}
    try {
      if (typeof window.TouchEvent === "function" && typeof window.Touch === "function") {
        const touch = new window.Touch({ identifier: 1, target: el, clientX: x, clientY: y, pageX: x, pageY: y, screenX: x, screenY: y });
        const active = kind === "up" ? [] : [touch];
        el.dispatchEvent(new window.TouchEvent(
          kind === "down" ? "touchstart" : kind === "move" ? "touchmove" : "touchend",
          { bubbles: true, cancelable: true, composed: true, view: window, touches: active, targetTouches: active, changedTouches: [touch] }
        ));
      }
    } catch (error) {}
  }

  // A finger drag: press, glide, release - with tiny human jitter.
  async function humanDrag(el, x0, y0, x1, y1, steps = 8) {
    if (!el || !Number.isFinite(x0) || !Number.isFinite(y0)) return false;
    const startEl = document.elementFromPoint(x0, y0) || el;
    dispatchGesture(startEl, x0, y0, "down");
    await sleep(10 + randomIndex(12));
    for (let i = 1; i <= steps; i += 1) {
      const t = i / steps;
      const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      const x = x0 + (x1 - x0) * ease + (randomIndex(7) - 3);
      const y = y0 + (y1 - y0) * ease;
      dispatchGesture(document.elementFromPoint(x, y) || startEl, x, y, "move");
      await sleep(7 + randomIndex(6));
    }
    // swipe release: no click (a real drag never clicks)
    dispatchGesture(document.elementFromPoint(x1, y1) || startEl, x1, y1, "up", false);
    return true;
  }

  // Tap a point - but refuse unless that point really belongs to the wanted row.
  async function tapPointAt(x, y, wantedText) {
    try {
      const hit = document.elementFromPoint(x, y);
      if (!hit) return false;
      if (wantedText != null && !yearRowMatches(hit, wantedText)) return false;
      dispatchGesture(hit, x, y, "down");
      await sleep(16 + randomIndex(22));
      const upY = Math.max(1, y - 1);
      const upHit = document.elementFromPoint(x, upY) || hit;
      if (wantedText != null && upHit !== hit && !hit.contains(upHit) && !upHit.contains(hit)) {
        if (!yearRowMatches(upHit, wantedText)) return false;   // a different year sits there
      }
      dispatchGesture(hit, x, upY, "up");   // always release on the verified element
      return true;
    } catch (error) {
      return false;
    }
  }

  // Tap a specific year row: the point must belong to that row, and the click is
  // dispatched on that very row - never on whatever happens to sit under (y - 1).
  async function tapRowElement(rowEl, wanted, sun = false) {
    if (!rowEl || rowEl.isConnected === false) return false;
    // FLASH: tap the row exactly where it is right NOW. On a carousel we have just
    // positioned ourselves, calling scrollIntoView would scroll the list's own
    // (overflow:hidden) host and throw the rows out of place - the tap then chases
    // a row that is no longer under the finger. Scrolling is the LAST resort.
    const attempt = async () => {
      // SUN SPEED: the rect was verified a moment ago by the caller - skip the
      // settle wait; the wrong-row / covered checks below still guard the tap.
      if (!sun) await settleRect(rowEl);
      const rect = getRect(rowEl);
      if (!rect || !rect.width || !rect.height) return false;
      const x = rect.left + rect.width * (0.40 + Math.random() * 0.20);
      const y = rect.top + rect.height * (0.45 + Math.random() * 0.18);
      const hit = document.elementFromPoint(x, y);
      if (hit && hit !== rowEl && !rowEl.contains(hit) && !hit.contains(rowEl)) return false;   // covered by something else
      if (hit && !yearRowMatches(hit, wanted)) return false;                                     // wrong row in the way
      try { window.__agentmailYearViaClick = true; } catch (error) {}
      dispatchGesture(hit || rowEl, x, y, "down");
      // SUN SPEED: 1 ms. The gesture still carries all four event families
      // (pointer/mouse/touch down + up + click) - only the pause is gone.
      await sleep(sun ? 1 : 7 + randomIndex(7));
      dispatchGesture(rowEl, x, y, "up");     // click lands on the verified row
      flash(rowEl);
      return true;
    };
    if (await attempt()) return true;
    // the finger really cannot reach it where it is - bring it into view ONCE
    try { rowEl.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
    return await attempt();
  }

  // Tap an element we have identified: the point must really belong to it, and
  // the click is dispatched on that element - never on whatever sits beneath.
  async function tapVerifiedElement(element, jitterX = 0.5, jitterY = 0.55) {
    if (!element || element.isConnected === false) return false;
    const rect = getRect(element);
    if (!rect || !rect.width || !rect.height) return false;
    const x = rect.left + rect.width * (jitterX + (Math.random() * 0.16 - 0.08));
    const y = rect.top + rect.height * jitterY;
    const hit = document.elementFromPoint(x, y);
    if (hit && hit !== element && !element.contains(hit) && !hit.contains(element)) return false;
    dispatchGesture(hit || element, x, y, "down");
    await sleep(6 + randomIndex(6));
    dispatchGesture(element, x, y, "up");
    return true;
  }

  // The list of years plus the element that actually scrolls it.
  let ultraPickerMemo = { at: 0, found: null };

  // v3.0 LITE: same cheap skips as yearOptionsInList, but it stops at the FIRST
  // exact match - a 127-row list costs a fraction of a full scan.
  function findYearRowFast(list, wanted) {
    if (!list) return null;
    try {
      for (const el of list.querySelectorAll("button, [role='option'], [role='button'], li, div, span")) {
        if (el.hidden || el.hasAttribute?.("hidden")) continue;
        if (el.getAttribute?.("aria-hidden") === "true") continue;
        if (el.childElementCount > 1) continue;
        const raw = String(el.textContent || "") + " " + String(el.getAttribute?.("aria-label") || "");
        if (!/\d{4}/.test(raw)) continue;
        const text = normalizeText(el.textContent || el.getAttribute?.("aria-label"));
        const year = /^\d{4}$/.test(text) ? Number(text) : numberFromText(text, 1900, 2100);
        if (year !== wanted) continue;
        if (hasHiddenAncestor(el)) continue;
        if (!isVisible(el) || isInsideAgentmailFloatingWidget(el)) continue;
        const rect = el.getBoundingClientRect();
        const area = rect.width * rect.height;
        if (!(area > 20 && area < 240000)) continue;
        return { el, year, text, area, top: rect.top };
      }
    } catch (error) {}
    return null;
  }

  // "is this a year list at all?" - cheap text-only counting, no layout reads.
  function hasYearRowsFast(list, need = 3) {
    if (!list) return false;
    try {
      let count = 0;
      for (const el of list.querySelectorAll("button, [role='option'], [role='button'], li, div, span")) {
        if (el.childElementCount > 1) continue;
        const text = normalizeText(el.textContent || "");
        if (!/^\d{4}$/.test(text)) continue;
        count += 1;
        if (count >= need) return true;
      }
    } catch (error) {}
    return false;
  }

  function yearPickerContainer() {
    try {
      // The deep scan below is the single most expensive thing this engine does,
      // and the ultra chain asks for it several times per pass. Reuse the answer
      // for 120 ms - but only after re-validating that it is really still there.
      const memo = ultraPickerMemo;
      if (memo.found && Date.now() - memo.at < 120) {
        const list = memo.found.list;
        try {
          if (list && list.isConnected !== false && !hasHiddenAncestor(list) && isVisible(list) && hasYearRowsFast(list)) {
            return memo.found;
          }
        } catch (error) {}
      }
      const lists = [];
      // the same walk the long path uses: the nearest ancestor that really scrolls
      const scrollerOf = (list) => {
        let scroller = list;
        for (let node = list, depth = 0; node && depth < 7; node = node.parentElement, depth += 1) {
          if (node.scrollHeight > node.clientHeight + 12) { scroller = node; break; }
        }
        return scroller;
      };
      // v3.0 LITE: a container we already know (prewarmed while the page was idle)
      // wins immediately - no page-wide scan at all when it is now visible.
      const pre = window.__agentmailSunPrewarm;
      if (pre && pre.container && pre.container.isConnected !== false &&
          !hasHiddenAncestor(pre.container) && isVisible(pre.container)) {
        if (hasYearRowsFast(pre.container)) {
          ultraPickerMemo = { at: Date.now(), found: { list: pre.container, scroller: scrollerOf(pre.container) } };
          return ultraPickerMemo.found;
        }
      }
      // semantic containers first (role=listbox / ul / ol) - they are cheap and
      // almost always the real answer on the live page.
      const semantic = [];
      for (const el of queryAllDeep("[role='listbox'], ul, ol")) {
        if (el.hasAttribute?.("hidden") || el.hidden) continue;
        if (el.getAttribute?.("aria-hidden") === "true") continue;
        if (hasHiddenAncestor(el)) continue;
        if (!isVisible(el) || isInsideAgentmailFloatingWidget(el)) continue;
        if (!hasYearRowsFast(el)) continue;
        semantic.push({ el, count: el.childElementCount });
      }
      if (semantic.length) {
        const list = semantic.sort((a, b) => b.count - a.count)[0].el;
        ultraPickerMemo = { at: Date.now(), found: { list, scroller: scrollerOf(list) } };
        return ultraPickerMemo.found;
      }
      for (const el of queryAllDeep("div")) {
        if (el.hasAttribute?.("hidden") || el.hidden) continue;
        if (el.getAttribute?.("aria-hidden") === "true") continue;
        if (hasHiddenAncestor(el)) continue;
        if (!isVisible(el) || isInsideAgentmailFloatingWidget(el)) continue;
        const rows = yearOptionsInList(el);
        if (rows.length < 3) continue;
        lists.push({ el, count: rows.length });
      }
      if (!lists.length) return null;
      const inner = lists.filter((a) => !lists.some((b) => b !== a && a.el.contains(b.el)));
      const list = (inner.length ? inner : lists).sort((a, b) => b.count - a.count)[0].el;
      const scroller = scrollerOf(list);
      const found = { list, scroller };
      ultraPickerMemo = { at: Date.now(), found };
      return found;
    } catch (error) {
      return null;
    }
  }

  // Open the picker with a real finger tap first (some pages ignore synthetic clicks).
  async function openYearPicker(control) {
    if (!control) return null;
    const current = yearPickerContainer();
    if (current) return current;
    try { control.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
    try { control.focus({ preventScroll: true }); } catch (error) {}
    await settleRect(control);

    if (await tapVerifiedElement(control, 0.5, 0.55)) {
      if (await waitFor(() => Boolean(yearPickerContainer()), { timeout: 90, poll: 10 })) return yearPickerContainer();
    }
    fireRealisticClick(control);
    if (await waitFor(() => Boolean(yearPickerContainer()), { timeout: 80, poll: 10 })) return yearPickerContainer();
    clickByPoint(control);
    if (await waitFor(() => Boolean(yearPickerContainer()), { timeout: 70, poll: 10 })) return yearPickerContainer();
    try { dispatchKey(control, "Enter"); } catch (error) {}
    if (await waitFor(() => Boolean(yearPickerContainer()), { timeout: 60, poll: 10 })) return yearPickerContainer();
    try { dispatchKey(control, "ArrowDown"); } catch (error) {}
    if (await waitFor(() => Boolean(yearPickerContainer()), { timeout: 60, poll: 10 })) return yearPickerContainer();
    return yearPickerContainer();
  }

  // Drag (or scroll) the list until 1999 is on screen. Returns true when the row
  // exists, so the caller can tap the exact node.
  async function dragListToYear(found, wanted) {
    if (!found || !found.list) return false;
    const { list, scroller } = found;

    const measure = () => {
      const rows = yearOptionsInList(list).sort((a, b) => a.top - b.top);
      if (!rows.length) return null;
      const years = rows.map((row) => row.year);
      const min = Math.min(...years);
      const max = Math.max(...years);
      const gaps = [];
      for (let i = 1; i < rows.length; i += 1) gaps.push(rows[i].top - rows[i - 1].top);
      const positive = gaps.filter((gap) => gap > 2).sort((a, b) => a - b);
      let step = positive.length ? positive[Math.floor(positive.length / 2)] : 0;
      if (!step) {
        const rect = getRect(rows[0].el);
        step = Math.max(1, rect ? Math.round(rect.height) : 40);
      }
      return { rows, min, max, step, descending: rows[0].year >= rows[rows.length - 1].year };
    };

    for (let effort = 0; effort < 5; effort += 1) {
      const info = measure();
      if (!info) return false;
      if (info.rows.some((row) => row.year === wanted)) return true;

      const index = info.descending ? (info.max - wanted) : (wanted - info.min);

      // The picker viewport = the rows themselves. A wrapper can be a transform
      // track with no measurable size, which used to produce a 4px "drag".
      const rowsBox = (() => {
        const rects = info.rows.map((row) => getRect(row.el)).filter((rect) => rect && rect.width && rect.height);
        if (!rects.length) return null;
        const top = Math.min(...rects.map((rect) => rect.top));
        const bottom = Math.max(...rects.map((rect) => rect.top + rect.height));
        const left = Math.min(...rects.map((rect) => rect.left));
        const right = Math.max(...rects.map((rect) => rect.left + rect.width));
        return { top, bottom, left, right, height: bottom - top, width: right - left };
      })();
      const containerRect = getRect(scroller) || getRect(list);
      const box = (rowsBox && rowsBox.height > 60) ? rowsBox : (containerRect || rowsBox);
      if (!box || !box.height || box.height < 20) return false;

      // 1) direct positioning - instant on ordinary scrollers
      const maxScroll = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      if (maxScroll > 0) {
        const target = Math.max(0, Math.min(maxScroll, (index * info.step) - Math.max(0, (scroller.clientHeight - info.step) / 2)));
        if (Math.abs(target - scroller.scrollTop) > 3) {
          scroller.scrollTop = target;
          try { scroller.dispatchEvent(new Event("scroll", { bubbles: true })); } catch (error) {}
          await sleep(22);
          const after = measure();
          if (after && after.rows.some((row) => row.year === wanted)) return true;
        }
      }

      // 2) finger drag - exactly what the user asked for, and the only thing that
      //    works on pickers that ignore programmatic scrolling
      const x = box.left + box.width * 0.5 + (randomIndex(9) - 4);
      const startY = box.top + Math.min(box.height * 0.72, box.height - 26);
      // A finger can swipe far: cover the remaining distance in as few gestures as
      // possible (still capped so each swipe looks human), instead of many hops.
      const travel = Math.max(120, Math.min(index * info.step, Math.max(240, box.height * 1.15), 900));
      const endY = Math.max(box.top + 10, startY - travel);
      await humanDrag(scroller, x, startY, x, endY, 8);
      await sleep(45);

      // 3) wheel nudge for desktop-style pickers
      try {
        const mid = document.elementFromPoint(x, box.top + box.height / 2) || scroller;
        mid.dispatchEvent(new WheelEvent("wheel", { bubbles: true, cancelable: true, composed: true, deltaY: Math.min(index * info.step, 600), deltaMode: 0 }));
      } catch (error) {}

      const after = measure();
      if (after && after.rows.some((row) => row.year === wanted)) return true;
    }
    const done = measure();
    return Boolean(done && done.rows.some((row) => row.year === wanted));
  }

  // Full "pick 1999 from the list" flow with verification on screen.
  // ---------------- v2.4 ULTRA: 1999 lands the moment the field is pressed ----
  function ultraNativeShows(select, wanted) {
    try {
      const value = String(select.value || "").trim();
      const text = String(select.options?.[select.selectedIndex]?.textContent || "").trim();
      const shown = numberFromText(text, 1900, 2100);
      return value === String(wanted) || text === String(wanted) || shown === wanted;
    } catch (error) {
      return false;
    }
  }

  // The native <select> the styled Year field is built on (no visibility filter:
  // a styled field usually keeps its select hidden on purpose).
  function yearNativeSelect() {
    try {
      const roots = [];
      const fieldRoot = dobYearFieldRoot();
      if (fieldRoot) roots.push(fieldRoot);
      roots.push(document);
      const seen = new Set();
      for (const root of roots) {
        for (const select of [...root.querySelectorAll("select")]) {
          if (!select || seen.has(select)) continue;
          seen.add(select);
          try { if (isInsideAgentmailFloatingWidget(select)) continue; } catch (error) {}
          const values = [...(select.options || [])].map((opt) => String(opt.value || opt.textContent || "").trim());
          if (values.includes("1999")) return select;
        }
      }
    } catch (error) {}
    return null;
  }

  // One synchronous native write: selectedIndex + the native value setter +
  // input/change in the same frame. No clicking, no popup, no waiting.
  function ultraWriteNativeYear(select, wanted, resync = false) {
    try {
      if (!select || select.isConnected === false) return false;
      window.__agentmailYearViaClick = false;   // a silent write is never a click
      const text = String(wanted);
      const options = [...(select.options || [])];
      let index = options.findIndex((opt) => String(opt.value || "").trim() === text);
      if (index < 0) index = options.findIndex((opt) => String(opt.textContent || "").trim() === text);
      if (index < 0) return false;

      // A clean write first: nudging makes controlled forms "commit" the value
      // that is already on screen, so it is only used to rescue a rejected write.
      if (resync) {
        // If the page's tracker already holds 1999 (stale), it drops our write as
        // "no change" - store an impossible value so the change is real. Only when
        // no tracker is reachable (real browser isolated world) do we nudge the
        // page with the value that is already on screen.
        let poked = false;
        try {
          const tracker = select._valueTracker;
          if (tracker && typeof tracker.setValue === "function") {
            tracker.setValue("__agentmail__");
            poked = true;
          }
        } catch (error) {}
        if (!poked) { try { nudgeReactTracker(select); } catch (error) {} }
      }
      try { select.selectedIndex = index; } catch (error) {}
      try { options[index].selected = true; } catch (error) {}
      const value = String(options[index].value != null && options[index].value !== "" ? options[index].value : text);
      try {
        const desc = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value");
        if (desc && typeof desc.set === "function") desc.set.call(select, value);
        else select.value = value;
      } catch (error) { try { select.value = value; } catch (error2) {} }
      try { select.dispatchEvent(new Event("input", { bubbles: true })); } catch (error) {}
      try { select.dispatchEvent(new Event("change", { bubbles: true })); } catch (error) {}
      return true;
    } catch (error) {
      return false;
    }
  }

  // Some native popups are drawn by the browser itself - no DOM click can reach
  // those rows. Typing the year on the focused select jumps straight to it.
  async function ultraKeyboardYear(select, wanted) {
    try {
      if (!select || select.isConnected === false) return false;
      try { select.focus({ preventScroll: true }); } catch (error) {}
      for (const digit of String(wanted).split("")) {
        const init = { key: digit, code: "Digit" + digit, bubbles: true, cancelable: true };
        select.dispatchEvent(new KeyboardEvent("keydown", init));
        select.dispatchEvent(new KeyboardEvent("keypress", init));
        select.dispatchEvent(new KeyboardEvent("keyup", init));
        await sleep(8);
      }
      const enter = { key: "Enter", code: "Enter", bubbles: true, cancelable: true };
      select.dispatchEvent(new KeyboardEvent("keydown", enter));
      select.dispatchEvent(new KeyboardEvent("keyup", enter));
      return true;
    } catch (error) {
      return false;
    }
  }

  // The visible "Year" box the user (and Meta) shows - the thing a finger presses.
  function dobYearVisibleTrigger() {
    try {
      const fieldRoot = dobYearFieldRoot();
      const scopes = fieldRoot ? [fieldRoot, document] : [document];
      const seen = new Set();
      const shown = (() => {
        try { const state = readVisibleYearState(); return state && state.shown ? String(state.shown) : ""; }
        catch (error) { return ""; }
      })();
      const pool = [];
      const candidates = [];
      scopes.forEach((scope) => {
        scope.querySelectorAll("select, [role='combobox'], button, [aria-haspopup], [aria-expanded], [tabindex], div, span").forEach((el) => {
          if (!el || seen.has(el)) return;
          seen.add(el);
          candidates.push(el);
        });
      });
      candidates.forEach((el) => {
        try {
          if (!el || el.nodeType !== 1) return;
          if (isInsideAgentmailFloatingWidget(el)) return;
          if (!isVisible(el)) return;
          const rect = getRect(el);
          if (!rect || rect.width < 46 || rect.height < 14 || rect.height > 140) return;
          if (rect.width > window.innerWidth * 0.97 && rect.height > 120) return;
          const text = String(el.textContent || "").trim();
          const role = String(el.getAttribute("role") || "").toLowerCase();
          const hasPopup = el.hasAttribute("aria-haspopup") || el.hasAttribute("aria-expanded");
          const chevron = Boolean(el.querySelector?.("svg, [class*=chevron], [class*=arrow], [class*=caret], [class*=icon]"));
          let score = 0;
          if (role === "combobox") score += 60;
          if (hasPopup) score += 40;
          if (el.tagName === "SELECT") score += 26;
          if (el.tagName === "BUTTON") score += 22;
          if (shown && text.includes(shown)) score += 34;
          if (/^(19|20)\d{2}$/.test(text)) score += 24;
          if (chevron) score += 16;
          if (rect.height >= 20 && rect.height <= 96) score += 12;
          if (rect.width >= window.innerWidth * 0.45) score += 8;
          if (looksClickable(el)) score += 12;
          if (score <= 0) return;
          pool.push({ el, score, area: rect.width * rect.height });
        } catch (error) {}
      });
      pool.sort((a, b) => (b.score - a.score) || (a.area - b.area));
      const best = pool[0];
      if (best) return best.el;
    } catch (error) {}
    return null;
  }

  // The picker's real box: a wrapper can be a transform track whose own rect is
  // empty, so fall back to the union of the row rects (same rule as the drag path).
  function ultraPickerBox(list, scroller) {
    try {
      const rect = getRect(scroller) || getRect(list);
      if (rect && rect.width > 40 && rect.height > 40) return rect;
      const rects = yearOptionsInList(list).map((row) => getRect(row.el)).filter((r) => r && r.width && r.height);
      if (!rects.length) return rect || null;
      const top = Math.min(...rects.map((r) => r.top));
      const bottom = Math.max(...rects.map((r) => r.top + r.height));
      const left = Math.min(...rects.map((r) => r.left));
      const right = Math.max(...rects.map((r) => r.left + r.width));
      return { top, bottom, left, right, height: bottom - top, width: right - left };
    } catch (error) {
      return null;
    }
  }

  // v2.7 FLASH: ONE big wheel event instead of a 40-move finger drag.
  async function ultraWheelJump(list, scroller, index, step, wanted) {
    try {
      const rect = ultraPickerBox(list, scroller);
      if (!rect || !rect.width || !rect.height) return false;
      // centre the wanted row inside the visible window (same rule as the scroll jump)
      const visibleRows = Math.max(1, Math.round(rect.height / Math.max(1, step)));
      const centre = Math.max(0, Math.floor((visibleRows - 1) / 2)) * step;
      const delta = Math.round(index * step - centre);
      if (delta < 8) return false;
      const x = rect.left + rect.width * 0.5;
      const y = rect.top + Math.min(rect.height * 0.6, Math.max(1, rect.height - 10));
      const hit = (() => { try { return document.elementFromPoint(x, y); } catch (error) { return null; } })();
      for (let shot = 0; shot < 2; shot += 1) {
        // shot 1 goes to whatever the finger is really over, shot 2 to the list
        // node itself - a carousel may listen on either of them.
        const target = (shot === 0 && hit) || list || scroller;
        try {
          target.dispatchEvent(new WheelEvent("wheel", {
            bubbles: true, cancelable: true, deltaMode: 0, deltaY: delta, clientX: x, clientY: y
          }));
        } catch (error) {}
        await sleep(6);
        if (yearOptionsInList(list).some((row) => row.year === wanted)) return true;
      }
    } catch (error) {}
    return false;
  }

  // A carousel moved by "transform: translateY(...)" can be pushed straight onto
  // 1999. If the rows do not really re-render, the old transform is put back, so
  // the page is never left in a strange state.
  async function ultraTrackJump(list, index, step, wanted) {
    try {
      const touched = [];
      const target = "translateY(" + String(-index * step) + "px)";
      for (const node of [list, list.firstElementChild, list.parentElement]) {
        if (!node || node.nodeType !== 1 || !node.style) continue;
        let raw = "";
        try { raw = String((getCachedStyle(node) || {}).transform || ""); } catch (error) { raw = ""; }
        const match = raw.match(/translateY\(([-\d.]+)px\)/i);
        if (!match) continue;
        try { node.style.transform = raw.replace(match[0], target); touched.push({ node, raw }); } catch (error) {}
      }
      if (!touched.length) return false;
      try { list.dispatchEvent(new Event("scroll", { bubbles: true })); } catch (error) {}
      await sleep(10);
      if (yearOptionsInList(list).some((row) => row.year === wanted)) return true;
      for (const item of touched) { try { item.node.style.transform = item.raw; } catch (error) {} }
    } catch (error) {}
    return false;
  }

  // Tap 1999 right away - only if that row is really rendered.
  async function ultraTapRow(found, wanted, verifyMs = 30, sun = false) {
    try {
      if (!found || !found.list) return false;
      if (yearUiShows(wanted)) return true;    // already there - never click twice
      const row = findYearRowFast(found.list, wanted) || pickYearOption(found.list, wanted);
      if (!row) return false;
      if (await tapRowElement(row.el, wanted, sun)) {
        return await waitFor(() => yearUiShows(wanted), { timeout: verifyMs, poll: sun ? 2 : 5 });
      }
    } catch (error) {}
    return false;
  }

  // One scrollTop write (instant on real scrollers) instead of a long drag.
  async function ultraJumpToYear(found, wanted, sun = false) {
    try {
      if (!found || !found.list) return false;
      const list = found.list;
      const scroller = found.scroller || list;
      const rows = yearOptionsInList(list).sort((a, b) => a.top - b.top);
      if (rows.length < 3) return false;
      const years = rows.map((row) => row.year);
      const first = years[0];
      const index = Math.max(0, first - wanted);
      const gaps = [];
      for (let i = 1; i < rows.length; i += 1) gaps.push(rows[i].top - rows[i - 1].top);
      const positive = gaps.filter((gap) => gap > 2).sort((a, b) => a - b);
      let step = positive.length ? positive[Math.floor(positive.length / 2)] : 0;
      if (!step) {
        const rect = getRect(rows[0].el);
        step = Math.max(1, rect ? Math.round(rect.height) : 44);
      }
      // The wanted row is already the FIRST visible row: nothing to move, and
      // moving would only risk pushing it against the edge (clipped -> untappable).
      if (index <= 0) return yearOptionsInList(list).some((row) => row.year === wanted);
      // FLASH: aim for the MIDDLE of the window - a row on the very edge can be
      // half-clipped, and a finger cannot click what it cannot see.
      const visibleRows = Math.max(1, Math.round((Number(scroller.clientHeight) || 0) / Math.max(1, step)));
      const centre = Math.max(0, Math.floor((visibleRows - 1) / 2)) * step;
      const maxScroll = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
      if (maxScroll > 0) {
        // A real scroller can be jumped with one instant scrollTop write. A CLIP
        // WINDOW (overflow hidden) cannot: writing its scrollTop only shifts the
        // rows out of sight, because the page's own carousel logic knows nothing
        // about that scroll. Those lists get the wheel/transform jump instead.
        const style = getCachedStyle(scroller) || {};
        const genuine = /(auto|scroll|overlay)/.test(String(style.overflowY || style.overflow || ""));
        const previousTop = Number(scroller.scrollTop) || 0;
        const target = Math.max(0, Math.min(maxScroll, previousTop + index * step - centre));
        if (genuine && Math.abs(target - previousTop) >= 3) {
          scroller.scrollTop = target;
          try { scroller.dispatchEvent(new Event("scroll", { bubbles: true })); } catch (error) {}
          // SUN: the page's own scroll listener has already rebuilt the rows in
          // this same tick - no pause needed.
          await sleep(sun ? 0 : 8);
          if (yearOptionsInList(list).some((row) => row.year === wanted)) return true;
          // the write did not land - leave the page exactly as we found it
          try {
            scroller.scrollTop = previousTop;
            scroller.dispatchEvent(new Event("scroll", { bubbles: true }));
          } catch (error) {}
        } else if (!genuine && previousTop > 0) {
          try { scroller.scrollTop = 0; } catch (error) {}
        }
      }
      // v2.7 FLASH: transform tracks and virtualised lists ignore scrollTop, and
      // they are the ones that used to need a long finger drag. Move them with
      // ONE wheel event - or one transform write - and never with a drag.
      if (await ultraWheelJump(list, scroller, index, step, wanted)) return true;
      return await ultraTrackJump(list, index, step, wanted);
    } catch (error) {
      return false;
    }
  }

  // ---------------- v2.5 ULTRA auto-click: the visible Year box --------------
  // The exact area the user circles in the screenshot: the rounded box holding
  // "Year", the current year and the chevron. Found by its own label when the
  // role hints are missing, so it works on Meta's real markup too.
  function yearLabelElement() {
    try {
      const labels = queryAllDeep("span, div, label, p, legend, b, strong")
        .filter((el) => el && el.nodeType === 1)
        .filter((el) => !isInsideAgentmailFloatingWidget(el))
        .filter((el) => isVisible(el))
        .filter((el) => normalizeText(el.textContent || "") === "year")
        .map((el) => ({ el, rect: getRect(el), kids: el.children ? el.children.length : 0 }))
        .filter((item) => item.rect && item.rect.width > 8 && item.rect.height > 6);
      if (!labels.length) return null;
      labels.sort((a, b) => (a.rect.height - b.rect.height) || (a.rect.width - b.rect.width) || (a.kids - b.kids));
      return labels[0].el;
    } catch (error) {
      return null;
    }
  }

  // Is this element something a finger would obviously press?
  function looksClickable(el) {
    try {
      if (!el || el.nodeType !== 1) return false;
      const role = String(el.getAttribute("role") || "").toLowerCase();
      if (role === "combobox" || role === "listbox" || role === "button") return true;
      if (el.hasAttribute("aria-haspopup") || el.hasAttribute("aria-expanded")) return true;
      if (el.tagName === "BUTTON" || el.tagName === "SELECT") return true;
      if (el.tabIndex >= 0) return true;
      const style = getCachedStyle(el);
      if (style && style.cursor === "pointer") return true;
    } catch (error) {}
    return false;
  }

  // Inside the "Year" row, find the real box a finger presses (the circled area).
  function bestBoxInside(row, shown) {
    try {
      if (!row || !row.querySelectorAll) return null;
      const pool = [];
      row.querySelectorAll("div, span, button, select, [role='combobox'], [aria-haspopup], [aria-expanded], [tabindex]").forEach((el) => {
        try {
          if (!el || el.nodeType !== 1) return;
          if (isInsideAgentmailFloatingWidget(el)) return;
          if (!isVisible(el)) return;
          const rect = getRect(el);
          if (!rect || rect.width < 60 || rect.height < 14 || rect.height > 140) return;
          if (rect.width > window.innerWidth * 0.97 && rect.height > 120) return;
          const text = String(el.textContent || "");
          const hasYear = /(19|20)\d{2}/.test(text) || (shown && text.includes(shown));
          const hasChevron = Boolean(el.querySelector && el.querySelector("svg, [class*=chevron], [class*=arrow], [class*=caret], [class*=icon]"));
          let score = 0;
          if (looksClickable(el)) score += 45;
          if (hasYear) score += 22;
          if (hasChevron) score += 14;
          if (rect.height >= 20 && rect.height <= 96) score += 10;
          if (!score) return;
          pool.push({ el, score, area: rect.width * rect.height });
        } catch (error) {}
      });
      if (!pool.length) return null;
      // highest score wins; the SMALLEST box wins a tie (inner control, not wrapper)
      pool.sort((a, b) => (b.score - a.score) || (a.area - b.area));
      return pool[0].el;
    } catch (error) {
      return null;
    }
  }

  function yearBoxFromLabel() {
    try {
      const label = yearLabelElement();
      if (!label) return null;
      const shown = (() => {
        try { const state = readVisibleYearState(); return state && state.shown ? String(state.shown) : ""; }
        catch (error) { return ""; }
      })();
      let node = label;
      for (let depth = 0; depth < 6 && node; depth += 1, node = node.parentElement) {
        if (!node || node === document.body || node.tagName === "HTML") break;
        const rect = getRect(node);
        if (!rect || rect.width < 80 || rect.height < 14 || rect.height > 190) continue;
        const text = String(node.textContent || "");
        const hasChevron = Boolean(node.querySelector && node.querySelector("svg, [class*=chevron], [class*=arrow], [class*=caret], [class*=icon]"));
        const hasYear = /(19|20)\d{2}/.test(text) || (shown && text.includes(shown));
        if (!hasChevron && !hasYear) continue;
        // The row itself may be a wrapper: prefer the real inner box when there is one.
        const inner = bestBoxInside(node, shown);
        if (inner && inner !== node) return inner;
        if (looksClickable(node)) return node;
        return node;
      }
      return label.parentElement && label.parentElement !== document.body ? label.parentElement : null;
    } catch (error) {
      return null;
    }
  }

  // Press the visible Year box: one verified human tap, counted in the HUD.
  let ultraYearBoxPressedAt = 0;
  async function ultraYearBoxPress(force = false) {
    try {
      if (!force && Date.now() - ultraYearBoxPressedAt < 800) return false;
      const box = dobYearVisibleTrigger() || yearBoxFromLabel();
      if (!box) return false;
      const rect = getRect(box);
      if (!rect || !rect.width || !rect.height) return false;
      const alreadyVisible = rect.top >= 0 && rect.top + rect.height <= (window.innerHeight || 800);
      if (!alreadyVisible) {
        try { box.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
      }
      const x = rect.left + rect.width * (0.48 + Math.random() * 0.06);
      const y = rect.top + rect.height * (0.5 + Math.random() * 0.08);
      const hit = document.elementFromPoint(x, y);
      if (hit && hit !== box && !box.contains(hit) && !hit.contains(box)) return false;
      dispatchGesture(hit || box, x, y, "down");
      await sleep(7 + randomIndex(7));            // instant press, still human-shaped
      dispatchGesture(box, x, y, "up");           // the click lands on the verified box
      const pressed = true;
      if (!pressed) return false;
      ultraYearBoxPressedAt = Date.now();
      try { POWER.clicks += 1; } catch (error) {}
      try { flash(box); } catch (error) {}
      powerLog("Year box clicked (ULTRA) - 1999 coming right up");
      return true;
    } catch (error) {
      return false;
    }
  }

  // The page-visible year must really be 1999 - our own written value is NOT
  // proof (a page can drop it and re-render the old year). Hold test included.
  let ultraSawSnapback = false;   // set when this page is seen restoring its old year

  async function ultraYearConfirmed(native, wanted, timeoutMs) {
    const stateOk = () => {
      const state = readVisibleYearState();
      if (state.shown === wanted) return true;
      if (state.shown === null && native && ultraNativeShows(native, wanted)) return true;
      return false;
    };
    if (!(await waitFor(stateOk, { timeout: timeoutMs, poll: 5 }))) return false;
    // FLASH: 30 ms is enough for a normal page; a page that has already snapped
    // back once gets the long 150 ms hold so a wrong year can never be submitted.
    await sleep(ultraSawSnapback ? 150 : 30);
    const ok = stateOk();
    if (!ok) ultraSawSnapback = true;
    return ok;
  }

  // v2.7 FLASH: the FIRST real win ends the race - so the silent native write
  // and the visible row click never wait for each other.
  function ultraFirstWin(promises, limitMs = 400) {
    return new Promise((resolve) => {
      let done = false;
      const settle = (value) => { if (!done && value) { done = true; resolve(value); } };
      for (const promise of promises) Promise.resolve(promise).then(settle, () => {});
      setTimeout(() => { if (!done) { done = true; resolve(""); } }, limitMs);
    });
  }

  // ULTRA chain: everything above is a few dozen milliseconds.
  let ultraNativeFailStreak = 0;
  let ultraNativeDeadUntil = 0;

  // 1999 in one shot: the press and the native write happen in the same tick, and
  // whichever lands first ends it. Everything is confirmed with 7 ms polling.
  async function ultraSetYear(wanted) {
    const startedAt = Date.now();
    try { window.__agentmailChainBeat = Date.now(); } catch (error) {}
    if (yearUiShows(wanted)) return true;

    const native = Date.now() < ultraNativeDeadUntil ? null : yearNativeSelect();

    // 1) ONE TICK - press the visible Year box (the user's own click), write the
    //    native select and look for an already-open list, all in the same tick.
    const openList = yearPickerContainer();
    const pressing = ultraYearBoxPress();
    const wrote = native ? ultraWriteNativeYear(native, wanted) : false;

    // 2) v2.7 FLASH - the native confirm and the DIRECT CLICK on the 1999 row run
    //    TOGETHER; nothing waits for anything else. A tap is a plain click on the
    //    verified row (plus one instant jump when that row is not rendered yet).
    const tapOne = async (found) => {
      if (!found || !found.list) return "";
      if (await ultraTapRow(found, wanted, 26, true)) return "row";
      if (await ultraJumpToYear(found, wanted)) {
        const again = yearPickerContainer() || found;
        if (await ultraTapRow(again, wanted, 26, true)) return "jump";
      }
      return "";
    };
    const confirmOne = (native && wrote)
      ? ultraYearConfirmed(native, wanted, 30).then((ok) => (ok ? "native" : ""))
      : Promise.resolve("");
    const tapOneList = (async () => {
      if (openList) return tapOne(openList);
      const fresh = await waitFor(() => yearPickerContainer(), { timeout: 60, poll: 2 });
      return tapOne(fresh);
    })();
    const landed = await ultraFirstWin([confirmOne, tapOneList]);
    await pressing;

    if (landed === "native") {
      ultraNativeFailStreak = 0;
      try { dispatchKey(native, "Escape"); native.blur(); } catch (error) {}
      powerLog("Year 1999 locked in " + (Date.now() - startedAt) + " ms (ULTRA)");
      return true;
    }
    if (landed === "row" || landed === "jump") {
      if (await ultraYearConfirmed(native, wanted, 30)) {
        ultraNativeFailStreak = 0;
        powerLog("Year 1999 clicked in " + (Date.now() - startedAt) + " ms (FLASH-" + landed + ")");
        return true;
      }
    }
    // the click may only have needed one more breath - one last quick look
    if (await waitFor(() => yearUiShows(wanted), { timeout: 30, poll: 5 })) {
      if (await ultraYearConfirmed(native, wanted, 30)) {
        powerLog("Year 1999 confirmed in " + (Date.now() - startedAt) + " ms");
        return true;
      }
    }

    // 3) a DOM list is open under the box: tap the 1999 row right away
    let found = yearPickerContainer();
    if (found) {
      if (await ultraTapRow(found, wanted)) {
        powerLog("Year 1999 tapped in " + (Date.now() - startedAt) + " ms (ULTRA)");
        return true;
      }
      if (await ultraJumpToYear(found, wanted)) {
        const again = yearPickerContainer() || found;
        if (await ultraTapRow(again, wanted)) {
          powerLog("Year 1999 jumped to in " + (Date.now() - startedAt) + " ms (ULTRA)");
          return true;
        }
      }
    }

    // 4) resync rescue for controlled forms (only when the clean write reached the page)
    if (native && wrote && ultraWriteNativeYear(native, wanted, true)) {
      if (await ultraYearConfirmed(native, wanted, 45)) {
        ultraNativeFailStreak = 0;
        powerLog("Year 1999 locked in " + (Date.now() - startedAt) + " ms (resync)");
        return true;
      }
    }
    if (native && !wrote) {
      ultraNativeFailStreak += 1;
      if (ultraNativeFailStreak >= 2) ultraNativeDeadUntil = Date.now() + 2500;
    }

    // 5) keyboard burst on the select (browser-drawn popups live outside the DOM)
    if (native && ultraNativeFailStreak < 2 && (await ultraKeyboardYear(native, wanted))) {
      if (await ultraYearConfirmed(native, wanted, 60)) {
        try { dispatchKey(native, "Enter"); } catch (error) {}
        ultraNativeFailStreak = 0;
        powerLog("Year 1999 typed in " + (Date.now() - startedAt) + " ms (keys)");
        return true;
      }
      ultraNativeFailStreak += 1;
      if (ultraNativeFailStreak >= 2) ultraNativeDeadUntil = Date.now() + 2500;
      try { dispatchKey(native, "Escape"); dispatchKey(native, "Tab"); native.blur(); } catch (error) {}
    }

    // 6) last resort: one more press (fresh popup) + jump/tap, then give the older
    //    ladder its turn - it is slower but it never gives up.
    if (await ultraYearBoxPress(true)) {
      await waitFor(() => Boolean(yearPickerContainer()), { timeout: 60, poll: 5 });
      const opened = yearPickerContainer();
      if (opened && (await ultraTapRow(opened, wanted))) return true;
      if (opened && (await ultraJumpToYear(opened, wanted)) && (await ultraTapRow(yearPickerContainer() || opened, wanted))) return true;
      if (native) {
        ultraWriteNativeYear(native, wanted);
        if (await ultraYearConfirmed(native, wanted, 60)) return true;
        ultraWriteNativeYear(native, wanted, true);
        if (await ultraYearConfirmed(native, wanted, 70)) return true;
      }
      try { if (native) dispatchKey(native, "Escape"); } catch (error) {}
    }
    return false;
  }

  async function chooseYearFromPicker(wanted) {
    const startedAt = Date.now();
    const budget = 4200;
    const control = dobYearVisibleTrigger() || findDobYearControl();
    if (!control) return false;

    for (let attempt = 0; attempt < 3; attempt += 1) {
      try { window.__agentmailChainBeat = Date.now(); } catch (error) {}
      if (!dobStepStillActive()) return yearUiShows(wanted);
      if (Date.now() - startedAt > budget) break;

      let found = yearPickerContainer();
      if (!found || !found.list.isConnected) {
        found = await openYearPicker(control);
      }
      if (!found) { await sleep(80); continue; }

      // FAST PATH: the row is rendered already - tap it at once.
      const direct = pickYearOption(found.list, wanted);
      if (direct) {
        if (await tapRowElement(direct.el, wanted)) {
          if (await waitFor(() => yearUiShows(wanted), { timeout: 130, poll: 20 })) return true;
        }
      }

      // INSTANT JUMP (v2.4): one scrollTop write beats any drag by a mile.
      if (await ultraJumpToYear(found, wanted)) {
        const jumped = yearPickerContainer();
        const rowFast = pickYearOption(jumped?.list || found.list, wanted);
        if (rowFast && (await tapRowElement(rowFast.el, wanted))) {
          if (await waitFor(() => yearUiShows(wanted), { timeout: 150, poll: 10 })) return true;
        }
      }

      // DRAG PATH (v2.7: only from the second pass - the first pass is pure
      // clicks: tap the row, else one instant jump, else the wheel/track jump).
      if (attempt > 0 && (await dragListToYear(found, wanted))) {
        const now = yearPickerContainer();
        const row = pickYearOption(now?.list || found.list, wanted) || pickYearOption(found.list, wanted);
        if (row) {
          if (await tapRowElement(row.el, wanted)) {
            if (await waitFor(() => yearUiShows(wanted), { timeout: 240, poll: 20 })) return true;
          }
        }
      }
      await sleep(45);
    }
    return yearUiShows(wanted);
  }

  async function chooseYearStrong(wantedYear = 1999) {
    const wanted = Number(wantedYear);

    // 0u) ULTRA (v2.4): press the Year box -> 1999 is simply there, no waiting.
    try {
      if (await ultraSetYear(wanted)) return true;
    } catch (error) {}

    // 0) Native <select> - set the option directly, so no wrong year is ever committed.
    try {
      const selects = findDobSelects();
      for (const key of ["year", "day", "month"]) {
        const select = selects && selects[key];
        if (select && select.tagName === "SELECT") {
          const before = numberFromText(select.options?.[select.selectedIndex]?.textContent || select.value, 1900, 2100);
          if (key === "year" && before !== wanted) {
            setSelectValue(select, wanted);
            await sleep(35);
          }
          if (key === "year") {
            const after = numberFromText(select.options?.[select.selectedIndex]?.textContent || select.value, 1900, 2100);
            if (after === wanted) return true;
          }
        }
      }
    } catch (error) {}

    const yearControl = findDobYearControl() || dobYearVisibleTrigger();
    if (!yearControl) return false;

    // Already exact? Do nothing - no pointless re-selection flicker.
    if (getYearFromControl(yearControl) === wanted) return true;

    const listScope = () => {
      try {
        const mapped = queryAllDeep("[role='listbox'], ul, ol, div")
          .filter((el) => !el.hasAttribute?.("hidden") && !el.hidden && el.getAttribute?.("aria-hidden") !== "true")
          .filter((el) => !hasHiddenAncestor(el))
          .filter((el) => isVisible(el) && !isInsideAgentmailFloatingWidget(el))
          .map((el) => {
            const years = yearOptionsInList(el).length;
            const directYears = Array.from(el.children || [])
              .filter((child) => /^(19|20)\d{2}$/.test(normalizeText(child.textContent || ""))).length;
            return { el, years, directYears, span: Math.max(0, el.scrollHeight - el.clientHeight) };
          })
          .filter((item) => item.years >= 3 || item.directYears >= 3);

        // Innermost list wins: a wrapper that merely CONTAINS the list must never
        // be picked (that is exactly what used to break the year dropdown).
        const inner = mapped.filter((item) => !mapped.some((other) => other !== item && item.el.contains(other.el)));
        const pool = (inner.length ? inner : mapped).sort((a, b) => (b.years - a.years) || (b.span - a.span));
        return pool[0]?.el || null;
      } catch (error) {
        return null;
      }
    };

    const listHasYear = () => {
      const list = listScope();
      return Boolean(list && yearOptionsInList(list).length >= 3);
    };

    const openDropdown = async () => {
      if (listHasYear()) return listScope(); // already open - never toggle it shut

      try { yearControl.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
      try { yearControl.focus({ preventScroll: true }); } catch (error) {}
      await settleRect(yearControl);

      // attempt 1: click the control itself
      fireRealisticClick(yearControl);
      if (await waitFor(listHasYear, { timeout: 260, poll: 30 })) return listScope();

      // attempt 2: click exactly what is under the control's centre
      clickByPoint(yearControl);
      if (await waitFor(listHasYear, { timeout: 240, poll: 30 })) return listScope();

      // attempt 3: some shells put the handler on the wrapper row
      try {
        const wrapper = yearControl.parentElement;
        if (wrapper && wrapper !== document.body) {
          fireRealisticClick(wrapper);
          if (await waitFor(listHasYear, { timeout: 260, poll: 30 })) return listScope();
        }
      } catch (error) {}

      // attempt 4: keyboard (Enter / ArrowDown on the focused combobox opens most lists)
      try {
        dispatchKey(yearControl, "Enter");
        if (await waitFor(listHasYear, { timeout: 200, poll: 30 })) return listScope();
        dispatchKey(yearControl, "ArrowDown");
        if (await waitFor(listHasYear, { timeout: 200, poll: 30 })) return listScope();
      } catch (error) {}

      return listScope();
    };

    const commitExactOption = async (list, timeoutMs = 620) => {
      const option = pickYearOption(list, wanted);
      if (!option) return false;
      try { option.el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
      await settleRect(option.el);
      if (option.el.isConnected === false || !dobStepStillActive()) return false;
      if (!optionIsSafelyClickable(option.el)) return false;   // never press a foreign point
      humanHover(option.el);
      await sleep(40 + randomIndex(60));
      fireRealisticClick(option.el);
      flash(option.el);
      const hit = await waitFor(() => getYearFromControl(yearControl) === wanted || readVisibleYearState().shown === wanted, { timeout: timeoutMs, poll: 30 });
      if (hit) return true;
      // One more chance with the precise point click, still safety-checked.
      if (optionIsSafelyClickable(option.el)) {
        clickByPoint(option.el);
        return await waitFor(() => getYearFromControl(yearControl) === wanted || readVisibleYearState().shown === wanted, { timeout: 360, poll: 30 });
      }
      return false;
    };

    // 0) DRAG ENGINE (v2.3): open the inline picker, drag it to 1999, tap that row,
    //    verify what the page shows. Fast path taps the row directly when visible.
    try {
      if (await chooseYearFromPicker(wanted)) return true;
    } catch (error) {}

    // 1) DIRECT: open the real list, scroll it to 1999, click the exact 1999 node.
    try {
      const list = await openDropdown();
      if (list) {
        await scrollListToYear(list, wanted, 8);
        if (await commitExactOption(list)) return true;
      }
    } catch (error) {}

    // 2) TYPE-AHEAD: type 1999 (native comboboxes jump straight to it).
    try {
      const list = await openDropdown();
      const active = document.activeElement || yearControl;
      for (const char of String(wanted)) dispatchKey(active, char);
      const option = list ? pickYearOption(list, wanted) : null;
      if (option) {
        fireRealisticClick(getClickableTarget(option.el));
      } else {
        dispatchKey(active, "Enter");
      }
      if (await waitFor(() => getYearFromControl(yearControl) === wanted, { timeout: 480, poll: 30 })) return true;
    } catch (error) {}

    // 3) KEYBOARD WALK: step the highlight and only commit when 1999 is highlighted.
    try {
      await openDropdown();
      const target = document.activeElement || yearControl;
      const currentYear = getYearFromControl(yearControl) || 2026;
      const direction = currentYear > wanted ? "ArrowDown" : "ArrowUp";
      const maxSteps = Math.min(96, Math.abs(currentYear - wanted) + 8);
      let steps = 0;
      let highlighted = highlightedYearOption(listScope());
      while (steps < maxSteps && !(highlighted && highlighted.year === wanted)) {
        dispatchKey(target, direction);
        steps += 1;
        if (steps % 4 === 0) {
          await sleep(10);
          const list = listScope();
          const option = list ? pickYearOption(list, wanted) : null;
          if (option) break; // 1999 became visible - click it exactly instead of walking further
          highlighted = highlightedYearOption(list);
        }
      }
      const listNow = listScope();
      const optionNow = listNow ? pickYearOption(listNow, wanted) : null;
      if (optionNow) {
        fireRealisticClick(getClickableTarget(optionNow.el));
      } else {
        const hl = highlightedYearOption(listScope());
        if (hl && hl.year === wanted) dispatchKey(target, "Enter");
      }
      if (await waitFor(() => getYearFromControl(yearControl) === wanted, { timeout: 520, poll: 30 })) return true;
    } catch (error) {}

    // 4) FINAL SWEEP: bigger scroll jumps, then exact click.
    for (let i = 0; i < 3; i += 1) {
      try {
        const list = await openDropdown();
        if (!list) break;
        await scrollListToYear(list, wanted, 12);
        if (await commitExactOption(list, 460)) return true;
      } catch (error) {}
    }

    if (getYearFromControl(yearControl) !== wanted) {
      powerLog(`Year ${wanted} not confirmed - retrying on next sweep`);
      return false; // caller must NOT press Next with a wrong year
    }
    return true;
  }

  async function chooseYear1999Fast() {
    return chooseYearStrong(1999);
  }

  async function setDobCustomControls(day, year) {
    // User requested: Day touch korbo na. Sudhu Year exact 1999 select korbo.
    return await chooseYear1999Fast();
  }

  // Submit governor: the real-browser run showed Next being pressed 34 times while
  // Meta kept rejecting the same unchanged field. That is spam (and detectable),
  // so a submit needs a changed field, a 2.5s gap and a 4-per-minute budget.
  function dobSubmitAllowed(signature) {
    const now = Date.now();
    const gov = window.__agentmailDobSubmitGov || (window.__agentmailDobSubmitGov = { windowStart: now, attempts: 0, lastAt: 0, lastSignature: "" });
    if (now - gov.windowStart > 60000) { gov.windowStart = now; gov.attempts = 0; }
    if (gov.attempts >= 4) return false;
    if (now - gov.lastAt < 2500) return false;
    if (gov.lastSignature === signature) return false;
    gov.attempts += 1;
    gov.lastAt = now;
    gov.lastSignature = signature;
    return true;
  }

  function dobSubmitSignature() {
    const state = readVisibleYearState();
    return `${state.shown}|${state.errorText}`;
  }

  async function clickNextAfterDob() {
    if (await dobSubmitBlocked()) {
      powerLog("DOB submit skipped: year 1999 not on screen yet");
      return false;
    }
    if (!dobSubmitAllowed(dobSubmitSignature())) {
      powerLog("DOB submit throttled: waiting for the field to change");
      return false;
    }
    if (yearFieldExists() && !(await yearConfirmedStable(1999, 200))) {
      powerLog("DOB submit held back: year 1999 did not stay on screen");
      return false;
    }
    for (let i = 0; i < 18; i += 1) {
      await sleep(i < 4 ? 25 : 55);
      const button = findNextButton();
      if (!button) continue;

      if (!isDisabledLike(button) || i > 3) {
        flash(button);
        await sleep(10 + randomIndex(20));
        fireRealisticClick(button);
        return true;
      }
    }
    return false;
  }

  async function fillVisiblePasswordOnDobPageIfNeeded(force = false) {
    if (dobPasswordHeldForYear()) return false;   // v2.8: 1999 first, password after
    const input = findMetaPasswordInput();
    if (!input) return false;
    const result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_PASSWORD" });
    const password = result.ok && result.password ? result.password : "FAHAD@10";
    const current = getEditableValue(input).trim();
    if (force || current !== password) {
      setNativeValue(input, "");
      await sleep(18 + randomIndex(18));
      setNativeValue(input, password);
      flash(input);
    }
    return true;
  }

  async function autoFillMetaDobPage(force = false) {
    if (!isMetaAuthPage() || !isMetaDobPage()) return { ok: false, message: "DOB page not found." };

    // v2.7 FLASH: arm the instant picker watch while the year is still wrong.
    window.__agentmailDobWanted = 1;
    window.__agentmailDobWantedAt = Date.now();

    if (window.__agentmailDobAutomationRunning) {
      return { ok: true, message: "DOB automation already running." };
    }

    window.__agentmailDobAutomationRunning = true;
    try {
      getGeneratedMetaDob();
      const selects = findDobSelects();

      // Year first - and we only accept what the page actually SHOWS on screen.
      let yearOk = await ensureYearSelected(1999);
      if (!yearOk && selects.year) yearOk = await commitYearNative(selects.year, 1999);
      if (!yearOk || !yearUiShows(1999)) {
        // Wrong/default year (e.g. 2026) -> never submit; the sweep retries.
        return { ok: false, message: "Year 1999 not selected yet; retrying." };
      }

      window.__agentmailDobFilledOnce = true;
      window.__agentmailDobNextRetries = 0;
      const passwordFilled = await fillVisiblePasswordOnDobPageIfNeeded(false);
      await sleep(passwordFilled ? 55 : 10);

      // Last look before submitting: a React re-render may have snapped the year
      // back while the password was being typed.
      if (!(await yearConfirmedStable(1999))) {
        const again = await ensureYearSelected(1999);
        if (!again || !(await yearConfirmedStable(1999))) return { ok: false, message: "Year changed back before submit; retried." };
      }

      await clickNextAfterDob();

      // If Meta still rejects the field, heal it right away and submit once more.
      await sleep(620);
      if (readVisibleYearState().errorText) await healDobValidationError(false);
      return { ok: true, message: passwordFilled ? "DOB year + password filled; Next clicked." : "DOB year set exactly: 1999" };
    } finally {
      window.__agentmailDobAutomationRunning = false;
    }
  }

  function pageHasVisiblePasswordInput() {
    return queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el))
      .some((el) => {
        const text = normalizeText([
          el.type,
          el.name,
          el.id,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.autocomplete
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        return type === "password" || text.includes("password");
      });
  }

  function isMetaPasswordPage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("create a password") ||
      pageText.includes("new password") ||
      pageText.includes("at least 6 characters") ||
      pageText.includes("couldn't guess") ||
      pageText.includes("couldn’t guess") ||
      // New Meta AI flow: DOB + Password + Save login info are on the same page.
      (pageText.includes("get started on meta ai") && pageHasVisiblePasswordInput()) ||
      (pageText.includes("date of birth") && pageText.includes("save login info") && pageHasVisiblePasswordInput())
    );
  }

  function findMetaPasswordInput() {
    if (!isMetaPasswordPage()) return null;

    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el));

    const ranked = inputs
      .map((el) => {
        const text = normalizeText([
          el.type,
          el.name,
          el.id,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.autocomplete
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        let score = 0;
        if (type === "password") score += 60;
        if (text.includes("password")) score += 40;
        if (text.includes("new password")) score += 40;
        return { el, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);

    return ranked[0]?.el || null;
  }

  // A page that asks for the birth year must never be submitted with a wrong one
  // (this is exactly how Meta ended up showing "Select a valid option." with 2026).
  async function dobSubmitBlocked() {
    try {
      const hasYearField = yearFieldExists();
      if (!isMetaDobPage() && !hasYearField) return false;
      // Fail closed: if a birth-year field is on screen, nothing gets submitted
      // until 1999 visibly HOLDS there.
      if (hasYearField && (await yearConfirmedStable(1999))) return false;
      const fixed = await ensureYearSelected(1999);
      if (!fixed || !(await yearConfirmedStable(1999))) return true;
      return false;
    } catch (error) {
      // Worst case (unknown state) we refuse to submit rather than risk a wrong year.
      return yearFieldExists();
    }
  }

  async function clickNextAfterPassword() {
    if (await dobSubmitBlocked()) {
      powerLog("Password submit paused: birth year must be 1999 first");
      return false;
    }
    if (isMetaDobPage() && !dobSubmitAllowed(dobSubmitSignature())) {
      powerLog("Password submit throttled: field unchanged");
      return false;
    }
    if (yearFieldExists() && !(await yearConfirmedStable(1999, 200))) {
      powerLog("Password submit held back: year 1999 did not stay on screen");
      return false;
    }
    const startedAt = Date.now();
    let attempts = 0;
    while (Date.now() - startedAt < 1800) {
      const button = findNextButton();
      if (button && (!isDisabledLike(button) || attempts > 4)) {
        flash(button);
        await humanDelay(1);
        await clickStrong(button, { kind: "next-password", pageId: POWER.lastPage.id });
        return true;
      }
      attempts += 1;
      if (button) await waitFor(() => !isDisabledLike(button), { timeout: 340, poll: 30 });
      else await waitFor(() => Boolean(findNextButton()), { timeout: 180, poll: 30 });
    }
    return false;
  }

  async function autoFillMetaPasswordPage(force = false) {
    if (!isMetaAuthPage() || !isMetaPasswordPage()) return { ok: false, message: "Password page not found." };

    if (window.__agentmailPasswordAutomationRunning) {
      return { ok: true, message: "Password automation already running." };
    }

    const input = findMetaPasswordInput();
    if (!input) return { ok: false, message: "Password input not found yet." };

    window.__agentmailPasswordAutomationRunning = true;
    try {
      const result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_PASSWORD" });
      const password = result.ok && result.password ? result.password : "FAHAD@10";
      const current = getEditableValue(input).trim();

      // v2.8 ORDER (the user's own rule): on the birth-date step the YEAR must be
      // 1999 on screen FIRST. The password used to be pasted first, which left the
      // field filled while the year still said 2026.
      if (dobPasswordHeldForYear()) {
        powerLog("Birth year first - password held back until 1999 is on screen");
        return { ok: false, message: "Waiting for birth year 1999 before the password." };
      }

      if (force || current !== password) {
        const landed = await fillStrong(input, password, { kind: "password" });
        if (!landed) {
          setNativeValue(input, "");
          await humanDelay(1);
          setNativeValue(input, password);
        }
        flash(input);
      }

      await humanDelay(1);
      if (isMetaDobPage() && !yearUiShows(1999)) {
        await ensureYearSelected(1999);
        if (!yearUiShows(1999)) {
          return { ok: false, message: "Password ready but waiting for birth year 1999." };
        }
      }
      await clickNextAfterPassword();
      return { ok: true, message: "Password filled; Next clicked." };
    } finally {
      window.__agentmailPasswordAutomationRunning = false;
    }
  }

  function findButtonByExactText(label) {
    const wanted = normalizeText(label);
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === wanted || item.text.includes(wanted))
      .filter((item) => item.area > 50 && item.area < 260000)
      .sort((a, b) => {
        const exactA = a.text === wanted ? 0 : 1;
        const exactB = b.text === wanted ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function isMetaSaveLoginPage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("save your login info") ||
      pageText.includes("save the login info") ||
      pageText.includes("you won't need to enter it next time") ||
      pageText.includes("you won’t need to enter it next time")
    );
  }

  async function autoClickMetaNotNow(force = false) {
    if (!isMetaAuthPage() || !isMetaSaveLoginPage()) return { ok: false, message: "Save login page not found." };

    if (window.__agentmailNotNowClickRunning && !force) {
      return { ok: true, message: "Not now click already running." };
    }

    const button = findButtonByExactText("Not now");
    if (!button) return { ok: false, message: "Not now button not found yet." };

    window.__agentmailNotNowClickRunning = true;
    try {
      for (let i = 0; i < 8; i += 1) {
        const current = findButtonByExactText("Not now");
        if (!current) return { ok: true, message: "Not now clicked." };
        flash(current);
        await clickStrong(() => findButtonByExactText("Not now"), { kind: "not-now" });
        await waitFor(() => !findButtonByExactText("Not now"), { timeout: 200, poll: 30 });
      }
      return { ok: true, message: "Not now click attempted." };
    } finally {
      window.__agentmailNotNowClickRunning = false;
    }
  }

  function isMetaFinalReviewPage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("your meta account information isn't public") ||
      pageText.includes("your meta account information isn’t public") ||
      pageText.includes("by creating your account") ||
      pageText.includes("meta terms of service") ||
      pageText.includes("create account") && pageText.includes("date of birth") && pageText.includes("password")
    );
  }

  function isCheckedLike(el) {
    if (!el) return false;
    if (typeof el.checked === "boolean") return el.checked;
    const aria = (el.getAttribute("aria-checked") || "").toLowerCase();
    if (aria === "true") return true;
    if (aria === "mixed") return true;
    return false;
  }

  function findMetaMarketingCheckbox() {
    if (!isMetaFinalReviewPage()) return null;

    const exactCheckbox = queryAllDeep("input[type='checkbox'], [role='checkbox']")
      .filter((el) => !el.disabled && isVisible(el))
      .sort((a, b) => {
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        return (ra.top - rb.top) || (ra.left - rb.left);
      })[0];
    if (exactCheckbox) return exactCheckbox;

    const label = queryAllDeep("label, div, span, p")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) =>
        item.text.includes("i'm interested in receiving emails") ||
        item.text.includes("i’m interested in receiving emails") ||
        item.text.includes("receiving emails about apps") ||
        item.text.includes("meta quest")
      )
      .filter((item) => item.area > 80 && item.area < 350000)
      .sort((a, b) => a.area - b.area)[0]?.el;

    if (!label) return null;

    const inside = label.querySelector?.("input[type='checkbox'], [role='checkbox']");
    if (inside) return inside;

    // Fallback: click the visible label/row. On mobile Meta this often toggles
    // the checkbox even when the actual input is hidden.
    return getClickableTarget(label);
  }

  async function autoClickMetaFinalReview(force = false) {
    if (!isMetaAuthPage() || !isMetaFinalReviewPage()) return { ok: false, message: "Final review page not found." };

    if (window.__agentmailFinalReviewAutomationRunning && !force) {
      return { ok: true, message: "Final review automation already running." };
    }

    window.__agentmailFinalReviewAutomationRunning = true;
    try {
        const checkbox = findMetaMarketingCheckbox();
      if (checkbox && (!isCheckedLike(checkbox) || force) && !window.__agentmailFinalReviewCheckboxClicked) {
        flash(checkbox);
        await clickStrong(() => findMetaMarketingCheckbox(), { kind: "final-review-checkbox" });
        window.__agentmailFinalReviewCheckboxClicked = true;
        await sleep(100);
      }

      for (let i = 0; i < 12; i += 1) {
        const createBtn = findButtonByExactText("Create account");
        if (!createBtn) {
          await sleep(90);
          continue;
        }

        if (!isDisabledLike(createBtn) || i > 4) {
          flash(createBtn);
          await clickStrong(() => findButtonByExactText("Create account"), { kind: "final-create" });
          window.__agentmailFinalReviewCreateClicked = true;
          return { ok: true, message: "Final Create account clicked." };
        }
        await sleep(100);
      }

      return { ok: false, message: "Create account button not clickable yet." };
    } finally {
      window.__agentmailFinalReviewAutomationRunning = false;
    }
  }

  function isMetaAiDetailsConfirmPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    return (
      pageText.includes("edit your meta ai details") &&
      pageText.includes("by tapping confirm") &&
      pageText.includes("confirm")
    ) || (
      pageText.includes("username") &&
      pageText.includes("name (optional)") &&
      pageText.includes("confirm") &&
      pageText.includes("terms") &&
      pageText.includes("policies")
    );
  }

  // ---------------------------------------------------------------
  // v3.3 LUX - the "Edit your Meta AI details" page.
  //
  // The user's screenshot: the Name (optional) box held the account EMAIL
  // (strangecountry222@agentmail.to). Whatever put it there, this engine must
  // never leave an email address in a name box: the email filler is not allowed
  // on this page at all, and any email already sitting in the box is replaced
  // with a proper human name before Confirm is pressed.
  // ---------------------------------------------------------------
  function findMetaAiDetailsNameInput() {
    if (!isMetaAuthPage() || !isMetaAiDetailsConfirmPage()) return null;
    try {
      const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
        .filter((el) => !el.disabled && !el.readOnly && isVisible(el));
      const ranked = inputs.map((el) => {
        const hint = normalizeText([
          el.name, el.id, el.placeholder, el.getAttribute("aria-label"),
          el.getAttribute("data-testid"), el.autocomplete,
          el.closest("label")?.innerText,
          el.parentElement?.innerText
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        let score = 0;
        if (hint.includes("name (optional)")) score += 80;
        if (hint.includes("name")) score += 30;
        if (hint.includes("username") || hint.includes("user name")) score -= 120;
        if (type === "email") score -= 200;
        return { el, score };
      }).filter((item) => item.score > 0).sort((a, b) => b.score - a.score);
      return ranked[0]?.el || null;
    } catch (error) {
      return null;
    }
  }

  async function autoCleanMetaAiDetailsName(force = false) {
    if (!isMetaAuthPage() || !isMetaAiDetailsConfirmPage()) return { ok: false, message: "Not the Meta AI details page." };
    const now = Date.now();
    if (!force && now - (window.__agentmailAiDetailsCheckAt || 0) < 400) return { ok: true, message: "Details check throttled." };
    window.__agentmailAiDetailsCheckAt = now;
    const input = findMetaAiDetailsNameInput();
    if (!input) return { ok: false, message: "Name (optional) box not found." };
    const value = getEditableValue(input).trim();
    if (!value || !value.includes("@")) return { ok: true, message: "Name box is clean." };
    const { first, last } = getGeneratedMetaName();
    const pretty = `${first} ${last}`;
    window.__agentmailAiDetailsNameCleanedAt = Date.now();
    powerLog("Name box had an email - replaced with a proper name (v3.3)");
    const wrote = await fillStrong(input, pretty, { kind: "ai-details-name" });
    if (!wrote) await typeLikeHuman(input, pretty).catch(() => {});
    const after = getEditableValue(input).trim();
    return { ok: !after.includes("@"), message: after.includes("@") ? "Name box still had an email." : `Name box cleaned: ${pretty}` };
  }

  // v3.3 LUX: keep the created account (mail + the password in use) so the user
  // can read it straight away in the panel / Account list / CopyMails.
  function keepCreatedAccount(source = "Meta AI Confirm") {
    const fire = () => sendRuntimeMessage({ type: "AGENTMAIL_SAVE_CURRENT_ACCOUNT", source }).then((r) => {
      try {
        if (r && r.ok && r.account) {
          window.__agentmailKeptAccount = r.account;
          powerLog(`Account kept: ${r.account.email} / ${r.account.password}`);
          updateEngineHud();
        }
      } catch (error) {}
      return r;
    }, () => {});
    try {
      fire();
      if (!window.__agentmailKeepOnHide) {
        window.__agentmailKeepOnHide = true;
        // the page may navigate in the same tick - one last chance to persist
        window.addEventListener("pagehide", () => { try { fire(); } catch (error) {} });
      }
    } catch (error) {}
  }

  async function autoClickMetaAiDetailsConfirm(force = false) {
    if (!isMetaAuthPage() || !isMetaAiDetailsConfirmPage()) return { ok: false, message: "Meta AI details confirm page not found." };

    if (window.__agentmailMetaAiDetailsConfirmRunning && !force) {
      return { ok: true, message: "Meta AI details Confirm click already running." };
    }

    window.__agentmailMetaAiDetailsConfirmRunning = true;
    try {
      for (let i = 0; i < 12; i += 1) {
        const confirmBtn = findButtonByExactText("Confirm");
        if (!confirmBtn) {
          await sleep(90);
          continue;
        }
        if (!isDisabledLike(confirmBtn) || i > 4) {
          flash(confirmBtn);
          // v3.3 LUX: keep the account BEFORE the press. This page navigates the
          // instant Confirm lands, so anything after the awaited click was lost.
          keepCreatedAccount("Meta AI Confirm");
          await clickStrong(() => findButtonByExactText("Confirm"), { kind: "meta-ai-confirm" });
          window.__agentmailMetaAiDetailsConfirmClicked = true;
          return { ok: true, message: "Meta AI details Confirm clicked." };
        }
        await sleep(100);
      }
      return { ok: false, message: "Confirm button not clickable yet." };
    } finally {
      window.__agentmailMetaAiDetailsConfirmRunning = false;
    }
  }

  function isMetaConfirmationCodePage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("enter the confirmation code") ||
      pageText.includes("confirmation code") && pageText.includes("6-digit") ||
      pageText.includes("code that was sent") ||
      pageText.includes("send code again") ||
      // New Meta AI flow screenshot: "Confirm your account" + "We sent a code to ..."
      pageText.includes("confirm your account") ||
      (pageText.includes("we sent a code to") && pageText.includes("look for an email")) ||
      (pageText.includes("we sent a code") && pageText.includes("send code again"))
    );
  }

  function findMetaConfirmationCodeInput() {
    if (!isMetaConfirmationCodePage()) return null;

    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el));

    const ranked = inputs
      .map((el) => {
        const text = normalizeText([
          el.type,
          el.name,
          el.id,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.autocomplete,
          el.inputMode
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        let score = 0;
        if (text.includes("confirmation code")) score += 80;
        if (text.includes("code")) score += 55;
        if (normalizeText(el.placeholder) === "code" || normalizeText(el.getAttribute("aria-label")) === "code") score += 65;
        if (["number", "tel", "text", ""].includes(type)) score += 12;
        if (String(el.inputMode || "").toLowerCase() === "numeric") score += 25;
        const rect = el.getBoundingClientRect();
        if (rect.top > 0 && rect.top < window.innerHeight * 0.55) score += 10;
        return { el, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);

    return ranked[0]?.el || inputs[0] || null;
  }

  function getCurrentConfirmationCodeValue() {
    const input = findMetaConfirmationCodeInput();
    if (!input) return "";
    return getEditableValue(input).replace(/\D+/g, "").slice(0, 6);
  }

  function confirmationCodeReady() {
    return /^\d{6}$/.test(getCurrentConfirmationCodeValue());
  }

  function clearPostCodeMetaAiRedirectFlag() {
    try {
      sessionStorage.removeItem("agentmail_meta_ai_after_code_pending");
      sessionStorage.removeItem("agentmail_meta_ai_after_code_started_at");
    } catch (error) {}
    window.__agentmailMetaAiAfterCodeScheduled = false;
  }

  function redirectMetaAiIfPostCodePending(force = false) {
    // User update: after OTP paste/Continue, do NOT go to https://www.meta.ai/.
    // Clean any old v1.8.18 pending redirect flag so upgraded tabs do not move.
    clearPostCodeMetaAiRedirectFlag();
    return false;
  }

  function scheduleMetaAiAfterConfirmationContinue(minDelay = 700) {
    // Kept for existing callers, but intentionally no navigation now.
    clearPostCodeMetaAiRedirectFlag();
    return false;
  }

  function findConfirmationContinueButton() {
    return findContinueButton() || findNextButton() || findButtonByExactVisibleText("Continue") || findButtonByExactVisibleText("Next");
  }

  async function clickNextAfterConfirmationCode() {
    if (!confirmationCodeReady()) return false;
    // v3.2 NOREFRESH: the submit is in flight (the button spins) - a reload now
    // would destroy it. Hold every reload path off for two minutes.
    markCodeStepNoReload(120000);

    const input = findMetaConfirmationCodeInput();
    const code = getCurrentConfirmationCodeValue();
    const clickedSameInput = window.__agentmailConfirmationContinueClickedForCode === code &&
      window.__agentmailConfirmationContinueClickedInput === input;
    if (clickedSameInput) {
      scheduleMetaAiAfterConfirmationContinue(300);
      return true;
    }

    const startedAt = Date.now();
    let attempts = 0;
    while (Date.now() - startedAt < 1200) {
      if (!confirmationCodeReady()) return false;
      const button = findConfirmationContinueButton();
      if (button && (!isDisabledLike(button) || attempts > 3)) {
        flash(button);
        await humanDelay(1);
        await clickStrong(button, { kind: "otp-continue", pageId: POWER.lastPage.id });
        window.__agentmailConfirmationContinueClickedAt = Date.now();
        window.__agentmailConfirmationContinueClickedForCode = code;
        window.__agentmailConfirmationContinueClickedInput = input;
        scheduleMetaAiAfterConfirmationContinue();
        return true;
      }
      attempts += 1;
      if (button) await waitFor(() => !isDisabledLike(button), { timeout: 260, poll: 30 });
      else await waitFor(() => confirmationCodeReady(), { timeout: 140, poll: 30 });
    }
    return false;
  }

  function redirectFromConfirmationCodePage(force = false) {
    if (!isMetaAuthPage() || !isMetaConfirmationCodePage()) return { ok: false, message: "Confirmation code page not found." };
    // v3.2 NOREFRESH: this used to send the tab back to the start link the FIRST
    // time the code screen appeared. From the user's side that was an automatic
    // "refresh" exactly when the code had to be entered - it cancelled the freshly
    // sent code and could end on a blank page. We now STAY on the page: the code
    // flow below pastes the code and presses Continue.
    try { sessionStorage.setItem("agentmail_code_page_redirect_done", "1"); } catch (error) {}
    try { sessionStorage.setItem("agentmail_last_code_page_redirect", String(Date.now())); } catch (error) {}
    markCodeStepNoReload();
    powerLog("Code page reached - staying put, no auto reload (v3.2 NOREFRESH)");
    return { ok: true, message: "Code page: staying put (no automatic reload); pasting the code." };
  }

  function findMetaConfirmationSendCodeAgainButton() {
    if (!isMetaConfirmationCodePage()) return null;
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title")),
        area: rectArea(el)
      }))
      .filter((item) => (
        item.text === "send code again" ||
        item.text.includes("send code again") ||
        item.text.includes("resend code") ||
        item.text.includes("send another code") ||
        item.text.includes("send a new code") ||
        item.text.includes("get a new code")
      ))
      .filter((item) => !item.text.includes("edit") && item.area > 25 && item.area < 260000)
      .sort((a, b) => {
        const exactA = a.text === "send code again" ? 0 : 1;
        const exactB = b.text === "send code again" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });
    return candidates[0]?.el ? getClickableTarget(candidates[0].el) : null;
  }

  function clickMetaConfirmationResendOkIfShown() {
    if (isMetaOopsModalVisible()) return false;
    const okButton = findButtonByExactVisibleText("OK") || findButtonByExactVisibleText("Okay");
    if (!okButton || isDisabledLike(okButton)) return false;
    flash(okButton);
    clickStrong(() => findButtonByExactVisibleText("OK") || findButtonByExactVisibleText("Okay"), { kind: "resend-ok" });
    return true;
  }

  // v3.1 HUMAN: a single click that moves like a hand - it drifts in with two
  // pointer moves, presses for ~70-140 ms, then releases and clicks. Nothing is
  // fired twice: the caller below only ever calls this ONCE per page.
  async function humanClickOnce(target) {
    if (!target) return false;
    try {
      const rect = getRect(target);
      if (!rect || !rect.width || !rect.height) return false;
      await sleep(130 + randomIndex(150));                 // natural hesitation
      try { target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
      const rect2 = getRect(target);
      if (!rect2 || !rect2.width || !rect2.height) return false;
      const x = rect2.left + rect2.width * (0.42 + Math.random() * 0.16);
      const y = rect2.top + rect2.height * (0.44 + Math.random() * 0.14);
      const hit = document.elementFromPoint(x, y);
      if (hit && hit !== target && !target.contains(hit) && !hit.contains(target)) return false;
      const base = { bubbles: true, cancelable: true, composed: true, view: window, button: 0, buttons: 1, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;
      const at = (px, py) => ({ ...base, clientX: px, clientY: py, screenX: window.screenX + px, screenY: window.screenY + py });
      const touchAt = (kind, px, py) => {
        try {
          if (typeof window.TouchEvent !== "function" || typeof window.Touch !== "function") return;
          const t = new window.Touch({ identifier: 1, target, clientX: px, clientY: py, pageX: px, pageY: py, screenX: px, screenY: py });
          const active = kind === "touchend" ? [] : [t];
          target.dispatchEvent(new window.TouchEvent(kind, { bubbles: true, cancelable: true, composed: true, view: window, touches: active, targetTouches: active, changedTouches: [t] }));
        } catch (error) {}
      };
      // the hand travels in
      const sx = x - 26 - Math.random() * 18;
      const sy = y - 16 - Math.random() * 12;
      target.dispatchEvent(new MouseEvent("mouseover", at(sx, sy)));
      target.dispatchEvent(new Pointer("pointermove", at(sx, sy)));
      target.dispatchEvent(new MouseEvent("mousemove", at(sx, sy)));
      await sleep(26 + randomIndex(28));
      const nx = x - 5 + Math.random() * 10;
      const ny = y - 4 + Math.random() * 8;
      target.dispatchEvent(new Pointer("pointermove", at(nx, ny)));
      target.dispatchEvent(new MouseEvent("mousemove", at(nx, ny)));
      await sleep(22 + randomIndex(24));
      // press, hold, release
      target.dispatchEvent(new Pointer("pointerdown", at(x, y)));
      target.dispatchEvent(new MouseEvent("mousedown", at(x, y)));
      touchAt("touchstart", x, y);
      await sleep(70 + randomIndex(70));
      target.dispatchEvent(new Pointer("pointerup", { ...at(x, y), buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...at(x, y), buttons: 0 }));
      touchAt("touchend", x, y);
      target.dispatchEvent(new MouseEvent("click", { ...at(x, y), buttons: 0 }));
      try { flash(target); } catch (error) {}
      invalidateDomCache();
      return true;
    } catch (error) {
      return false;
    }
  }

  // ONE-SEND RULE (v3.1): the mailbox this page is confirming. The record below
  // makes a second send impossible even after a reload or a new tab.
  function confirmationMailboxName() {
    try {
      const text = getPageTextFast();
      const match = text.match(/we sent a code to\s+([^\s]+@[^\s]+)/i) || text.match(/([^\s]+@[^\s.]+\.[^\s]+)/);
      return match ? match[1].toLowerCase().replace(/[.,]$/, "") : "unknown-mailbox";
    } catch (error) {
      return "unknown-mailbox";
    }
  }

  function resendGuardKey() {
    return "agentmail_resend_once_" + confirmationMailboxName();
  }

  function resendGuardRead() {
    return new Promise((resolve) => {
      try {
        if (!chrome?.storage?.local) return resolve(0);
        chrome.storage.local.get([resendGuardKey()], (data) => resolve(Number(data?.[resendGuardKey()] || 0)));
      } catch (error) { resolve(0); }
    });
  }

  function resendGuardWrite() {
    try {
      if (!chrome?.storage?.local) return;
      chrome.storage.local.set({ [resendGuardKey()]: Date.now() });
    } catch (error) {}
  }

  async function clickMetaConfirmationSendCodeAgainOnce(force = false) {
    if (!isMetaAuthPage() || !isMetaConfirmationCodePage()) return false;
    // v3.1 ONE-SEND RULE: three independent locks must all be open before the one
    // (and only) resend is allowed to fire.
    if (window.__agentmailResendFired) return false;
    try { if (sessionStorage.getItem("agentmail_confirmation_resend_clicked_once") === "1") return false; } catch (error) {}
    if (!force) {
      const last = await resendGuardRead();
      if (last && Date.now() - last < 10 * 60 * 1000) {
        powerLog("Send code already used for this mailbox - not sending again");
        return false;
      }
    }

    for (let i = 0; i < 12; i += 1) {
      const button = findMetaConfirmationSendCodeAgainButton();
      if (button && (!isDisabledLike(button) || i > 6)) {
        window.__agentmailResendFired = true;
        try { sessionStorage.setItem("agentmail_confirmation_resend_clicked_once", "1"); } catch (error) {}
        resendGuardWrite();
        const ok = await humanClickOnce(button);
        powerLog(ok ? "Send code again: clicked ONCE (human shaped)" : "Send code again: press failed");
        [420, 900, 1600, 2600, 4200].forEach((delay) => {
          setTimeout(() => clickMetaConfirmationResendOkIfShown(), delay);
        });
        return ok;
      }
      await sleep(120);
    }
    return false;
  }

  async function autoFillMetaConfirmationCodePage(force = false) {
    if (!isMetaAuthPage() || !isMetaConfirmationCodePage()) return { ok: false, message: "Confirmation code page not found." };

    // v3.2 NOREFRESH: the first-visit redirect is gone. Mark the step as handled
    // (so no legacy path can trigger it) and continue straight to the paste in the
    // SAME pass - no reload, no lost OTP.
    try {
      if (sessionStorage.getItem("agentmail_code_page_redirect_done") !== "1") {
        sessionStorage.setItem("agentmail_code_page_redirect_done", "1");
        powerLog("Code page first visit - pasting here, no reload (v3.2)");
      }
    } catch (error) {}
    markCodeStepNoReload();

    // v3.1: ONE code flow at a time, whatever the caller says - a forced call used
    // to start a second parallel mailbox poll and the page could end up with dozens
    // of them hammering the mail API. A forced call now just queues one re-run.
    if (window.__agentmailConfirmationCodeAutomationRunning) {
      if (force) window.__agentmailConfirmationCodeRerunQueued = true;
      return { ok: true, message: "Confirmation code automation already running." };
    }

    const input = findMetaConfirmationCodeInput();
    if (!input) return { ok: false, message: "Confirmation code input not found yet." };

    if (window.__agentmailConfirmationActiveInput !== input) {
      window.__agentmailConfirmationActiveInput = input;
      window.__agentmailLastPastedConfirmationCode = null;
      window.__agentmailConfirmationCodeFilledAt = 0;
      window.__agentmailConfirmationContinueClickedForCode = null;
      window.__agentmailConfirmationContinueClickedInput = null;
    }

    const current = getEditableValue(input).trim();
    if (/^\d{6}$/.test(current)) {
      if (!window.__agentmailConfirmationCodeFilledAt || Date.now() - window.__agentmailConfirmationCodeFilledAt > 1200) {
        window.__agentmailConfirmationCodeFilledAt = Date.now();
      }
      const clicked = await clickNextAfterConfirmationCode();
      scheduleMetaAiAfterConfirmationContinue(clicked ? 450 : 1800);
      return { ok: true, message: "Confirmation code already filled; Continue clicked." };
    }

    window.__agentmailConfirmationCodeAutomationRunning = true;
    try {
      // v3.1: the first email is already on its way the moment this screen opens -
      // wait for it properly (18 s) BEFORE touching "Send code again". That is why
      // the code is now sent only once on this page instead of twice.
      let result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_CONFIRMATION_CODE", timeoutMs: 18000 });
      if (!result.ok || !result.code) {
        const resent = await clickMetaConfirmationSendCodeAgainOnce(false);
        if (resent) await sleep(220);
        result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_CONFIRMATION_CODE", timeoutMs: 90000 });
      }
      if (!result.ok || !result.code) {
        return { ok: false, message: result.error || "Confirmation code not received yet." };
      }

      const code = String(result.code || "").trim();
      const currentDigitsBeforePaste = getCurrentConfirmationCodeValue();
      if (currentDigitsBeforePaste === code) {
        const clicked = await clickNextAfterConfirmationCode();
        scheduleMetaAiAfterConfirmationContinue(clicked ? 450 : 1800);
        return { ok: true, message: "Confirmation code already in field; Continue clicked." };
      }
      const sameInputRecentPaste = window.__agentmailLastPastedConfirmationCode === code &&
        window.__agentmailConfirmationActiveInput === input &&
        Date.now() - (window.__agentmailConfirmationCodeFilledAt || 0) < 700;
      if (sameInputRecentPaste && !force) {
        await waitFor(() => confirmationCodeReady(), { timeout: 160, poll: 8 });
        await clickNextAfterConfirmationCode();
        return { ok: true, message: "Confirmation code paste already attempted; waiting." };
      }

      input.focus?.();
      const pasted = await pasteCodeStrong(code);
      if (!pasted) setNativeValue(input, code);
      window.__agentmailLastPastedConfirmationCode = code;
      window.__agentmailConfirmationCodeFilledAt = Date.now();
      markCodeStepNoReload(120000);   // v3.2 NOREFRESH: from this moment on, no reloads
      flash(input);

      // Avoid OTP field glitch: paste once, then continue the instant all digits land.
      if (!/^\d{6}$/.test(getCurrentConfirmationCodeValue())) {
        await waitFor(() => /^\d{6}$/.test(getCurrentConfirmationCodeValue()), { timeout: 200, poll: 8 });
      } else {
        await humanDelay(1);
      }
      const clicked = await clickNextAfterConfirmationCode();
      scheduleMetaAiAfterConfirmationContinue(clicked ? 450 : 1800);
      setTimeout(() => {
        if (isMetaAuthPage() && isMetaConfirmationCodePage()) {
          scheduleMetaAiAfterConfirmationContinue(0);
        }
      }, 2600);
      return { ok: true, message: clicked ? `Confirmation code filled and Continue clicked: ${code}` : `Confirmation code filled: ${code}` };
    } finally {
      window.__agentmailConfirmationCodeAutomationRunning = false;
      if (window.__agentmailConfirmationCodeRerunQueued) {
        window.__agentmailConfirmationCodeRerunQueued = false;
        if (isMetaAuthPage() && isMetaConfirmationCodePage() && !confirmationCodeReady()) {
          setTimeout(() => { try { autoFillMetaConfirmationCodePage(true); } catch (error) {} }, 120);
        }
      }
    }
  }

  function findButtonByExactVisibleText(label) {
    const wanted = normalizeText(label);
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === wanted)
      .filter((item) => item.area > 35 && item.area < 260000)
      .sort((a, b) => a.area - b.area);

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function isMetaOopsModalVisible() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("oops") &&
      pageText.includes("something went wrong") &&
      (pageText.includes("try again") || pageText.includes("getting this fixed"))
    );
  }

  async function autoClickMetaOopsOk(force = false) {
    if (!isMetaAuthPage() || !isMetaOopsModalVisible()) return { ok: false, message: "Oops modal not found." };

    if (window.__agentmailOopsOkClickRunning && !force) {
      return { ok: true, message: "Oops refresh already running." };
    }

    const now = Date.now();
    const lastRefresh = Number(sessionStorage.getItem("agentmail_last_oops_modal_refresh") || "0");
    if (!force && now - lastRefresh < 8000) {
      return { ok: true, message: "Oops modal already refreshed recently." };
    }

    window.__agentmailOopsOkClickRunning = true;
    try {
      sessionStorage.setItem("agentmail_last_oops_modal_refresh", String(now));
      // If Oops appears on the code page, after refresh we should paste the code,
      // not redirect again.
      if (isMetaConfirmationCodePage()) sessionStorage.setItem("agentmail_code_page_redirect_done", "1");
      setTimeout(() => reloadAuthPageOnce("oops_modal_once"), 350);
      return { ok: true, message: "Oops modal detected; refreshing once." };
    } finally {
      setTimeout(() => { window.__agentmailOopsOkClickRunning = false; }, 1200);
    }
  }

  function isMetaCreateAccountBlockedPaused() {
    try {
      return sessionStorage.getItem("agentmail_create_blocked_stop") === "1";
    } catch (error) {
      return Boolean(window.__agentmailCreateBlockedStop);
    }
  }

  function isMetaCreateAccountBlockedModal() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    return (
      pageText.includes("something went wrong") &&
      (
        pageText.includes("can't create a new account") ||
        pageText.includes("can’t create a new account") ||
        pageText.includes("cannot create a new account") ||
        pageText.includes("you can't create a new account") ||
        pageText.includes("you can’t create a new account")
      ) &&
      pageText.includes("ok")
    );
  }

  async function autoHandleMetaCreateAccountBlocked(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    const modalVisible = isMetaCreateAccountBlockedModal();
    if (!modalVisible && !isMetaCreateAccountBlockedPaused()) {
      return { ok: false, message: "Create-account block modal not found." };
    }

    window.__agentmailCreateBlockedStop = true;
    try { sessionStorage.setItem("agentmail_create_blocked_stop", "1"); } catch (error) {}

    if (window.__agentmailCreateBlockedOkRunning && !force) {
      return { ok: true, message: "Create-account block already handled; automation paused." };
    }

    if (!modalVisible) {
      return { ok: true, message: "Create-account block detected earlier; automation paused." };
    }

    window.__agentmailCreateBlockedOkRunning = true;
    try {
      for (let i = 0; i < 10; i += 1) {
        const okButton = findButtonByExactVisibleText("OK") || findButtonByExactVisibleText("Ok");
        if (okButton) {
          flash(okButton);
          await clickStrong(() => findButtonByExactVisibleText("OK") || findButtonByExactVisibleText("Ok"), { kind: "blocked-ok" });
        }
        await waitFor(() => !isMetaCreateAccountBlockedModal(), { timeout: 260, poll: 40 });
        if (!isMetaCreateAccountBlockedModal()) break;
      }
      return { ok: true, message: "Meta says account cannot be created now; OK clicked and automation paused." };
    } finally {
      window.__agentmailCreateBlockedOkRunning = false;
    }
  }

  function parseRgbColor(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/i);
    if (!match) return null;
    return {
      r: Number(match[1]),
      g: Number(match[2]),
      b: Number(match[3]),
      a: match[4] === undefined ? 1 : Number(match[4])
    };
  }

  function isStrongMetaBlueColor(color) {
    if (!color || color.a < 0.75) return false;
    // Active Meta blue is usually around rgb(0, 100, 224) / rgb(24, 119, 242).
    // Disabled captcha button is pale blue, with high red value. Reject that.
    return color.b >= 145 && color.g >= 70 && color.r <= 90 && color.b > color.r + 70;
  }

  function buttonLooksActiveBlue(button) {
    if (!button || !isVisible(button)) return false;

    let node = button;
    for (let depth = 0; node && node !== document.documentElement && depth < 6; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const style = getCachedStyle(node);
      if (Number(style?.opacity || "1") < 0.72) return false;
      const bg = parseRgbColor(style.backgroundColor);
      if (isStrongMetaBlueColor(bg)) return true;
    }

    const descendants = [...button.querySelectorAll?.("div, span, button") || []].slice(0, 20);
    return descendants.some((el) => isVisible(el) && isStrongMetaBlueColor(parseRgbColor(getCachedStyle(el)?.backgroundColor || "")));
  }

  async function fireHumanLikeClick(target) {
    if (!target) return false;
    const rect = getRect(target);
    const x = rect ? rect.left + rect.width * (0.38 + randomIndex(24) / 100) : 0;
    const y = rect ? rect.top + rect.height * (0.38 + randomIndex(24) / 100) : 0;
    const base = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: window.screenX + x,
      screenY: window.screenY + y,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: "touch",
      isPrimary: true
    };

    try { target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
    try { target.focus({ preventScroll: true }); } catch (error) {}

    const Pointer = window.PointerEvent || window.MouseEvent;
    try {
      target.dispatchEvent(new Pointer("pointerover", base));
      target.dispatchEvent(new Pointer("pointerenter", base));
      target.dispatchEvent(new Pointer("pointerdown", base));
    } catch (error) {
      target.dispatchEvent(new MouseEvent("mousedown", base));
    }

    // One soft frame instead of 120-280ms of dead time (instant when hidden).
    await humanDelay(1);

    try {
      if (window.Touch && window.TouchEvent) {
        const touch = new Touch({
          identifier: 1,
          target,
          clientX: x,
          clientY: y,
          screenX: window.screenX + x,
          screenY: window.screenY + y
        });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        await humanDelay(1);
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      }
    } catch (error) { /* touch not supported - pointer/mouse path already sent */ }

    try {
      target.dispatchEvent(new Pointer("pointerup", { ...base, buttons: 0 }));
    } catch (error) {
      target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
    }
    target.dispatchEvent(new MouseEvent("mousedown", base));
    target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
    target.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
    invalidateDomCache();
    return true;
  }

  function isMetaHumanConfirmPage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("confirm that you're human") ||
      pageText.includes("confirm that you’re human") ||
      pageText.includes("human to use your account") ||
      pageText.includes("confirm you're human") ||
      pageText.includes("confirm you’re human")
    );
  }

  function scheduleHumanContinueStuckRefresh(reason = "human_continue") {
    clearTimeout(window.__agentmailHumanContinueStuckTimer);
    window.__agentmailHumanContinueStuckTimer = setTimeout(() => {
      if (!isMetaAuthPage() || !isMetaHumanConfirmPage()) return;
      if (codeStepNoReloadActive()) return;   // v3.2 NOREFRESH

      const now = Date.now();
      const lastRefresh = Number(sessionStorage.getItem("agentmail_last_human_stuck_refresh") || "0");
      if (now - lastRefresh < 12000) return;

      sessionStorage.setItem("agentmail_last_human_stuck_refresh", String(now));
      window.location.reload();
    }, 7000);
  }

  function humanCaptchaIsPresent() {
    const pageText = getPageTextFast();
    if (
      pageText.includes("i'm not a robot") ||
      pageText.includes("i’m not a robot") ||
      pageText.includes("not a robot") ||
      pageText.includes("recaptcha") ||
      pageText.includes("security check")
    ) return true;

    return Boolean(document.querySelector("iframe[src*='recaptcha'], iframe[src*='google.com/recaptcha'], iframe[title*='recaptcha' i], iframe[title*='captcha' i]"));
  }

  function greenishStyleValue(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return false;
    const r = Number(match[1]);
    const g = Number(match[2]);
    const b = Number(match[3]);
    return g > 120 && g > r * 1.25 && g > b * 1.15;
  }

  function elementLooksLikeSolvedCaptchaTick(el) {
    if (!el || !isVisible(el)) return false;
    const text = el.innerText || el.textContent || "";
    if (/✓|✔|✅/.test(text)) return true;

    const style = getCachedStyle(el) || {};
    const green =
      greenishStyleValue(style.color) ||
      greenishStyleValue(style.backgroundColor) ||
      greenishStyleValue(style.borderColor) ||
      greenishStyleValue(style.fill) ||
      greenishStyleValue(style.stroke);
    if (!green) return false;

    const rect = el.getBoundingClientRect();
    return rect.width >= 8 && rect.width <= 90 && rect.height >= 8 && rect.height <= 90;
  }

  function visibleNotRobotSolvedIndicator() {
    const pageText = getPageTextFast();
    if (!pageText.includes("not a robot") && !pageText.includes("recaptcha")) return false;

    const checkedControls = queryAllDeep("input[type='checkbox'], [role='checkbox'], [aria-checked]")
      .filter((el) => isVisible(el) || (el.getAttribute("aria-checked") || "").toLowerCase() === "true")
      .filter((el) => {
        if (typeof el.checked === "boolean" && el.checked) return true;
        return (el.getAttribute("aria-checked") || "").toLowerCase() === "true";
      });
    if (checkedControls.length) return true;

    const robotTextNodes = queryAllDeep("div, span, label, p")
      .filter((el) => isVisible(el))
      .filter((el) => normalizeText(el.innerText || el.textContent || "").includes("not a robot"));

    for (const node of robotTextNodes) {
      let box = node;
      for (let depth = 0; box && depth < 5; depth += 1, box = box.parentElement) {
        const candidates = [...box.querySelectorAll("svg, path, span, div, i")];
        if (candidates.some(elementLooksLikeSolvedCaptchaTick)) return true;
      }
    }

    // Final fallback: page text itself contains a visible tick and the robot label.
    const rawText = document.body?.innerText || document.body?.textContent || "";
    return /✓|✔|✅/.test(rawText) && normalizeText(rawText).includes("not a robot");
  }

  function humanCaptchaChallengeOpen() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("select all squares") ||
      pageText.includes("if there are none") ||
      pageText.includes("click skip") ||
      pageText.includes("crosswalk") ||
      pageText.includes("traffic light") ||
      pageText.includes("bicycle") ||
      pageText.includes("bus") ||
      pageText.includes("motorcycle") ||
      pageText.includes("stairs") ||
      pageText.includes("chimney") ||
      pageText.includes("skip")
    );
  }

  function humanCaptchaLooksComplete() {
    if (!humanCaptchaIsPresent()) return true;

    // Very strict: don't trust hidden g-recaptcha-response tokens because Meta or
    // Google can create them before the visible challenge is accepted. Continue
    // only after a checked control or visible green/tick solved indicator.
    return visibleNotRobotSolvedIndicator();
  }

  async function autoClickMetaHumanContinue(force = false) {
    // CAPTCHA / human-verification screens must be handled manually.
    // Automated Continue clicks after CAPTCHA can be rejected by Meta/Google and
    // may cause the page to get stuck. So this function intentionally does not
    // click on human verification pages.
    if (!isMetaAuthPage() || !isMetaHumanConfirmPage()) {
      return { ok: false, message: "Human confirm page not found." };
    }
    return { ok: true, message: "Manual CAPTCHA step: solve it and tap Continue yourself." };
  }

  function isMetaFullPageSomethingWentWrong() {
    const pageText = getPageTextFast();
    if (!pageText.includes("something went wrong")) return false;
    // Modal has Oops + OK and should be handled by OK click. Full error page has
    // just "Something went wrong." and no useful button.
    if (pageText.includes("oops") && pageText.includes("ok")) return false;
    return true;
  }

  async function autoRefreshMetaSomethingWentWrong(force = false) {
    if (!isMetaAuthPage() || !isMetaFullPageSomethingWentWrong()) return { ok: false, message: "Full error page not found." };
    if (codeStepNoReloadActive()) return { ok: true, message: "NOREFRESH: error refresh held back during the code step." };

    const now = Date.now();
    const lastRefresh = Number(sessionStorage.getItem("agentmail_last_error_refresh") || "0");
    if (!force && now - lastRefresh < 6000) {
      return { ok: true, message: "Recently refreshed for error page." };
    }

    sessionStorage.setItem("agentmail_last_error_refresh", String(now));
    setTimeout(() => window.location.reload(), 700);
    return { ok: true, message: "Something went wrong page detected; refreshing." };
  }

  function isMetaCantUseRightNowPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    const cantUse =
      pageText.includes("can't use meta right now") ||
      pageText.includes("can’t use meta right now") ||
      pageText.includes("cannot use meta right now") ||
      pageText.includes("you can't use meta right now") ||
      pageText.includes("you can’t use meta right now");
    if (!cantUse) return false;
    return (
      pageText.includes("reviewing your submission") ||
      pageText.includes("what happens next") ||
      pageText.includes("won't be able to use meta") ||
      pageText.includes("won’t be able to use meta") ||
      pageText.includes("until then")
    );
  }

  async function autoRefreshMetaCantUseRightNow(force = false) {
    if (!isMetaAuthPage() || !isMetaCantUseRightNowPage()) {
      return { ok: false, message: "Can't-use-Meta review page not found." };
    }

    const alreadyRefreshedOnce = sessionStorage.getItem("agentmail_cant_use_meta_refresh_once_done") === "1";
    if (alreadyRefreshedOnce && !force) {
      return { ok: true, message: "Can't-use-Meta page already refreshed once; not looping." };
    }

    sessionStorage.setItem("agentmail_cant_use_meta_refresh_once_done", "1");
    sessionStorage.setItem("agentmail_last_cant_use_meta_refresh", String(Date.now()));
    setTimeout(() => reloadAuthPageOnce("cant_use_meta_right_now_once"), 650);
    return { ok: true, message: "Can't-use-Meta review page detected; refreshing once." };
  }

  function isMetaSelfieUploadPage() {
    const pageText = getPageTextFast();
    return (
      pageText.includes("upload a verification selfie") ||
      pageText.includes("upload a photo that clearly shows your face") ||
      pageText.includes("well-lit and isn't blurry") ||
      pageText.includes("well-lit and isn’t blurry") ||
      pageText.includes("don't include other people") ||
      pageText.includes("don’t include other people")
    );
  }

  function scheduleRedirectAfterSelfieUploadGone() {
    try {
      sessionStorage.setItem("agentmail_selfie_redirect_after_gone", "1");
      sessionStorage.setItem("agentmail_selfie_continue_clicked_at", String(Date.now()));
    } catch (error) {}

    const checkAndRedirect = () => {
      if (!isMetaAuthPage()) return false;
      try {
        if (sessionStorage.getItem("agentmail_selfie_redirect_after_gone") !== "1") return false;
        const clickedAt = Number(sessionStorage.getItem("agentmail_selfie_continue_clicked_at") || "0");
        if (clickedAt && Date.now() - clickedAt > 120000) {
          sessionStorage.removeItem("agentmail_selfie_redirect_after_gone");
          sessionStorage.removeItem("agentmail_selfie_continue_clicked_at");
          return false;
        }
      } catch (error) {}

      if (isMetaSelfieUploadPage()) return false;

      try {
        sessionStorage.removeItem("agentmail_selfie_redirect_after_gone");
        sessionStorage.removeItem("agentmail_selfie_continue_clicked_at");
      } catch (error) {}
      setTimeout(() => {
        try { window.location.replace(CODE_PAGE_REDIRECT_URL); }
        catch (error) { window.location.href = CODE_PAGE_REDIRECT_URL; }
      }, 90);
      return true;
    };

    [300, 700, 1200, 1800, 2600, 3800, 5200, 7000, 9500, 12500, 16000, 22000, 30000].forEach((delay) => {
      setTimeout(checkAndRedirect, delay);
    });
    return checkAndRedirect;
  }

  function redirectAfterSelfieUploadGoneIfNeeded() {
    try {
      if (sessionStorage.getItem("agentmail_selfie_redirect_after_gone") !== "1") return false;
    } catch (error) {
      return false;
    }
    const check = scheduleRedirectAfterSelfieUploadGone();
    return check();
  }

  async function autoClickMetaSelfieContinue(force = false) {
    if (!isMetaAuthPage() || !isMetaSelfieUploadPage()) return { ok: false, message: "Selfie upload page not found." };

    const lastClickedAt = window.__agentmailSelfieContinueClickedAt || 0;
    if (!force && Date.now() - lastClickedAt < 10000) {
      return { ok: true, message: "Selfie Continue recently clicked; waiting." };
    }

    if (window.__agentmailSelfieContinueRunning && !force) {
      return { ok: true, message: "Selfie Continue automation already running." };
    }

    if (!window.__agentmailSelfiePageSeenAt || force) {
      window.__agentmailSelfiePageSeenAt = Date.now();
    }

    window.__agentmailSelfieContinueRunning = true;
    try {
      for (let i = 0; i < 40; i += 1) {
        if (!isMetaSelfieUploadPage() && i > 1) {
          redirectAfterSelfieUploadGoneIfNeeded();
          return { ok: true, message: "Selfie page gone; redirecting to start link." };
        }

        const elapsed = Date.now() - window.__agentmailSelfiePageSeenAt;
        if (elapsed < 2000) {
          await sleep(Math.min(250, 2000 - elapsed));
          continue;
        }

        const button = findButtonByExactVisibleText("Continue") || findButtonByExactText("Continue");
        if (button && (!isDisabledLike(button) || i > 8)) {
          flash(button);
          await clickStrong(() => findButtonByExactVisibleText("Continue") || findButtonByExactText("Continue"), { kind: "selfie-continue" });
          window.__agentmailSelfieContinueClickedAt = Date.now();
          window.__agentmailSelfiePageSeenAt = null;
          scheduleRedirectAfterSelfieUploadGone();
          setTimeout(() => {
            if (isMetaAuthPage() && isMetaSelfieUploadPage()) {
              hardReloadAuthPage("selfie_upload_still_open_after_continue");
            }
          }, 5000);
          return { ok: true, message: "Selfie Continue clicked; will redirect to start link when photo upload UI disappears." };
        }

        await sleep(150);
      }

      return { ok: false, message: "Selfie Continue button not clickable yet." };
    } finally {
      window.__agentmailSelfieContinueRunning = false;
    }
  }

  function isMetaBlankWhitePage() {
    if (!isMetaAuthPage()) return false;
    const text = getPageTextFast();
    if (text.length > 3) return false;

    const importantVisible = queryAllDeep("button, input, textarea, select, iframe, img, svg, canvas, video, [role='button'], [role='checkbox']")
      .filter((el) => isVisible(el));
    if (importantVisible.length > 0) return false;

    const body = document.body;
    if (!body) return false;
    const bodyRect = body.getBoundingClientRect();
    const ready = document.readyState === "complete" || document.readyState === "interactive";
    return ready && bodyRect.width > 0;
  }

  function hardReloadAuthPage(reason = "stuck") {
    if (codeStepNoReloadActive()) {
      powerLog("NOREFRESH: no hard reload on the code step (" + reason + ")");
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: "AGENTMAIL_FORCE_RELOAD_TAB", reason }, () => {
        // If background reload fails/no response, fallback below will still run.
        chrome.runtime.lastError;
      });
    } catch (error) {
      // Ignore and use location fallback.
    }

    try {
      const url = new URL(window.location.href);
      url.searchParams.set("_agentmail_reload", String(Date.now()));
      setTimeout(() => window.location.replace(url.toString()), 800);
      setTimeout(() => window.location.reload(), 1600);
    } catch (error) {
      setTimeout(() => window.location.reload(), 800);
    }
  }

  // ---------------------------------------------------------------
  // v3.2 NOREFRESH - "no automatic reload on the code step".
  //
  // The user's screenshots: the Confirm-your-account screen was reached, the code
  // was pasted, Continue was spinning - and then the extension itself reloaded the
  // page once (the old first-visit redirect and the blank/dark-stuck healers), which
  // threw the confirmation away and left a blank page. While the code step is
  // unfinished, or inside the grace window right after the code was submitted,
  // NO reload path below may fire. The extension keeps waiting instead.
  // ---------------------------------------------------------------
  const AGENTMAIL_CODE_NORELOAD_MS = 90000;
  const AGENTMAIL_CODE_NORELOAD_KEY = "agentmail_code_noreload_until";

  // The deadline is kept in sessionStorage, NOT in a variable: the code submit is
  // followed by a real navigation (Meta verifies on a fresh document), and a fresh
  // content script would otherwise forget the rule and reload the blank page.
  function markCodeStepNoReload(extraMs = 0) {
    const windowMs = extraMs || AGENTMAIL_CODE_NORELOAD_MS;
    const until = Date.now() + windowMs;
    try {
      const previous = Number(sessionStorage.getItem(AGENTMAIL_CODE_NORELOAD_KEY) || "0");
      if (until > previous) sessionStorage.setItem(AGENTMAIL_CODE_NORELOAD_KEY, String(until));
    } catch (error) {}
    try { window.__agentmailCodeNoReloadUntil = until; } catch (error) {}
  }

  function codeStepNoReloadActive() {
    try {
      if (isMetaConfirmationCodePage()) {
        markCodeStepNoReload();          // the clock keeps running while we are here
        return true;
      }
      if (Date.now() < Number(sessionStorage.getItem(AGENTMAIL_CODE_NORELOAD_KEY) || "0")) return true;
      if (Date.now() < (window.__agentmailCodeNoReloadUntil || 0)) return true;
    } catch (error) {
      if (Date.now() < (window.__agentmailCodeNoReloadUntil || 0)) return true;
    }
    return false;
  }

  function reloadAuthPageOnce(reason = "blank_white_once") {
    if (codeStepNoReloadActive()) {
      powerLog("NOREFRESH: no auto reload on the code step (" + reason + ")");
      return;
    }
    let handled = false;
    try {
      chrome.runtime.sendMessage({ type: "AGENTMAIL_FORCE_RELOAD_TAB", reason }, (response) => {
        chrome.runtime.lastError;
        handled = Boolean(response && response.ok);
        if (!handled) {
          setTimeout(() => {
            try { window.location.reload(); } catch (error) {}
          }, 120);
        }
      });
    } catch (error) {
      setTimeout(() => {
        try { window.location.reload(); } catch (innerError) {}
      }, 120);
      return;
    }

    setTimeout(() => {
      if (!handled) {
        try { window.location.reload(); } catch (error) {}
      }
    }, 900);
  }

  async function autoRefreshMetaBlankWhite(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (!isMetaBlankWhitePage()) {
      try {
        sessionStorage.removeItem("agentmail_blank_seen_at");
        sessionStorage.removeItem("agentmail_blank_refresh_once_done");
      } catch (error) {}
      return { ok: false, message: "Blank white page not found." };
    }

    const now = Date.now();
    const seenAt = Number(sessionStorage.getItem("agentmail_blank_seen_at") || "0") || now;
    if (!sessionStorage.getItem("agentmail_blank_seen_at")) {
      sessionStorage.setItem("agentmail_blank_seen_at", String(now));
    }

    const alreadyRefreshedOnce = sessionStorage.getItem("agentmail_blank_refresh_once_done") === "1";
    if (alreadyRefreshedOnce && !force) {
      return { ok: true, message: "Blank white page already refreshed once; not looping." };
    }

    const blankLongEnough = force || now - seenAt >= 1000;

    if (blankLongEnough) {
      sessionStorage.setItem("agentmail_blank_refresh_once_done", "1");
      sessionStorage.setItem("agentmail_last_blank_refresh", String(now));
      sessionStorage.removeItem("agentmail_blank_seen_at");
      reloadAuthPageOnce("blank_white_once");
      return { ok: true, message: "Blank white auth page detected; refreshing once." };
    }

    return { ok: true, message: "Blank white page detected; waiting 1 second before one refresh." };
  }


  function colorIsDark(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return false;
    const r = Number(match[1]);
    const g = Number(match[2]);
    const b = Number(match[3]);
    return (r + g + b) / 3 < 55;
  }

  function isMetaDarkStuckPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    if (pageText.length > 5) return false;

    const ready = document.readyState === "complete" || document.readyState === "interactive";
    if (!ready) return false;

    const body = document.body;
    if (!body) return false;
    const bodyRect = body.getBoundingClientRect();
    if (bodyRect.width <= 0) return false;

    const bodyStyle = getCachedStyle(body) || {};
    const htmlStyle = getCachedStyle(document.documentElement) || {};
    let darkBg = colorIsDark(bodyStyle.backgroundColor) || colorIsDark(htmlStyle.backgroundColor);

    if (!darkBg) {
      darkBg = queryAllDeep("body, main, div, section").some((el) => {
        if (!isVisible(el)) return false;
        const rect = el.getBoundingClientRect();
        if (rect.width < window.innerWidth * 0.6 || rect.height < window.innerHeight * 0.35) return false;
        return colorIsDark(getCachedStyle(el)?.backgroundColor || "");
      });
    }

    const formControls = queryAllDeep("input, textarea, select, iframe, video, [role='checkbox']").filter((el) => isVisible(el));
    if (formControls.length > 0) return false;

    // Skeleton bars on stuck page.
    const skeletons = queryAllDeep("div, span").filter((el) => {
      if (!isVisible(el)) return false;
      const rect = el.getBoundingClientRect();
      if (rect.width < 30 || rect.height < 8 || rect.height > 80) return false;
      return colorIsDark(getCachedStyle(el)?.backgroundColor || "");
    });

    return darkBg || skeletons.length >= 1 || pageText.length === 0;
  }

  async function autoRefreshMetaDarkStuck(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (!isMetaDarkStuckPage()) {
      try { sessionStorage.removeItem("agentmail_dark_seen_at"); } catch (error) {}
      return { ok: false, message: "Dark stuck page not found." };
    }

    const now = Date.now();
    const seenAt = Number(sessionStorage.getItem("agentmail_dark_seen_at") || "0") || now;
    if (!sessionStorage.getItem("agentmail_dark_seen_at")) {
      sessionStorage.setItem("agentmail_dark_seen_at", String(now));
    }

    const lastRefresh = Number(sessionStorage.getItem("agentmail_last_dark_refresh") || "0");
    const stuckLongEnough = force || now - seenAt >= 2500;
    const cooldownDone = force || now - lastRefresh >= 9000;

    if (stuckLongEnough && cooldownDone) {
      sessionStorage.setItem("agentmail_last_dark_refresh", String(now));
      sessionStorage.removeItem("agentmail_dark_seen_at");
      hardReloadAuthPage("dark_stuck");
      return { ok: true, message: "Dark stuck auth page detected; hard reloading." };
    }

    return { ok: true, message: "Dark stuck page detected; waiting before refresh." };
  }

  function isDisabledLike(el) {
    if (!el) return true;
    if (el.disabled) return true;
    if ((el.getAttribute("aria-disabled") || "").toLowerCase() === "true") return true;
    const style = getCachedStyle(el);
    if (style && style.pointerEvents === "none") return true;
    return false;
  }

  function fireRealisticClick(target) {
    if (!target) return false;

    const rect = getRect(target);
    // Natural press point: slightly off-centre (like a real finger) and never
    // dead-centre where an overlay could swallow the click.
    const jx = 0.40 + (randomIndex(21) / 100);
    const jy = 0.40 + (randomIndex(21) / 100);
    const x = rect ? rect.left + rect.width * jx : 0;
    const y = rect ? rect.top + rect.height * jy : 0;
    const eventInit = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: window.screenX + x,
      screenY: window.screenY + y,
      button: 0,
      buttons: 1,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true
    };

    // Double-fire guard: the sweep, the observer and the timers can all reach
    // the same button inside one frame. Firing it twice made Meta double-submit.
    const now = Date.now();
    if (window.__agentmailLastClickTarget === target && now - (window.__agentmailLastClickAt || 0) < 45) {
      return true;
    }
    window.__agentmailLastClickTarget = target;
    window.__agentmailLastClickAt = now;

    try { target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
    try { target.focus({ preventScroll: true }); } catch (error) {}

    const Pointer = window.PointerEvent || window.MouseEvent;
    target.dispatchEvent(new Pointer("pointerover", eventInit));
    target.dispatchEvent(new Pointer("pointerenter", eventInit));
    target.dispatchEvent(new Pointer("pointerdown", eventInit));
    target.dispatchEvent(new MouseEvent("mousedown", eventInit));
    target.dispatchEvent(new Pointer("pointerup", { ...eventInit, buttons: 0 }));
    target.dispatchEvent(new MouseEvent("mouseup", { ...eventInit, buttons: 0 }));
    // Single activation: the dispatched click already activates the element, so
    // calling target.click() again would double-trigger every handler.
    target.dispatchEvent(new MouseEvent("click", { ...eventInit, buttons: 0 }));
    invalidateDomCache();
    return true;
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { ok: false, error: "No response from extension." });
      });
    });
  }

  // v3.6: if the mail API cannot be reached, read only the already-saved local
  // account. Prefer the current prepared mailbox, otherwise the newest saved one.
  // This is strictly a network-failure fallback; it never overrides a successful
  // fresh-mail response and never makes a new account/API request of its own.
  function getSavedMailForOfflineFallback() {
    return new Promise((resolve) => {
      try {
        if (!chrome?.storage?.local?.get) { resolve(null); return; }
        chrome.storage.local.get(["agentmail_account", "agentmail_accounts"], (saved) => {
          try {
            if (chrome.runtime?.lastError) { resolve(null); return; }
            const current = saved?.agentmail_account || {};
            const list = Array.isArray(saved?.agentmail_accounts) ? saved.agentmail_accounts : [];
            const currentEmail = String(current.email || "").trim();
            if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(currentEmail)) {
              resolve({ email: currentEmail, account: current, source: "current" });
              return;
            }
            const latest = list.find((item) => item && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(item.email || "").trim()));
            if (latest) {
              resolve({ email: String(latest.email).trim(), account: latest, source: "saved-list" });
              return;
            }
            resolve(null);
          } catch (error) { resolve(null); }
        });
      } catch (error) { resolve(null); }
    });
  }

  function mailNetworkUnavailable(error) {
    if (typeof navigator !== "undefined" && navigator.onLine === false) return true;
    return /failed to fetch|fetch failed|network error|network request failed|no internet|offline|err_internet_disconnected|load failed|connection (?:was )?(?:lost|reset|refused|failed)/i
      .test(String(error || ""));
  }

  async function clickContinueAfterEmail(email) {
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      window.__agentmailWaitingForOnlineContinue = true;
      if (!window.__agentmailOfflineContinueLogged) {
        window.__agentmailOfflineContinueLogged = true;
        powerLog("Email is ready; waiting for the internet before Continue.");
      }
      return;
    }
    window.__agentmailWaitingForOnlineContinue = false;
    window.__agentmailOfflineContinueLogged = false;
    if (window.__agentmailContinueClickRunning) return;
    window.__agentmailContinueClickRunning = true;

    try {
      const startedAt = Date.now();
      let attempts = 0;
      while (Date.now() - startedAt < 3000) {
        const input = findMetaEmailInput();
        if (input && email && !getEditableValue(input).includes(email)) {
          setNativeValue(input, email);
        }

        const button = findContinueButton();
        if (button && (!isDisabledLike(button) || attempts > 4)) {
          // Smart cooldown: never machine-gun the same button (that caused Meta
          // double-submits). A re-rendered button is a new node, so it clicks at once.
          const now = Date.now();
          const sameTarget = window.__agentmailContinueClickTarget === button &&
            window.__agentmailContinueClickEmail === email;
          if (sameTarget && now - (window.__agentmailContinueClickAt || 0) < 700) {
            await humanDelay(2);
            attempts += 1;
            continue;
          }
          window.__agentmailContinueClickTarget = button;
          window.__agentmailContinueClickEmail = email;
          window.__agentmailContinueClickAt = now;
          flash(button);
          await humanDelay(1);
          await clickStrong(button, { kind: "continue-email", pageId: POWER.lastPage.id });
          return;
        }

        attempts += 1;
        if (button) await waitFor(() => !isDisabledLike(button), { timeout: 300, poll: 30 });
        else await waitFor(() => Boolean(findContinueButton()), { timeout: 160, poll: 30 });
      }
    } finally {
      window.__agentmailContinueClickRunning = false;
    }
  }

  async function autoClickMetaCreateNewAccount(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (window.__agentmailCreateAccountClickRunning && !force) {
      return { ok: true, message: "Create account click already running." };
    }

    const firstButton = findMetaCreateNewAccountButton();
    if (!firstButton) return { ok: false, message: "Create new account button not found yet." };

    window.__agentmailCreateAccountClickRunning = true;
    try {
      // v3.5: ONE press, then verify. The old loop pressed the same button again
      // every 70 ms while the page was slow to navigate (the "two clicks" report).
      let pressed = false;
      for (let i = 0; i < 8 && !pressed; i += 1) {
        const button = findMetaCreateNewAccountButton();
        if (!button) { await sleep(60); continue; }
        if (isDisabledLike(button) && i < 5) { await sleep(80); continue; }
        flash(button);
        pressed = await clickStrong(() => findMetaCreateNewAccountButton(), { kind: "create-account" });
        break;                       // never a second press in a row
      }
      if (!pressed) return { ok: false, message: "Create new account not pressable yet." };

      const moved = await waitFor(() => {
        const again = findMetaCreateNewAccountButton();
        return !again || !isVisible(again) || isDisabledLike(again);
      }, { timeout: 900, poll: 60 });
      if (!moved && !window.__agentmailCreateAccountRetried) {
        window.__agentmailCreateAccountRetried = true;   // at most ONE verification retry
        await clickStrong(() => findMetaCreateNewAccountButton(), { kind: "create-account-retry" });
      }
      return { ok: true, message: "Create new account pressed (single press, v3.5)." };
    } finally {
      window.__agentmailCreateAccountClickRunning = false;
    }
  }

  async function autoFillMetaEmailInput() {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    if (isMetaConfirmationCodePage()) return { ok: false, message: "Confirmation page: do not edit email; waiting for code." };
    // v3.3 LUX: the Meta AI details page has NO email field - its text box is
    // "Name (optional)". The email filler is banned here so the address can never
    // be pasted into it (the user's screenshot).
    if (isMetaAiDetailsConfirmPage()) return { ok: false, message: "Meta AI details page: no email box here - nothing filled." };

    const input = findMetaEmailInput();
    if (!input) return { ok: false, message: "Meta email input not found yet." };

    const currentValue = getEditableValue(input).trim();
    if (currentValue.includes("@")) {
      window.__agentmailAccountSavedAfterLogout = false;
      window.__agentmailNextEmailPreparedAfterLogout = false;
      try { sessionStorage.removeItem("agentmail_confirmation_resend_clicked_once"); } catch (error) {}
      clickContinueAfterEmail(currentValue);
      return { ok: true, message: "Email already filled; clicking Continue.", email: currentValue };
    }

    if (window.__agentmailEmailApiRequestRunning) {
      return { ok: true, message: "Email generation already running." };
    }

    window.__agentmailEmailApiRequestRunning = true;
    try {
      flash(input);
      let forceNewEmail = false;
      try {
        forceNewEmail = sessionStorage.getItem("agentmail_force_new_email_next") === "1";
      } catch (error) {}
      let result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: forceNewEmail });
      if (!result.ok || !result.email) {
        const errorText = result.error || "Could not generate MasterTeam mail.";
        if (!mailNetworkUnavailable(errorText)) {
          return { ok: false, message: errorText };
        }
        const fallback = await getSavedMailForOfflineFallback();
        if (!fallback?.email) {
          powerLog("No internet and no saved mailbox is available.");
          return { ok: false, message: "Internet unavailable; there is no locally saved mailbox to fill." };
        }
        result = {
          ok: true,
          email: fallback.email,
          account: fallback.account,
          reused: true,
          offlineFallback: true,
          offlineFallbackSource: fallback.source
        };
        window.__agentmailOfflineMailFallback = true;
        powerLog("Internet unavailable: filled the locally saved mailbox.");
      } else {
        window.__agentmailOfflineMailFallback = false;
      }

      for (let i = 0; i < 3; i += 1) {
        if (await fillStrong(input, result.email, { kind: "email" })) break;
        flash(input);
        await humanDelay(1);
      }
      flash(input);

      window.__agentmailAccountSavedAfterLogout = false;
      window.__agentmailNextEmailPreparedAfterLogout = false;
      try { sessionStorage.removeItem("agentmail_force_new_email_next"); } catch (error) {}
      try { sessionStorage.removeItem("agentmail_confirmation_resend_clicked_once"); } catch (error) {}
      clickContinueAfterEmail(result.email);
      const offlineNote = result.offlineFallback ? " (local saved-mail fallback; waiting for internet)" : "";
      return { ok: true, message: `MasterTeam mail filled${offlineNote}.`, email: result.email, reused: result.reused, offlineFallback: Boolean(result.offlineFallback) };
    } finally {
      window.__agentmailEmailApiRequestRunning = false;
    }
  }

  function isMetaCookieChoicePage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    return (
      pageText.includes("allow all cookies") &&
      (
        pageText.includes("how we use these cookies") ||
        pageText.includes("if you allow these cookies") ||
        pageText.includes("if you don't allow these cookies") ||
        pageText.includes("if you don’t allow these cookies") ||
        pageText.includes("decline optional cookies") ||
        pageText.includes("controlling cookies with browser settings") ||
        pageText.includes("cookie choices")
      )
    );
  }

  function findMetaAllowAllCookiesButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "allow all cookies" || item.text.includes("allow all cookies"))
      .filter((item) => item.area > 60 && item.area < 260000)
      .sort((a, b) => {
        const exactA = a.text === "allow all cookies" ? 0 : 1;
        const exactB = b.text === "allow all cookies" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function scheduleMetaAfterCookieConsent() {
    const now = Date.now();
    if (window.__agentmailCookieResumeScheduledAt && now - window.__agentmailCookieResumeScheduledAt < 5000) return;
    window.__agentmailCookieResumeScheduledAt = now;

    [250, 650, 1100, 1800, 2800, 4200, 6500, 9000, 12000].forEach((delay) => {
      setTimeout(() => {
        if (!isMetaAuthPage()) return;
        // Cookie page gone hole email-choice/email-input flow abar run korbe.
        clickMetaEmailChoice(false);
        autoFillMetaEmailInput();
      }, delay);
    });
  }

  async function autoClickMetaAllowAllCookies(force = false) {
    if (!isMetaAuthPage() || !isMetaCookieChoicePage()) {
      return { ok: false, message: "Cookie choice page not found." };
    }

    if (window.__agentmailAllowCookiesClickRunning && !force) {
      return { ok: true, message: "Allow cookies click already running." };
    }

    const firstButton = findMetaAllowAllCookiesButton();
    if (!firstButton) return { ok: false, message: "Allow all cookies button not found yet." };

    window.__agentmailAllowCookiesClickRunning = true;
    try {
      for (let i = 0; i < 5; i += 1) {
        if (!isMetaCookieChoicePage() && i > 0) {
          scheduleMetaAfterCookieConsent();
          return { ok: true, message: "Cookie page gone; Meta flow resumed." };
        }
        const button = findMetaAllowAllCookiesButton();
        if (!button) {
          await sleep(60);
          continue;
        }
        flash(button);
        await clickStrong(() => findMetaAllowAllCookiesButton(), { kind: "cookies" });
        scheduleMetaAfterCookieConsent();
        await sleep(i < 2 ? 90 : 140);
      }
      return { ok: true, message: "Allow all cookies clicked; Meta flow resume queued." };
    } finally {
      window.__agentmailAllowCookiesClickRunning = false;
    }
  }

  function isMetaSavedAccountLoginPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    // Start korle majhe majhe direct remembered-account page ase. Header text
    // slightly different hote pare, so button text thaklei ei page dhorbo.
    return (
      pageText.includes("log in to another account") ||
      pageText.includes("login to another account") ||
      pageText.includes("log into another account") ||
      pageText.includes("use another account") ||
      (
        pageText.includes("another account") &&
        (pageText.includes("continue as") || pageText.includes("meta account") || pageText.includes("log in"))
      )
    );
  }

  function findMetaLoginAnotherAccountButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) =>
        item.text === "log in to another account" ||
        item.text === "login to another account" ||
        item.text === "log into another account" ||
        item.text === "use another account" ||
        item.text.includes("log in to another account") ||
        item.text.includes("login to another account") ||
        item.text.includes("log into another account") ||
        item.text.includes("use another account")
      )
      .filter((item) => item.area > 80 && item.area < 260000)
      .sort((a, b) => {
        const exactA = (a.text === "use another account" || a.text === "log in to another account" || a.text === "login to another account" || a.text === "log into another account") ? 0 : 1;
        const exactB = (b.text === "use another account" || b.text === "log in to another account" || b.text === "login to another account" || b.text === "log into another account") ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  async function autoClickMetaLoginAnotherAccount(force = false) {
    if (!isMetaAuthPage()) {
      return { ok: false, message: "Not auth.meta.com" };
    }

    const firstButton = findMetaLoginAnotherAccountButton();
    if (!isMetaSavedAccountLoginPage() && !firstButton) {
      return { ok: false, message: "Saved-account login page not found." };
    }

    if (window.__agentmailLoginAnotherAccountRunning && !force) {
      return { ok: true, message: "Another-account click already running." };
    }

    if (!firstButton) return { ok: false, message: "Log in to another account button not found yet." };

    window.__agentmailLoginAnotherAccountRunning = true;
    try {
      // Next email input must use a fresh MasterTeam inbox, not the remembered Meta account.
      try { sessionStorage.setItem("agentmail_force_new_email_next", "1"); } catch (error) {}

      const now = Date.now();
      if (window.__agentmailLoginAnotherAccountClickedAt && !force && now - window.__agentmailLoginAnotherAccountClickedAt < 3500) {
        scheduleMetaAfterLogout();
        return { ok: true, message: "Use another account already clicked recently." };
      }

      const button = findMetaLoginAnotherAccountButton();
      if (!button) return { ok: false, message: "Use another account button not found yet." };
      window.__agentmailLoginAnotherAccountClickedAt = now;
      flash(button);
      await clickStrong(() => findMetaLoginAnotherAccountButton(), { kind: "login-another" });

      scheduleMetaAfterLogout();
      setTimeout(() => {
        if (isMetaAuthPage() && !isMetaSavedAccountLoginPage()) {
          clickMetaEmailChoice(false);
          autoFillMetaEmailInput();
        }
      }, 700);
      return { ok: true, message: "Use another account clicked once; email-choice watcher queued." };
    } finally {
      window.__agentmailLoginAnotherAccountRunning = false;
    }
  }

  function isMetaLanguageLogoutPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    if (!pageText) return false;

    // Screenshot-er page: Language + LOG OUT + Accounts Centre page.
    return (
      (pageText.includes("log out") || pageText.includes("logout")) &&
      pageText.includes("language") &&
      (
        pageText.includes("accounts centre") ||
        pageText.includes("accounts center") ||
        pageText.includes("password, security") ||
        pageText.includes("personal details") ||
        pageText.includes("connected experiences") ||
        pageText.includes("english (uk)") ||
        pageText.includes("english")
      )
    );
  }

  function findMetaLogoutButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          el,
          text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
          area: rect.width * rect.height,
          top: rect.top,
          left: rect.left
        };
      })
      .filter((item) => item.text === "log out" || item.text === "logout")
      .filter((item) => item.area > 30 && item.area < 120000)
      .sort((a, b) => {
        // Prefer the small top-right LOG OUT button from the screenshot.
        const topA = a.top < 180 ? 0 : 1;
        const topB = b.top < 180 ? 0 : 1;
        if (topA !== topB) return topA - topB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function isInsideAgentmailFloatingWidget(el) {
    try {
      const root = el?.getRootNode?.();
      if (root?.host?.id === "agentmail-floating-widget-host") return true;
    } catch (error) {}
    let node = el;
    for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
      if (node.id === "agentmail-floating-widget-host") return true;
    }
    return false;
  }

  function findMetaHamburgerMenuButton() {
    if (!isMetaAuthPage()) return null;
    const candidates = queryAllDeep("button, [role='button'], a, div, span, svg")
      .filter((el) => isVisible(el) && !isInsideAgentmailFloatingWidget(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title"));
        const aria = normalizeText(el.getAttribute("aria-label") || el.getAttribute("title") || "");
        const area = rect.width * rect.height;
        const topRight = rect.top >= 18 && rect.top < Math.min(320, window.innerHeight * 0.52) && rect.right > window.innerWidth * 0.54;
        const sizeOk = rect.width >= 6 && rect.width <= 150 && rect.height >= 2 && rect.height <= 150;
        const menuText = aria.includes("menu") || aria.includes("more") || text === "☰" || text === "≡" || text === "menu" || text === "";
        const hasSvgOrLines = el.querySelector?.("svg, path, line, rect, div, span") || el.tagName === "svg" || text.length <= 3;
        const lineLike = text.length <= 3 && rect.width > 10 && rect.height > 1;
        const likelyClickable = ["BUTTON", "A", "SVG"].includes(el.tagName) || (el.getAttribute("role") || "").toLowerCase() === "button" || el.tabIndex >= 0 || getCachedStyle(el)?.cursor === "pointer";
        return { el, rect, text, area, topRight, sizeOk, menuText, hasSvgOrLines, lineLike, likelyClickable };
      })
      .filter((item) => item.topRight && item.sizeOk && item.area > 10 && (item.likelyClickable || item.menuText || item.hasSvgOrLines || item.lineLike))
      .sort((a, b) => {
        const clickableA = a.likelyClickable ? 0 : 1;
        const clickableB = b.likelyClickable ? 0 : 1;
        if (clickableA !== clickableB) return clickableA - clickableB;
        const menuA = a.menuText ? 0 : 1;
        const menuB = b.menuText ? 0 : 1;
        if (menuA !== menuB) return menuA - menuB;
        return (b.rect.right - a.rect.right) || (a.rect.top - b.rect.top);
      });
    return candidates[0]?.el ? getClickableTarget(candidates[0].el) : null;
  }

  // v3.5 STUCK: has the page really painted? Text alone was the wrong test - the
  // user's screenshot page (blank auth.meta.com with skeleton bars + the 3-line
  // menu) has NO text at all, so the old text-length guard made the engine blind
  // on exactly that screen. Paint evidence = text, or the menu button, or any
  // rendered box. The Meta-AI-details exclusion below still keeps that form safe.
  function metaPagePaintEvidence() {
    try {
      const rs = document.readyState;
      if (rs !== "interactive" && rs !== "complete") return false;
      if (getPageTextFast().length >= 12) return true;
      if (findMetaHamburgerMenuButton()) return true;
    } catch (error) {
      return false;
    }
    try {
      const nodes = document.querySelectorAll("div, span, svg");
      const limit = Math.min(nodes.length, 120);
      for (let i = 0; i < limit; i += 1) {
        const el = nodes[i];
        if (isInsideAgentmailFloatingWidget(el)) continue;
        const rect = el.getBoundingClientRect();
        if (rect.width > 24 && rect.height > 3) return true;   // skeleton bars count
      }
    } catch (error) {}
    return false;
  }

  function isMetaSparseHamburgerScreen() {
    if (!isMetaAuthPage()) return false;
    const text = getPageTextFast();
    if (!metaPagePaintEvidence()) return false;
    if (isMetaAiDetailsConfirmPage()) return false;
    if (text.includes("use mobile number or email") || text.includes("continue with facebook") || text.includes("continue with instagram")) return false;
    if (isMetaConfirmationCodePage() || isMetaDobPage() || isMetaPasswordPage() || isMetaHumanConfirmPage() || isMetaSelfieUploadPage()) return false;
    if (text.includes("upload") || text.includes("selfie") || text.includes("photo") || text.includes("verification") || text.includes("clearly shows your face")) return false;
    if (text.includes("log out") || text.includes("logout")) return true;

    // Do not let hidden auth iframes break the sparse-page detection. Only real
    // visible form controls should block the hamburger click.
    const controls = queryAllDeep("input, textarea, select, [role='checkbox']")
      .filter((el) => isVisible(el))
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        return rect.width > 10 && rect.height > 10;
      });
    if (controls.length > 0) return false;

    const hamburger = findMetaHamburgerMenuButton();
    const skeletonBars = queryAllDeep("div, span").filter((el) => {
      if (!isVisible(el) || isInsideAgentmailFloatingWidget(el)) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 35 && rect.width < window.innerWidth * 0.76 && rect.height > 3 && rect.height < 56 && rect.top > 55 && rect.top < 500;
    }).length;
    // Screenshot page: mostly blank auth.meta.com with only top-right 3-line menu
    // and 2-3 skeleton bars. If the 3-line element is not exposed in the DOM,
    // still use coordinate click fallback on this sparse screen.
    return Boolean(hamburger) || text.length <= 120 || skeletonBars >= 2;
  }

  function nudgeFloatingWidgetAwayFromHamburger() {
    try {
      const host = document.getElementById("agentmail-floating-widget-host");
      if (!host) return;
      const rect = host.getBoundingClientRect();
      if (rect.top < 190 && rect.right > window.innerWidth * 0.54) {
        host.style.top = "190px";
        host.style.right = "8px";
      }
    } catch (error) {}
  }

  // Is this element part of a year list / listbox? Clicking such an element with
  // a blind sweep is what selected the wrong year, so the sweep must never do it.
  function isYearListElement(el) {
    try {
      if (!el || el.nodeType !== 1) return false;
      const own = String(el.textContent || "").trim();
      if (/^(19|20)\d{2}$/.test(own)) return true;
      let node = el;
      for (let i = 0; i < 4 && node; i += 1, node = node.parentElement) {
        const role = String(node.getAttribute?.("role") || "").toLowerCase();
        if (role === "option" || role === "listbox") return true;
        const text = String(node.textContent || "").trim();
        if (/^(19|20)\d{2}$/.test(text) && node.children.length === 0) return true;
      }
    } catch (error) {}
    return false;
  }

  // The date-of-birth step owns the page: no blind coordinate sweep may run.
  function yearStepOwnsPage() {
    try {
      if (yearFieldExists()) return true;
      if (yearPickerContainer()) return true;
      if (isMetaDobPage()) return /year/i.test(getPageTextFast().slice(0, 4000));
    } catch (error) {}
    return false;
  }

  function clickElementFromPointStrong(x, y) {
    if (yearStepOwnsPage()) return false;
    // v3.5: real paint evidence (a text-free skeleton page still counts).
    if (!metaPagePaintEvidence()) return false;
    if (sparseHamburgerRecentlyPressed()) return false;   // v3.5: the one press already happened
    // v3.3 LUX: on "Edit your Meta AI details" the ONLY allowed click is the
    // dedicated Confirm press (which also saves the account). A blind sweep here
    // used to hit Confirm first, so the account was never kept.
    if (isMetaAuthPage() && isMetaAiDetailsConfirmPage()) return false;
    const targets = [];
    const first = document.elementFromPoint(x, y);
    if (first) targets.push(first);
    let node = first;
    for (let depth = 0; node && depth < 7; depth += 1, node = node.parentElement) {
      if (node && !targets.includes(node)) targets.push(node);
    }
    targets.push(document.body, document.documentElement);

    let clicked = false;
    const pending = [];
    targets.forEach((target) => {
      if (!target || isInsideAgentmailFloatingWidget(target)) return;
      if (isYearListElement(target)) return;   // never a year row / listbox
      clicked = true;
      pending.push(target);
    });

    // Butter stagger: hop the layers a frame apart (~14ms) instead of 35ms of
    // dead time each, and all at once when the tab is hidden.
    const hidden = isHiddenView();
    pending.forEach((target, index) => {
      const doClick = () => {
        try { fireRealisticClick(getClickableTarget(target) || target); } catch (error) {}
      };
      if (index === 0 || hidden) {
        doClick();
        return;
      }
      setTimeout(doClick, index * 14);
    });
    return clicked;
  }

  function clickMetaHamburgerByCoordinates() {
    if (yearStepOwnsPage()) return false;   // the DOB year step always wins
    if (!metaPagePaintEvidence()) return false;   // v3.5: real paint evidence
    if (isMetaAuthPage() && isMetaAiDetailsConfirmPage()) return false;   // v3.3 LUX
    if (sparseHamburgerRecentlyPressed()) return false;   // v3.5: never again after the one press
    nudgeFloatingWidgetAwayFromHamburger();
    const vv = window.visualViewport;
    const width = vv?.width || window.innerWidth || document.documentElement.clientWidth || 390;
    const height = vv?.height || window.innerHeight || document.documentElement.clientHeight || 700;
    const xs = [width - 44, width - 52, width - 62, width - 74, width - 86].filter((x) => x > width * 0.55 && x < width - 4);
    const ys = [58, 70, 82, 94, 108, 124, 142, Math.min(165, height * 0.24)].filter((y) => y > 20 && y < Math.min(230, height * 0.42));

    const points = [];
    xs.forEach((x) => ys.forEach((y) => points.push([x, y])));

    // Whole grid is swept in a few frames instead of one 28ms timer per point.
    const perFrame = isHiddenView() ? points.length : 6;
    let index = 0;

    const step = () => {
      let count = 0;
      while (index < points.length && count < perFrame) {
        const point = points[index];
        index += 1;
        count += 1;
        try { clickElementFromPointStrong(point[0], point[1]); } catch (error) {}
      }
      if (index < points.length) nextFrame(step);
    };
    step();
    return true;
  }

  function clickMetaHamburgerStrong(menu) {
    // v3.5b: on the skeleton page only the stuck watcher presses (once).
    if (isMetaSparseHamburgerScreen() && !sparseHamburgerRecentlyPressed()) return false;
    nudgeFloatingWidgetAwayFromHamburger();
    if (!menu) return clickMetaHamburgerByCoordinates();
    const rect = menu.getBoundingClientRect();
    flash(menu);
    fireRealisticClick(menu);

    // Some Meta mobile shells attach the listener to a parent or to the element
    // under the pointer, so repeat with elementFromPoint/parent targets.
    const points = [
      { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
      { x: Math.max(4, window.innerWidth - 42), y: rect.top + rect.height / 2 },
      { x: Math.max(4, window.innerWidth - 54), y: Math.max(40, rect.top + 8) }
    ];
    points.forEach((point, index) => {
      setTimeout(() => {
        const el = document.elementFromPoint(point.x, point.y);
        if (!el || isInsideAgentmailFloatingWidget(el)) return;
        const target = getClickableTarget(el);
        if (target && isVisible(target)) fireRealisticClick(target);
      }, 50 + index * 90);
    });
    setTimeout(() => {
      if (yearStepOwnsPage()) return;   // re-check: the page may have moved on
      clickMetaHamburgerByCoordinates();
    }, 140);
    return true;
  }

  // ---------------------------------------------------------------
  // v3.5 STUCK - the screenshot page: auth.meta.com showing only skeleton
  // bars and the 3-line menu in the top-right corner. If that screen is still
  // there after 700 ms, ONE press lands on the menu button; the menu opens and
  // the normal Logout watcher takes over. It can never be pressed twice.
  // ---------------------------------------------------------------
  function sparseHamburgerStamp() {
    try { return Number(sessionStorage.getItem("agentmail_sparse_hamburger_at") || "0"); } catch (error) { return 0; }
  }

  function sparseHamburgerRecentlyPressed(windowMs = 6000) {
    // v3.5c: once this document has pressed, it is done - no second round ever.
    if (window.__agentmailSparseHamburgerPressedAt) return true;
    const at = sparseHamburgerStamp();
    return at > 0 && Date.now() - at < windowMs;
  }

  function markSparseHamburgerPressed() {
    window.__agentmailSparseHamburgerPressedAt = Date.now();
    window.__agentmailHamburgerMenuClickedAt = Date.now();
    try { sessionStorage.setItem("agentmail_sparse_hamburger_at", String(Date.now())); } catch (error) {}
  }

  function hamburgerMenuLooksOpen() {
    try {
      if (findMetaLogoutButton()) return true;
      const menu = findMetaHamburgerMenuButton();
      return Boolean(menu && (menu.getAttribute("aria-expanded") || "").toLowerCase() === "true");
    } catch (error) { return false; }
  }

  // ONE press on the top-right menu. The DOM element is used when it exists; the
  // coordinate fallback presses a SINGLE point (the old code swept ~56 points).
  async function pressTopRightMenuOnce() {
    const menu = findMetaHamburgerMenuButton();
    if (menu) {
      try { humanHover(menu); } catch (error) {}
      try { fireRealisticClick(menu); } catch (error) {}
      return "element";
    }
    nudgeFloatingWidgetAwayFromHamburger();
    const vv = window.visualViewport;
    const width = vv?.width || window.innerWidth || 390;
    const points = [[width - 40, 62], [width - 52, 70], [width - 64, 80], [width - 46, 98]];
    for (const point of points) {
      const el = document.elementFromPoint(point[0], point[1]);
      if (!el || isInsideAgentmailFloatingWidget(el)) continue;
      if (el === document.documentElement || el === document.body) continue;
      try { await tapVerifiedElement(getClickableTarget(el) || el, 0.5, 0.5); } catch (error) {}
      return "coordinates";
    }
    return "none";
  }

  function watchForLogoutAfterMenuPress() {
    [400, 900, 1600, 2600, 4200].forEach((delay) => {
      setTimeout(() => {
        try {
          if (!isMetaAuthPage()) return;
          if (findMetaLogoutButton()) scheduleDelayedMetaLogoutClick("hamburger-menu", false);
        } catch (error) {}
      }, delay);
    });
  }

  async function pressSparseHamburgerOnce(reasonLabel) {
    if (sparseHamburgerRecentlyPressed()) return false;
    markSparseHamburgerPressed();   // stamped BEFORE the press: one press, ever
    powerLog(`Skeleton menu page stuck ${reasonLabel} - one press`);
    await pressTopRightMenuOnce().catch(() => "none");
    if (await waitFor(() => hamburgerMenuLooksOpen(), { timeout: 650, poll: 40 })) {
      watchForLogoutAfterMenuPress();
      return true;
    }
    // exactly ONE verification retry - only when the menu visibly did not open
    await pressTopRightMenuOnce().catch(() => "none");
    await waitFor(() => hamburgerMenuLooksOpen(), { timeout: 900, poll: 40 });
    watchForLogoutAfterMenuPress();
    return true;
  }

  function installSparseHamburgerStuckWatch() {
    if (window.__agentmailSparseStuckWatchStarted) return;
    window.__agentmailSparseStuckWatchStarted = true;
    setInterval(() => {
      try {
        if (window.__agentmailSweepStopped) return;
        if (!isMetaAuthPage()) { window.__agentmailSparseStuckSince = 0; return; }
        if (sparseHamburgerRecentlyPressed()) return;
        if (!isMetaSparseHamburgerScreen()) { window.__agentmailSparseStuckSince = 0; return; }
        if (!window.__agentmailSparseStuckSince) { window.__agentmailSparseStuckSince = Date.now(); return; }
        if (Date.now() - window.__agentmailSparseStuckSince < 700) return;
        pressSparseHamburgerOnce("for 700 ms");
      } catch (error) {}
    }, 100);
  }

  function scheduleDelayedMetaLogoutClick(source = "Logout", force = false) {
    if (!isMetaAuthPage()) return false;
    if (window.__agentmailLogoutDelayTimerActive && !force) return true;

    window.__agentmailLogoutDelayTimerActive = true;
    window.__agentmailLogoutDelayedClickAt = Date.now();

    setTimeout(() => {
      try {
        if (!isMetaAuthPage()) return;
        // v3.5: never a second Logout press inside a short window (the old
        // 600 ms release could let two watchers through).
        if (window.__agentmailLogoutClickedAt && Date.now() - window.__agentmailLogoutClickedAt < 2500) return;
        const button = findMetaLogoutButton();
        if (!button) return;
        window.__agentmailLogoutClickedAt = Date.now();   // v3.5b: stamped BEFORE the press
        flash(button);
        clickStrong(() => findMetaLogoutButton(), { kind: "logout" });
        // Save only after LOG OUT click is actually fired.
        saveCurrentAccountAfterLogout();
        scheduleMetaAfterLogout();
      } finally {
        setTimeout(() => {
          window.__agentmailLogoutDelayTimerActive = false;
          window.__agentmailLogoutDelayedClickAt = 0;
        }, 600);
      }
    }, 250);

    return true;
  }

  async function autoClickMetaHamburgerAndLogout(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    // v3.3 LUX: the AI-details form is a normal step - no menu hunting here.
    if (isMetaAiDetailsConfirmPage()) return { ok: false, message: "Meta AI details page: no menu hunt." };
    // v3.5: the stuck watcher already made its one press on this screen.
    if (sparseHamburgerRecentlyPressed()) return { ok: true, message: "Stuck-menu press already made (v3.5)." };

    const logoutButton = findMetaLogoutButton();
    if (logoutButton) {
      scheduleDelayedMetaLogoutClick("menu", force);
      return { ok: true, message: "Logout click scheduled." };
    }

    if (!isMetaSparseHamburgerScreen()) return { ok: false, message: "Hamburger menu screen not found." };
    // v3.5b: the skeleton page belongs to the stuck watcher (700 ms -> ONE press).
    // The legacy multi-strategy press + coordinate sweep used to fire here first
    // and pressed the same button up to nine times.
    if (!sparseHamburgerRecentlyPressed()) {
      return { ok: true, message: "Skeleton page: waiting for the 700 ms rule (v3.5)." };
    }
    const now = Date.now();
    if (!force && window.__agentmailHamburgerMenuClickedAt && now - window.__agentmailHamburgerMenuClickedAt < 2500) {
      return { ok: true, message: "Hamburger recently clicked; waiting." };
    }
    const menu = findMetaHamburgerMenuButton();
    window.__agentmailHamburgerMenuClickedAt = now;
    clickMetaHamburgerStrong(menu);
    [250, 550, 900, 1300, 2000, 3200, 4800].forEach((delay) => {
      setTimeout(() => {
        const btn = findMetaLogoutButton();
        if (btn) {
          scheduleDelayedMetaLogoutClick("hamburger-menu", false);
        }
      }, delay);
    });
    return { ok: true, message: "Hamburger menu clicked; logout watcher queued." };
  }

  function prepareNextEmailAfterLogout() {
    if (window.__agentmailNextEmailPreparedAfterLogout) return;
    window.__agentmailNextEmailPreparedAfterLogout = true;
    setTimeout(() => {
      try {
        chrome.storage.local.get(["agentmail_mail_provider"], (saved) => {
          const provider = saved.agentmail_mail_provider === "baby" ? "baby" : "toxic";
          sendRuntimeMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: true, provider });
        });
      } catch (error) {
        try { sendRuntimeMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: true }); } catch (innerError) {}
      }
    }, 250);
  }

  function saveCurrentAccountAfterLogout() {
    if (window.__agentmailAccountSavedAfterLogout) {
      prepareNextEmailAfterLogout();
      return;
    }
    window.__agentmailAccountSavedAfterLogout = true;
    try {
      sendRuntimeMessage({ type: "AGENTMAIL_SAVE_CURRENT_ACCOUNT", source: "Logout" })
        .then(() => prepareNextEmailAfterLogout())
        .catch(() => prepareNextEmailAfterLogout());
    } catch (error) {
      // Ignore; background may be waking.
      prepareNextEmailAfterLogout();
    }
  }

  function scheduleMetaAfterLogout() {
    const now = Date.now();
    if (window.__agentmailAfterLogoutResumeScheduledAt && now - window.__agentmailAfterLogoutResumeScheduledAt < 5000) return;
    window.__agentmailAfterLogoutResumeScheduledAt = now;

    // Logout-er por same page / Use mobile number or email address ashle click korbe,
    // then email input ashle fresh mail paste korbe.
    try { sessionStorage.setItem("agentmail_force_new_email_next", "1"); } catch (error) {}

    [500, 1000, 1600, 2400, 3500, 5200, 7500, 10000, 13500, 17000].forEach((delay) => {
      setTimeout(() => {
        if (!isMetaAuthPage()) return;
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) return;

        autoClickMetaProfileContinue(false);
        autoClickMetaAllowAllCookies(false);
        autoClickMetaLoginAnotherAccount(false);

        const emailOptionRow = findMetaInitialThirdEmailOptionRow();
        const choice = emailOptionRow || findMetaEmailChoiceButton();
        if (choice) {
          if (emailOptionRow) clickInitialThirdEmailOptionOnly(emailOptionRow);
          else fireEmailChoiceClick(choice);
        }

        clickMetaEmailChoice(false);
        autoFillMetaEmailInput();
      }, delay);
    });
  }

  async function redirectFromMetaLanguagePage(force = false) {
    // Kept function name for existing callers, but behavior is now: click LOG OUT,
    // not redirect to Wikipedia.
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    if (!isMetaLanguageLogoutPage() && !findMetaLogoutButton()) {
      return { ok: false, message: "Language/logout page not found." };
    }

    if (window.__agentmailLogoutClicking && !force) {
      return { ok: true, message: "Logout click already running." };
    }

    window.__agentmailLogoutClicking = true;
    try {
      // LOG OUT page means this mail/account reached the success/logout stage.
      // User requested: LOG OUT should be clicked after 2 seconds, not instantly.
      const scheduled = scheduleDelayedMetaLogoutClick("language-page", force);
      if (scheduled) return { ok: true, message: "LOG OUT click scheduled after 2 seconds; account will save after click." };
      return { ok: false, message: "LOG OUT button not ready for delayed click." };
    } finally {
      setTimeout(() => { window.__agentmailLogoutClicking = false; }, 2400);
    }
  }

  function targetIsSocialLoginChoice(target) {
    if (!target || !isMetaAuthPage()) return false;
    let node = target;
    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute?.("aria-label"));
      if (area > 230000 || text.length > 140) continue;
      if (text.includes("continue with facebook") || text.includes("continue with instagram")) return true;
    }
    return false;
  }

  function installSocialChoiceClickBlocker() {
    if (window.__agentmailSocialChoiceClickBlockerInstalled) return;
    window.__agentmailSocialChoiceClickBlockerInstalled = true;

    const blockIfSocial = (event) => {
      if (!isMetaAuthPage()) return;
      const emailRow = findMetaInitialThirdEmailOptionRow();
      if (!emailRow) return;
      if (!targetIsSocialLoginChoice(event.target)) return;

      // User requested: never click Continue with Facebook/Instagram on this screen.
      // Stop old/stale click loops too, then force the Use mobile/email row.
      try { event.preventDefault(); } catch (error) {}
      try { event.stopPropagation(); } catch (error) {}
      try { event.stopImmediatePropagation(); } catch (error) {}
      setTimeout(() => {
        const row = findMetaInitialThirdEmailOptionRow();
        if (row) clickInitialThirdEmailOptionOnly(row);
      }, 40);
    };

    ["touchstart", "touchend", "pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((type) => {
      try { window.addEventListener(type, blockIfSocial, { capture: true, passive: false }); } catch (error) {}
      try { document.addEventListener(type, blockIfSocial, { capture: true, passive: false }); } catch (error) {}
    });
  }

  function targetIsEditEmailAddressLink(target) {
    if (!target || !isMetaAuthPage() || !isMetaConfirmationCodePage()) return false;
    let node = target;
    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute?.("aria-label"));
      if (area > 260000 || text.length > 220) continue;
      if (
        text.includes("edit mobile number or email address") ||
        text.includes("edit email address") ||
        text.includes("edit mobile number")
      ) return true;
    }
    return false;
  }

  function installEditEmailClickBlocker() {
    if (window.__agentmailEditEmailClickBlockerInstalled) return;
    window.__agentmailEditEmailClickBlockerInstalled = true;

    const blockEditEmail = (event) => {
      if (!targetIsEditEmailAddressLink(event.target)) return;
      try { event.preventDefault(); } catch (error) {}
      try { event.stopPropagation(); } catch (error) {}
      try { event.stopImmediatePropagation(); } catch (error) {}
      setTimeout(() => autoFillMetaConfirmationCodePage(true), 60);
    };

    ["touchstart", "touchend", "pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((type) => {
      try { window.addEventListener(type, blockEditEmail, { capture: true, passive: false }); } catch (error) {}
      try { document.addEventListener(type, blockEditEmail, { capture: true, passive: false }); } catch (error) {}
    });
  }

  function targetIsConfirmationContinueButton(target) {
    if (!target || !isMetaAuthPage() || !isMetaConfirmationCodePage()) return false;
    let node = target;
    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute?.("aria-label"));
      if (area > 280000 || text.length > 120) continue;
      if (text === "continue" || text === "next") return true;
    }
    return false;
  }

  function installConfirmationContinueClickBlocker() {
    if (window.__agentmailConfirmationContinueBlockerInstalled) return;
    window.__agentmailConfirmationContinueBlockerInstalled = true;
    const blockIfCodeMissing = (event) => {
      if (!targetIsConfirmationContinueButton(event.target)) return;
      if (confirmationCodeReady()) return;
      try { event.preventDefault(); } catch (error) {}
      try { event.stopPropagation(); } catch (error) {}
      try { event.stopImmediatePropagation(); } catch (error) {}
      setTimeout(() => autoFillMetaConfirmationCodePage(true), 80);
    };
    ["touchstart", "touchend", "pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((type) => {
      try { window.addEventListener(type, blockIfCodeMissing, { capture: true, passive: false }); } catch (error) {}
      try { document.addEventListener(type, blockIfCodeMissing, { capture: true, passive: false }); } catch (error) {}
    });
  }

  function clickMetaEmailChoice(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (window.__agentmailMetaClickLoopRunning && !force && window.__agentmailMetaClickLoopTimer) {
      return { ok: true, message: "Already running" };
    }

    try { clearInterval(window.__agentmailMetaClickLoopTimer); } catch (error) {}
    window.__agentmailMetaClickLoopRunning = true;
    const startedAt = Date.now();
    const maxWaitMs = 24000;
    let attempts = 0;

    const stop = () => {
      clearInterval(timer);
      if (window.__agentmailMetaClickLoopTimer === timer) window.__agentmailMetaClickLoopTimer = null;
      window.__agentmailMetaClickLoopRunning = false;
    };

    const timer = setInterval(() => {
      try {
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
          autoHandleMetaCreateAccountBlocked(false);
          stop();
          return;
        }
        if (isMetaConfirmationCodePage()) {
          autoFillMetaConfirmationCodePage();
          return;
        }

        // Shared pipeline (single cached pass instead of a second full sweep).
        runMetaPipeline(false, false);

        const emailOptionRow = findMetaInitialThirdEmailOptionRow();
        const target = emailOptionRow || findMetaEmailChoiceButton();
        if (target) {
          const now = Date.now();
          if (!window.__agentmailEmailChoiceLastClick || now - window.__agentmailEmailChoiceLastClick > 900) {
            window.__agentmailEmailChoiceLastClick = now;
            attempts += 1;
            if (emailOptionRow) clickInitialThirdEmailOptionOnly(emailOptionRow);
            else fireEmailChoiceClick(target);
          }
        }

        const inputAlreadyVisible = Boolean(findMetaEmailInput());
        const stillThere = Boolean(findMetaEmailChoiceButton());
        if ((inputAlreadyVisible && attempts >= 1) || (attempts >= 6 && !stillThere) || attempts >= 12 || Date.now() - startedAt > maxWaitMs) {
          stop();
        }
      } catch (error) {
        // Never let one bad page state kill the loop.
      }
    }, 150);
    window.__agentmailMetaClickLoopTimer = timer;

    return { ok: true, message: "Meta automation started" };
  }

  function isMetaProfileContinuePage() {
    if (!isMetaAuthPage()) return false;
    const pageText = getPageTextFast();
    if (isMetaConfirmationCodePage() || isMetaDobPage() || isMetaPasswordPage() || isMetaHumanConfirmPage()) return false;
    return (
      pageText.includes("use another profile") &&
      pageText.includes("continue") &&
      !pageText.includes("confirm your account")
    ) || (
      pageText.includes("meta") &&
      pageText.includes("use another profile") &&
      findContinueButton()
    );
  }

  async function autoClickMetaProfileContinue(force = false) {
    if (!isMetaProfileContinuePage()) return { ok: false, message: "Profile continue page not found." };
    const now = Date.now();
    if (window.__agentmailMetaProfileContinueClickedAt && !force && now - window.__agentmailMetaProfileContinueClickedAt < 6000) {
      return { ok: true, message: "Profile Continue clicked recently." };
    }
    const button = findContinueButton() || findButtonByExactVisibleText("Continue");
    if (!button) return { ok: false, message: "Profile Continue button not found." };
    window.__agentmailMetaProfileContinueClickedAt = now;
    flash(button);
    await clickStrong(() => findContinueButton() || findButtonByExactVisibleText("Continue"), { kind: "profile-continue" });
    return { ok: true, message: "Profile Continue clicked." };
  }

  function isMetaAiPage() {
    const host = window.location.hostname.toLowerCase();
    return host === "www.meta.ai" || host === "meta.ai" || host === "auth.meta.ai";
  }

  // v3.4 SIGNUP: is the "Sign in to get started" dialog on screen?
  function isMetaAiSignUpDialogVisible() {
    if (!isMetaAiPage()) return false;
    const text = getPageTextFast();
    if (text.includes("sign in to get started")) return true;
    if (text.includes("log in or sign up")) return true;
    return Boolean(findMetaAiSignUpButton() && findMetaAiLoginButton());
  }

  function findMetaAiLoginButton() {
    if (!isMetaAiPage()) return null;
    const rows = queryAllDeep("button, [role='button'], a[href]")
      .filter((el) => isVisible(el))
      .filter((el) => /^(log ?in|sign ?in)$/.test(normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label") || "")));
    return rows[0] || null;
  }

  // The container that holds both the heading and the Sign up pill - used to
  // prefer the button that belongs to THIS dialog.
  function metaAiSignInDialogRoot() {
    try {
      const heads = queryAllDeep("h1, h2, h3, p, div, span").filter((el) => {
        const t = normalizeText(el.innerText || el.textContent || "");
        return t === "sign in to get started" || t === "log in or sign up to ask meta ai anything";
      });
      for (const head of heads.slice(0, 4)) {
        let node = head;
        for (let depth = 0; node && depth < 9; node = node.parentElement, depth += 1) {
          if (!node.querySelectorAll) continue;
          const hasSignUp = Array.from(node.querySelectorAll("button, [role='button'], a")).some((el) => /^sign ?up/i.test(normalizeText(el.innerText || el.textContent || "")));
          if (hasSignUp) return node;
        }
      }
    } catch (error) {}
    return null;
  }

  // v3.4 SIGNUP: "Sign up" only. Real interactive elements first; a container
  // whose text merely mentions "sign up" can never win again.
  function findMetaAiSignUpButton() {
    if (!isMetaAiPage()) return null;
    const score = (el) => {
      const raw = normalizeText([
        el.innerText, el.textContent, el.getAttribute("aria-label"), el.getAttribute("title"), el.value
      ].filter(Boolean).join(" "));
      if (!raw) return null;
      const tag = (el.tagName || "").toLowerCase();
      const interactive = tag === "button" || tag === "a" || (el.getAttribute("role") || "").toLowerCase() === "button";
      let value = 0;
      if (raw === "sign up" || raw === "signup") value += 100;
      else if (/^sign ?up\b/.test(raw)) value += 70;                  // "Sign up with email"
      else if (raw.includes("sign up")) value += 15;                  // text inside a button
      else if (raw.includes("create account") || raw.includes("create new account")) value += 45;
      else return null;                                               // nothing else may match
      if (/\blog ?in\b|\bsign ?in\b|login/.test(raw)) value -= 200;   // NEVER the Log in / Sign in pill
      if (interactive) value += 12;
      if (hasHiddenAncestor(el)) value -= 100;
      const area = rectArea(el);
      if (area < 40 || area > 60000) value -= 60;                     // a pill button is small
      return { el, raw, value, area, interactive };
    };
    try {
      const pool = queryAllDeep("button, [role='button'], a[href], input[type='button'], input[type='submit']")
        .filter((el) => isVisible(el))
        .map(score)
        .filter(Boolean)
        .filter((row) => row.value > 0)
        .sort((a, b) => b.value - a.value || a.area - b.area);
      if (pool.length) return getClickableTarget(pool[0].el) || pool[0].el;

      // Legacy safety net: a dialog that exposes the pill as a plain div/span.
      const fallback = queryAllDeep("div, span, li")
        .filter((el) => isVisible(el) && el.childElementCount <= 1)
        .map(score)
        .filter(Boolean)
        .filter((row) => row.value > 0 && row.area < 60000)
        .sort((a, b) => b.value - a.value || a.area - b.area);
      return fallback.length ? (getClickableTarget(fallback[0].el) || fallback[0].el) : null;
    } catch (error) {
      return null;
    }
  }

  // Did pressing Sign up actually move the page?
  function metaAiSignUpMoved() {
    try {
      if (!isMetaAiPage()) return true;                       // navigated away - done
      if (!isMetaAiSignUpDialogVisible()) return true;         // dialog closed - done
      const button = findMetaAiSignUpButton();
      if (button && (button.disabled || (button.getAttribute?.("aria-busy") || "") === "true")) return true;
      return false;
    } catch (error) {
      return false;
    }
  }

  async function autoClickMetaAiSignUp(force = false) {
    if (!isMetaAiPage()) return { ok: false, message: "Not meta.ai" };
    if (window.__agentmailMetaAiSignUpDone && !force) {
      return { ok: true, message: "Meta AI Sign up already handled." };
    }
    if (window.__agentmailMetaAiSignUpRunning && !force) {
      return { ok: true, message: "Meta AI Sign up click already running." };
    }
    // v3.4: never fire on an ordinary meta.ai page - only when the dialog is up.
    if (!isMetaAiSignUpDialogVisible()) return { ok: false, message: "Meta AI sign-in dialog not on screen." };

    window.__agentmailMetaAiSignUpRunning = true;
    try {
      // v3.4b: waiting for the pill is FREE - only real presses use the budget.
      const watchUntil = Date.now() + 25000;
      let presses = 0;
      while (presses < 3) {
        if (Date.now() > watchUntil) {
          return { ok: false, message: "Sign up button never appeared." };
        }
        const button = findMetaAiSignUpButton();
        if (!button || !isVisible(button)) { await sleep(120); continue; }
        presses += 1;
        const attempt = presses;
        flash(button);
        try { humanHover(button); } catch (error) {}
        // attempt 1: the proven strong click (pointer + mouse + touch, 4 strategies)
        // attempt 2/3: a real coordinate press on the button centre
        if (attempt === 1) {
          await clickStrong(() => findMetaAiSignUpButton(), { kind: "meta-ai-signup" });
        } else {
          await tapVerifiedElement(findMetaAiSignUpButton() || button).catch(() => false);
          if (!metaAiSignUpMoved()) {
            await clickStrong(() => findMetaAiSignUpButton(), { kind: "meta-ai-signup-retry" });
          }
        }
        window.__agentmailMetaAiSignUpClickedAt = Date.now();
        window.__agentmailMetaAiSignUpClicks = (window.__agentmailMetaAiSignUpClicks || 0) + 1;
        powerLog(`Meta AI Sign up pressed (${attempt}/3)`);
        const moved = await waitFor(() => metaAiSignUpMoved(), { timeout: 1200, poll: 60 });
        if (moved) {
          window.__agentmailMetaAiSignUpDone = true;
          powerLog("Meta AI Sign up accepted - moving on");
          return { ok: true, message: "Meta AI Sign up clicked." };
        }
      }
      // three real presses were made - stop hammering, Meta may just be slow
      window.__agentmailMetaAiSignUpDone = true;
      return { ok: false, message: "Sign up pressed 3 times but the dialog stayed." };
    } catch (error) {
      return { ok: false, message: `Sign up click soft-failed: ${(error && error.message) || error}` };
    } finally {
      window.__agentmailMetaAiSignUpRunning = false;
    }
  }

  function startMetaAiSignupWatcher() {
    if (window.__agentmailMetaAiSignupWatcherStarted) return;
    window.__agentmailMetaAiSignupWatcherStarted = true;
    if (!isMetaAiPage()) return;

    // Click Sign up the instant it is visible: immediate tries, a brisk timer
    // and a frame-coalesced observer (one callback per frame, not per mutation).
    [0, 40, 100, 180, 300, 500, 800, 1200, 1800, 2600, 4000, 6500, 9000].forEach((delay) => {
      setTimeout(() => autoClickMetaAiSignUp(false), delay);
    });

    const fastTimer = setInterval(() => {
      if (!isMetaAiPage()) { clearInterval(fastTimer); return; }
      scheduleCoalesced("agentmailMetaAiSignupTick", () => autoClickMetaAiSignUp(false));
    }, 130);
    setTimeout(() => clearInterval(fastTimer), 20000);

    try {
      const observer = new MutationObserver(() => {
        scheduleCoalesced("agentmailMetaAiSignupDom", () => autoClickMetaAiSignUp(false));
      });
      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      setTimeout(() => observer.disconnect(), 25000);
    } catch (error) {}
  }

  // ================================================================
  // POWER ENGINE v2.0 - self-detecting page brain + strong actions
  // Every screen is recognised by weight-matched signatures, the right
  // action fires first, and every click / paste escalates through 4
  // strategies until the page really moves.
  // ================================================================
  const POWER = {
    startedAt: Date.now(),
    sweeps: 0,
    detections: 0,
    clicks: 0,
    fills: 0,
    keys: 0,
    heals: 0,
    errors: 0,
    fastSkips: 0,
    lastPage: { id: "boot", name: "Starting", confidence: 0, steps: 0 },
    pageSince: Date.now(),
    lastAction: "boot",
    lastActionAt: Date.now(),
    log: []
  };

  function powerLog(message) {
    try {
      POWER.log.push({ at: Date.now(), message: String(message).slice(0, 90) });
      if (POWER.log.length > 30) POWER.log.shift();
    } catch (error) {}
  }

  function touchAction(kind) {
    POWER.lastAction = kind;
    POWER.lastActionAt = Date.now();
  }

  // ---------------- page signatures (weight matched) ----------------
  const PAGE_SIGNATURES = [
    { id: "blocked", name: "Account block", steps: 0, words: [["you can't use meta right now", 70], ["you can\u2019t use meta right now", 70], ["we limit how often you can", 40], ["temporarily blocked", 40]] },
    { id: "code", name: "Confirmation code", steps: 2, words: [["enter the confirmation code", 75], ["confirmation code", 40], ["6-digit", 25], ["send code again", 35], ["we sent a code", 35], ["look for an email", 20]] },
    { id: "selfie", name: "Photo verification", steps: 7, words: [["clearly shows your face", 65], ["take a photo", 30], ["selfie", 45], ["upload", 12]] },
    { id: "name", name: "Your name", steps: 4, words: [["what's your name", 75], ["what\u2019s your name", 75], ["first name", 30], ["surname", 30], ["last name", 25], ["name cannot contain", 40]] },
    { id: "dob", name: "Date of birth", steps: 5, words: [["date of birth", 65], ["birthday", 20], ["what's your date of birth", 70]] },
    { id: "password", name: "Password", steps: 6, words: [["create a password", 65], ["new password", 45], ["at least 6 characters", 35], ["couldn't guess", 30], ["couldn\u2019t guess", 30]] },
    { id: "save-login", name: "Save login", steps: 6, words: [["save login info", 60], ["save your login", 55], ["not now", 15]] },
    { id: "final-review", name: "Final review", steps: 7, words: [["review your info", 55], ["agree to", 18], ["terms and conditions", 15], ["marketing emails", 30]] },
    { id: "human", name: "Human check", steps: 6, words: [["confirm that you're human", 70], ["confirm that you\u2019re human", 70], ["i'm not a robot", 65], ["i\u2019m not a robot", 65], ["human to use your account", 60]] },
    { id: "cookies", name: "Cookie choice", steps: 0, words: [["allow all cookies", 60], ["decline optional cookies", 45], ["how we use these cookies", 40]] },
    { id: "saved-login", name: "Saved account", steps: 0, words: [["use another account", 60], ["log in to another account", 60], ["log into another account", 60], ["login to another account", 60]] },
    { id: "email-choice", name: "Login options", steps: 1, words: [["log in or create an account", 60], ["use mobile number or email", 50], ["continue with facebook", 45], ["continue with instagram", 45]] },
    { id: "email-entry", name: "Email entry", steps: 1, words: [["what's your mobile number or email address", 70], ["what\u2019s your mobile number or email address", 70], ["you'll use this to log in", 25], ["you\u2019ll use this to log in", 25]] },
    { id: "language-logout", name: "Logout screen", steps: 0, words: [["log out", 35], ["logout", 35], ["language", 30], ["accounts centre", 25]] },
    { id: "meta-ai", name: "Meta AI", steps: 8, words: [["meta ai", 30], ["sign up", 30], ["chat with meta ai", 40]] },
    { id: "error", name: "Something went wrong", steps: 0, words: [["something went wrong", 70], ["please try again", 25]] }
  ];

  // Structural boosts: cheap cached queries that beat text guessing.
  function structuralHints(pageText) {
    const hints = {};
    try {
      if (pageHasVisiblePasswordInput()) hints.password = 40;
    } catch (error) {}
    try {
      if (queryAllDeep("input[type='password']").length && !hints.password) hints.password = 25;
    } catch (error) {}
    try {
      const selects = queryAllDeep("select").filter((el) => isVisible(el));
      if (selects.length >= 2 && (pageText.includes("date of birth") || pageText.includes("birth"))) hints.dob = 35;
      if (!hints.dob && pageText.includes("birth")) {
        // Custom pickers: Day / Month / Year labels with combobox rows, no <select>.
        const kinds = new Set();
        for (const el of queryAllDeep("span, label, div")) {
          if (kinds.size >= 3) break;
          if (!isVisible(el)) continue;
          const text = normalizeText(el.textContent || el.getAttribute?.("aria-label") || "");
          if (/^(day|month|year)$/.test(text)) kinds.add(text);
        }
        if (kinds.size >= 2) hints.dob = 40;
      }
    } catch (error) {}
    try {
      const codeish = queryAllDeep("input").filter((el) => {
        if (!isVisible(el)) return false;
        const mode = String(el.inputMode || el.getAttribute("inputmode") || "").toLowerCase();
        const autoc = String(el.autocomplete || "").toLowerCase();
        return mode === "numeric" || autoc.includes("one-time-code") || Number(el.maxLength) === 6;
      });
      if (codeish.length) hints.code = 45;
    } catch (error) {}
    try {
      const nameAttrs = queryAllDeep("input").filter((el) => {
        const hint = normalizeText([el.name, el.id, el.getAttribute("autocomplete")].filter(Boolean).join(" "));
        return /first|last|surname|given-name|family-name/.test(hint);
      });
      if (nameAttrs.length) hints.name = 40;
    } catch (error) {}
    try {
      if (queryAllDeep("input[type='file']").length) hints.selfie = 45;
    } catch (error) {}
    return hints;
  }

  function detectPage() {
    const text = getPageTextFast();
    if (!text) {
      return { id: "blank", name: "Blank / loading", confidence: 80, steps: 0 };
    }

    const scores = {};
    for (const sig of PAGE_SIGNATURES) {
      let score = 0;
      for (const pair of sig.words) {
        if (text.includes(pair[0])) score += pair[1];
      }
      if (score) scores[sig.id] = score;
    }

    const hints = structuralHints(text);
    for (const key of Object.keys(hints)) {
      scores[key] = (scores[key] || 0) + hints[key];
    }

    if (window.location.hostname.toLowerCase().includes("meta.ai")) {
      scores["meta-ai"] = (scores["meta-ai"] || 0) + 65;
    }

    let bestId = "unknown";
    let bestScore = 0;
    for (const key of Object.keys(scores)) {
      if (scores[key] > bestScore) { bestScore = scores[key]; bestId = key; }
    }

    if (bestId === "unknown") {
      return { id: "unknown", name: "Unrecognised screen", confidence: Math.min(45, Math.round(text.length / 12)), steps: 0 };
    }

    const sig = PAGE_SIGNATURES.find((s) => s.id === bestId);
    return {
      id: bestId,
      name: sig ? sig.name : bestId,
      confidence: Math.min(100, bestScore),
      steps: sig ? sig.steps : 0
    };
  }

  // ---------------- learned memory (gets faster every run) ----------------
  function elementKey(el) {
    if (!el) return "";
    try {
      const parts = [
        el.tagName,
        el.id,
        el.getAttribute && el.getAttribute("name"),
        el.getAttribute && el.getAttribute("aria-label"),
        el.getAttribute && el.getAttribute("data-testid"),
        (el.value || "").slice(0, 12),
        (el.innerText || el.textContent || "").trim().slice(0, 20)
      ];
      return normalizeText(parts.filter(Boolean).join("|")).slice(0, 140);
    } catch (error) {
      return "";
    }
  }

  function rememberWin(kind, el) {
    const key = elementKey(el);
    if (!kind || !key) return;
    try {
      const store = JSON.parse(sessionStorage.getItem("agentmail_power_memory") || "{}");
      store[kind] = { key, at: Date.now() };
      sessionStorage.setItem("agentmail_power_memory", JSON.stringify(store));
    } catch (error) {}
  }

  function recallWin(kind) {
    try {
      const store = JSON.parse(sessionStorage.getItem("agentmail_power_memory") || "{}");
      const hit = store[kind];
      if (hit && hit.key && Date.now() - (hit.at || 0) < 6 * 60 * 60 * 1000) return hit.key;
    } catch (error) {}
    return "";
  }

  // ---------------- strong click: 4 escalating strategies ----------------
  function tryKeyActivation(target) {
    if (!target) return false;
    try {
      try { target.focus({ preventScroll: true }); } catch (error) {}
      const init = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true, composed: true };
      target.dispatchEvent(new KeyboardEvent("keydown", init));
      target.dispatchEvent(new KeyboardEvent("keypress", init));
      target.dispatchEvent(new KeyboardEvent("keyup", init));
      POWER.keys += 1;
      touchAction("key");
      return true;
    } catch (error) {
      return false;
    }
  }

  function clickByPoint(target) {
    try {
      const rect = getRect(target);
      if (!rect || !rect.width || !rect.height) return false;
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const el = document.elementFromPoint(x, y);
      if (!el) return false;
      const hit = getClickableTarget(el) || el;
      if (hit === target) return false;
      return fireRealisticClick(hit);
    } catch (error) {
      return false;
    }
  }

  // Verification: the target really left the screen, or the page state changed.
  function clickVerify(target, pageIdBefore) {
    return () => {
      try {
        if (!document.contains(target)) return true;
        if (!isVisible(target)) return true;
        const page = detectPage();
        if (page.id !== pageIdBefore && page.confidence >= 50) return true;
        if (getEditableValue(document.activeElement) && document.activeElement !== target) return true;
      } catch (error) {}
      return false;
    };
  }

  // ---------------- actionability (Playwright-style) ----------------
  function resolveTarget(targetOrGetter) {
    try {
      if (typeof targetOrGetter === "function") return targetOrGetter() || null;
      return targetOrGetter || null;
    } catch (error) {
      return null;
    }
  }

  function targetIsActionable(node) {
    if (!node) return false;
    try {
      if (!document.contains(node)) return false;
      if (!isVisible(node)) return false;
      const style = getCachedStyle(node);
      if (style && style.pointerEvents === "none" && node.tagName !== "INPUT") return false;
      return true;
    } catch (error) {
      return false;
    }
  }

  function targetIsTopmost(node) {
    try {
      const rect = getRect(node);
      if (!rect || !rect.width || !rect.height) return false;
      const hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
      if (!hit) return false;
      return hit === node || node.contains(hit) || hit.contains(node);
    } catch (error) {
      return false;
    }
  }

  async function settleRect(node) {
    try {
      const before = getRect(node);
      await humanDelay(1);
      const after = getRect(node);
      if (!before || !after) return false;
      return Math.abs(before.left - after.left) < 2 && Math.abs(before.top - after.top) < 2;
    } catch (error) {
      return false;
    }
  }

  // Verified wait: gives React a beat to commit the change instead of guessing.
  async function waitForClickResult(verify, timeoutMs = 320) {
    if (!verify) return false;
    try { if (verify()) return true; } catch (error) {}
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      await humanDelay(1);
      try { if (verify()) return true; } catch (error) {}
    }
    return false;
  }

  // Human-like pointer travel: short curved mousemove path + hover events before
  // the click. Automated clicks that appear out of nowhere look robotic; a tiny
  // move-in path with random timing reads as a normal mouse (anti-detection).
  function humanHover(node) {
    try {
      const rect = getRect(node);
      if (!rect || !rect.width || !rect.height) return;
      const end = {
        x: rect.left + rect.width * (0.40 + Math.random() * 0.20),
        y: rect.top + rect.height * (0.40 + Math.random() * 0.20)
      };
      const startX = end.x + (40 + Math.random() * 120) * (Math.random() < 0.5 ? -1 : 1);
      const startY = end.y + (30 + Math.random() * 90) * (Math.random() < 0.5 ? -1 : 1);
      const steps = 3 + Math.floor(Math.random() * 3);
      const Pointer = window.PointerEvent || window.MouseEvent;
      const move = (x, y) => {
        const init = { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, pointerId: 1, pointerType: "mouse", isPrimary: true };
        const hit = document.elementFromPoint(x, y) || node;
        hit.dispatchEvent(new Pointer("pointermove", init));
        hit.dispatchEvent(new MouseEvent("mousemove", init));
      };
      for (let i = 1; i <= steps; i += 1) {
        const t = i / steps;
        const ease = t * t * (3 - 2 * t);
        const bend = Math.sin(t * Math.PI) * (Math.random() * 14 - 7);
        move(startX + (end.x - startX) * ease, startY + (end.y - startY) * ease + bend);
      }
      const over = { bubbles: true, cancelable: true, composed: true, view: window, clientX: end.x, clientY: end.y };
      node.dispatchEvent(new MouseEvent("mouseover", over));
      node.dispatchEvent(new MouseEvent("mousemove", over));
    } catch (error) {}
  }

  async function clickStrong(targetOrGetter, options = {}) {
    const kind = options.kind || "click";
    const pageIdBefore = options.pageId || POWER.lastPage.id;

    let target = resolveTarget(targetOrGetter);
    if (!target) return false;

    // v3.5 DOUBLE-CLICK GUARD: never press the very same element twice with the
    // same kind of action inside 1 s - the first press is still in flight. The
    // audit of the hamburger / create-account / logout paths is why this exists.
    try {
      const last = window.__agentmailLastStrongPress;
      if (last && last.el === target && last.kind === kind && Date.now() - last.at < 1000) {
        powerLog(`Skipped a duplicate ${kind} press (v3.5)`);
        return true;
      }
      window.__agentmailLastStrongPress = { el: target, kind, at: Date.now() };
    } catch (error) {}

    const verify = typeof options.verify === "function"
      ? options.verify
      : () => {
          try {
            if (!document.contains(target)) return true;
            if (!isVisible(target)) return true;
            // Button went busy/disabled after the click => Meta registered it.
            // Stop here so we never double-submit while the request is in flight.
            if (target.disabled) return true;
            if ((target.getAttribute?.("aria-disabled") || "").toLowerCase() === "true") return true;
            if ((target.getAttribute?.("aria-busy") || "").toLowerCase() === "true") return true;
            const busyStyle = getCachedStyle(target);
            if (busyStyle && busyStyle.pointerEvents === "none") return true;
            const page = detectPage();
            if (page.id !== pageIdBefore && page.confidence >= 50) return true;
          } catch (error) {}
          return false;
        };

    // Make it on-screen, let the layout settle, then act on what is really there.
    try { target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
    await settleRect(target);

    const tryClick = async (node, label, timeoutMs = 420) => {
      if (!targetIsActionable(node)) return false;
      humanHover(node);
      await sleep(70 + Math.random() * 150);
      fireRealisticClick(node);
      POWER.clicks += 1;
      touchAction(label || kind);
      rememberWin(kind, node);
      return await waitForClickResult(verify, timeoutMs + Math.random() * 90);
    };

    // 1) clean realistic click
    if (await tryClick(target)) return true;

    // 2) the node may have been re-rendered - re-find the fresh one and click that
    const fresh = resolveTarget(targetOrGetter);
    if (fresh && fresh !== target) {
      target = fresh;
      try { target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" }); } catch (error) {}
      await settleRect(target);
      if (await tryClick(target)) return true;
    }

    // 3) keyboard activation (Enter) - best for role=button rows and links
    if (targetIsActionable(target)) {
      tryKeyActivation(target);
      POWER.clicks += 1;
      if (await waitForClickResult(verify, 260)) return true;
    }

    // 4) the listener may live on a parent - click the nearest clickable ancestor
    try {
      const alt = getClickableTarget(target);
      if (alt && alt !== target && targetIsActionable(alt)) {
        fireRealisticClick(alt);
        POWER.clicks += 1;
        if (await waitForClickResult(verify, 260)) return true;
      }
    } catch (error) {}

    // 5) precise point click: re-read the rect, press exactly what is under it
    humanHover(target);
    if (targetIsActionable(target) && clickByPoint(target)) {
      POWER.clicks += 1;
      if (await waitForClickResult(verify, 260)) return true;
    }

    // 6) last resort - raw pointer/mouse sequence at the point under the element
    try {
      const rect = getRect(target);
      if (rect && rect.width && rect.height) {
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        const hit = document.elementFromPoint(x, y) || target;
        const init = {
          bubbles: true, cancelable: true, composed: true, view: window,
          clientX: x, clientY: y, button: 0, buttons: 1,
          pointerId: 1, pointerType: "mouse", isPrimary: true
        };
        const Pointer = window.PointerEvent || window.MouseEvent;
        hit.dispatchEvent(new Pointer("pointerdown", init));
        hit.dispatchEvent(new MouseEvent("mousedown", init));
        hit.dispatchEvent(new Pointer("pointerup", { ...init, buttons: 0 }));
        hit.dispatchEvent(new MouseEvent("mouseup", { ...init, buttons: 0 }));
        hit.dispatchEvent(new MouseEvent("click", { ...init, buttons: 0 }));
        POWER.clicks += 1;
        invalidateDomCache();
      }
    } catch (error) {}

    powerLog(`Strong fallback used: ${kind}`);
    return true;
  }

  // ---------------- strong fill: 4 escalating strategies ----------------
  function valueLanded(input, value) {
    const want = String(value == null ? "" : value);
    const got = getEditableValue(input) || "";
    if (!want) return true;
    if (got.includes(want)) return true;
    const probe = want.slice(0, Math.min(8, want.length));
    return probe.length > 0 && got.includes(probe);
  }

  function tryPasteEvent(input, value) {
    try {
      try { input.focus({ preventScroll: true }); } catch (error) {}
      let data = null;
      if (window.DataTransfer) {
        data = new DataTransfer();
        data.setData("text/plain", String(value));
      }
      const init = { bubbles: true, cancelable: true, composed: true, clipboardData: data };
      let event = null;
      try { event = new ClipboardEvent("paste", init); } catch (error) { event = null; }
      if (!event) event = new Event("paste", { bubbles: true, cancelable: true, composed: true });
      input.dispatchEvent(event);
      return valueLanded(input, value);
    } catch (error) {
      return false;
    }
  }

  async function typeCharsStrong(input, value) {
    const text = String(value == null ? "" : value);
    if (!input || !text) return false;
    try {
      try { input.focus({ preventScroll: true }); } catch (error) {}
      input.select?.();
      for (let i = 0; i < text.length; i += 1) {
        const ch = text[i];
        const init = {
          key: ch,
          code: ch,
          charCode: ch.charCodeAt(0),
          keyCode: ch.toUpperCase().charCodeAt(0),
          which: ch.toUpperCase().charCodeAt(0),
          bubbles: true,
          cancelable: true,
          composed: true
        };
        let bi = null;
        try { bi = new InputEvent("beforeinput", { bubbles: true, cancelable: true, composed: true, inputType: "insertText", data: ch }); } catch (error) { bi = new Event("beforeinput", { bubbles: true }); }
        input.dispatchEvent(bi);
        input.dispatchEvent(new KeyboardEvent("keydown", init));
        if (typeof input.setRangeText === "function" && input.setSelectionRange) {
          const start = typeof input.selectionStart === "number" ? input.selectionStart : getEditableValue(input).length;
          const end = typeof input.selectionEnd === "number" ? input.selectionEnd : start;
          try { input.setRangeText(ch, start, end, "end"); } catch (error) { }
        }
        input.dispatchEvent(new KeyboardEvent("keyup", init));
        let ie = null;
        try { ie = new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: ch }); } catch (error) { ie = new Event("input", { bubbles: true }); }
        input.dispatchEvent(ie);
        POWER.keys += 1;
        if (i % 3 === 2) await humanDelay(1);
      }
      input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
      touchAction("type");
      return valueLanded(input, text);
    } catch (error) {
      return false;
    }
  }

  async function fillStrong(input, value, options = {}) {
    if (!input) return false;
    const kind = options.kind || "fill";
    const text = value == null ? "" : String(value);

    // strategy 1 - single native write (butter path)
    setNativeValue(input, text);
    POWER.fills += 1;
    rememberWin(kind, input);
    if (valueLanded(input, text)) { touchAction(kind); return true; }

    await humanDelay(1);
    if (valueLanded(input, text)) { touchAction(kind); return true; }

    // strategy 2 - execCommand insertText (some legacy inputs only accept this)
    try {
      try { input.focus({ preventScroll: true }); } catch (error) {}
      input.select?.();
      document.execCommand?.("insertText", false, text);
    } catch (error) {}
    if (valueLanded(input, text)) { touchAction(kind); return true; }

    // strategy 3 - per character typing with real key events
    if (await typeCharsStrong(input, text)) return true;

    // strategy 4 - a genuine paste event carrying the text
    if (tryPasteEvent(input, text)) return true;

    return valueLanded(input, text);
  }

  // ---------------- split OTP boxes (4-6 single digit inputs) ----------------
  function findOtpInputs() {
    try {
      const inputs = queryAllDeep("input").filter((el) => {
        if (!el || !isVisible(el)) return false;
        const type = (el.type || "text").toLowerCase();
        if (!["text", "tel", "number", "password", "search", ""].includes(type)) return false;
        const maxLen = Number(el.maxLength || 0);
        const size = Number(el.getAttribute("size") || 0);
        const autoc = String(el.autocomplete || "").toLowerCase();
        const mode = String(el.inputMode || el.getAttribute("inputmode") || "").toLowerCase();
        const hint = normalizeText([el.id, el.name, el.getAttribute("aria-label"), el.placeholder].filter(Boolean).join(" "));
        return maxLen === 1 || size === 1 || mode === "numeric" || autoc.includes("one-time-code") || /otp|code|pin|digit/.test(hint);
      });
      return inputs.sort((a, b) => {
        const ra = getRect(a) || { left: 0, top: 0 };
        const rb = getRect(b) || { left: 0, top: 0 };
        return (ra.left - rb.left) || (ra.top - rb.top);
      });
    } catch (error) {
      return [];
    }
  }

  async function pasteCodeStrong(code) {
    const digits = String(code || "").replace(/\D+/g, "");
    if (!digits) return false;

    // Split boxes: one digit per box, left to right, then focus the last one.
    const boxes = findOtpInputs().filter((el) => Number(el.maxLength) === 1 || Number(el.getAttribute("size")) === 1);
    if (boxes.length >= 4 && digits.length >= boxes.length) {
      for (let i = 0; i < boxes.length; i += 1) {
        const box = boxes[i];
        if (!box || !isVisible(box)) break;
        await fillStrong(box, digits[i], { kind: "otp-box" });
        await humanDelay(1);
      }
      try { boxes[Math.min(digits.length, boxes.length) - 1]?.focus?.({ preventScroll: true }); } catch (error) {}
      touchAction("otp-split");
      return getCurrentConfirmationCodeValue() === digits.slice(0, 6) || boxes.every((b, i) => getEditableValue(b).replace(/\D+/g, "") === digits[i]);
    }

    // Single box
    const input = findMetaConfirmationCodeInput();
    if (!input) return false;
    const ok = await fillStrong(input, digits, { kind: "otp" });
    if (ok) {
      try {
        input.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: digits }));
      } catch (error) {
        input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
      }
    }
    return ok;
  }

  // ---------------- self heal ----------------
  function powerAutoHeal(force = false) {
    if (!force && POWER.sweeps % 24 !== 0) return false;
    if (!isMetaAuthPage()) return false;

    const page = POWER.lastPage;
    const stuckFor = Date.now() - POWER.pageSince;
    const idleFor = Date.now() - POWER.lastActionAt;

    // Unrecognised / blank screen with no progress: nudge, then one soft reload.
    if ((page.id === "unknown" || page.id === "blank") && stuckFor > 15000 && idleFor > 12000) {
      // v3.2 NOREFRESH: never - not even the self-heal - while the code step is
      // fresh. This is the reload that ended the user's flow on a blank screen.
      if (codeStepNoReloadActive()) return false;
      try {
        const lastHeal = Number(sessionStorage.getItem("agentmail_power_last_heal") || "0");
        const heals = Number(sessionStorage.getItem("agentmail_power_heal_count") || "0");
        if (Date.now() - lastHeal > 45000 && heals < 3) {
          sessionStorage.setItem("agentmail_power_last_heal", String(Date.now()));
          sessionStorage.setItem("agentmail_power_heal_count", String(heals + 1));
          POWER.heals += 1;
          powerLog(`Self-heal #${heals + 1}: refresh ${page.name}`);
          window.scrollBy(0, 40);
          window.location.reload();
          return true;
        }
      } catch (error) {}
    }
    return false;
  }

  // ---------------- telemetry ----------------
  function powerStats() {
    return {
      ok: true,
      version: AGENTMAIL_SCRIPT_VERSION,
      running: Boolean(window.__agentmailSweepEngineStarted) && !window.__agentmailSweepStopped,
      page: POWER.lastPage,
      pageForMs: Date.now() - POWER.pageSince,
      lastAction: POWER.lastAction,
      lastActionForMs: Date.now() - POWER.lastActionAt,
      counters: {
        sweeps: POWER.sweeps,
        detections: POWER.detections,
        clicks: POWER.clicks,
        fills: POWER.fills,
        keys: POWER.keys,
        heals: POWER.heals,
        errors: POWER.errors
      },
      uptimeMs: Date.now() - POWER.startedAt,
      log: POWER.log.slice(-5)
    };
  }

  // ---------------- live HUD inside the floating widget ----------------
  let __agentmailHudKey = "";
  function updateEngineHud(force = false) {
    try {
      const host = document.getElementById("agentmail-floating-widget-host");
      const shadow = host && host.shadowRoot;
      if (!shadow) return;

      const running = Boolean(window.__agentmailSweepEngineStarted) && !window.__agentmailSweepStopped;
      const busy = Date.now() - POWER.lastActionAt < 1600;
      const state = !running ? "idle" : busy ? "work" : "live";
      const key = `${state}|${POWER.lastPage.name}|${POWER.lastPage.confidence}|${POWER.clicks}|${POWER.fills}|${POWER.sweeps}|${POWER.heals}`;
      if (!force && key === __agentmailHudKey) return;
      __agentmailHudKey = key;

      // v3.0 LITE: the HUD shows the current screen and a plain state word - no
      // counters, no scan numbers, nothing that has to be redrawn.
      const lastId = POWER.lastPage ? POWER.lastPage.id : "unknown";
      const friendly = lastId === "unknown" || lastId === "blank" ? "Ready" : POWER.lastPage.name;
      const pageText = running ? friendly : "Engine idle";
      const statsText = running ? "Engine on" : "Engine idle";
      const lastLog = "Engine ready";

      ["#engineDot", "#engineMiniDot", "#engineHudDot"].forEach((sel) => {
        const el = shadow.querySelector(sel);
        if (el) el.dataset.state = state;
      });
      const pageEl = shadow.querySelector("#enginePage");
      if (pageEl) pageEl.textContent = pageText;
      const statsEl = shadow.querySelector("#engineStats");
      if (statsEl) statsEl.textContent = "Engine on";
      const pageBig = shadow.querySelector("#enginePageBig");
      if (pageBig) pageBig.textContent = pageText;
      // v3.3 LUX: one light phrase that follows the state - nothing to redraw.
      const noteEl = shadow.querySelector("#engineNote");
      if (noteEl) {
        const phrase = window.__agentmailKeptAccount
          ? "Mail+pass \u2713"
          : state === "work" ? "Softly working" : state === "live" ? "Flowing" : "Standing by";
        if (noteEl.textContent !== phrase) noteEl.textContent = phrase;
      }
      const logElNow = shadow.querySelector("#engineLog");
      if (logElNow && !POWER.log.length) logElNow.textContent = "Sit back \u2014 everything is flowing.";
      const statsBig = shadow.querySelector("#engineStatsBig");
      if (statsBig) statsBig.textContent = statsText;
      const kept = window.__agentmailKeptAccount;
      const logEl = shadow.querySelector("#engineLog");
      if (logEl) {
        const line = kept ? `Saved: ${kept.email} / ${kept.password}` : (POWER.log.length ? POWER.log[POWER.log.length - 1].message : lastLog);
        if (logEl.textContent !== line) logEl.textContent = line;
      }
      const pill = shadow.querySelector("#engineState");
      if (pill) {
        pill.dataset.state = state;
        pill.textContent = state === "work" ? "WORKING" : state === "live" ? "LIVE" : "IDLE";
      }
      const orb = shadow.querySelector("#logoBtn");
      if (orb) orb.dataset.state = state;
    } catch (error) {}
  }

  // ---------------- page aware fast path (act first, pipeline as safety) ----------------
  const PAGE_FASTPATH = {
    "email-entry": (force) => {
      const r = autoFillMetaEmailInput();
      return Boolean(r);
    },
    "cookies": (force) => {
      const r = autoClickMetaAllowAllCookies(force);
      return Boolean(r && r.ok && !/not found/i.test(r.message || ""));
    },
    "saved-login": (force) => {
      const r = autoClickMetaLoginAnotherAccount(force);
      return Boolean(r && r.ok && !/not found/i.test(r.message || ""));
    },
    "name": (force) => {
      const r = autoFillMetaNamePage(force);
      return Boolean(r && r.ok && /filled|clicked|queued/i.test(r.message || ""));
    },
    "dob": (force) => {
      const r = autoFillMetaDobPage(force);
      healDobValidationError(force);
      return Boolean(r && r.ok && /filled|clicked|selected/i.test(r.message || ""));
    },
    "password": (force) => {
      const r = autoFillMetaPasswordPage(force);
      return Boolean(r && r.ok && /filled|clicked|queued/i.test(r.message || ""));
    },
    "save-login": (force) => {
      const r = autoClickMetaNotNow(force);
      return Boolean(r && r.ok && !/not found/i.test(r.message || ""));
    },
    "final-review": (force) => {
      const r = autoClickMetaFinalReview(force);
      return Boolean(r && r.ok && !/not found/i.test(r.message || ""));
    },
    "selfie": (force) => {
      const r = autoClickMetaSelfieContinue(force);
      return Boolean(r && r.ok && !/not found/i.test(r.message || ""));
    }
  };

  function runFastPath(page, force) {
    if (!page || page.confidence < 70) return false;
    const handler = PAGE_FASTPATH[page.id];
    if (!handler) return false;
    // Safety valve: never skip the full pipeline for too long.
    if (POWER.fastSkips > 45) {
      POWER.fastSkips = 0;
      return false;
    }
    let handled = false;
    try { handled = Boolean(handler(force)); } catch (error) { handled = false; }
    POWER.fastSkips = handled ? POWER.fastSkips + 1 : 0;
    return handled;
  }

  // ----------------------------------------------------------------
  // BUTTER DRIVE - one shared pipeline, one adaptive loop, zero jank.
  // ----------------------------------------------------------------
  function runMetaPipeline(force = false, includeEmailChoice = true) {
    autoClickMetaProfileContinue(force);
    if (includeEmailChoice) clickMetaEmailChoice(force);
    redirectFromMetaLanguagePage(false);
    autoClickMetaHamburgerAndLogout(false);
    autoClickMetaAllowAllCookies(false);
    autoClickMetaLoginAnotherAccount(false);
    autoRefreshMetaBlankWhite(false);
    autoRefreshMetaDarkStuck(false);
    autoRefreshMetaSomethingWentWrong(false);
    autoRefreshMetaCantUseRightNow(false);
    autoClickMetaOopsOk(false);
    autoClickMetaHumanContinue(false);
    autoClickMetaCreateNewAccount(force);
    autoFillMetaNamePage(false);
    autoFillMetaDobPage(false);
    healDobValidationError(false);
    autoFillMetaPasswordPage(false);
    autoClickMetaNotNow(false);
    autoClickMetaFinalReview(false);
    autoCleanMetaAiDetailsName(false);   // v3.3 LUX: never an email in the Name box
    autoClickMetaAiDetailsConfirm(false);
    autoFillMetaConfirmationCodePage(false);
    autoClickMetaSelfieContinue(false);
    autoFillMetaEmailInput();
  }

  let __agentmailSweepBusy = false;
  let __agentmailSweepPending = false;
  let __agentmailLastSweepAt = 0;

  function runMetaSweep(force = false) {
    if (__agentmailSweepBusy) {
      // Never run twice in parallel: queue one follow-up instead.
      __agentmailSweepPending = true;
      return false;
    }
    __agentmailSweepBusy = true;
    POWER.sweeps += 1;
    invalidateDomCache(); // one fresh DOM view shared by every check below

    try {
      if (isMetaAiPage()) {
        // v3.4b: name the screen for the HUD (nothing else to detect here).
        if (!POWER.lastPage || POWER.lastPage.id !== "meta-ai") {
          POWER.lastPage = { id: "meta-ai", name: "Meta AI", confidence: 92, steps: 1 };
        }
        autoClickMetaAiSignUp(force);
        startMetaAiSignupWatcher();
        return true;
      }
      if (!isMetaAuthPage()) return false;
      if (redirectMetaAiIfPostCodePending(false)) return true;
      if (redirectAfterSelfieUploadGoneIfNeeded()) return true;
      if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
        autoHandleMetaCreateAccountBlocked(force);
        return true;
      }
      if (isMetaConfirmationCodePage()) {
        autoFillMetaConfirmationCodePage(force);
        return true;
      }

      // POWER: recognise the screen, then let the matching handler fire first.
      const page = detectPage();
      updatePowerTelemetry(page);
      if (runFastPath(page, force)) {
        updateEngineHud();
        return true;
      }

      runMetaPipeline(force);
      powerAutoHeal(false);
      updateEngineHud();
      return true;
    } catch (error) {
      // Soft-fail: one odd page state can never break the loop or throw.
      POWER.errors += 1;
      powerLog(`Soft-fail: ${(error && error.message) || error}`);
      return false;
    } finally {
      __agentmailSweepBusy = false;
      __agentmailLastSweepAt = Date.now();
      if (__agentmailSweepPending) {
        __agentmailSweepPending = false;
        scheduleCoalesced("agentmailSweepPending", () => {
          if (!window.__agentmailSweepStopped) runMetaSweep(force);
        });
      }
    }
  }

  function updatePowerTelemetry(page) {
    try {
      if (!page) return;
      if (page.id !== POWER.lastPage.id) {
        POWER.detections += 1;
        POWER.lastPage = page;
        POWER.pageSince = Date.now();
        powerLog(`Detected: ${page.name} (${page.confidence}%)`);
      } else {
        POWER.lastPage = page;
      }
    } catch (error) {}
  }

  function requestMetaSweep(minGap = 80, force = false) {
    if (Date.now() - __agentmailLastSweepAt < minGap) return false;
    return runMetaSweep(force);
  }

  function startMetaSweepEngine() {
    window.__agentmailSweepStopped = false;

    if (window.__agentmailSweepEngineStarted) {
      scheduleCoalesced("agentmailSweepNow", () => requestMetaSweep(0));
      return;
    }
    window.__agentmailSweepEngineStarted = true;

    let idleStreak = 0;
    let stopped = false;
    const stopAt = Date.now() + 180000;

    const stopEngine = () => {
      stopped = true;
      window.__agentmailSweepStopped = true;
      window.__agentmailSweepEngineStarted = false;
      window.__agentmailNamePoller = null;
      window.__agentmailEmailPoller = null;
      window.__agentmailMetaClickLoopTimer = null;
      try { window.__agentmailMetaObserver?.disconnect(); } catch (error) {}
      window.__agentmailMetaObserver = null;
    };

    const arm = (delay) => {
      if (stopped) return;
      // setTimeout handle kept in the legacy fields so older callers still work.
      window.__agentmailNamePoller = setTimeout(run, delay);
      window.__agentmailEmailPoller = window.__agentmailNamePoller;
    };

    function run() {
      if (stopped) return;
      if (Date.now() > stopAt) { stopEngine(); return; }
      const versionBefore = SMOOTH.domVersion;
      runMetaSweep(false);
      // Adaptive cadence: snappy while the page is moving, gentle while it idles.
      idleStreak = SMOOTH.domVersion > versionBefore + 1 ? 0 : idleStreak + 1;
      // v3.0 LITE: a quiet page is checked less often - less work, less heat, no lag.
      arm(idleStreak > 10 ? 700 : idleStreak > 4 ? 250 : 120);
    }

    if (!window.__agentmailMetaObserver) {
      try {
        window.__agentmailMetaObserver = new MutationObserver(() => {
          markDomDirty();
          idleStreak = 0;
          // React to real DOM changes on the very next frame.
          scheduleCoalesced("agentmailSweepObserver", () => requestMetaSweep(70));
        });
        window.__agentmailMetaObserver.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      } catch (error) {}
    }

    arm(0);
  }

  // v3.3 LUX: the kept account (mail + pass) is shown in the panel on every page,
  // so the user can read it after the account has been created.
  function restoreKeptAccount() {
    if (window.__agentmailKeptAccount || window.__agentmailKeptRestoreStarted) return;
    window.__agentmailKeptRestoreStarted = true;
    try {
      chrome.storage.local.get(["agentmail_account", "agentmail_accounts"], (saved) => {
        try {
          const current = (saved && saved.agentmail_account) || {};
          const list = (saved && Array.isArray(saved.agentmail_accounts)) ? saved.agentmail_accounts : [];
          const pick = current.email ? current : (list.find((item) => item && item.email) || null);
          if (pick && pick.email) {
            window.__agentmailKeptAccount = { email: pick.email, password: pick.password || "" };
            updateEngineHud();
          }
        } catch (error) {}
      });
    } catch (error) {}
  }

  function runMetaAutomation(force = false) {
    restoreKeptAccount();
    startMetaSweepEngine();
    requestMetaSweep(0, force);
  }

  window.__agentmailRunMetaAutomation = runMetaAutomation;
  window.__agentmailClickMetaEmailChoice = clickMetaEmailChoice;
  window.__agentmailAutoFillMetaEmailInput = autoFillMetaEmailInput;
  window.__agentmailAutoClickMetaAllowAllCookies = autoClickMetaAllowAllCookies;
  window.__agentmailAutoClickMetaLoginAnotherAccount = autoClickMetaLoginAnotherAccount;
  window.__agentmailAutoClickMetaProfileContinue = autoClickMetaProfileContinue;
  window.__agentmailAutoClickMetaCreateNewAccount = autoClickMetaCreateNewAccount;
  window.__agentmailAutoFillMetaNamePage = autoFillMetaNamePage;
  window.__agentmailAutoFillMetaDobPage = autoFillMetaDobPage;
  // Small diagnostics surface (used by the automated tests, harmless in normal use).
  window.__agentmailChooseYearStrong = chooseYearStrong;
  window.__agentmailFindDobYearControl = findDobYearControl;
  window.__agentmailDetectPage = detectPage;
  window.__agentmailGetYearFromControl = getYearFromControl;
  window.__agentmailAutoFillMetaPasswordPage = autoFillMetaPasswordPage;
  window.__agentmailAutoClickMetaNotNow = autoClickMetaNotNow;
  window.__agentmailAutoClickMetaFinalReview = autoClickMetaFinalReview;
  window.__agentmailAutoClickMetaAiDetailsConfirm = autoClickMetaAiDetailsConfirm;
  window.__agentmailAutoFillMetaConfirmationCodePage = autoFillMetaConfirmationCodePage;
  window.__agentmailAutoClickMetaAiSignUp = autoClickMetaAiSignUp;
  window.__agentmailAutoClickMetaOopsOk = autoClickMetaOopsOk;
  window.__agentmailAutoHandleMetaCreateAccountBlocked = autoHandleMetaCreateAccountBlocked;
  window.__agentmailAutoClickMetaHumanContinue = autoClickMetaHumanContinue;
  window.__agentmailAutoRefreshMetaSomethingWentWrong = autoRefreshMetaSomethingWentWrong;
  window.__agentmailAutoRefreshMetaCantUseRightNow = autoRefreshMetaCantUseRightNow;
  window.__agentmailAutoRefreshMetaBlankWhite = autoRefreshMetaBlankWhite;
  window.__agentmailAutoRefreshMetaDarkStuck = autoRefreshMetaDarkStuck;
  window.__agentmailAutoClickMetaSelfieContinue = autoClickMetaSelfieContinue;
  window.__agentmailRedirectFromMetaLanguagePage = redirectFromMetaLanguagePage;
  window.__agentmailAutoClickMetaHamburgerAndLogout = autoClickMetaHamburgerAndLogout;

  function widgetHostEl() {
    try { return document.getElementById("agentmail-floating-widget-host"); } catch (error) { return null; }
  }

  // The extension popup tells the page when it is open so the page widget can
  // step aside - one interface at a time, never two.
  function setWidgetVisible(visible) {
    try {
      const host = widgetHostEl();
      if (host) host.style.display = visible ? "" : "none";
    } catch (error) {}
  }

  // Single-UI state machine. The extension popup and the in-page panel must never
  // be visible together, and the orb must ALWAYS come back (it used to be hidden
  // with the whole widget, so a second tap did nothing).
  function markPopupOpen(open) {
    try {
      window.__agentmailPopupOpen = Boolean(open);
      window.__agentmailPopupOpenedAt = open ? Date.now() : 0;
      window.__agentmailPopupLastSeen = open ? Date.now() : 0;

      const host = widgetHostEl();
      const root = host?.shadowRoot || null;
      if (root) {
        const panel = root.querySelector("#panel");
        const wrap = root.querySelector("#wrapBox");
        if (panel) panel.classList.remove("open");
        if (wrap) {
          wrap.classList.toggle("popupOpen", Boolean(open));
          wrap.classList.toggle("panelOpen", Boolean(panel && panel.classList.contains("open")));
        }
      }
      if (host) host.style.display = "";   // the launcher orb always stays usable
      if (open) {
        try { if (typeof window.__agentmailPopupUiReady === "function") window.__agentmailPopupUiReady(); } catch (error) {}
      }
    } catch (error) {}
  }
  window.__agentmailMarkPopupOpen = markPopupOpen;

  function isTopFrame() {
    try { return window.top === window; } catch (error) { return false; }
  }

  function startFloatingMiniMenu() {
    // Only the outermost frame gets the floating widget (no duplicates inside iframes).
    if (!isTopFrame()) return;
    const oldHost = document.getElementById("agentmail-floating-widget-host");
    if (window.__agentmailFloatingMiniMenuStarted && oldHost?.dataset?.version === AGENTMAIL_SCRIPT_VERSION) return;
    window.__agentmailFloatingMiniMenuStarted = true;
    if (oldHost) oldHost.remove();

    const host = document.createElement("div");
    host.id = "agentmail-floating-widget-host";
    host.dataset.version = AGENTMAIL_SCRIPT_VERSION;
    host.style.position = "fixed";
    host.style.zIndex = "2147483647";
    host.style.top = "92px";
    host.style.right = "10px";
    host.style.width = "84px";
    host.style.minHeight = "150px";
    host.style.pointerEvents = "auto";
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });
    const iconUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAMuElEQVR4nG1ZWYslR3o954vIu9fWVV3daqnVLc1oGY0EHoPBLwZjMPjBD/6bfjc2fph5GrAZkNEYWRokRtJIrV6qu7a75xLf8UNkZt1qKbgk3LyZEd/+fedcnj54aGYASAIws/w1XyUB6O9zZ+WvAAxGMwJGAiCDKQIyC2ZBkiQDAUgMipQhP8xAmiQ2lBwAZTHv3guUr3llafiThVuLJLMoICEJAhNlpADdqCo6IThlIAWaTAJoFggnZAJvBOo1ztddabK1XluS2lcNBNQJSjkoMwMoKe8nhwACpu4IkRREwAgRBUhRN0KQzGe8rv7OAz8VK0uWD1P3EpzAzdMSCAqgCBlACBCSBHPBJZCgMfSq9/b4qRC7ntoVeseQNxYF8Jos+b7gkgMECYgC849uBAmjgSBA60Xpd9x11mu2eU2afD47I3VCAJC7p5RyRMvbkE0QlAAKEkRkwcjOvJLiTjS8HtT9/j/rqjbyaCAhwN3JCAJyB+CkSS4YITOTZHAgdDJnLztI7ZjMuujx1ra95X8+p7IThM6ikuhS1kndyieqVRuAuwDSb2wIZuvKEggJnl+MnRf0WkTfRFWXKrce6GSSBIgg2uSXBIk5ZW/KmEDTbnABlGAElJ1AQcm9r343RW83mNz9Ru0dC0miYO2GrcJJcpfkJCUgq5T1zx/A1UB9FIie3841AgBiH0C80fgmlHatshu47k4y0EGKXcK7kCsLxNZLlismCLrELJdTIM3AHOBAA8QcWPG10GnPds9BhNv5f0s+lxtImJhjJahVWyIt7ynBDUbBc/GRSSLdiETkNgK5kCCDdFOC2wx135Xs50shsuM9py4AQgREtHFMurt7al2O1n3ZjIBLcDlTg7a7WO/4+JoXsky3CiaZfwKQs1e9SwXkEgNACoDBbjIwRw8BOWgA3GU3sQAo758lguQS4k8zKwvXt7bsvjbVUzIy9/ZsptS9mcPNgVwAsqclIr/eKeASGbrXIXkbRaSrSc6orojsikUy+253CMkJxRBuYqhtpQAQve0aQoJTuX/KQCbQIG/TjMYuQAEgtfnqIkSk2G7u/tMWkd3X3883m6Zp5yfl4uS5CKmtZQ1o3jpKua/RkLKJlG8ntsWLMCMaIDhCLmG5dXQVqy8QfSHOMwPQxy864xF0dyNoQfJEBuaSQ0n9fhAoJANpIeWuj2zWWt4kL8wCs/XMXXEnRlsRdjs/pJScZIyh9gTJaCEEl8MVY5HAarspBgWAsqwCB1ITLJcMUxJJWiBgFoNAyBXkBigWA6PV7omKciAKil2rZW+noihijHVVJ08kj+/cGQ6Gz54/m+3NQiwibT6fT6bTvb3987Oz4XB47+1Hz398VjfVW4/eqaumCLGqa0+u5IPRyCw0dU2SCNFiqhtDAQ8k5/OrhDqE6ILDoSTd9DIAqOv66vzs6Pju6f0HwzuDv3z3HcnpbFZXXjfN4dHReDwmbe/w4Pmzp7/66JMv9Mcffvju7//xn58//bcPf/3Ru794P8TBixcvnj359qOPf7PerIsYv/ry/04fPHzw5luDweCrP305f3X5+NEHBSbDYnz+4uVX336WUgohSJAn0OLthFeIcbVanp+fHx0exhCGxfDq6nqz3u4f7ldl+cVnnz5+78OTe/eqbXn+6nz/4Dg8ffrNt39m0HQ0/u1//vt2vXr0i19+9of/unx59sEnf/3ZH37//OnTf/inf/n8s//54vNPmyY9fvThaj7//X//6ye/+tuj2dspOQh3Tw4hOJveZQIQ42AwGjdNU5dVVZaT8WQ0HpvFZVpgW6fRtExe13W9raqqurh4hZTund6rt5umqlLj73/w8ZMfv/3qy88ViuevXh49e75c1hyM1qtlEcYfvv+bZ2dPtpv1erkU/ez8uVVTuBTk3k6TcEV3N2M3i0qSQaA2223d1NvNejzdCyFuVosQl6PJZHF9HUMh+Waz2i6Wg8kw1dXl+eXvfvcfbz98/PjdDx7cf/S/f/y0brbL6/l4NKtTdXH+0jwu5hd1tY3DYr1e/dX7f9c4nzz/OjXlKE7lDtDhAGPbQmAA5A2kum4Kb5bXV6EogtKaDIrbclOUoyLE9Waz1yS55pfL68uzu/fuvXh6NpvuhSJ895dvLq+ujo7faOqmruvUSO6ems1is1lvL6+f7e0fpCat16vnyx9Ojx9fr84nw6m7uk4nOa0fsnLlA5k8NXVT1+UQvlxv66pumqapq6oqx+Pp0dGd9fVFWW6LIib3i5cvilgsl4vRcPDOo/cOD49Tuamr7WA4jEWsqk0RgxrMhocfPPqb4/23l8tyudxeL1641m+e/DIwpFTnKQqSkGI/bwEgDUBq6tFwsK7LxWJewqZFGMLKchuWV1UIozgoqzoW8fzF93EwXK2uy/Xck5/9+MNwMBS03paTvaPl4vqlngyLYbVerFcvm21aD6YNbFLYvYPTs4s/X179OB48AJF8GzmULMkN4NHd+2YWguVmtVouqDQbDOZVIzAGOxjG+WqbzKrNhgDNpodH29Xapb3ZwWa73CxXJyf3rq7O5bJgR4d3h8Xw4upFuS3vn7xzvXq1Ws5DiIIP4th9sz+cMky31eW7d9+zwd1Xi++LUEAxd4VWoDaugXK9mVLLxuNoQnq92VAKk+kgRsliCMVgkJuChZhzoa5Lyfen+yC9UVXVo9GA0Nmrl4M4mk73Yhx6lcpyTXK73WzK9eHe8eXyYrN59dH9j5tiXKZVoaJByDjypsnLJaVFVQ+msxBIBCuGg9n+pBhSBLW3NxsNB7PJ5PjoTlGE2Wzy5hv37t85LTebEO3hw8fHx3c36wVDeuvNd+8c3LWg6Xjy8PSt1KwgGTgZTU4OT0OMJ/un+9M3/nT2ddmsgwWnSIGKHZLLRESCxTgZBTN3t8BRMbZc082bzfpis54dHS83l9v1eu/4JG2333/9ZTEcK8TlejW/uqgrB3F9Pb9/Nx3MjrblQo5nT56sNuV4NEZGaYCBovanB+PRNOVR20glqUUdPeTlaDiKsVDHPeRhmQRhddLl/Krx2sLgajn3VMfh8PTB29PZvlPHd+6U82szjIYTguV2A9NoOImimU2GM1DsoI3kOa8HMeZZERIosUUdPbpg3/hp5pJ5IumiC5PxDPLNcnUwPjg4OFwuFmzSjKoEgNvFZjW/mgCj0fjyYr68eGnCwON2NY9hJCWQIAXJE9ASQpLADk5JntwAAd4BxTaeWiXkhGXah5AbYIQneXLSPDHph/lqBUZgtVi8dXp/2Khcr0DUTbOcX1bb9WJ9geSR1kgORwuNBLTwy2gQ3JOnRt5EKCM0tf4BcgchaWYuQcwMSqDgvm3Kg7HoPhkMCzb3jw8K2qIqD2P45tsv90eT6fjINPEyLbfLSaxq91RWKSQRLhkJl1wAYQDgHbDM9bAjrNpizX5qVH+nnddMaqKFg4EVaIxmTVWWNVcLDIesfZGuL2pV9eLEtSq3dyYHoj1fz989PonS3J0yQS4nQGvH2Y5i2EG6hyenpAHez/MdQ0ejSQqiEYIaNVZVI0+X4KAYXM/nxgAohCihKIrZeLpYLcu6NBrk+3uHxnBxdfbr47tVPLzyMhooy5BkB+e3Dsw4iIcnJ2TIHu0faHlPdFCynfN9vVqCYTyewr1F6ARFg9HYwj8DZBTNAGK13jSb5cmd+02MFDKLmDHlLRjqdHmjFFts0jOEJMmMkh0p9FQcKHEwmJKkKLXEEDp1HS0T1sppGYZwPBqVsK28yB2TngST5b65YyBleiv2iEfKTCUyqHCIgAPGjOSSRGOgdbg4t2MwUwhAmxQtk9lOfQI4Gg1hbKG+Z3JPgJOBmYHrcDzQkQ27iEwtsJV3UNos87ciQiYrmb8RbSZzl9Ru8zVBxo538eQ0iOgYD8Ep0UgZ2vhxZYF64NyWxw6uZ5jXw8V2gsrsFDKxkN1geS7uIaW7I8PIlorIqjYkgQBkgiD/mGFahsFCBxRv0HSPmjuqqUOkHfuUqQwHO1tDcPotIjYX4psNW1XzAw5EgJQRLiUhAoIawACPWVHcXi03qNb8zDM4+kM9E8sd98IOZ9NTolkmPdTSz1TH0nYipjY/5YIDdXdmxmUwY+Ylb+UaOq/lWbL7s6Ln725xXOo1kOCiZcuJ8taLBIDkyWhdPWyJIbbSwiUa4636dJtH68VyZP4LoZNmd3mefzNfT7qcqa0fHUFwQ+t4V/BaTrSrRi4JkmdMbUgp7bAcJNRxcr1YzHQ03Dti8Cb924kcbQfKrm6hFm/b29s92xzKSbfDS0WhyX23v9vyy6mlTEAYQ56QHCBc3nJCvQd74pqk5b80OrKkf6w7or/wZpNsHADA/wPT6rPpJoHw9wAAAABJRU5ErkJggg==";
    shadow.innerHTML = `
      <style>
        :host {
          all: initial;
          --mt-ink: #e9edf7;
          --mt-soft: #9aa6c0;
          --mt-line: rgba(255,255,255,.14);
          --mt-line-2: rgba(255,255,255,.08);
          --mt-glass: rgba(14,17,30,.78);
          --mt-a: #8b7cff;
          --mt-b: #2cd4e6;
          --mt-ok: #3ddc97;
        }
        * {
          box-sizing: border-box;
          font-family: Inter, "Segoe UI", ui-sans-serif, system-ui, Arial, sans-serif;
          -webkit-tap-highlight-color: transparent;
        }
        .wrap { position: relative; width: 94px; user-select: none; }

        /* ---------- orb ---------- */
        .orbWrap { position: relative; width: 54px; height: 54px; margin-left: 11px; }
        .ring {
          position: absolute; inset: -3px; border-radius: 20px; pointer-events: none;
          background: linear-gradient(140deg, rgba(139,124,255,.55), rgba(44,212,230,.4));
          filter: blur(6px); opacity: .5;
        }
        .logoBtn {
          position: relative; width: 54px; height: 54px; border: 0; border-radius: 17px;
          padding: 0; cursor: grab; touch-action: none; overflow: hidden;
          background: linear-gradient(160deg, #171b2e, #0d1020 70%);
          box-shadow: 0 8px 22px rgba(6,8,16,.5), inset 0 0 0 1px rgba(255,255,255,.12);
          display: grid; place-items: center;
          transition: transform .16s ease, box-shadow .2s ease;
        }
        .logoBtn:hover { transform: translateY(-1px); }
        .logoBtn:active { cursor: grabbing; transform: scale(.97); }
        .logoBtn[data-state="work"] { box-shadow: 0 10px 26px rgba(44,212,230,.32), inset 0 0 0 1px rgba(44,212,230,.55); }
        .logoBtn[data-state="idle"] .ring { opacity: .22; }
        .logoPic {
          display: block; width: 100%; height: 100%;
          background-image: url("${iconUrl}");
          background-size: cover; background-position: center; background-repeat: no-repeat;
        }

        .stateDot {
          position: absolute; right: -3px; bottom: -3px; width: 15px; height: 15px; border-radius: 50%;
          background: #5d6784; border: 2.5px solid #0b0e18;
        }
        .stateDot[data-state="live"] { background: var(--mt-ok); }
        .stateDot[data-state="work"] { background: var(--mt-b); }
        .countBadge {
          position: absolute; right: -7px; top: -8px; min-width: 24px; height: 24px; padding: 0 6px;
          border-radius: 999px; background: #e9edf7; color: #0d1020;
          font-size: 11px; font-weight: 800; display: grid; place-items: center;
          border: 2px solid #0b0e18; letter-spacing: -.02em;
        }

        /* ---------- mini hud (hidden while the panel is open) ---------- */
        .miniHud {
          margin: 7px 0 0 5px; width: 82px; padding: 6px 9px; border-radius: 13px;
          background: var(--mt-glass); border: 1px solid var(--mt-line-2);
          backdrop-filter: blur(10px);
        }
        .miniHudRow { display: flex; align-items: center; gap: 5px; }
        .miniDot { width: 6px; height: 6px; border-radius: 50%; background: #5d6784; flex: 0 0 auto; }
        .miniDot[data-state="live"] { background: var(--mt-ok); }
        .miniDot[data-state="work"] { background: var(--mt-b); }
        .miniPage {
          font-size: 9px; font-weight: 700; color: #cdd6ea;
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 66px;
        }
        .miniStats { margin-top: 2px; font-size: 8px; color: var(--mt-soft); white-space: nowrap; overflow: hidden; }
        .miniNote { margin-top: 3px; font-size: 8px; letter-spacing: .02em; text-transform: none; color: rgba(163,175,201,.9); white-space: nowrap; overflow: hidden; }
        .hudFoot { margin-top: 8px; padding-top: 7px; border-top: 1px solid var(--mt-line-2); font-size: 9.5px; letter-spacing: .06em; color: rgba(154,166,192,.75); }

        .copyMini {
          margin: 6px 0 0 5px; width: 82px; border: 1px solid var(--mt-line); border-radius: 999px;
          padding: 7px 4px; font-size: 9.5px; font-weight: 800; letter-spacing: .01em;
          color: #e9edf7; background: rgba(255,255,255,.08); cursor: pointer;
          transition: background .15s ease, transform .15s ease;
        }
        .copyMini:hover { background: rgba(255,255,255,.15); }
        .copyMini:active { transform: scale(.96); }

        /* one UI at a time: the panel hides the mini hud + copy button */
        .wrap.panelOpen .miniHud,
        .wrap.panelOpen .copyMini { display: none; }
        /* Popup window open: hide the page-side extras, keep the launcher orb. */
        .wrap.popupOpen .miniHud,
        .wrap.popupOpen .copyMini { display: none; }

        /* ---------- panel ---------- */
        .panel {
          position: absolute; top: -4px; right: 84px; width: min(300px, calc(100vw - 96px));
          padding: 14px; border-radius: 18px; color: var(--mt-ink); display: none;
          background: rgba(13,16,28,.92);
          border: 1px solid var(--mt-line);
          box-shadow: 0 22px 60px rgba(0,0,0,.5);
          backdrop-filter: blur(18px) saturate(1.1);
          max-height: min(78vh, 560px); overflow: auto;
        }
        .panel.open { display: block; }
        .panel::-webkit-scrollbar { width: 6px; }
        .panel::-webkit-scrollbar-thumb { background: rgba(255,255,255,.14); border-radius: 99px; }

        .head { display: flex; align-items: center; gap: 9px; margin-bottom: 12px; }
        .headLogo {
          width: 32px; height: 32px; border-radius: 11px; flex: 0 0 auto;
          background-image: url("${iconUrl}"); background-size: cover; background-position: center;
          box-shadow: inset 0 0 0 1px rgba(255,255,255,.14);
        }
        .title { font-size: 13.5px; font-weight: 800; letter-spacing: -.01em; }
        .sub { color: var(--mt-soft); font-size: 10px; margin-top: 2px; }
        .headState {
          margin-left: auto; font-size: 9px; font-weight: 800; letter-spacing: .09em;
          padding: 4px 8px; border-radius: 999px; color: #cdd6ea;
          background: rgba(255,255,255,.09); border: 1px solid var(--mt-line-2);
        }
        .headState[data-state="live"] { color: #0d1020; background: var(--mt-ok); border-color: transparent; }
        .headState[data-state="work"] { color: #0d1020; background: var(--mt-b); border-color: transparent; }

        .hud {
          margin: 0 0 12px; padding: 10px 11px; border-radius: 13px;
          background: rgba(255,255,255,.045); border: 1px solid var(--mt-line-2);
        }
        .hudTop { display: flex; align-items: center; gap: 7px; }
        .hudDot { width: 7px; height: 7px; border-radius: 50%; background: #5d6784; }
        .hudDot[data-state="live"] { background: var(--mt-ok); }
        .hudDot[data-state="work"] { background: var(--mt-b); }
        .hudLabel { font-size: 9.5px; letter-spacing: .11em; text-transform: uppercase; color: #92a0bc; font-weight: 700; }
        .hudPage { margin-top: 5px; font-size: 13px; font-weight: 800; color: #fff; letter-spacing: -.01em; }
        .hudStats { margin-top: 3px; font-size: 10px; color: #93a0bc; }
        .hudLog { margin-top: 5px; font-size: 9.5px; color: #7684a3; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

        .stat {
          display: flex; justify-content: space-between; align-items: center; padding: 9px 11px;
          border-radius: 13px; background: rgba(255,255,255,.045); border: 1px solid var(--mt-line-2);
          margin-bottom: 11px; font-size: 11.5px; color: #b9c3db;
        }
        .stat strong { color: #fff; font-size: 16px; font-weight: 800; }

        .tabs { display: grid; grid-template-columns: repeat(4, 1fr); gap: 4px; margin-bottom: 11px; padding: 3px; border-radius: 13px; background: rgba(255,255,255,.045); border: 1px solid var(--mt-line-2); }
        .tab { border: 0; border-radius: 10px; padding: 8px 4px; color: #a9b4cd; background: transparent; font-weight: 700; font-size: 10px; cursor: pointer; transition: background .15s ease, color .15s ease; }
        .tab:hover { color: #fff; background: rgba(255,255,255,.06); }
        .tab.active { color: #0d1020; background: #e9edf7; }

        .section { display: none; }
        .section.active { display: block; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 7px; }
        .btn {
          border: 1px solid var(--mt-line-2); border-radius: 11px; padding: 10px 8px; cursor: pointer;
          color: #e9edf7; font-weight: 700; font-size: 11px; background: rgba(255,255,255,.05);
          transition: background .15s ease, transform .15s ease, border-color .15s ease;
        }
        .btn:hover { background: rgba(255,255,255,.1); }
        .btn:active { transform: scale(.97); }
        .btn.primary { background: rgba(139,124,255,.2); border-color: rgba(139,124,255,.4); }
        .btn.primary.active { background: rgba(139,124,255,.34); border-color: rgba(139,124,255,.7); }
        .btn.blue { background: rgba(44,212,230,.16); border-color: rgba(44,212,230,.36); }
        .btn.danger { background: rgba(255,84,112,.14); border-color: rgba(255,84,112,.3); }
        .btn.full, .input.full { grid-column: 1 / -1; }

        .input {
          width: 100%; border: 1px solid var(--mt-line); background: rgba(255,255,255,.05);
          color: #fff; border-radius: 11px; padding: 10px 11px; outline: none; font-size: 11.5px;
        }
        .input:focus { border-color: rgba(139,124,255,.6); }

        .selected, .emailPreview {
          margin: 8px 0 0; padding: 8px 10px; border-radius: 11px;
          background: rgba(255,255,255,.045); border: 1px solid var(--mt-line-2);
          color: #d3dcf0; font-size: 10.5px; word-break: break-all;
        }
        .hint { margin: 9px 0 0; color: var(--mt-soft); font-size: 10.5px; line-height: 1.45; }
        .msg { min-height: 14px; margin-top: 9px; color: var(--mt-soft); font-size: 10.5px; line-height: 1.35; }

        @media (prefers-reduced-motion: reduce) {
          .logoBtn { transition: none !important; }
        }
      </style>
      <div class="wrap" id="wrapBox">
        <div class="orbWrap">
          <div class="ring" aria-hidden="true"></div>
          <button class="logoBtn" id="logoBtn" data-state="idle" title="MasterTeam - click to open">
            <span class="logoPic" aria-hidden="true"></span>
          </button>
          <div class="stateDot" id="engineDot" data-state="idle" aria-hidden="true"></div>
          <div class="countBadge" id="countBadge">0</div>
        </div>

        <div class="miniHud">
          <div class="miniHudRow">
            <span class="miniDot" id="engineMiniDot" data-state="idle" aria-hidden="true"></span>
            <span class="miniPage" id="enginePage">Starting\u2026</span>
          </div>
          <div class="miniStats" id="engineStats">Engine on</div>
          <div class="miniNote" id="engineNote">Flowing smoothly</div>
        </div>

        <button class="copyMini" id="copyMini" type="button">CopyMails</button>

        <div class="panel" id="panel">
          <div class="head">
            <span class="headLogo" aria-hidden="true"></span>
            <div>
              <div class="title">MasterTeam</div>
              <div class="sub">Power Engine v3.6 \u00b7 offline-safe</div>
            </div>
            <span class="headState" id="engineState" data-state="idle">IDLE</span>
          </div>

          <div class="hud">
            <div class="hudTop">
              <span class="hudDot" id="engineHudDot" data-state="idle" aria-hidden="true"></span>
              <span class="hudLabel">Live detection</span>
            </div>
            <div class="hudPage" id="enginePageBig">Starting\u2026</div>
            <div class="hudStats" id="engineStatsBig">0 clicks \u2022 0 fills \u2022 0 scans</div>
            <div class="hudLog" id="engineLog">Booting engine\u2026</div>
            <div class="hudFoot" id="engineFoot">Auto \u00b7 smooth \u00b7 safe</div>
          </div>

          <div class="stat"><span>Total account</span><strong id="panelCount">0</strong></div>

          <div class="tabs">
            <button class="tab active" data-sec="mails" type="button">Mails</button>
            <button class="tab" data-sec="start" type="button">Start</button>
            <button class="tab" data-sec="password" type="button">Pass</button>
            <button class="tab" data-sec="account" type="button">Account</button>
          </div>

          <div class="section active" id="sec-mails">
            <div class="grid">
              <button class="btn primary" id="toxicBtn" type="button">Toxic mail</button>
              <button class="btn primary" id="babyBtn" type="button">Baby mail</button>
            </div>
            <div class="selected" id="selectedProviderMini">Selected: Toxic mail</div>
            <div class="emailPreview" id="emailPreviewMini">Mail: none</div>
          </div>

          <div class="section" id="sec-start">
            <button class="btn blue full" id="startBtnMini" type="button">Start with fresh mail</button>
            <p class="hint">Selected provider diye fresh mail niye Meta flow start korbe.</p>
          </div>

          <div class="section" id="sec-password">
            <div class="grid">
              <input class="input full" id="pwdMini" type="text" autocomplete="off" placeholder="Password" />
              <button class="btn" id="genPwdMini" type="button">Generate</button>
              <button class="btn blue" id="savePwdMini" type="button">Set Password</button>
            </div>
          </div>

          <div class="section" id="sec-account">
            <button class="btn full" id="copyPanelBtn" type="button">CopyMails</button>
            <p class="hint">LOG OUT stage ashle account list-e mail save hobe.</p>
          </div>

          <div class="msg" id="msg">Drag orb to move. Click orb to open the extension popup.</div>
        </div>
      </div>
    `;

    const $s = (selector) => shadow.querySelector(selector);
    const logoBtn = $s("#logoBtn");
    const copyMini = $s("#copyMini");
    const panel = $s("#panel");
    const countBadge = $s("#countBadge");
    const panelCount = $s("#panelCount");
    const msg = $s("#msg");
    const selectedProviderMini = $s("#selectedProviderMini");
    const emailPreviewMini = $s("#emailPreviewMini");
    const pwdMini = $s("#pwdMini");
    const toxicBtn = $s("#toxicBtn");
    const babyBtn = $s("#babyBtn");

    function setMsg(value) {
      msg.textContent = value;
      clearTimeout(setMsg.timer);
      setMsg.timer = setTimeout(() => { msg.textContent = "Drag orb to move. Click orb to open the extension popup."; }, 2600);
    }

    function applySavedPosition() {
      try {
        const saved = JSON.parse(localStorage.getItem("agentmail_float_pos") || "null");
        if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
          host.style.left = `${Math.max(0, Math.min(window.innerWidth - 84, saved.left))}px`;
          host.style.top = `${Math.max(0, Math.min(window.innerHeight - 150, saved.top))}px`;
          host.style.right = "auto";
        }
      } catch (error) {}
    }

    function providerLabelMini(provider) {
      return provider === "baby" ? "Baby mail" : "Toxic mail";
    }


    function updateSnapshot() {
      chrome.storage.local.get(["agentmail_accounts", "agentmail_account", "agentmail_mail_provider"], (saved) => {
        const accounts = Array.isArray(saved.agentmail_accounts) ? saved.agentmail_accounts : [];
        const account = saved.agentmail_account || {};
        const provider = saved.agentmail_mail_provider || account.mail_provider || "toxic";
        const count = accounts.filter((item) => item && item.email).length;
        countBadge.textContent = String(count);
        panelCount.textContent = String(count);
        selectedProviderMini.textContent = `Selected: ${providerLabelMini(provider)}`;
        emailPreviewMini.textContent = account.email ? `Mail: ${account.email}` : "Mail: none";
        toxicBtn.classList.toggle("active", provider !== "baby");
        babyBtn.classList.toggle("active", provider === "baby");
        if (!pwdMini.matches(":focus")) pwdMini.value = account.password || "FAHAD@10";
      });
    }

    function copyTextFromPage(text) {
      if (!text) return Promise.resolve(false);
      if (navigator.clipboard?.writeText) {
        return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
      }
      return new Promise((resolve) => {
        try {
          const area = document.createElement("textarea");
          area.value = text;
          area.style.position = "fixed";
          area.style.left = "-9999px";
          document.body.appendChild(area);
          area.focus();
          area.select();
          const ok = document.execCommand("copy");
          area.remove();
          resolve(ok);
        } catch (error) {
          resolve(false);
        }
      });
    }

    async function copyAllMails() {
      chrome.storage.local.get(["agentmail_accounts"], async (saved) => {
        const accounts = Array.isArray(saved.agentmail_accounts) ? saved.agentmail_accounts : [];
        const usable = accounts.filter((item) => item && item.email);
        const mails = usable.map((item) => `${item.email} / ${item.password || ""}`.trim()).filter(Boolean).join("\n");
        if (!mails) {
          setMsg("No saved mails yet.");
          return;
        }
        const ok = await copyTextFromPage(mails);
        setMsg(ok ? `Copied ${usable.length} account(s) - mail + pass.` : "Copy failed.");
      });
    }

    function switchSection(name) {
      shadow.querySelectorAll(".tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.sec === name));
      shadow.querySelectorAll(".section").forEach((sec) => sec.classList.toggle("active", sec.id === `sec-${name}`));
    }

    function syncPanelUi() {
      // Single-UI rule: while the in-page panel is open, the mini HUD + copy
      // button hide so only ONE interface is visible at a time.
      const wrap = $s("#wrapBox");
      if (wrap) wrap.classList.toggle("panelOpen", panel.classList.contains("open"));
    }

    function openMainMenu() {
      // Clicking the orb shows the extension popup window ONLY - never two UIs.
      // Every tap must do something, even if the browser hides/ignores popups.
      if (panel.classList.contains("open")) {
        panel.classList.remove("open");
        syncPanelUi();
        return;
      }
      const now = Date.now();
      if (now - (window.__agentmailOrbClickAt || 0) < 320) return;   // double-tap guard
      window.__agentmailOrbClickAt = now;
      updateSnapshot();

      let settled = false;
      const showPanel = () => {
        if (settled) return;
        settled = true;
        window.__agentmailPopupUiReady = null;
        panel.classList.add("open");
        syncPanelUi();
      };
      // The moment the real popup window announces itself we stop the fallback -
      // and if it appears late, markPopupOpen() closes the panel again (one UI).
      window.__agentmailPopupUiReady = () => { settled = true; };

      try {
        chrome.runtime.sendMessage({ type: "AGENTMAIL_OPEN_EXTENSION_POPUP" }, (response) => {
          const failed = Boolean(chrome.runtime.lastError) || !response || !response.ok;
          if (failed) showPanel();
        });
      } catch (error) {
        showPanel();
      }
      // Browsers that swallow openPopup() without an error: still show something.
      setTimeout(showPanel, 700);
    }


    function createFresh(provider) {
      switchSection("mails");
      const label = providerLabelMini(provider);
      setMsg(`Creating ${label}...`);
      chrome.runtime.sendMessage({ type: "AGENTMAIL_SET_MAIL_PROVIDER", provider }, () => {
        chrome.runtime.lastError;
        chrome.runtime.sendMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: true, provider }, (response) => {
          if (chrome.runtime.lastError || !response?.ok) {
            setMsg(response?.error || chrome.runtime.lastError?.message || `${label} failed.`);
            updateSnapshot();
            return;
          }
          setMsg(`${label}: ${response.email}`);
          updateSnapshot();
          autoFillMetaEmailInput?.();
        });
      });
    }

    function startFlow() {
      setMsg("Starting...");
      chrome.storage.local.get(["agentmail_mail_provider"], (saved) => {
        const provider = saved.agentmail_mail_provider || "toxic";
        chrome.runtime.sendMessage({ type: "OPEN_START", prepareEmail: true, forceNewEmail: true, provider }, (response) => {
          if (chrome.runtime.lastError || !response?.ok) {
            setMsg(response?.error || chrome.runtime.lastError?.message || "Start failed.");
            return;
          }
          setMsg(response.email ? `Started: ${response.email}` : "Started.");
          updateSnapshot();
        });
      });
    }

    function randomMiniPassword() {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789@#$";
      let out = "";
      for (let i = 0; i < 10; i += 1) out += chars[Math.floor(Math.random() * chars.length)];
      return `${out}@10`;
    }

    function saveMiniPassword() {
      const password = (pwdMini.value || "").trim() || "FAHAD@10";
      chrome.storage.local.get(["agentmail_account"], (saved) => {
        const account = { ...(saved.agentmail_account || {}), password };
        chrome.storage.local.set({ agentmail_account: account }, () => {
          setMsg("Password set.");
          updateSnapshot();
          try { fill("password", password); } catch (error) {}
          autoFillMetaPasswordPage?.(true);
        });
      });
    }

    let drag = null;
    // Finger taps wobble; 4px used to count as a drag and silently swallow the tap.
    const DRAG_SLOP = 9;

    const beginDrag = (pointerId, clientX, clientY) => {
      if (String(pointerId) !== "mouse") window.__agentmailOrbTouchAt = Date.now();
      drag = {
        pointerId,
        startX: clientX,
        startY: clientY,
        left: host.getBoundingClientRect().left,
        top: host.getBoundingClientRect().top,
        moved: false
      };
    };

    const endDrag = (pointerId, clientX, clientY, allowOpen) => {
      if (!drag) return false;
      if (pointerId != null && drag.pointerId !== pointerId) return false;
      const wasMoved = drag.moved;
      drag = null;
      if (!allowOpen || wasMoved) return false;
      openMainMenu();
      return true;
    };

    logoBtn.addEventListener("pointerdown", (event) => {
      beginDrag(event.pointerId, event.clientX, event.clientY);
      try { logoBtn.setPointerCapture?.(event.pointerId); } catch (error) {}
      try { event.preventDefault(); } catch (error) {}
    });

    logoBtn.addEventListener("pointercancel", (event) => { endDrag(event.pointerId, event.clientX, event.clientY, false); });
    logoBtn.addEventListener("lostpointercapture", () => { drag = null; });

    logoBtn.addEventListener("pointermove", (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > DRAG_SLOP) drag.moved = true;
      const left = Math.max(0, Math.min(window.innerWidth - 84, drag.left + dx));
      const top = Math.max(0, Math.min(window.innerHeight - 150, drag.top + dy));
      host.style.left = `${left}px`;
      host.style.top = `${top}px`;
      host.style.right = "auto";
    });

    logoBtn.addEventListener("pointerup", (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      try { logoBtn.releasePointerCapture?.(event.pointerId); } catch (error) {}
      const rect = host.getBoundingClientRect();
      try { localStorage.setItem("agentmail_float_pos", JSON.stringify({ left: rect.left, top: rect.top })); } catch (error) {}
      endDrag(event.pointerId, event.clientX, event.clientY, true);
    });

    // Safety net for the tap: whatever swallowed the pointer sequence (popup stole
    // focus, scroll gesture, browser quirk), a plain click still opens the menu -
    // but never twice for the same tap.
    logoBtn.addEventListener("click", (event) => {
      try { event.stopPropagation(); } catch (error) {}
      const last = window.__agentmailOrbClickAt || 0;
      if (Date.now() - last < 650) return;
      if (drag) drag = null;
      openMainMenu();
    });

    // Browsers without PointerEvent (some Android WebViews): bind touch + mouse.
    if (!window.PointerEvent) {
      let touchId = null;
      logoBtn.addEventListener("touchstart", (event) => {
        const touch = event.touches && event.touches[0];
        if (!touch) return;
        touchId = touch.identifier;
        beginDrag(touchId, touch.clientX, touch.clientY);
      }, { passive: true });
      logoBtn.addEventListener("touchmove", (event) => {
        if (!drag || touchId == null) return;
        const touch = [...(event.touches || [])].find((t) => t.identifier === touchId) || event.touches[0];
        if (!touch) return;
        const dx = touch.clientX - drag.startX;
        const dy = touch.clientY - drag.startY;
        if (Math.abs(dx) + Math.abs(dy) > DRAG_SLOP) drag.moved = true;
      }, { passive: true });
      logoBtn.addEventListener("touchend", (event) => {
        const touch = (event.changedTouches && event.changedTouches[0]) || null;
        endDrag(touchId, touch ? touch.clientX : null, touch ? touch.clientY : null, true);
        touchId = null;
      });
      logoBtn.addEventListener("touchcancel", () => { endDrag(touchId, null, null, false); touchId = null; });
      logoBtn.addEventListener("mousedown", (event) => {
        if (Date.now() - (window.__agentmailOrbTouchAt || 0) < 800) return;
        beginDrag("mouse", event.clientX, event.clientY);
      });
      logoBtn.addEventListener("mouseup", (event) => { endDrag("mouse", event.clientX, event.clientY, true); });
    }

    copyMini.addEventListener("click", (event) => { event.stopPropagation(); copyAllMails(); });
    $s("#copyPanelBtn").addEventListener("click", copyAllMails);
    toxicBtn.addEventListener("click", () => createFresh("toxic"));
    babyBtn.addEventListener("click", () => createFresh("baby"));
    $s("#startBtnMini").addEventListener("click", startFlow);
    $s("#genPwdMini").addEventListener("click", () => { pwdMini.value = randomMiniPassword(); pwdMini.focus(); });
    $s("#savePwdMini").addEventListener("click", saveMiniPassword);
    shadow.querySelectorAll(".tab").forEach((tab) => tab.addEventListener("click", () => switchSection(tab.dataset.sec)));

    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && (changes.agentmail_accounts || changes.agentmail_account || changes.agentmail_mail_provider)) updateSnapshot();
      });
    } catch (error) {}

    applySavedPosition();
    updateSnapshot();
    setInterval(updateSnapshot, 30000);
  }

  // ------------------------------------------------------------------
  // v2.7 FLASH WATCH: the moment a year list is on screen - opened by the engine
  // OR by the user's own finger - 1999 is clicked straight away: one plain click
  // (plus one instant jump when 1999 is not rendered). Never a drag, never a
  // long wait, and never while a bigger chain is already working the page.
  // ------------------------------------------------------------------
  // ---------------------------------------------------------------
  // v2.9 SUN SPEED - the year follows your finger.
  //
  // The reaction starts on TOUCH DOWN (or mouse down), not on the click and not
  // on the next engine tick. While your finger is on the Year box a 5 ms burst -
  // plus the DOM observer, which fires the instant the list appears - looks for
  // the list and taps the 1999 row with no artificial pause at all.
  // ---------------------------------------------------------------
  let sunBurstTimer = 0;

  function sunArmed() {
    try { return Boolean(window.__agentmailSunArmedAt) && Date.now() - window.__agentmailSunArmedAt < 900; }
    catch (error) { return false; }
  }

  function sunDone(armedAt) {
    const ms = Math.max(0, Date.now() - armedAt);
    window.__agentmailSunLastMs = ms;
    window.__agentmailSunArmedAt = 0;
    if (sunBurstTimer) { clearInterval(sunBurstTimer); sunBurstTimer = 0; }
    if (ms > 0 && ms < 1500) powerLog("SUN: 1999 on screen " + ms + " ms after your tap");
    try { updateEngineHud(true); } catch (error) {}
  }

  // PREWARM (v2.9 SUN): find the 1999 row while the page is idle - long before the
  // finger touches the box. The click then only has to tap a row we already know,
  // so the whole pick costs a few milliseconds instead of a full scan.
  let sunPrewarmAt = 0;

  function sunPrewarm() {
    try {
      const now = Date.now();
      if (now - sunPrewarmAt < 600) return;
      sunPrewarmAt = now;
      const rows = [];
      for (const el of document.querySelectorAll("button, [role='option'], [role='button'], li, div, span")) {
        if (el.childElementCount > 1) continue;
        const text = normalizeText(el.textContent || "");
        if (!/^\d{4}$/.test(text)) continue;
        const year = Number(text);
        if (year < 1900 || year > 2100) continue;
        rows.push({ el, year });
      }
      if (rows.length < 3) { window.__agentmailSunPrewarm = null; return; }
      // the container that holds (nearly) all of them, counted up the tree
      const counts = new Map();
      for (const row of rows) {
        let node = row.el.parentElement;
        for (let depth = 0; node && depth < 6; node = node.parentElement, depth += 1) {
          counts.set(node, (counts.get(node) || 0) + 1);
        }
      }
      let best = null;
      let bestCount = 0;
      counts.forEach((count, node) => {
        if (count > bestCount) { bestCount = count; best = node; }
      });
      if (!best || bestCount < 3) { window.__agentmailSunPrewarm = null; return; }
      const years = rows.filter((row) => best.contains(row.el)).map((row) => row.year).sort((a, b) => b - a);
      // a real list is a run of consecutive years - anything else is a false match
      let consecutive = false;
      for (let i = 0; i + 2 < years.length; i += 1) {
        if (years[i] - years[i + 1] === 1 && years[i + 1] - years[i + 2] === 1) { consecutive = true; break; }
      }
      if (!consecutive) { window.__agentmailSunPrewarm = null; return; }
      const exact = rows
        .filter((row) => row.year === 1999 && best.contains(row.el))
        .map((row) => {
          const rect = getRect(row.el);
          return { el: row.el, depth: (() => { let d = 0; for (let n = row.el; n && n !== best; n = n.parentElement) d += 1; return d; })() };
        })
        .sort((a, b) => a.depth - b.depth);
      window.__agentmailSunPrewarm = exact.length ? { container: best, row1999: exact[0].el } : null;
    } catch (error) {
      window.__agentmailSunPrewarm = null;
    }
  }

  function sunAct() {
    try {
      const armedAt = window.__agentmailSunArmedAt || 0;
      if (!armedAt) return;
      if (yearUiShows(1999)) { sunDone(armedAt); return; }
      if (window.__agentmailSunBusy || window.__agentmailSunPrewarmBusy) return;
      // ---- the prewarmed shortcut: tap the row we already know -----------------
      const pre = window.__agentmailSunPrewarm;
      if (pre && pre.row1999 && pre.row1999.isConnected !== false &&
          !computeHasHiddenAncestor(pre.row1999) && isVisible(pre.row1999)) {
        window.__agentmailSunPrewarmBusy = true;
        (async () => {
          let ok = false;
          try {
            ok = await tapRowElement(pre.row1999, 1999, true);
            if (ok) ok = await waitFor(() => yearUiShows(1999), { timeout: 12, poll: 2 });
          } catch (error) {} finally { window.__agentmailSunPrewarmBusy = false; }
          if (ok) sunDone(armedAt);
          else window.__agentmailSunPrewarm = null;   // a wrong guess: fall back to the scan
        })();
        return;
      }
      const found = yearPickerContainer();
      if (!found || !found.list) return;
      if (window.__agentmailFlashPickDoneFor === found.list) return;   // already being worked
      window.__agentmailFlashPickDoneFor = found.list;
      window.__agentmailSunBusy = true;
      (async () => {
        let ok = false;
        try {
          ok = await ultraTapRow(found, 1999, 12, true);
          if (!ok && (await ultraJumpToYear(found, 1999, true))) {
            const again = yearPickerContainer() || found;
            ok = await ultraTapRow(again, 1999, 12, true);
          }
        } catch (error) {} finally { window.__agentmailSunBusy = false; }
        if (ok) sunDone(armedAt);
        else window.__agentmailFlashPickDoneFor = 0;    // let the next tick have another go
      })();
    } catch (error) {}
  }

  function startSunBurst() {
    if (sunBurstTimer) return;
    sunBurstTimer = setInterval(() => {
      if (!sunArmed()) { clearInterval(sunBurstTimer); sunBurstTimer = 0; return; }
      sunAct();
    }, 5);
    sunAct();
  }

  // Only a REAL finger arms this: synthetic events (ours) have isTrusted false,
  // so the engine can never arm itself and double-press anything.
  function startSunSpeedWatch() {
    if (window.__agentmailSunWatchStarted) return;
    window.__agentmailSunWatchStarted = true;
    const onDown = (event) => {
      try {
        if (!event || event.isTrusted !== true) return;
        if (yearUiShows(1999)) return;
        if (!isMetaAuthPage() || !isMetaDobPage()) return;
        const target = event.target;
        const box = dobYearVisibleTrigger() || yearBoxFromLabel();
        if (!box || !target) return;
        if (!(target === box || box.contains(target) || (target.contains && target.contains(box)))) return;
        window.__agentmailSunArmedAt = Date.now();   // the clock starts at TOUCH DOWN
        startSunBurst();
      } catch (error) {}
    };
    ["pointerdown", "mousedown", "touchstart"].forEach((type) => {
      try { document.addEventListener(type, onDown, true); } catch (error) {}
    });
  }

  function startFlashPickerWatch() {
    if (window.__agentmailFlashWatchStarted) return;
    window.__agentmailFlashWatchStarted = true;
    const act = () => {
      try {
        // SUN SPEED first: while a real finger is on the Year box nothing else -
        // no tick, no heart-beat, no running chain - may delay the reaction.
        if (sunArmed()) { sunAct(); return; }
        if (window.__agentmailFlashPickBusy) return;
        // Only stand aside while a running chain is actually working the page
        // (its heart-beat is fresh). A chain that is just sleeping must not stop
        // the instant reaction to the user's own click.
        if (window.__agentmailDobAutomationRunning && Date.now() - (window.__agentmailChainBeat || 0) < 250) return;
        if (!window.__agentmailDobWanted) return;                  // never armed: stay free
        if (!yearUiShows(1999)) sunPrewarm();                       // keep the 1999 row known
        if (Date.now() - (window.__agentmailDobWantedAt || 0) > 9000) { window.__agentmailDobWanted = 0; return; }
        if (yearUiShows(1999)) return;
        const found = yearPickerContainer();                       // memoised - cheap
        if (!found || !found.list) return;
        if (window.__agentmailFlashPickDoneFor === found.list) return;
        window.__agentmailFlashPickDoneFor = found.list;
        window.__agentmailFlashPickBusy = true;
        (async () => {
          try {
            if (await ultraTapRow(found, 1999, 30)) return;
            if (await ultraJumpToYear(found, 1999)) {
              const again = yearPickerContainer() || found;
              if (await ultraTapRow(again, 1999, 30)) return;
            }
            const native = yearNativeSelect();
            if (native && Date.now() >= ultraNativeDeadUntil) {
              ultraWriteNativeYear(native, 1999);
              if (await ultraYearConfirmed(native, 1999, 40)) return;
              ultraWriteNativeYear(native, 1999, true);
              await ultraYearConfirmed(native, 1999, 45);
            }
          } catch (error) {} finally {
            window.__agentmailFlashPickBusy = false;
          }
        })();
      } catch (error) {}
    };
    try {
      const observer = new MutationObserver(() => act());   // the list IS the event
      observer.observe(document.documentElement || document.body, {
        childList: true, subtree: true,
        attributes: true, attributeFilter: ["style", "class", "hidden", "aria-hidden", "aria-expanded"]
      });
      window.__agentmailFlashObserver = observer;
    } catch (error) {}
    // v3.0 LITE: a 40 ms heartbeat only while the birth-year step is unfinished or
    // a finger is on the box; otherwise the observer does the waking and the timer
    // drops to one gentle beat every 600 ms (no work, no redraw).
    const tick = () => {
      const hot = Boolean(window.__agentmailDobWanted) || sunArmed() || Boolean(window.__agentmailSunArmedAt);
      try { act(); } catch (error) {}
      setTimeout(tick, hot ? 40 : 600);
    };
    setTimeout(tick, 60);
  }

  function startAuthStuckWatchdog() {
    if (window.__agentmailAuthStuckWatchdogStarted) return;
    window.__agentmailAuthStuckWatchdogStarted = true;
    // Gentle safety net: only works when the main engine has stopped, so the
    // page never runs three copies of the same checks.
    setInterval(() => {
      try {
        if (!isMetaAuthPage()) return;
        if (window.__agentmailSweepEngineStarted) return;
        runMetaSweep(false);
      } catch (error) {}
    }, 1500);
  }

  if (isTopFrame()) {
    startFloatingMiniMenu();
    updateEngineHud(true);
    setTimeout(() => updateEngineHud(true), 300);
    // Safety net: the popup window heartbeats every second. If the beats stop
    // (closed, crashed, or a lost close-event) the page side resets within ~4s.
    setInterval(() => {
      try {
        if (!window.__agentmailPopupOpen) return;
        const seen = window.__agentmailPopupLastSeen || window.__agentmailPopupOpenedAt || 0;
        if (Date.now() - seen > 4000) markPopupOpen(false);
      } catch (error) {}
    }, 1200);
  }
  startMetaAiSignupWatcher();
  installSparseHamburgerStuckWatch();
  startAccountsCenterRedirectWatcher();
  installSocialChoiceClickBlocker();
  installEditEmailClickBlocker();
  installConfirmationContinueClickBlocker();
  startAuthStuckWatchdog();
  startFlashPickerWatch();
  startSunSpeedWatch();
  setTimeout(() => { try { sunPrewarm(); } catch (error) {} }, 900);

  runMetaAutomation();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message !== "object") return false;

    if (message.type === "AGENTMAIL_POPUP_OPEN") {
      markPopupOpen(true);
      sendResponse({ ok: true });
      return false;
    }

    if (message.type === "AGENTMAIL_POPUP_HEARTBEAT") {
      window.__agentmailPopupLastSeen = Date.now();
      if (!window.__agentmailPopupOpen) markPopupOpen(true);
      sendResponse({ ok: true });
      return false;
    }

    if (message.type === "AGENTMAIL_POPUP_CLOSE") {
      markPopupOpen(false);
      sendResponse({ ok: true });
      return false;
    }

    if (message.type === "AGENTMAIL_POWER_STATS") {
      try { sendResponse(powerStats()); } catch (error) { sendResponse({ ok: false, error: String(error && error.message || error) }); }
      return false;
    }

    if (message.type === "AGENTMAIL_POWER_PING") {
      try { sendResponse({ ok: true, version: AGENTMAIL_SCRIPT_VERSION }); } catch (error) { sendResponse({ ok: false }); }
      return false;
    }

    if (message.type === "AGENTMAIL_FILL") {
      const result = fill(message.kind, message.value);
      sendResponse(result);
      return false;
    }

    if (message.type === "AGENTMAIL_CLICK_META_EMAIL_CHOICE" || message.type === "AGENTMAIL_RUN_META_AUTOMATION") {
      runMetaAutomation(Boolean(message.force));
      sendResponse({ ok: true, message: "Meta automation triggered" });
      return false;
    }

    if (message.type === "AGENTMAIL_REDIRECT_ACCOUNTS_CENTER") {
      Promise.resolve(redirectAccountsCenterToAuthStart(Boolean(message.force))).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_EMAIL") {
      autoFillMetaEmailInput().then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_PROFILE_CONTINUE") {
      autoClickMetaProfileContinue(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_ALLOW_ALL_COOKIES") {
      autoClickMetaAllowAllCookies(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_LOGIN_ANOTHER_ACCOUNT") {
      autoClickMetaLoginAnotherAccount(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_CREATE_NEW_ACCOUNT") {
      autoClickMetaCreateNewAccount(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_NAME") {
      autoFillMetaNamePage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_DOB") {
      autoFillMetaDobPage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_PASSWORD") {
      autoFillMetaPasswordPage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_NOT_NOW") {
      autoClickMetaNotNow(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_FINAL_REVIEW") {
      autoClickMetaFinalReview(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_AI_DETAILS_CONFIRM") {
      autoClickMetaAiDetailsConfirm(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_AI_SIGN_UP") {
      autoClickMetaAiSignUp(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_CONFIRMATION_CODE") {
      autoFillMetaConfirmationCodePage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_OOPS_OK") {
      autoClickMetaOopsOk(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_HANDLE_CREATE_BLOCKED") {
      autoHandleMetaCreateAccountBlocked(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_HUMAN_CONTINUE") {
      autoClickMetaHumanContinue(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_SOMETHING_WENT_WRONG") {
      autoRefreshMetaSomethingWentWrong(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_CANT_USE_RIGHT_NOW") {
      autoRefreshMetaCantUseRightNow(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_BLANK_WHITE") {
      autoRefreshMetaBlankWhite(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_DARK_STUCK") {
      autoRefreshMetaDarkStuck(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_SELFIE_CONTINUE") {
      autoClickMetaSelfieContinue(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_HAMBURGER_LOGOUT") {
      Promise.resolve(autoClickMetaHamburgerAndLogout(Boolean(message.force))).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REDIRECT_META_LANGUAGE_PAGE") {
      Promise.resolve(redirectFromMetaLanguagePage(Boolean(message.force))).then(sendResponse);
      return true;
    }

    return false;
  });
})();
