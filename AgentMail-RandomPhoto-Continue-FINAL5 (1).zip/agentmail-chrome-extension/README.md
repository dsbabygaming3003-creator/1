# MasterTeam Mail Menu Chrome Extension

Dynamic Chrome extension menu with:

- **Mails** → **Toxic mail** / **Baby mail** provider selection.
- **Start** opens the updated Meta OIDC/auth link with a fresh selected-provider mail.
- **Set Password** saves/fills password.
- **Account** stores successful logout-stage mails only, with Copy mails and Download `.txt`.
- Floating mini logo/menu on `auth.meta.com`, draggable, with total account count and CopyMails.
- Stuck/error handling including blank page refresh, dark stuck refresh, full error refresh, and **You can't use Meta right now** page refresh once.

## Install / Load in Chrome

1. Unzip `agentmail-chrome-extension.zip`.
2. Open Chrome and go to `chrome://extensions/`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the `agentmail-chrome-extension` folder.
6. Close old `auth.meta.com` tabs and start fresh.

## Note

This version has no login/license system. API settings UI is removed from Account panel; built-in provider defaults are used.

## API config

Edit `backend_api.js` if you need to add/change Toxic/Baby API keys. The popup Account panel does not show API settings.
