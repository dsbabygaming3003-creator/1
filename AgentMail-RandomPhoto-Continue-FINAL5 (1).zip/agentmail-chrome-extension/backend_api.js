// Master Team backend/API config file.
// Owner note: if you need to change API, edit this file only.
// Put new plain keys in toxicApiKey / babyApiKey. If blank, built-in encoded defaults are used.
// Do not show this file to users if you add your own private keys.
(function(root) {
  root.MASTER_TEAM_BACKEND_API = {
    toxicApiKey: "",
    toxicApiKeyParts: ["YW1fdXNfMDRi", "NWNmOWZmNGNh", "N2U5NTY4MDc2", "ZDcyNjI2Zjky", "ZTg4YTllMWUx", "NmVkZDk1OTM4", "NGY4OTQ0NzNh", "MWUzYTdiYw=="],
    toxicBaseUrl: "https://api.agentmail.to/v0/",
    babyApiKey: "",
    babyApiKeyParts: ["YmtfdXMxXzNy", "QjV5ajB3MGwy", "SkFQcE9DWWVC", "cEw4MndQbHd3"],
    babyBaseUrl: "https://us1.platform.bird.com/v1/"
  };
})(typeof self !== "undefined" ? self : globalThis);
