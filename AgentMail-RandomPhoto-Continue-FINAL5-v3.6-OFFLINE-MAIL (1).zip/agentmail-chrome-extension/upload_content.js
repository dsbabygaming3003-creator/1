// Butter-smooth random photo picker (v1.9.0)
// - single instance per page
// - one frame-coalesced scan instead of one scan per DOM mutation
// - observer released as soon as the photo is attached
(() => {
  "use strict";

  const VERSION = "1.9.0";
  if (window.__agentmailUploadScriptVersion === VERSION) return;
  window.__agentmailUploadScriptVersion = VERSION;

  const IMAGES = [
    chrome.runtime.getURL("photo1.jpg"),
    chrome.runtime.getURL("photo2.jpg"),
    chrome.runtime.getURL("photo3.jpg"),
    chrome.runtime.getURL("photo4.jpg")
  ];

  let done = false;
  let queued = false;
  let observer = null;
  let stopTimer = 0;

  async function chooseRandomFile() {
    const url = IMAGES[Math.floor(Math.random() * IMAGES.length)];
    const response = await fetch(url);
    const blob = await response.blob();
    return new File([blob], "random-test-photo.jpg", {
      type: blob.type || "image/jpeg",
      lastModified: Date.now()
    });
  }

  async function fillInput(input) {
    if (done || !input || input.type !== "file") return;
    if (input.files && input.files.length) return;

    try {
      const file = await chooseRandomFile();
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;

      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      done = true;
      releaseWatcher();
      console.log("[Random Auto Upload] Image attached successfully.");
    } catch (e) {
      console.error("[Random Auto Upload]", e);
    }
  }

  function scan() {
    if (done) return;
    document.querySelectorAll('input[type="file"]').forEach(fillInput);
  }

  function releaseWatcher() {
    try { observer?.disconnect(); } catch (error) {}
    observer = null;
    queued = false;
    if (stopTimer) { clearTimeout(stopTimer); stopTimer = 0; }
  }

  function scheduleScan() {
    if (done || queued) return;
    queued = true;
    const run = () => {
      queued = false;
      scan();
    };
    // One scan per frame at most (was one full scan per mutation).
    if (typeof requestAnimationFrame === "function" && document.visibilityState === "visible") {
      requestAnimationFrame(run);
    } else {
      setTimeout(run, 16);
    }
  }

  scan();

  try {
    observer = new MutationObserver(scheduleScan);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    // Safety: let go of the observer after 3 minutes no matter what.
    stopTimer = setTimeout(releaseWatcher, 180000);
  } catch (error) {
    observer = null;
  }
})();
