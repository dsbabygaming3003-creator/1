const $ = (id) => document.getElementById(id);
let tabId = null;
let running = true;
let polling = null;

function fmt(ms) {
  return ms + ' ms (' + Math.round(1000 / ms) + ' clicks/s)';
}

function paintToggle() {
  const b = $('toggle');
  b.textContent = running ? 'STOP' : 'START';
  b.classList.toggle('off', !running);
  $('dot').style.background = running ? '#22c55e' : '#da3633';
}

async function poll() {
  if (tabId == null) return;
  try {
    const res = await chrome.tabs.sendMessage(tabId, { type: 'status' });
    if (res) {
      $('found').textContent = res.found ? 'detected ✓' : 'not on page';
      $('inject').style.display = 'none';
    }
  } catch (e) {
    $('found').textContent = 'not loaded';
    $('inject').style.display = 'block';
  }
}

async function init() {
  const stored = await chrome.storage.local.get({ ac_running: true, ac_interval: 50 });
  running = !!stored.ac_running;
  $('speed').value = stored.ac_interval;
  $('speedLabel').textContent = fmt(stored.ac_interval);
  paintToggle();

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab && tab.id;
  const onMeta = tab && tab.url && tab.url.startsWith('https://auth.meta.com');
  if (!onMeta) {
    $('found').textContent = 'n/a';
    $('hint').textContent = 'Open an auth.meta.com page — the clicker starts automatically there.';
  } else {
    poll();
    polling = setInterval(poll, 700);
  }

  $('toggle').onclick = async () => {
    running = !running;
    await chrome.storage.local.set({ ac_running: running });
    paintToggle();
  };

  $('speed').oninput = (e) => {
    const v = parseInt(e.target.value, 10);
    $('speedLabel').textContent = fmt(v);
    chrome.storage.local.set({ ac_interval: v });
  };

  $('inject').onclick = async () => {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tabId }, files: ['content.js'] });
      $('inject').style.display = 'none';
      if (!polling) polling = setInterval(poll, 700);
      poll();
    } catch (err) {
      $('hint').textContent = 'Could not inject: ' + err.message;
    }
  };
}

init();
