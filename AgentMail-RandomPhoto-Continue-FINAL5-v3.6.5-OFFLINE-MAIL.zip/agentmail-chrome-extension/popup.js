function decodePackedSecret(parts) {
  try { return atob(parts.join("")); } catch (error) { return ""; }
}
function getMasterTeamApiConfig() { return window.MASTER_TEAM_BACKEND_API || {}; }
function secretFromConfig(plain, parts) {
  if (plain && String(plain).trim()) return String(plain).trim();
  return decodePackedSecret(parts || []);
}
const DEFAULT_API_KEY = secretFromConfig(getMasterTeamApiConfig().toxicApiKey, getMasterTeamApiConfig().toxicApiKeyParts);
const DEFAULT_BASE_URL = getMasterTeamApiConfig().toxicBaseUrl || "https://api.agentmail.to/v0/";
const DEFAULT_BIRD_API_KEY = secretFromConfig(getMasterTeamApiConfig().babyApiKey, getMasterTeamApiConfig().babyApiKeyParts);
const DEFAULT_BIRD_BASE_URL = getMasterTeamApiConfig().babyBaseUrl || "https://us1.platform.bird.com/v1/";
const DEFAULT_PASSWORD = "FAHAD@10";
const START_URL = "https://auth.meta.com/?waterfall_id=43439df0-2e2d-499a-a067-fd148cbfc329&redirect_uri=https%3A%2F%2Fauth.meta.com%2Foidc%2F%3Fapp_id%3D1522763855472543%26redirect_uri%3Dhttps%253A%252F%252Fauth.meta.ai%252Fecto%26response_type%3Dcode%26scope%3Dopenid%252Blinking%26state%3DeyJjc3JmX3Rva2VuIjoia0FpbWJDX2JvUnVEU3p4cjFVUjdqc2ZMM3hYSFNNUEVLV3VRTEVqR2ZDRSIsInJlZGlyZWN0X3RvIjoiaHR0cHM6Ly93d3cubWV0YS5haS9vaWRjL2NhbGxiYWNrIiwic3RhcnRlZF9hdCI6MTc4NzM4ODQ3MjcyMSwid2F0ZXJmYWxsX2lkIjoiNDM0MzlkZjAtMmUyZC00OTlhLWEwNjctZmQxNDhjYmZjMzI5In0%253D%26waterfall_id%3D43439df0-2e2d-499a-a067-fd148cbfc329%26code_challenge%3DczTb3mBuOFgn2XHZT2sbINOQv4bEdMZwOnR27PTh8Uc%26code_challenge_method%3DS256&source_app_id=1522763855472543&force_reauth=0&rcs=AToJ9_sn3hbKj9zIJ8tczAsW-DPBffTze3xHYU7gZrBZeeZJSZgr_LJ6m8nsUHQKnB-ykoKYX0FcAKE4DkFVODO-_yLoicnxVKRJhIc-g95tt_f9UxSN9rbGWMhanlcVhKi8JMtlYfO11vJxavSJTdP0pGK1GDoxQR3MDWYBncrLk_fpIWkOtxD9TL8";

const STORAGE = {
  account: "agentmail_account",
  accounts: "agentmail_accounts",
  apiKey: "agentmail_api_key",
  baseUrl: "agentmail_base_url",
  mailProvider: "agentmail_mail_provider",
  birdApiKey: "agentmail_bird_api_key",
  birdBaseUrl: "agentmail_bird_base_url",
  uiTheme: "agentmail_ui_theme",
  uiDensity: "agentmail_ui_density",
  uiMotion: "agentmail_ui_motion",
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const state = {
  account: {},
  accounts: [],
  apiKey: DEFAULT_API_KEY,
  baseUrl: DEFAULT_BASE_URL,
  mailProvider: "toxic",
  birdApiKey: DEFAULT_BIRD_API_KEY,
  birdBaseUrl: DEFAULT_BIRD_BASE_URL,
  uiTheme: "violet",
  uiDensity: "comfortable",
  uiMotion: true
};

const els = {
  miniStatus: $("#miniStatus"),
  menuButtons: $$(".menu-btn[data-panel]"),
  panels: $$(".panel"),
  startBtn: $("#startBtn"),
  toxicMailBtn: $("#toxicMailBtn"),
  babyMailBtn: $("#babyMailBtn"),
  selectedProviderLabel: $("#selectedProviderLabel"),
  selectedEmail: $("#selectedEmail"),
  selectedPassword: $("#selectedPassword"),
  copyEmailBtn: $("#copyEmailBtn"),
  copyPasswordBtn: $("#copyPasswordBtn"),
  fillEmailBtn: $("#fillEmailBtn"),
  fillPasswordBtn: $("#fillPasswordBtn"),
  passwordInput: $("#passwordInput"),
  generatePasswordBtn: $("#generatePasswordBtn"),
  savePasswordBtn: $("#savePasswordBtn"),
  accountEmail: $("#accountEmail"),
  accountPassword: $("#accountPassword"),
  accountInboxId: $("#accountInboxId"),
  accountStartUrl: $("#accountStartUrl"),
  copyAccountBtn: $("#copyAccountBtn"),
  resetAccountBtn: $("#resetAccountBtn"),
  accountList: $("#accountList"),
  accountCount: $("#accountCount"),
  copyAllAccountsBtn: $("#copyAllAccountsBtn"),
  downloadAccountsTxtBtn: $("#downloadAccountsTxtBtn"),
  clearAccountListBtn: $("#clearAccountListBtn"),
  apiKeyInput: $("#apiKeyInput"),
  baseUrlInput: $("#baseUrlInput"),
  birdApiKeyInput: $("#birdApiKeyInput"),
  birdBaseUrlInput: $("#birdBaseUrlInput"),
  saveSettingsBtn: $("#saveSettingsBtn"),
  toast: $("#toast"),
  themeButtons: $$("[data-theme-option]"),
  themeName: $("#themeName"),
  densityToggle: $("#densityToggle"),
  densityStatus: $("#densityStatus"),
  motionToggle: $("#motionToggle"),
  motionStatus: $("#motionStatus"),
};

function normalizeBaseUrl(url) {
  const clean = (url || DEFAULT_BASE_URL).trim();
  return clean.endsWith("/") ? clean : `${clean}/`;
}

function normalizeBirdBaseUrl(url) {
  const clean = (url || DEFAULT_BIRD_BASE_URL).trim();
  return clean.endsWith("/") ? clean : `${clean}/`;
}

function chromeStorageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function chromeStorageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

function chromeStorageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function showToast(message, type = "ok") {
  els.toast.textContent = message;
  els.toast.className = `toast show ${type}`;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    els.toast.className = "toast";
  }, 2800);
}

function setStatus(message) {
  els.miniStatus.textContent = message;
}

const THEME_LABELS = {
  violet: "Violet Flux",
  arctic: "Arctic Pulse",
  cyber: "Cyber Pulse",
  emerald: "Emerald Grid",
  solar: "Solar Flare"
};

function applyTheme(theme) {
  const selected = Object.prototype.hasOwnProperty.call(THEME_LABELS, theme) ? theme : "violet";
  state.uiTheme = selected;
  document.documentElement.dataset.theme = selected;
  els.themeButtons.forEach((button) => {
    const active = button.dataset.themeOption === selected;
    button.classList.toggle("active", active);
    button.setAttribute("aria-checked", String(active));
  });
  if (els.themeName) els.themeName.textContent = THEME_LABELS[selected];
}

async function selectTheme(theme) {
  applyTheme(theme);
  try {
    await chromeStorageSet({ [STORAGE.uiTheme]: state.uiTheme });
  } catch (error) {
    showToast("Theme preference could not be saved.", "error");
  }
}

function applyDensity(density) {
  state.uiDensity = density === "compact" ? "compact" : "comfortable";
  document.documentElement.dataset.density = state.uiDensity;
  const compact = state.uiDensity === "compact";
  if (els.densityToggle) {
    els.densityToggle.setAttribute("aria-pressed", String(compact));
    els.densityToggle.classList.toggle("enabled", compact);
  }
  if (els.densityStatus) els.densityStatus.textContent = compact ? "On" : "Off";
}

function applyMotion(enabled) {
  state.uiMotion = enabled !== false;
  document.documentElement.dataset.motion = state.uiMotion ? "on" : "off";
  if (els.motionToggle) {
    els.motionToggle.setAttribute("aria-pressed", String(state.uiMotion));
    els.motionToggle.classList.toggle("enabled", state.uiMotion);
  }
  if (els.motionStatus) els.motionStatus.textContent = state.uiMotion ? "On" : "Off";
}

async function toggleDensity() {
  applyDensity(state.uiDensity === "compact" ? "comfortable" : "compact");
  try { await chromeStorageSet({ [STORAGE.uiDensity]: state.uiDensity }); }
  catch (error) { showToast("Layout preference could not be saved.", "error"); }
}

async function toggleMotion() {
  applyMotion(!state.uiMotion);
  try { await chromeStorageSet({ [STORAGE.uiMotion]: state.uiMotion }); }
  catch (error) { showToast("Motion preference could not be saved.", "error"); }
}


function setLoading(button, isLoading) {
  if (!button) return;
  button.classList.toggle("loading", isLoading);
  button.disabled = isLoading;
}

function providerLabel(provider = state.mailProvider) {
  return provider === "baby" ? "Baby mail" : "Toxic mail";
}

function maskSecret(value) {
  if (!value) return "Not set";
  if (value.length <= 8) return "•".repeat(value.length);
  return `${value.slice(0, 2)}${"•".repeat(Math.min(10, value.length - 4))}${value.slice(-2)}`;
}

function accountRecordFrom(account = {}, source = "") {
  if (!account.email) return null;
  return {
    email: account.email,
    password: account.password || state.account.password || DEFAULT_PASSWORD,
    inbox_id: account.inbox_id || account.email,
    pod_id: account.pod_id || "",
    provider: account.provider || providerLabel(account.mail_provider || state.mailProvider),
    mail_provider: account.mail_provider || state.mailProvider,
    source,
    created_at: account.created_at || account.mail_created_at || new Date().toISOString(),
    saved_at: new Date().toISOString()
  };
}

async function upsertAccountList(account = {}, source = "") {
  const record = accountRecordFrom(account, source);
  if (!record) return;

  const existingIndex = state.accounts.findIndex((item) => item.email === record.email);
  if (existingIndex >= 0) {
    state.accounts[existingIndex] = {
      ...state.accounts[existingIndex],
      ...record,
      password: record.password || state.accounts[existingIndex].password
    };
  } else {
    state.accounts.unshift(record);
  }

  state.accounts = state.accounts.slice(0, 1000);
  await chromeStorageSet({ [STORAGE.accounts]: state.accounts });
  renderAccountList();
}

function formatShortDate(value) {
  try {
    return new Date(value).toLocaleString();
  } catch (error) {
    return "";
  }
}

function renderAccountList() {
  if (!els.accountList) return;
  els.accountList.textContent = "";
  els.accountCount.textContent = String(state.accounts.length || 0);
  els.copyAllAccountsBtn.disabled = state.accounts.length === 0;
  els.downloadAccountsTxtBtn.disabled = state.accounts.length === 0;
  els.clearAccountListBtn.disabled = state.accounts.length === 0;

  if (!state.accounts.length) {
    const empty = document.createElement("div");
    empty.className = "empty-list";
    empty.textContent = "Nothing saved yet. Recorded entries will appear here.";
    els.accountList.appendChild(empty);
    return;
  }

  state.accounts.forEach((account, index) => {
    const item = document.createElement("div");
    item.className = "account-item";

    const top = document.createElement("div");
    top.className = "account-item-top";

    const avatar = document.createElement("div");
    avatar.className = "account-avatar";
    avatar.textContent = String(account.email || "?").trim().charAt(0).toUpperCase() || "?";

    const email = document.createElement("div");
    email.className = "account-email";
    email.textContent = account.email || "No email";

    const copy = document.createElement("button");
    copy.className = "ghost small";
    copy.type = "button";
    copy.dataset.copyAccountIndex = String(index);
    copy.textContent = "Copy";

    top.append(avatar, email, copy);

    const meta = document.createElement("div");
    meta.className = "account-meta";
    meta.textContent = `Password: ${account.password || ""} • Saved: ${formatShortDate(account.saved_at || account.created_at)}`;

    item.append(top, meta);
    els.accountList.appendChild(item);
  });
}

function render() {
  const email = state.account.email || "No inbox selected";
  const password = state.account.password || "No password set";

  els.selectedEmail.textContent = email;
  els.selectedPassword.textContent = state.account.password ? password : "No password set";
  els.passwordInput.value = state.account.password || "";
  try { updatePasswordStrength(); } catch (error) {}

  if (els.accountEmail) els.accountEmail.textContent = state.account.email || "Not set";
  if (els.accountPassword) els.accountPassword.textContent = state.account.password || "Not set";
  if (els.accountInboxId) els.accountInboxId.textContent = state.account.inbox_id || state.account.mailbox_id || "Not set";
  if (els.accountStartUrl) els.accountStartUrl.textContent = START_URL;

  if (els.selectedProviderLabel) els.selectedProviderLabel.textContent = `Selected: ${providerLabel()}`;
  const pill = document.getElementById("providerPill");
  if (pill) pill.textContent = state.mailProvider === "baby" ? "Baby" : "Toxic";
  els.toxicMailBtn?.classList.toggle("active", state.mailProvider !== "baby");
  els.babyMailBtn?.classList.toggle("active", state.mailProvider === "baby");

  if (els.apiKeyInput) els.apiKeyInput.value = state.apiKey || "";
  if (els.baseUrlInput) els.baseUrlInput.value = state.baseUrl || DEFAULT_BASE_URL;
  if (els.birdApiKeyInput) els.birdApiKeyInput.value = state.birdApiKey || DEFAULT_BIRD_API_KEY;
  if (els.birdBaseUrlInput) els.birdBaseUrlInput.value = state.birdBaseUrl || DEFAULT_BIRD_BASE_URL;

  const hasEmail = Boolean(state.account.email);
  const hasPassword = Boolean(state.account.password);
  els.copyEmailBtn.disabled = !hasEmail;
  els.fillEmailBtn.disabled = !hasEmail;
  els.copyPasswordBtn.disabled = !hasPassword;
  els.fillPasswordBtn.disabled = !hasPassword;

  renderAccountList();

  if (hasEmail && hasPassword) setStatus("Mail + password ready");
  else if (hasEmail) setStatus("Mail ready");
  else setStatus("Ready");
}

function switchPanel(panelName) {
  els.panels.forEach((panel) => panel.classList.toggle("active", panel.id === `panel-${panelName}`));
  els.menuButtons.forEach((button) => button.classList.toggle("active", button.dataset.panel === panelName));
}

async function copyText(text, successMessage = "Copied") {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch (error) {
    const area = document.createElement("textarea");
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
  showToast(successMessage);
}

function buildAccountText(account = state.account) {
  return [
    `Mail: ${account.email || ""}`,
    `Password: ${account.password || ""}`,
    `Inbox ID: ${account.inbox_id || ""}`,
    `Start URL: ${START_URL}`
  ].join("\n");
}

function buildAllAccountsText() {
  return state.accounts
    .map((account) => account.email || "")
    .filter(Boolean)
    .join("\n");
}
function buildDownloadFileName() {
  const pad = (num) => String(num).padStart(2, "0");
  const now = new Date();
  return `agentmail-mails-${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}.txt`;
}

async function downloadAccountsTxt() {
  const text = buildAllAccountsText();
  if (!text) {
    showToast("No saved mail to download.", "error");
    return;
  }

  const fileName = buildDownloadFileName();
  const content = `${text}\n`;

  try {
    if (chrome.downloads?.download) {
      const url = `data:text/plain;charset=utf-8,${encodeURIComponent(content)}`;
      chrome.downloads.download({ url, filename: fileName, saveAs: false }, () => {
        if (chrome.runtime.lastError) {
          showToast(chrome.runtime.lastError.message || "Download failed.", "error");
          return;
        }
        showToast(`Downloaded ${state.accounts.length} mails.`);
      });
      return;
    }
  } catch (error) {
    // Fallback below.
  }

  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1200);
  showToast(`Downloaded ${state.accounts.length} mails.`);
}


function randomPassword(length = 16) {
  const lower = "abcdefghijklmnopqrstuvwxyz";
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const digits = "0123456789";
  const symbols = "!@#$%^&*?";
  const all = lower + upper + digits + symbols;
  const bytes = new Uint32Array(length);
  crypto.getRandomValues(bytes);

  const required = [lower, upper, digits, symbols].map((set, i) => set[bytes[i] % set.length]);
  const rest = [...bytes].slice(required.length).map((num) => all[num % all.length]);
  const combined = required.concat(rest);

  for (let i = combined.length - 1; i > 0; i--) {
    const swapIndex = bytes[i] % (i + 1);
    [combined[i], combined[swapIndex]] = [combined[swapIndex], combined[i]];
  }
  return combined.join("");
}

async function saveAccount(patch) {
  state.account = {
    ...state.account,
    ...patch,
    updated_at: new Date().toISOString()
  };
  await chromeStorageSet({ [STORAGE.account]: state.account });
  render();
}

async function createProviderMail(provider = state.mailProvider) {
  state.mailProvider = provider === "baby" ? "baby" : "toxic";
  await chromeStorageSet({
    [STORAGE.mailProvider]: state.mailProvider,
    [STORAGE.birdApiKey]: state.birdApiKey || DEFAULT_BIRD_API_KEY,
    [STORAGE.birdBaseUrl]: state.birdBaseUrl || DEFAULT_BIRD_BASE_URL
  });
  sendRuntimeMessage({ type: "AGENTMAIL_SET_MAIL_PROVIDER", provider: state.mailProvider });
  render();

  const button = state.mailProvider === "baby" ? els.babyMailBtn : els.toxicMailBtn;
  setLoading(button, true);
  setStatus(`Creating fresh ${providerLabel()}...`);

  try {
    const result = await sendRuntimeMessage({
      type: "AGENTMAIL_GET_OR_CREATE_EMAIL",
      forceNew: true,
      provider: state.mailProvider
    });

    if (!result.ok || !result.email) {
      setStatus("API error");
      showToast(result.error || `Could not create ${providerLabel()}.`, "error");
      return;
    }

    if (result.account) {
      state.account = result.account;
      await chromeStorageSet({ [STORAGE.account]: state.account });
    } else {
      await saveAccount({ email: result.email, provider: providerLabel(), mail_provider: state.mailProvider });
    }

    render();
    showToast(`Fresh ${providerLabel()} set: ${result.email}`);
    await fillActiveTab("email", result.email, { silent: true });
  } finally {
    setLoading(button, false);
    render();
  }
}

function tabCanBeInjected(tab) {
  const url = tab?.url || "";
  return url.startsWith("http://") || url.startsWith("https://");
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function sendRuntimeMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: "No response from extension." });
    });
  });
}

async function openStartWithFreshMail() {
  setLoading(els.startBtn, true);
  setStatus("Generating mail...");

  try {
    const result = await sendRuntimeMessage({
      type: "OPEN_START",
      prepareEmail: true,
      forceNewEmail: true,
      provider: state.mailProvider
    });

    if (!result.ok) {
      setStatus("API error");
      showToast(result.error || "Could not generate mail.", "error");
      return;
    }

    if (result.account) {
      state.account = result.account;
      await chromeStorageSet({ [STORAGE.account]: state.account });
    } else if (result.email) {
      await saveAccount({ email: result.email, provider: providerLabel(), mail_provider: state.mailProvider });
    }

    render();
    showToast(result.email ? `Mail generated: ${result.email}` : "Start opened.");
  } finally {
    setLoading(els.startBtn, false);
  }
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: "No response from page." });
    });
  });
}

async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch (error) {
    // Some pages block injection. The caller shows a readable message.
  }
}

async function fillActiveTab(kind, value, options = {}) {
  if (!value) return;
  const tab = await getActiveTab();

  if (!tabCanBeInjected(tab)) {
    if (!options.silent) showToast("Open a normal web page first, then fill again.", "error");
    return;
  }

  let result = await sendMessageToTab(tab.id, { type: "AGENTMAIL_FILL", kind, value });
  if (!result?.ok) {
    await ensureContentScript(tab.id);
    result = await sendMessageToTab(tab.id, { type: "AGENTMAIL_FILL", kind, value });
  }

  if (result?.ok) {
    if (!options.silent) showToast(`${kind === "email" ? "Mail" : "Password"} filled on page.`);
  } else if (!options.silent) {
    showToast(result?.message || result?.error || `Could not fill ${kind}.`, "error");
  }
}

async function saveSettings() {
  if (!els.apiKeyInput || !els.baseUrlInput || !els.birdApiKeyInput || !els.birdBaseUrlInput) return;
  state.apiKey = els.apiKeyInput.value.trim();
  state.baseUrl = normalizeBaseUrl(els.baseUrlInput.value);
  state.birdApiKey = els.birdApiKeyInput.value.trim();
  state.birdBaseUrl = normalizeBirdBaseUrl(els.birdBaseUrlInput.value || DEFAULT_BIRD_BASE_URL);
  await chromeStorageSet({
    [STORAGE.apiKey]: state.apiKey,
    [STORAGE.baseUrl]: state.baseUrl,
    [STORAGE.birdApiKey]: state.birdApiKey,
    [STORAGE.birdBaseUrl]: state.birdBaseUrl
  });
  render();
  showToast("API settings saved.");
}

async function resetAccount() {
  await chromeStorageRemove([STORAGE.account]);
  state.account = {};
  render();
  showToast("Account data reset.");
}

async function clearAccountList() {
  state.accounts = [];
  await chromeStorageSet({ [STORAGE.accounts]: state.accounts });
  renderAccountList();
  showToast("Account list cleared.");
}

function accountListClickHandler(event) {
  const button = event.target.closest?.("[data-copy-account-index]");
  if (!button) return;
  const index = Number(button.dataset.copyAccountIndex);
  const account = state.accounts[index];
  if (!account) return;
  copyText(account.email, "Mail copied.");
}

async function init() {
  const saved = await chromeStorageGet([STORAGE.account, STORAGE.accounts, STORAGE.apiKey, STORAGE.baseUrl, STORAGE.mailProvider, STORAGE.birdApiKey, STORAGE.birdBaseUrl, STORAGE.uiTheme, STORAGE.uiDensity, STORAGE.uiMotion]);
  applyTheme(saved[STORAGE.uiTheme]);
  applyDensity(saved[STORAGE.uiDensity]);
  applyMotion(saved[STORAGE.uiMotion]);
  state.account = saved[STORAGE.account] || {};
  state.accounts = Array.isArray(saved[STORAGE.accounts]) ? saved[STORAGE.accounts] : [];
  state.mailProvider = saved[STORAGE.mailProvider] || state.account.mail_provider || "toxic";
  state.birdApiKey = saved[STORAGE.birdApiKey] || DEFAULT_BIRD_API_KEY;
  state.birdBaseUrl = saved[STORAGE.birdBaseUrl] || DEFAULT_BIRD_BASE_URL;
  if (!state.account.password) {
    state.account.password = DEFAULT_PASSWORD;
    await chromeStorageSet({ [STORAGE.account]: state.account });
  }
  state.apiKey = saved[STORAGE.apiKey] || DEFAULT_API_KEY;
  state.baseUrl = normalizeBaseUrl(saved[STORAGE.baseUrl] || DEFAULT_BASE_URL);

  if (!saved[STORAGE.apiKey] && DEFAULT_API_KEY) {
    await chromeStorageSet({ [STORAGE.apiKey]: DEFAULT_API_KEY, [STORAGE.baseUrl]: DEFAULT_BASE_URL });
  }
  await chromeStorageSet({
    [STORAGE.mailProvider]: state.mailProvider,
    [STORAGE.birdApiKey]: state.birdApiKey,
    [STORAGE.birdBaseUrl]: state.birdBaseUrl
  });

  render();
}

els.menuButtons.forEach((button) => button.addEventListener("click", () => switchPanel(button.dataset.panel)));
els.themeButtons.forEach((button) => button.addEventListener("click", () => selectTheme(button.dataset.themeOption)));
els.densityToggle?.addEventListener("click", toggleDensity);
els.motionToggle?.addEventListener("click", toggleMotion);
els.startBtn.addEventListener("click", openStartWithFreshMail);
els.toxicMailBtn?.addEventListener("click", () => createProviderMail("toxic"));
els.babyMailBtn?.addEventListener("click", () => createProviderMail("baby"));
els.copyEmailBtn.addEventListener("click", () => copyText(state.account.email, "Mail copied."));
els.copyPasswordBtn.addEventListener("click", () => copyText(state.account.password, "Password copied."));
els.copyAccountBtn?.addEventListener("click", () => copyText(state.account.email, "Mail copied."));
els.copyAllAccountsBtn.addEventListener("click", () => copyText(buildAllAccountsText(), "All mails copied."));
els.downloadAccountsTxtBtn.addEventListener("click", downloadAccountsTxt);
els.clearAccountListBtn.addEventListener("click", clearAccountList);
els.accountList.addEventListener("click", accountListClickHandler);
els.fillEmailBtn.addEventListener("click", () => fillActiveTab("email", state.account.email));
els.fillPasswordBtn.addEventListener("click", () => fillActiveTab("password", state.account.password));
els.generatePasswordBtn.addEventListener("click", () => {
  els.passwordInput.value = randomPassword();
  els.passwordInput.focus();
  try { updatePasswordStrength(); } catch (error) {}
});
els.savePasswordBtn.addEventListener("click", async () => {
  const password = els.passwordInput.value.trim();
  if (!password) {
    showToast("Type or generate a password first.", "error");
    return;
  }
  await saveAccount({ password });
  showToast("Password set.");
  await fillActiveTab("password", password, { silent: true });
});
els.saveSettingsBtn?.addEventListener("click", saveSettings);
els.resetAccountBtn?.addEventListener("click", resetAccount);

init();


/* =========================================================================
   Power Engine live panel (v3.3 LUX)
   Reads the automation telemetry straight from the active Meta tab.
   ========================================================================= */
const engineEls = {
  stateDot: document.getElementById("engineStateDot"),
  state: document.getElementById("engineState"),
  page: document.getElementById("enginePage"),
  bar: document.getElementById("engineBar"),
  clicks: document.getElementById("engineClicks"),
  fills: document.getElementById("engineFills"),
  scans: document.getElementById("engineScans"),
  log: document.getElementById("engineLog"),
  refresh: document.getElementById("engineRefreshBtn"),
  pwdStrength: document.getElementById("pwdStrength")
};

function renderEngineState(stats, note) {
  const dot = engineEls.stateDot;
  const stateEl = engineEls.state;
  const bar = engineEls.bar;
  if (!dot || !stateEl) return;

  if (!stats || !stats.ok) {
    dot.dataset.state = "idle";
    stateEl.dataset.state = "idle";
    stateEl.textContent = "IDLE";
    if (bar) bar.dataset.state = "idle";
    if (engineEls.page) engineEls.page.textContent = stats === null ? "Waiting for a supported tab" : "Engine offline";
    if (engineEls.log) engineEls.log.textContent = note || "Open a supported tab to view live status.";
    if (engineEls.clicks) engineEls.clicks.textContent = "-";
    if (engineEls.fills) engineEls.fills.textContent = "-";
    if (engineEls.scans) engineEls.scans.textContent = "-";
    return;
  }

  const busy = Number(stats.lastActionForMs || 0) < 1600;
  const state = !stats.running ? "idle" : busy ? "work" : "live";
  dot.dataset.state = state;
  stateEl.dataset.state = state;
  stateEl.textContent = state === "work" ? "WORKING" : state === "live" ? "LIVE" : "IDLE";
  if (bar) bar.dataset.state = state;

  const page = stats.page || {};
  if (engineEls.page) {
    engineEls.page.textContent = `${page.name || "Unknown"} · ${page.confidence || 0}%`;
  }
  const counters = stats.counters || {};
  if (engineEls.clicks) engineEls.clicks.textContent = String(counters.clicks || 0);
  if (engineEls.fills) engineEls.fills.textContent = String(counters.fills || 0);
  if (engineEls.scans) engineEls.scans.textContent = String(counters.sweeps || 0);
  if (engineEls.log) {
    const log = Array.isArray(stats.log) && stats.log.length ? stats.log[stats.log.length - 1].message : "";
    const secs = Math.max(0, Math.round((stats.uptimeMs || 0) / 1000));
    engineEls.log.textContent = log || `Engine v${stats.version || "?"} · up ${secs}s`;
  }
}

async function refreshEngineStats() {
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.id || !tabCanBeInjected(tab)) {
      renderEngineState(null, "Open a supported tab to view live status.");
      return;
    }
    const res = await sendMessageToTab(tab.id, { type: "AGENTMAIL_POWER_STATS" });
    if (!res || !res.ok) {
      renderEngineState(null, "Engine not loaded on this page yet.");
      return;
    }
    renderEngineState(res);
  } catch (error) {
    renderEngineState(null, "Engine status unavailable.");
  }
}

engineEls.refresh?.addEventListener("click", refreshEngineStats);
refreshEngineStats();
setInterval(refreshEngineStats, 1200);

/* One interface at a time: tell the page widget to step aside while this popup
   is open, and to come back the moment it closes. */
async function notifyPageWidget(isOpen, type) {
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.id || !tabCanBeInjected(tab)) return;
    chrome.tabs.sendMessage(
      tab.id,
      { type: type || (isOpen ? "AGENTMAIL_POPUP_OPEN" : "AGENTMAIL_POPUP_CLOSE") },
      () => chrome.runtime.lastError
    );
  } catch (error) {}
}
notifyPageWidget(true);
window.addEventListener("pagehide", () => notifyPageWidget(false));
window.addEventListener("unload", () => notifyPageWidget(false));

// Heartbeat: proves to the page that this popup is still open. If the beats stop,
// the page restores its normal UI on its own - it can never get stuck.
setInterval(() => notifyPageWidget(true, "AGENTMAIL_POPUP_HEARTBEAT"), 1000);

// A dedicated port is the most reliable "popup closed" signal there is: the
// background worker sees the disconnect even when pagehide/unload never fire.
try {
  if (chrome.runtime && typeof chrome.runtime.connect === "function") {
    const popupPort = chrome.runtime.connect({ name: "agentmail-popup" });
    popupPort.onDisconnect.addListener(() => {});
  }
} catch (error) {}

function updatePasswordStrength() {
  const meter = document.getElementById("pwdStrength");
  if (!meter || !els.passwordInput) return;
  const value = els.passwordInput.value || "";
  let level = 0;
  if (value.length >= 4) level = 1;
  if (value.length >= 8) level = 2;
  if (value.length >= 10 && /[A-Z]/.test(value) && /\d/.test(value)) level = 3;
  if (value.length >= 12 && /[A-Z]/.test(value) && /\d/.test(value) && /[^A-Za-z0-9]/.test(value)) level = 4;
  meter.dataset.level = String(level);
}

els.passwordInput.addEventListener("input", updatePasswordStrength);
updatePasswordStrength();
