function decodePackedSecret(parts) {
  try { return atob(parts.join("")); } catch (error) { return ""; }
}
try { importScripts("backend_api.js"); } catch (error) { /* backend api config optional */ }
function getMasterTeamApiConfig() { return self.MASTER_TEAM_BACKEND_API || {}; }
function secretFromConfig(plain, parts) {
  if (plain && String(plain).trim()) return String(plain).trim();
  return decodePackedSecret(parts || []);
}
const START_URL = "https://auth.meta.com/?waterfall_id=43439df0-2e2d-499a-a067-fd148cbfc329&redirect_uri=https%3A%2F%2Fauth.meta.com%2Foidc%2F%3Fapp_id%3D1522763855472543%26redirect_uri%3Dhttps%253A%252F%252Fauth.meta.ai%252Fecto%26response_type%3Dcode%26scope%3Dopenid%252Blinking%26state%3DeyJjc3JmX3Rva2VuIjoia0FpbWJDX2JvUnVEU3p4cjFVUjdqc2ZMM3hYSFNNUEVLV3VRTEVqR2ZDRSIsInJlZGlyZWN0X3RvIjoiaHR0cHM6Ly93d3cubWV0YS5haS9vaWRjL2NhbGxiYWNrIiwic3RhcnRlZF9hdCI6MTc4NzM4ODQ3MjcyMSwid2F0ZXJmYWxsX2lkIjoiNDM0MzlkZjAtMmUyZC00OTlhLWEwNjctZmQxNDhjYmZjMzI5In0%253D%26waterfall_id%3D43439df0-2e2d-499a-a067-fd148cbfc329%26code_challenge%3DczTb3mBuOFgn2XHZT2sbINOQv4bEdMZwOnR27PTh8Uc%26code_challenge_method%3DS256&source_app_id=1522763855472543&force_reauth=0&rcs=AToJ9_sn3hbKj9zIJ8tczAsW-DPBffTze3xHYU7gZrBZeeZJSZgr_LJ6m8nsUHQKnB-ykoKYX0FcAKE4DkFVODO-_yLoicnxVKRJhIc-g95tt_f9UxSN9rbGWMhanlcVhKi8JMtlYfO11vJxavSJTdP0pGK1GDoxQR3MDWYBncrLk_fpIWkOtxD9TL8";
const DEFAULT_API_KEY = secretFromConfig(getMasterTeamApiConfig().toxicApiKey, getMasterTeamApiConfig().toxicApiKeyParts);
const DEFAULT_BASE_URL = getMasterTeamApiConfig().toxicBaseUrl || "https://api.agentmail.to/v0/";
const DEFAULT_BIRD_API_KEY = secretFromConfig(getMasterTeamApiConfig().babyApiKey, getMasterTeamApiConfig().babyApiKeyParts);
const DEFAULT_BIRD_BASE_URL = getMasterTeamApiConfig().babyBaseUrl || "https://us1.platform.bird.com/v1/";
const DEFAULT_PASSWORD = "FAHAD@10";

const STORAGE = {
  account: "agentmail_account",
  accounts: "agentmail_accounts",
  apiKey: "agentmail_api_key",
  baseUrl: "agentmail_base_url",
  mailProvider: "agentmail_mail_provider",
  birdApiKey: "agentmail_bird_api_key",
  birdBaseUrl: "agentmail_bird_base_url"
};

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function storageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}




function normalizeBaseUrl(url) {
  const clean = (url || DEFAULT_BASE_URL).trim();
  return clean.endsWith("/") ? clean : `${clean}/`;
}

function normalizeBirdBaseUrl(url) {
  const clean = (url || DEFAULT_BIRD_BASE_URL).trim();
  return clean.endsWith("/") ? clean : `${clean}/`;
}

function providerLabel(provider) {
  return provider === "baby" ? "Baby Mail" : "Toxic Mail";
}

function isAuthMetaUrl(url) {
  try {
    return new URL(url).hostname === "auth.meta.com";
  } catch (error) {
    return false;
  }
}

async function saveAgentMailAccount(account, apiKey, baseUrl, inbox, reused) {
  const nextAccount = {
    ...account,
    email: inbox.email,
    inbox_id: inbox.inbox_id || inbox.email,
    pod_id: inbox.pod_id,
    display_name: inbox.display_name || "Agent",
    provider: "Toxic Mail",
    mail_provider: "toxic",
    mail_created_at: inbox.created_at || account.mail_created_at || new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  // Do NOT add to saved account list here. User requested: save mail to Account
  // list only after LOG OUT is clicked/success page appears.
  await storageSet({
    [STORAGE.account]: nextAccount,
    [STORAGE.apiKey]: apiKey,
    [STORAGE.baseUrl]: baseUrl,
    [STORAGE.mailProvider]: "toxic"
  });

  return { ok: true, email: nextAccount.email, account: nextAccount, reused };
}

async function listExistingAgentMails(apiKey, baseUrl, limit = 20) {
  const response = await fetch(`${baseUrl}inboxes?limit=${limit}`, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Accept": "application/json"
    }
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    const detail = typeof data === "string" ? data : (data.message || data.error || JSON.stringify(data));
    return { ok: false, error: `Toxic Mail list error ${response.status}: ${detail}` };
  }

  const inboxes = data.inboxes || [];
  if (!inboxes.length) {
    return { ok: false, error: "No Toxic Mail inbox found. Delete an old inbox or upgrade your mail plan." };
  }

  return { ok: true, inboxes };
}

async function deleteAgentMailInbox(apiKey, baseUrl, inboxId) {
  const response = await fetch(`${baseUrl}inboxes/${encodeURIComponent(inboxId)}`, {
    method: "DELETE",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Accept": "application/json"
    }
  });

  if (response.ok || response.status === 404) {
    return { ok: true };
  }

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();
  const detail = typeof data === "string" ? data : (data.message || data.error || JSON.stringify(data));
  return { ok: false, error: `Toxic Mail delete error ${response.status}: ${detail}` };
}

async function freeOneInboxSlot(apiKey, baseUrl, preferredInboxId) {
  const listed = await listExistingAgentMails(apiKey, baseUrl, 20);
  if (!listed.ok) return listed;

  const sorted = [...listed.inboxes].sort((a, b) => {
    if (preferredInboxId) {
      const aPreferred = (a.inbox_id || a.email) === preferredInboxId ? 0 : 1;
      const bPreferred = (b.inbox_id || b.email) === preferredInboxId ? 0 : 1;
      if (aPreferred !== bPreferred) return aPreferred - bPreferred;
    }
    return new Date(a.created_at || 0) - new Date(b.created_at || 0);
  });

  const inbox = sorted[0];
  const inboxId = inbox?.inbox_id || inbox?.email;
  if (!inboxId) return { ok: false, error: "No deletable Toxic Mail inbox found." };

  const deleted = await deleteAgentMailInbox(apiKey, baseUrl, inboxId);
  if (!deleted.ok) return deleted;
  return { ok: true, deleted_inbox_id: inboxId };
}

async function createAgentMailInbox(apiKey, baseUrl) {
  const response = await fetch(`${baseUrl}inboxes`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify({
      display_name: "Agent",
      metadata: {
        source: "chrome_extension",
        label: "auth_meta_auto_email"
      }
    })
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    return { ok: false, status: response.status, data };
  }

  return { ok: true, inbox: data };
}

async function getOrCreateAgentMail(options = {}) {
  const saved = await storageGet([STORAGE.account, STORAGE.apiKey, STORAGE.baseUrl]);
  const account = saved[STORAGE.account] || {};
  const apiKey = saved[STORAGE.apiKey] || DEFAULT_API_KEY;
  const baseUrl = normalizeBaseUrl(saved[STORAGE.baseUrl] || DEFAULT_BASE_URL);

  if (account.email && account.mail_provider !== "baby" && !options.forceNew) {
    return { ok: true, email: account.email, account, reused: true };
  }

  if (!apiKey) {
    return { ok: false, error: "Toxic Mail API key missing." };
  }

  let lastCreateError = null;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const created = await createAgentMailInbox(apiKey, baseUrl);
    if (created.ok) {
      return saveAgentMailAccount(account, apiKey, baseUrl, created.inbox, false);
    }

    lastCreateError = created;
    const data = created.data;
    const errorCode = typeof data === "object" ? String(data.code || data.name || "").toLowerCase() : "";
    const isLimitError = created.status === 403 && errorCode.includes("limit");

    if (!isLimitError) break;

    // New mail every Start: the AgentMail plan limit is small, so when the
    // limit is full we delete one old inbox and immediately create a fresh one.
    const freed = await freeOneInboxSlot(apiKey, baseUrl, account.inbox_id || account.email);
    if (!freed.ok) return freed;
  }

  const data = lastCreateError?.data;
  const status = lastCreateError?.status || "unknown";
  const detail = typeof data === "string" ? data : (data?.message || data?.error || JSON.stringify(data));
  return { ok: false, error: `Toxic Mail API error ${status}: ${detail}` };
}

async function createBirdMailbox(apiKey, baseUrl) {
  const response = await fetch(`${baseUrl}email/mailboxes`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "Accept": "application/json"
    },
    body: JSON.stringify({
      display_name: "Baby Mail",
      receive_policy: "open"
    })
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();
  if (!response.ok) return { ok: false, status: response.status, data };
  return { ok: true, mailbox: data };
}

async function saveBirdMailAccount(account, apiKey, baseUrl, mailbox, reused = false) {
  const email = mailbox.address || mailbox.email || mailbox.mailbox || mailbox.name;
  const mailboxId = mailbox.id || mailbox.mailbox_id || email;
  if (!email) return { ok: false, error: "Bird mailbox address missing in API response." };

  const nextAccount = {
    ...account,
    email,
    inbox_id: mailboxId,
    mailbox_id: mailboxId,
    display_name: mailbox.display_name || "Baby Mail",
    provider: "Baby Mail",
    mail_provider: "baby",
    bird_mailbox_id: mailboxId,
    mail_created_at: mailbox.created_at || account.mail_created_at || new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  // Do NOT add to saved account list here. User requested: save mail to Account
  // list only after LOG OUT is clicked/success page appears.
  await storageSet({
    [STORAGE.account]: nextAccount,
    [STORAGE.mailProvider]: "baby",
    [STORAGE.birdApiKey]: apiKey,
    [STORAGE.birdBaseUrl]: baseUrl
  });

  return { ok: true, email: nextAccount.email, account: nextAccount, reused };
}

async function getOrCreateBirdMail(options = {}) {
  const saved = await storageGet([STORAGE.account, STORAGE.birdApiKey, STORAGE.birdBaseUrl]);
  const account = saved[STORAGE.account] || {};
  const apiKey = saved[STORAGE.birdApiKey] || DEFAULT_BIRD_API_KEY;
  const baseUrl = normalizeBirdBaseUrl(saved[STORAGE.birdBaseUrl] || DEFAULT_BIRD_BASE_URL);

  if (account.email && account.mail_provider === "baby" && !options.forceNew) {
    return { ok: true, email: account.email, account, reused: true };
  }
  if (!apiKey) return { ok: false, error: "Baby Mail API key missing." };

  const created = await createBirdMailbox(apiKey, baseUrl);
  if (created.ok) return saveBirdMailAccount(account, apiKey, baseUrl, created.mailbox, false);

  const data = created.data;
  const status = created.status || "unknown";
  const birdError = typeof data === "object" ? (data.error || data) : null;
  const scope = birdError?.param || "";
  if (status === 403 && String(birdError?.name || "").toLowerCase().includes("insufficientscope")) {
    return { ok: false, error: `Baby Mail API key scope missing: ${scope || "mailbox_management:write"}. Create a Bird key with mailbox_management:write + mailbox:read scopes.` };
  }
  const detail = typeof data === "string" ? data : (birdError?.message || data?.message || data?.error || JSON.stringify(data));
  return { ok: false, error: `Baby Mail API error ${status}: ${detail}` };
}

async function getOrCreateSelectedMail(options = {}) {
  const saved = await storageGet([STORAGE.mailProvider]);
  const provider = options.provider || saved[STORAGE.mailProvider] || "toxic";
  if (provider === "baby") return getOrCreateBirdMail(options);
  return getOrCreateAgentMail(options);
}

async function markCurrentAccountSuccessful(source = "Logout") {
  const saved = await storageGet([STORAGE.account, STORAGE.accounts]);
  const account = saved[STORAGE.account] || {};
  if (!account.email) return { ok: false, error: "No current mail to save." };

  let accounts = Array.isArray(saved[STORAGE.accounts]) ? saved[STORAGE.accounts] : [];
  const record = {
    email: account.email,
    password: account.password || DEFAULT_PASSWORD,
    inbox_id: account.inbox_id || account.mailbox_id || account.email,
    mailbox_id: account.mailbox_id || account.bird_mailbox_id || "",
    pod_id: account.pod_id || "",
    provider: account.provider || providerLabel(account.mail_provider),
    mail_provider: account.mail_provider || "toxic",
    source,
    created_at: account.mail_created_at || account.created_at || new Date().toISOString(),
    saved_at: new Date().toISOString()
  };

  const existingIndex = accounts.findIndex((item) => item.email === record.email);
  if (existingIndex >= 0) accounts[existingIndex] = { ...accounts[existingIndex], ...record };
  else accounts.unshift(record);
  accounts = accounts.slice(0, 1000);

  await storageSet({ [STORAGE.accounts]: accounts });
  return { ok: true, email: record.email, count: accounts.length, account: record };
}

async function getSavedPassword() {
  const saved = await storageGet([STORAGE.account]);
  const account = saved[STORAGE.account] || {};
  const password = account.password || DEFAULT_PASSWORD;

  if (!account.password) {
    await storageSet({
      [STORAGE.account]: {
        ...account,
        password,
        updated_at: new Date().toISOString()
      }
    });
  }

  return { ok: true, password, account: { ...account, password } };
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function extractSixDigitCodeFromMessage(message) {
  const parts = [
    message.subject,
    message.preview,
    message.text,
    message.extracted_text,
    message.html,
    message.extracted_html
  ].filter(Boolean).join("\n");

  const html = String(message.html || message.extracted_html || "");
  const tagCodes = [...html.matchAll(/>\s*(\d{6})\s*</g)].map((match) => match[1]);
  const goodTagCode = tagCodes.find((code) => code !== "141823");
  if (goodTagCode) return goodTagCode;

  const codeNearWords = parts.match(/(?:confirmation|confirm|code|security)[\s\S]{0,500}?(?<![#\d])(\d{6})(?!\d)/i);
  if (codeNearWords && codeNearWords[1] !== "141823") return codeNearWords[1];

  const allCodes = [...parts.matchAll(/(?<![#\d])(\d{6})(?!\d)/g)]
    .map((match) => match[1])
    .filter((code) => !["141823", "000000", "111111"].includes(code));
  return allCodes[0] || null;
}

async function fetchJson(url, apiKey, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Accept": "application/json",
      ...(options.headers || {})
    }
  });

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();
  return { ok: response.ok, status: response.status, data };
}

// v3.1c: every caller shares ONE poll loop - two tabs (or a queued re-run) can
// never double the request rate on the mail API.
let agentmailCodePollInFlight = null;

async function getAgentMailConfirmationCode(account, apiKey, baseUrl, timeoutMs) {
  if (agentmailCodePollInFlight) return agentmailCodePollInFlight;
  agentmailCodePollInFlight = getAgentMailConfirmationCodeLoop(account, apiKey, baseUrl, timeoutMs)
    .catch((error) => ({ ok: false, error: error.message || String(error) }))
    .finally(() => { agentmailCodePollInFlight = null; });
  return agentmailCodePollInFlight;
}

async function getAgentMailConfirmationCodeLoop(account, apiKey, baseUrl, timeoutMs) {
  const inboxId = account.inbox_id || account.email;
  if (!inboxId) return { ok: false, error: "No inbox found for confirmation code." };

  const startedAt = Date.now();
  let lastError = "No confirmation email yet.";
  // v3.1 BLINK: a message is never fetched twice - the list entry is tried first
  // (subject + preview almost always carry the code), and a full fetch happens
  // only once per message_id, only when the list entry itself had no digits.
  const fullCodeCache = new Map();

  while (Date.now() - startedAt < timeoutMs) {
    const listUrl = `${baseUrl}inboxes/${encodeURIComponent(inboxId)}/messages?limit=10&include_spam=true&include_unauthenticated=true&include_blocked=true`;
    const listed = await fetchJson(listUrl, apiKey);
    if (!listed.ok) {
      lastError = typeof listed.data === "string" ? listed.data : (listed.data.message || JSON.stringify(listed.data));
      await delay(600);   // v3.1 BLINK: recover in 0.6s, not 1.8s
      continue;
    }

    const messages = (listed.data.messages || []).slice();
    // newest first when the API gives us a time
    messages.sort((a, b) => new Date(b.timestamp || b.created_at || b.date || 0) - new Date(a.timestamp || a.created_at || a.date || 0));
    const candidates = messages.filter((message) => {
      const haystack = [message.from, message.subject, message.preview].filter(Boolean).join(" ").toLowerCase();
      return haystack.includes("meta") || haystack.includes("facebook") || haystack.includes("confirmation") || haystack.includes("code");
    });

    for (const item of candidates) {
      // ---- BLINK: one HTTP call is enough when the list entry has the code ----
      const listCode = extractSixDigitCodeFromMessage(item);
      if (listCode) {
        return { ok: true, code: listCode, source: "list", inbox_id: inboxId, email: account.email, message_id: item.message_id, subject: item.subject };
      }
      if (!item.message_id) continue;
      if (fullCodeCache.has(item.message_id)) continue;   // known to carry no code
      const getUrl = `${baseUrl}inboxes/${encodeURIComponent(inboxId)}/messages/${encodeURIComponent(item.message_id)}`;
      const full = await fetchJson(getUrl, apiKey);
      const message = full.ok ? full.data : item;
      const code = extractSixDigitCodeFromMessage(message);
      fullCodeCache.set(item.message_id, code || null);
      if (code) {
        return { ok: true, code, source: "full", inbox_id: inboxId, email: account.email, message_id: message.message_id || item.message_id, subject: message.subject || item.subject };
      }
    }
    // v3.1 BLINK: poll every 240-380 ms instead of every 2000 ms.
    await delay(240 + Math.floor(Math.random() * 140));
  }
  return { ok: false, error: lastError || "Confirmation code not received yet." };
}

async function getBirdConfirmationCode(account, apiKey, baseUrl, timeoutMs) {
  const mailboxId = account.bird_mailbox_id || account.mailbox_id || account.inbox_id;
  if (!mailboxId) return { ok: false, error: "No Baby Mail mailbox found for confirmation code." };

  const startedAt = Date.now();
  let lastError = "No confirmation email yet.";

  while (Date.now() - startedAt < timeoutMs) {
    // Fast path: mailbox messages list endpoint, with extracted_text included when supported.
    const mailboxUrls = [
      `${baseUrl}email/mailboxes/${encodeURIComponent(mailboxId)}/messages?limit=20&include=extracted_text`,
      `${baseUrl}email/mailboxes/${encodeURIComponent(mailboxId)}/messages?limit=20`
    ];
    for (const url of mailboxUrls) {
      const listed = await fetchJson(url, apiKey);
      if (listed.ok) {
        const messages = listed.data.data || listed.data.messages || [];
        for (const message of messages) {
          const haystack = [message.from, message.subject, message.preview, message.extracted_text, message.text].filter(Boolean).join(" ").toLowerCase();
          if (!(haystack.includes("meta") || haystack.includes("facebook") || haystack.includes("confirmation") || haystack.includes("code"))) continue;
          const code = extractSixDigitCodeFromMessage(message);
          if (code) return { ok: true, code, inbox_id: mailboxId, email: account.email, message_id: message.id || message.message_id, subject: message.subject };
        }
      } else {
        lastError = typeof listed.data === "string" ? listed.data : (listed.data?.message || JSON.stringify(listed.data));
      }
    }

    // Thread path from Bird docs.
    const threadsUrl = `${baseUrl}email/threads?mailbox_id=${encodeURIComponent(mailboxId)}&limit=10`;
    const threads = await fetchJson(threadsUrl, apiKey);
    if (threads.ok) {
      const list = threads.data.data || threads.data.threads || [];
      for (const thread of list) {
        const threadId = thread.id || thread.thread_id;
        if (!threadId) continue;
        const messagesUrl = `${baseUrl}email/threads/${encodeURIComponent(threadId)}/messages?limit=20&include=extracted_text`;
        const threadMessages = await fetchJson(messagesUrl, apiKey);
        if (!threadMessages.ok) continue;
        const messages = threadMessages.data.data || threadMessages.data.messages || [];
        for (const message of messages) {
          const haystack = [thread.subject, message.from, message.subject, message.preview, message.extracted_text, message.text].filter(Boolean).join(" ").toLowerCase();
          if (!(haystack.includes("meta") || haystack.includes("facebook") || haystack.includes("confirmation") || haystack.includes("code"))) continue;
          const code = extractSixDigitCodeFromMessage({ ...message, subject: message.subject || thread.subject });
          if (code) return { ok: true, code, inbox_id: mailboxId, email: account.email, message_id: message.id || message.message_id, subject: message.subject || thread.subject };
        }
      }
    } else {
      lastError = typeof threads.data === "string" ? threads.data : (threads.data?.message || JSON.stringify(threads.data));
    }

    await delay(2000);
  }

  return { ok: false, error: lastError || "Confirmation code not received yet." };
}

async function getConfirmationCode(options = {}) {
  const saved = await storageGet([STORAGE.account, STORAGE.apiKey, STORAGE.baseUrl, STORAGE.birdApiKey, STORAGE.birdBaseUrl, STORAGE.mailProvider]);
  let account = saved[STORAGE.account] || {};
  const timeoutMs = options.timeoutMs || 90000;

  if (!account.email) {
    const inbox = await getOrCreateSelectedMail({ forceNew: false });
    if (!inbox.ok) return inbox;
    account = inbox.account || { email: inbox.email, inbox_id: inbox.email };
  }

  const provider = account.mail_provider || saved[STORAGE.mailProvider] || "toxic";
  if (provider === "baby") {
    const apiKey = saved[STORAGE.birdApiKey] || DEFAULT_BIRD_API_KEY;
    const baseUrl = normalizeBirdBaseUrl(saved[STORAGE.birdBaseUrl] || DEFAULT_BIRD_BASE_URL);
    if (!apiKey) return { ok: false, error: "Baby Mail API key missing." };
    return getBirdConfirmationCode(account, apiKey, baseUrl, timeoutMs);
  }

  const apiKey = saved[STORAGE.apiKey] || DEFAULT_API_KEY;
  const baseUrl = normalizeBaseUrl(saved[STORAGE.baseUrl] || DEFAULT_BASE_URL);
  if (!apiKey) return { ok: false, error: "Toxic Mail API key missing." };
  return getAgentMailConfirmationCode(account, apiKey, baseUrl, timeoutMs);
}

const authStuckReloadState = new Map();
const authBlankReloadedOnceState = new Map();

function executeScriptInTab(tabId, func) {
  return new Promise((resolve) => {
    chrome.scripting.executeScript({ target: { tabId }, func }, (results) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve({ ok: true, result: results?.[0]?.result });
    });
  });
}

function authStuckSnapshot() {
  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }

  function parseRgb(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return null;
    return { r: Number(match[1]), g: Number(match[2]), b: Number(match[3]) };
  }

  function isDark(value) {
    const rgb = parseRgb(value);
    if (!rgb) return false;
    return (rgb.r + rgb.g + rgb.b) / 3 < 70;
  }

  const text = (document.body?.innerText || document.body?.textContent || "").replace(/\s+/g, " ").trim();
  const controls = [...document.querySelectorAll("input, textarea, select, iframe, button, [role='button'], [role='checkbox']")].filter(isVisible).length;
  const imgs = [...document.querySelectorAll("img, video, canvas")].filter(isVisible).length;
  const bodyStyle = document.body ? window.getComputedStyle(document.body) : null;
  const htmlStyle = window.getComputedStyle(document.documentElement);
  let dark = isDark(bodyStyle?.backgroundColor) || isDark(htmlStyle.backgroundColor);

  if (!dark) {
    const bigDark = [...document.querySelectorAll("body, main, div, section")].some((el) => {
      if (!isVisible(el)) return false;
      const rect = el.getBoundingClientRect();
      if (rect.width < window.innerWidth * 0.6 || rect.height < window.innerHeight * 0.4) return false;
      return isDark(window.getComputedStyle(el).backgroundColor);
    });
    dark = bigDark;
  }

  const skeletons = [...document.querySelectorAll("div, span")].filter((el) => {
    if (!isVisible(el)) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 30 || rect.height < 8 || rect.height > 80) return false;
    return isDark(window.getComputedStyle(el).backgroundColor);
  }).length;

  const normText = text.toLowerCase();
  const languageLogout =
    (normText.includes("log out") || normText.includes("logout")) &&
    normText.includes("language") &&
    (
      normText.includes("accounts centre") ||
      normText.includes("accounts center") ||
      normText.includes("password, security") ||
      normText.includes("personal details") ||
      normText.includes("connected experiences") ||
      normText.includes("english (uk)") ||
      normText.includes("english")
    );

  const savedAccountLogin =
    (normText.includes("log in with your meta account") || normText.includes("login with your meta account") || normText.includes("continue as")) &&
    (normText.includes("log in to another account") || normText.includes("login to another account") || normText.includes("log into another account") || normText.includes("use another account") || normText.includes("another account"));

  const allowAllCookies =
    normText.includes("allow all cookies") &&
    (
      normText.includes("how we use these cookies") ||
      normText.includes("if you allow these cookies") ||
      normText.includes("if you don't allow these cookies") ||
      normText.includes("if you don’t allow these cookies") ||
      normText.includes("decline optional cookies") ||
      normText.includes("controlling cookies with browser settings") ||
      normText.includes("cookie choices")
    );

  return {
    host: window.location.hostname,
    href: window.location.href,
    readyState: document.readyState,
    textLength: text.length,
    textPreview: text.slice(0, 120),
    languageLogout,
    savedAccountLogin,
    allowAllCookies,
    controls,
    media: imgs,
    dark,
    skeletons,
    bodyWidth: document.body?.getBoundingClientRect().width || 0
  };
}

function clickMetaAllowAllCookiesFromCookiePage() {
  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  function normalizeText(text) {
    return (text || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function getClickableTarget(el) {
    let current = el;
    for (let i = 0; i < 4 && current; i += 1) {
      const role = (current.getAttribute?.("role") || "").toLowerCase();
      const tag = current.tagName;
      if (tag === "BUTTON" || tag === "A" || role === "button" || current.onclick) return current;
      current = current.parentElement;
    }
    return el;
  }
  function clickLikeHuman(target) {
    const rect = target.getBoundingClientRect();
    const x = rect.left + Math.max(2, Math.min(rect.width - 2, rect.width * 0.55));
    const y = rect.top + Math.max(2, Math.min(rect.height - 2, rect.height * 0.55));
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y, view: window }));
    });
  }

  if (window.__agentmailAllowCookiesClickScheduled) {
    return { ok: true, message: "Allow all cookies click already scheduled." };
  }

  const candidates = [...document.querySelectorAll("button, [role='button'], a, div, span")]
    .filter(isVisible)
    .map((el) => {
      const rect = el.getBoundingClientRect();
      return { el, text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")), area: rect.width * rect.height };
    })
    .filter((item) => item.text === "allow all cookies" || item.text.includes("allow all cookies"))
    .filter((item) => item.area > 60 && item.area < 260000)
    .sort((a, b) => {
      const exactA = a.text === "allow all cookies" ? 0 : 1;
      const exactB = b.text === "allow all cookies" ? 0 : 1;
      if (exactA !== exactB) return exactA - exactB;
      return a.area - b.area;
    });

  if (!candidates.length) return { ok: false, message: "Allow all cookies button not found." };
  window.__agentmailAllowCookiesClickScheduled = true;
  clickLikeHuman(getClickableTarget(candidates[0].el));
  [120, 350, 750, 1500].forEach((delay) => {
    setTimeout(() => {
      try { window.__agentmailRunMetaAutomation?.(true); } catch (error) {}
    }, delay);
  });
  setTimeout(() => { window.__agentmailAllowCookiesClickScheduled = false; }, 1500);
  return { ok: true, message: "Allow all cookies clicked; resume queued." };
}

function clickMetaLogoutFromLanguagePage() {
  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  function normalizeText(text) {
    return (text || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function getClickableTarget(el) {
    let current = el;
    for (let i = 0; i < 4 && current; i += 1) {
      const role = (current.getAttribute?.("role") || "").toLowerCase();
      const tag = current.tagName;
      if (tag === "BUTTON" || tag === "A" || role === "button" || current.onclick) return current;
      current = current.parentElement;
    }
    return el;
  }
  function clickLikeHuman(target) {
    const rect = target.getBoundingClientRect();
    const x = rect.left + Math.max(2, Math.min(rect.width - 2, rect.width * 0.55));
    const y = rect.top + Math.max(2, Math.min(rect.height - 2, rect.height * 0.55));
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y, view: window }));
    });
  }

  const candidates = [...document.querySelectorAll("button, [role='button'], a, div, span")]
    .filter(isVisible)
    .map((el) => {
      const rect = el.getBoundingClientRect();
      return {
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rect.width * rect.height,
        top: rect.top
      };
    })
    .filter((item) => item.text === "log out" || item.text === "logout")
    .filter((item) => item.area > 30 && item.area < 120000)
    .sort((a, b) => {
      const topA = a.top < 180 ? 0 : 1;
      const topB = b.top < 180 ? 0 : 1;
      if (topA !== topB) return topA - topB;
      return a.area - b.area;
    });

  if (!candidates.length) return { ok: false, message: "LOG OUT button not found." };
  if (window.__agentmailLogoutClickScheduled) {
    return { ok: true, message: "LOG OUT click already scheduled." };
  }
  window.__agentmailLogoutClickScheduled = true;
  setTimeout(() => {
    const fresh = [...document.querySelectorAll("button, [role='button'], a, div, span")]
      .filter(isVisible)
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return { el, text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")), area: rect.width * rect.height, top: rect.top };
      })
      .filter((item) => item.text === "log out" || item.text === "logout")
      .filter((item) => item.area > 30 && item.area < 120000)
      .sort((a, b) => {
        const topA = a.top < 180 ? 0 : 1;
        const topB = b.top < 180 ? 0 : 1;
        if (topA !== topB) return topA - topB;
        return a.area - b.area;
      });
    if (fresh[0]) clickLikeHuman(getClickableTarget(fresh[0].el));
    setTimeout(() => {
      const again = [...document.querySelectorAll("button, [role='button'], a, div, span")]
        .filter(isVisible)
        .find((el) => {
          const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
          return text === "log out" || text === "logout";
        });
      if (again) clickLikeHuman(getClickableTarget(again));
      window.__agentmailLogoutClickScheduled = false;
    }, 300);
  }, 600);
  return { ok: true, message: "LOG OUT click scheduled." };
}

function clickMetaLoginAnotherAccountFromSavedPage() {
  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  function normalizeText(text) {
    return (text || "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function getClickableTarget(el) {
    let current = el;
    for (let i = 0; i < 4 && current; i += 1) {
      const role = (current.getAttribute?.("role") || "").toLowerCase();
      const tag = current.tagName;
      if (tag === "BUTTON" || tag === "A" || role === "button" || current.onclick) return current;
      current = current.parentElement;
    }
    return el;
  }
  function clickLikeHuman(target) {
    const rect = target.getBoundingClientRect();
    const x = rect.left + Math.max(2, Math.min(rect.width - 2, rect.width * 0.55));
    const y = rect.top + Math.max(2, Math.min(rect.height - 2, rect.height * 0.55));
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y, view: window }));
    });
  }

  const candidates = [...document.querySelectorAll("button, [role='button'], a, div, span")]
    .filter(isVisible)
    .map((el) => {
      const rect = el.getBoundingClientRect();
      return { el, text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")), area: rect.width * rect.height };
    })
    .filter((item) => item.text === "use another account" || item.text === "log in to another account" || item.text === "login to another account" || item.text === "log into another account" || item.text.includes("use another account") || item.text.includes("log in to another account") || item.text.includes("login to another account") || item.text.includes("log into another account"))
    .filter((item) => item.area > 80 && item.area < 260000)
    .sort((a, b) => a.area - b.area);

  if (!candidates.length) return { ok: false, message: "Log in to another account button not found." };
  try { sessionStorage.setItem("agentmail_force_new_email_next", "1"); } catch (error) {}
  clickLikeHuman(getClickableTarget(candidates[0].el));
  return { ok: true, message: "Use another account clicked." };
}

async function checkAndReloadAuthIfStuck(tabId, reason = "auth_stuck") {
  const snapResult = await executeScriptInTab(tabId, authStuckSnapshot);
  if (!snapResult.ok || !snapResult.result) return;
  const snap = snapResult.result;
  if (snap.host !== "auth.meta.com") return;
  if (snap.readyState !== "complete" && snap.readyState !== "interactive") return;

  if (snap.allowAllCookies) {
    await executeScriptInTab(tabId, clickMetaAllowAllCookiesFromCookiePage);
    return;
  }

  if (snap.languageLogout) {
    await executeScriptInTab(tabId, clickMetaLogoutFromLanguagePage);
    return;
  }

  if (snap.savedAccountLogin) {
    await executeScriptInTab(tabId, clickMetaLoginAnotherAccountFromSavedPage);
    return;
  }

  const looksBlank = snap.textLength <= 2 && snap.controls === 0 && snap.media === 0;
  const looksDarkSkeleton = snap.textLength <= 5 && snap.dark && snap.controls <= 1 && snap.skeletons >= 1;

  if (!looksBlank) authBlankReloadedOnceState.delete(tabId);
  if (!looksBlank && !looksDarkSkeleton) return;

  if (looksBlank) {
    if (authBlankReloadedOnceState.get(tabId)) return;
    authBlankReloadedOnceState.set(tabId, true);
    chrome.tabs.reload(tabId, { bypassCache: true }, () => chrome.runtime.lastError);
    return;
  }

  const now = Date.now();
  const last = authStuckReloadState.get(tabId) || 0;
  if (now - last < 10000) return;
  authStuckReloadState.set(tabId, now);
  chrome.tabs.reload(tabId, { bypassCache: true }, () => chrome.runtime.lastError);
}

function scheduleAuthStuckChecks(tabId) {
  [400, 900, 1600, 2600, 4000, 6000, 9000, 14000, 22000, 40000, 70000].forEach((delay) => {
    setTimeout(() => checkAndReloadAuthIfStuck(tabId, `scheduled_${delay}`), delay);
  });
}

function scheduleMetaAutomation(tabId) {
  scheduleAuthStuckChecks(tabId);
  const delays = [50, 130, 260, 480, 800, 1300, 2000, 3200, 5000];

  delays.forEach((delay) => {
    setTimeout(() => {
      chrome.scripting.executeScript(
        {
          target: { tabId, allFrames: true },
          files: ["content.js"]
        },
        () => {
          // Ignore frames/pages where injection is not allowed.
          chrome.runtime.lastError;

          chrome.tabs.sendMessage(
            tabId,
            { type: "AGENTMAIL_RUN_META_AUTOMATION", force: true },
            () => chrome.runtime.lastError
          );
        }
      );
    }, delay);
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    agentmail_installed_at: new Date().toISOString(),
    [STORAGE.apiKey]: DEFAULT_API_KEY,
    [STORAGE.baseUrl]: DEFAULT_BASE_URL,
    [STORAGE.birdApiKey]: DEFAULT_BIRD_API_KEY,
    [STORAGE.birdBaseUrl]: DEFAULT_BIRD_BASE_URL,
    [STORAGE.mailProvider]: "toxic"
  });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url || tab?.url || "";
  if (isAuthMetaUrl(url) && (changeInfo.status === "loading" || changeInfo.status === "complete" || changeInfo.url)) {
    scheduleMetaAutomation(tabId);
  }
});

// The popup window keeps a port open while it lives. When it disconnects the
// popup is gone for sure - tell every tab so the page side always recovers
// (this is the fix for "popup opened once, then the orb never worked again").
chrome.runtime.onConnect.addListener((port) => {
  if (!port || port.name !== "agentmail-popup") return;
  port.onDisconnect.addListener(() => {
    try {
      chrome.tabs.query({}, (tabs) => {
        for (const tab of tabs || []) {
          if (!tab || typeof tab.id !== "number") continue;
          try {
            chrome.tabs.sendMessage(tab.id, { type: "AGENTMAIL_POPUP_CLOSE" }, () => { void chrome.runtime.lastError; });
          } catch (error) {}
        }
      });
    } catch (error) {}
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") return false;

  if (message.type === "AGENTMAIL_OPEN_EXTENSION_POPUP") {
    try {
      if (chrome.action && typeof chrome.action.openPopup === "function") {
        const maybePromise = chrome.action.openPopup();
        if (maybePromise && typeof maybePromise.then === "function") {
          maybePromise
            .then(() => sendResponse({ ok: true }))
            .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
          return true;
        }
        sendResponse({ ok: true });
        return false;
      }
      sendResponse({ ok: false, error: "Popup open is not supported in this browser." });
      return false;
    } catch (error) {
      sendResponse({ ok: false, error: error.message || String(error) });
      return false;
    }
  }

  if (message.type === "OPEN_START") {
    (async () => {
      let prepared = null;

      if (message.prepareEmail) {
        prepared = await getOrCreateSelectedMail({ forceNew: Boolean(message.forceNewEmail), provider: message.provider });
        if (!prepared.ok) {
          sendResponse(prepared);
          return;
        }
      }

      chrome.tabs.create({ url: START_URL }, (tab) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }

        if (tab?.id) scheduleMetaAutomation(tab.id);
        sendResponse({
          ok: true,
          tabId: tab?.id,
          email: prepared?.email,
          account: prepared?.account,
          reused: prepared?.reused
        });
      });
    })().catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === "AGENTMAIL_GET_OR_CREATE_EMAIL") {
    getOrCreateSelectedMail({ forceNew: Boolean(message.forceNew), provider: message.provider })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === "AGENTMAIL_SET_MAIL_PROVIDER") {
    const provider = message.provider === "baby" ? "baby" : "toxic";
    storageSet({ [STORAGE.mailProvider]: provider })
      .then(() => sendResponse({ ok: true, provider, label: providerLabel(provider) }))
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === "AGENTMAIL_SAVE_CURRENT_ACCOUNT") {
    markCurrentAccountSuccessful(message.source || "Logout")
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === "AGENTMAIL_GET_PASSWORD") {
    getSavedPassword()
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === "AGENTMAIL_GET_CONFIRMATION_CODE") {
    getConfirmationCode({ timeoutMs: message.timeoutMs || 90000 })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }



  if (message.type === "AGENTMAIL_FORCE_RELOAD_TAB") {
    const tabId = sender?.tab?.id;
    if (!tabId) {
      sendResponse({ ok: false, error: "No sender tab found." });
      return false;
    }
    chrome.tabs.reload(tabId, { bypassCache: true }, () => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.type === "AGENTMAIL_GO_TO_LANGUAGE_TARGET" || message.type === "AGENTMAIL_CLICK_META_LOGOUT") {
    const tabId = sender?.tab?.id;
    if (!tabId) {
      sendResponse({ ok: false, error: "No sender tab found." });
      return false;
    }
    executeScriptInTab(tabId, clickMetaLogoutFromLanguagePage)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  return false;
});
