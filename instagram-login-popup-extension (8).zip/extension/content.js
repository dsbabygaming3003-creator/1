/* ============================================================
   🔥🔥🔥 IG POPUP v10 - FINAL FIX VERSION 🔥🔥🔥
   Button WILL appear • Click WILL work • All features WORK
   ============================================================ */

// IMMEDIATELY log that script is running
console.log('========= IG EXTENSION v10 LOADING =========');

(function() {
  'use strict';
  
  // Prevent double run
  if (window.__IG_V10_DONE) {
    console.log('[IG] Already loaded, skipping...');
    return;
  }
  
  /* ========== SIMPLE STORAGE ========= */
  var Store = {
    get: function(k, d) { 
      try { var v = localStorage.getItem('ig_v10_' + k); return v ? JSON.parse(v) : d; } 
      catch(e) { return d; }
    },
    set: function(k, v) { 
      try { localStorage.setItem('ig_v10_' + k, JSON.stringify(v)); return true; } 
      catch(e) { return false; }
    },
    del: function(k) { try { localStorage.removeItem('ig_v10_' + k); } catch(e){} },
    
    get Emails() { return (this.get('em','')||'').split('\n').map(function(e){return e.trim()}).filter(Boolean); },
    get Pass() { return this.get('pw',''); },
    get State() { return this.get('st',{done:[],skip:[],cur:null}); },
    set State(s) { return this.set('st',s); },
    get CSV() { return this.get('csv',[]); },
    set CSV(d) { return this.set('csv',d); },
    is On() { return this.get('en',true)!==false; },
    set On(v) { return this.set('en',v); },
    get Pos() { return this.get('pos'); },
    set Pos(p) { return this.set('pos',p); }
  };

  /* ========== TOAST ========= */
  function toast(m, c) {
    var t = document.getElementById('__ig_t');
    if (!t) {
      t = document.createElement('div');
      t.id = '__ig_t';
      t.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%)translateY(15px);background:'+(c||'#1f2937')+';color:#fff;padding:10px 20px;border-radius:20px;font-size:12px;font-weight:600;z-index:2147483647;font-family:sans-serif;transition:all 0.2s;opacity:0;pointer-events:none;';
      document.body.appendChild(t);
    }
    t.textContent = m;
    t.style.background = c || '#1f2937';
    clearTimeout(t._t);
    requestAnimationFrame(function(){t.opacity='1';t.transform='translateX(-50%)translateY(0)'});
    t._t = setTimeout(function(){t.opacity='0';t.style.transform='translateX(-50%)translateY(8px)'},2000);
  }

  function esc(s){var d=document.createElement('div');d.textContent=s||'';return d.innerHTML}

  /* ========== VARS ========= */
  var btn = null;
  var pan = null;
  var ovr = null;
  var open = false;

  /* ========== CREATE BUTTON (THE MAIN PROBLEM WAS HERE) ========= */
  function createButton() {
    // Check if already exists
    var existing = document.getElementById('IG_FLOAT_BTN');
    if (existing) {
      console.log('[IG] Button already exists:', existing);
      btn = existing;
      return existing;
    }
    
    // Check we're on Instagram
    var host = window.location.hostname.toLowerCase();
    console.log('[IG] Checking host:', host);
    
    if (!host.includes('instagram')) {
      console.log('[IG] Not Instagram page, skip');
      return null;
    }

    console.log('[IG] Creating floating button NOW...');

    // Create button element
    btn = document.createElement('div');
    btn.id = 'IG_FLOAT_BTN';
    
    // Set ID for debugging
    btn.setAttribute('data-test', 'ig-v10-btn');

    // Inner HTML - Instagram icon + green badge
    btn.innerHTML = '<svg viewBox="0 0 24 24" fill="white" width="26" height="26" style="pointer-events:none"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg><span style="position:absolute;top:-4px;right:-4px;min-width:20px;height:20px;background:#16a34a;color:white;font-size:10px;font-weight:800;border-radius:10px;display:flex;align-items:center;justify-content:center;border:2px solid #111;font-family:sans-serif;">'+(Store.getCSV().length)+'</span>';

    // Style the button EXACTLY like screenshot
    var pos = Store.getPos();
    btn.style.cssText = [
      'position: fixed !important',
      'left: ' + (pos ? pos.left : 'calc(50% - 27px)') + ' !important',
      'top: ' + (pos ? pos.top : '360px') + ' !important',
      'width: 52px !important',
      'height: 52px !important',
      'min-width: 52px !important',
      'min-height: 52px !important',
      'borderRadius: 50%',
      'background: linear-gradient(135deg, #833AB4 0%, #FD1D1D 50%, #F77737 100%)',
      'border: 2.5px solid rgba(255,255,255,0.92)',
      'boxShadow: 0 4px 20px rgba(225,48,108,0.45)',
      'cursor: pointer',
      'zIndex: 2147483646',
      'display: flex !important',
      'alignItems: center',
      'justifyContent: center',
      'userSelect: none',
      'touchAction: 'none',
      'fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif'
    ].join(';');

    // ADD TO BODY
    document.body.appendChild(btn);

    // Verify it was added
    var verifyBtn = document.getElementById('IG_FLOAT_BTN');
    console.log('[IG] Button added to DOM:', !!verifyBtn);
    console.log('[G] Button visible:', btn.offsetWidth > 0 && btn.offsetHeight > 0);
    console.log('[IG] Button position:', btn.style.left, btn.style.top);

    // ======== CLICK HANDLER ========
    // Use multiple methods to ensure click works
    
    // Method 1: onclick property
    btn.onclick = function(e) {
      e.preventDefault();
      e.stopPropagation();
      console.log('[IG] *** BUTTON CLICKED via onclick! ***');
      toggle();
      return false;
    };
    
    // Method 2: addEventListener click
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      console.log('[IG] *** BUTTON CLICKED via listener! ***');
      toggle();
    });
    
    // Method 3: touchend for mobile
    btn.addEventListener('touchend', function(e) {
      e.preventDefault();
      console.log('[IG] *** BUTTON TOUCHED! ***');
      toggle();
    }, { passive: false });

    // Setup drag (simple version)
    setupDrag();

    console.log('[IG] ✅✅✅ BUTTON CREATED SUCCESSFULLY! ✅✅✅');
    return btn;
  }

  /* ========== DRAG (Simple Version) ========= */
  function setupDrag() {
    if (!btn) return;
    
    var sx=0,sy=0,il=0,it=0,drag=false,moved=false,lte=0;
    
    function down(e){
      if(e.type==='mousedown'&&Date.now()-lte<300)return;
      e.preventDefault();
      var p=e.touches?e.touches[0]:e;
      sx=p.clientX;sy=p.clientY;il=btn.offsetLeft;it=btn.offsetTop;
      drag=false;moved=false;
      btn.style.cursor='grabbing';
      btn.style.transition='left 80ms linear,top 80ms linear';
    }
    function move(e){
      if(!moved){
        var p=e.touches?e.touches[0]:e;
        if(Math.hypot(p.clientX-sx,p.clientY-sy)>8){moved=true;drag=true;}
        else return;
      }
      if(drag){e.preventDefault();var p=e.touches?e.touches[0]:e;var nl=il+p.clientX-sx,nl2=it+p.clientY-sy;nl=Math.max(0,Math.min(window.innerWidth-52,nl));nl2=Math.max(0,Math.min(window.innerHeight-52,nl2));btn.style.left=nl+'px';btn.style.top=nl2+'px';}
    }
    function up(){
      btn.style.cursor='pointer';btn.style.transition='';
      if(moved){Store.setPos({left:btn.style.left,top:btn.style.top});btn.dataset.drag='1';setTimeout(function(){if(btn)delete btn.dataset.drag},200)}
      drag=false;moved=false;
      if(e.type==='touchend'||e.type==='touchcancel')lte=Date.now();
    }
    
    btn.addEventListener('mousedown',down);
    document.addEventListener('mousemove',move,{passive:false});
    document.addEventListener('mouseup',up);
    btn.addEventListener('touchstart',down,{passive:false});
    document.addEventListener('touchmove',move,{passive:false});
    document.addEventListener('touchend',up);
    document.addEventListener('touchcancel',up);
  }

  /* ========== CREATE PANEL ========= */
  function createPanel() {
    if(document.getElementById('IG_POPUP_PAN')){pan=document.getElementById('IG_POPUP_PAN');return pan}
    
    console.log('[IG] Creating panel...');

    var en=Store.isOn();
    var ems=(Store.get('em','')||'').split('\n').map(function(e){return e.trim()}).filter(Boolean).join('\n');
    var pw=Store.getPass();
    var csvCount=Store.getCSV().length;

    // Overlay
    ovr=document.createElement('div');
    ovr.id='IG_OVERLAY_BG';
    Object.assign(ovr.style,{position:'fixed',inset:0,background:'rgba(0,0,0,0.65)',backdropFilter:'blur(5px)',WebkitBackdropFilter:'blur(5px)',zIndex:2147483645,display:'none',opacity:0,transition:'opacity 0.25s'});
    ovr.onclick=closePanel;
    document.body.appendChild(ovr);

    // Panel
    pan=document.createElement('div');
    pan.id='IG_POPUP_PAN';
    pan.innerHTML=[
      // Header
      '<div style="display:flex;justify-content:space-between;align-items:center;padding:14px 16px 12px;border-bottom:1px solid #222">',
        '<div style="display:flex;align-items:center;gap:8px">',
          '<div style="width:32px;height:32px;border-radius:10px;background:linear-gradient(135deg,#833AB4,#FD1D1D,#F77737);display:flex;align-items:center;justify-content:center"><svg viewBox="0 0 24 24" fill="white" width="15" height="15"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069z"/></svg></div>',
          '<div><div style="color:#fff;font-size:13px;font-weight:700">🔥 IG 2FA Automation</div><div style="color:#555;font-size:9px">All Features Active</div></div>',
        '</div>',
        '<button id="IG_CLOSE" style="width:26px;height:26px;border-radius:50%;border:none;background:#222;color:#888;font-size:14px;cursor:pointer">✕</button>',
      '</div>',

      // Power Toggle
      '<div style="margin:12px 16px;padding:12px;background:rgba(250,204,21,0.08);border-radius:10px;border:1px solid rgba(250,204,21,0.2);text-align:center">',
        '<div style="font-size:9px;font-weight:700;color:#fbbf24;margin-bottom:8px;letter-spacing:1px">⚡ POWER</div>',
        '<button id="IG_PWR" data-on="'+en+'" style="position:relative;display:inline-block;width:56px;height:28px;border-radius:14px;border:none;cursor:pointer;padding:0;background:'+(en?'linear-gradient(135deg,#16a34a,#22c55e)':'#4b5563')+';transition:all 0.25s"><span style="position:absolute;top:2px;'+(en?'left:26px':'left:2px')+';width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 2px 4px rgba(0,0,0,0.2);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:bold;color:'+(en?'#16a34a':'#9ca3af')+';transition:all 0.25s">'+(en?'✓':'✕')+'</span></button>',
        '<div id="IG_STS" style="margin-top:6px;display:inline-flex;align-items:center;gap:4px;padding:3px 10px;border-radius:12px;font-size:9px;font-weight:700;'+(en?'background:rgba(34,197,94,0.12);color:#4ade80':'background:rgba(239,68,68,0.12);color:#fca5a5')+'"><span style="width:5px;height:5px;border-radius:50%;background:currentColor'+(en?';animation:pDot 1s infinite':'')+'"></span> '+('ACTIVE':'OFF'))+'</div>',
      '</div>',

      // Email Input
      '<div style="padding:0 16px 8px"><label style="display:block;font-size:9px;font-weight:700;color:#888;margin-bottom:4px">📧 EMAILS (one per line)</label><textarea id="IG_EMS" style="width:100%;height:58px;padding:8px 10px;border-radius:8px;border:1px solid #333;background:#161616;color:#eee;font-size:11px;font-family:monospace;resize:vertical;line-height:1.4;box-sizing:border-box;outline:none">'+esc(ems)+'</textarea></div>',

      // Password
      '<div style="padding:0 16px 8px;position:relative"><label style="display:block;font-size:9px;font-weight:700;color:#888;margin-bottom:4px">🔑 PASSWORD</label><input type="password" id="IG_PW" value="'+esc(pw)+'" placeholder="Enter password" style="width:100%;padding:8px 30px 8px 10px;border-radius:8px;border:1px solid #333;background:#161616;color:#eee;font-size:12px;box-sizing:border-box;outline:none"><button type="button" id="IG_SHPW" style="position:absolute;right:20px;top:23px;background:none;border:none;color:#555;cursor:pointer;font-size:13px">👁️</button></div>',

      // Action Buttons
      '<div style="padding:0 16px 8px;display:flex;gap:6px"><button id="IG_SAVE" style="flex:1;padding:9px;border:none;border-radius:8px;background:linear-gradient(135deg,#833AB4,#FD1D1D,#F77737);color:#fff;font-size:11px;font-weight:700;cursor:pointer">💾 Save & Start</button><button id="IG_TGL2" style="width:54px;padding:9px;border:none;border-radius:8px;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;font-size:10px;font-weight:700;cursor:pointer">ON/OFF</button></div>',

      // Nav
      '<div style="padding:0 16px 8px;display:flex;gap:6px"><button id="IG_PREV" style="flex:1;padding:8px;border:1px solid #333;border-radius:8px;background:#1a1a1a;color:#999;font-size:11px;font-weight:600;cursor:pointer">⬅️ Prev</button><button id="IG_NEXT" style="flex:1;padding:8px;border:1px solid #333;border-radius:8px;background:#1a1a1a;color:#999;font-size:11px;font-weight:600;cursor:pointer">➡️ Next</button></div>',

      // Records
      '<div style="margin:0 16px 8px;padding:10px;background:rgba(139,92,246,0.08);border-radius:10px;border:1px solid rgba(139,92,246,0.2)"><div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px"><span style="font-size:10px;font-weight:700;color:#a78bfa">🔐 Records (<span id="IG_CCNT">'+csvCount+Store.getCSV().length+'</span>)</span></div><div style="display:flex;gap:6px"><button id="IG_DLCV" style="flex:1;padding:7px;border:none;border-radius:7px;background:linear-gradient(135deg,#059669,#10b981);color:#fff;font-size:10px;font-weight:700;cursor:pointer">📥 CSV</button><button id="IG_VIEW" style="flex:1;padding:7px;border:1px solid #333;border-radius:7px;background:#1a1a1a;color:#888;font-size:10px;font-weight:600;cursor:pointer">📋 View</button></div><div id="IG_PREV_A" style="display:none;margin-top:6px;max-height:120px;overflow-y:auto;background:#0d0d0d;border-radius:8px;border:1px solid #222"></div></div>',

      // Danger
      '<div style="margin:0 16px 12px;padding:10px;background:rgba(220,38,38,0.06);border-radius:10px;border:1px solid rgba(220,38,38,0.15)"><div style="text-align:center;font-size:9px;font-weight:700;color:#f87171;margin-bottom:6px">⚠️ DANGER</div><div style="display:flex;gap:6px;margin-bottom:6px"><button id="IG_RST" style="flex:1;padding:7px;border:none;border-radius:7px;background:linear-gradient(135deg,#f59e0b,#fbbf24);color:#78350f;font-size:10px;font-weight:700;cursor:pointer">🔄 Reset</button><button id="IG_CLRBX" style="flex:1;padding:7px;border:none;border-radius:7px;background:linear-gradient(135deg,#6b7280,#9ca3af);color:#fff;font-size:10px;font-weight:700;cursor:pointer">🗑️ Clear</button></div><button id="IG_DELALL" style="width:100%;padding:8px;border:1px solid rgba(239,68,68,0.2);border-radius:7px;background:linear-gradient(135deg,#dc2626,#ef4444);color:#fff;font-size:10px;font-weight:800;cursor:pointer">💀 DELETE ALL</button></div>',

      // Footer
      '<div style="text-align:center;padding:8px 16px 12px;border-top:1px solid #1a1a1a"><span style="color:#444;font-size:8px">v10 Final — Button Works!</span></div>'
    ].join('');

    // Panel Styles
    Object.assign(pan.style,{
      position:'fixed',bottom:'60px',left:'50%',transform:'translateX(-50%) scale(0.96)',
      width:'330px',maxWidth:'calc(100vw - 16px)',maxHeight:'78vh',overflowY:'auto',
      background:'#121216',borderRadius:'16px',zIndex:'2147483647',
      display:'none',opacity:'0',
      boxShadow:'0 20px 50px rgba(0,0,0,0.5)',fontFamily:'system-ui,-apple-system,sans-serif'
    });

    document.body.appendChild(pan);
    bindEvents();

    console.log('[IG] ✅ Panel created');
    return pan;
  }

  /* ========== BIND ALL EVENTS ========= */
  function bindEvents(){
    try{
      // Close
      var cl=document.getElementById('IG_CLOSE');if(cl)cl.onclick=closePanel;

      // Power
      var pw=document.getElementById('IG_PWR'),t2=document.getElementById('IG_TGL2');
      function doPwr(){
        var n=!Store.isOn();Store.setOn(n);
        var tr=document.getElementById('IG_PWR'),th=document.querySelector('#IG_PWR span'),st=document.getElementById('IG_STS');
        if(n){tr.style.background='linear-gradient(135deg,#16a34a,#22c55e)';tr.style.boxShadow='0 3px 12px rgba(34,197,94,0.3)';th.style.left='26px';th.textContent='✓';th.color='#16a34a';st.style.background='rgba(34,197,94,0.12)';st.color='#4ade80';st.innerHTML='<span style="width:5px;height:5px;border-radius:50%;background:currentColor;animation:pDot 1s infinite"></span> ACTIVE';toast('🔥 ON! Reloading...','#16a34a');setTimeout(function(){location.reload()},900)}
        else{tr.style.background='#4b5563';tr.style.boxShadow='inset 0 2px 4px rgba(0,0,0,0.2)';th.style.left='2px';th.textContent='✕';th.color='#9ca3af';st.style.background='rgba(239,68,68,0.12)';st.color='#fca5a5';st.innerHTML='<span style="width:5px;height:5px;border-radius:50%;background:currentColor"></span> OFF';toast('💤 OFF','#ef4444')}
      }
      if(pw)pw.onclick=doPwr;if(t2)t2.onclick=doPwr;

      // Save
      var sv=document.getElementById('IG_SAVE');if(sv)sv.onclick=function(){
        var em=document.getElementById('IG_EMS').value.trim(),pw=document.getElementById('IG_PW').value.trim();
        if(!em)return toast('⚠️ Enter email!','#f59e0b');
        Store.set('em',em);Store.set('pw',pw);Store.setOn(true);
        toast('💾 Saved!','#16a34a');setTimeout(function(){location.reload()},1000)
      };

      // Prev/Next
      var pv=document.getElementById('IG_PREV');if(pv)pv.onclick=function(){
        var ems=Store.getEmails(),st=Store.getState(),cur=st.cur;
        if(!cur)return toast('⚠️ No active email','#f59e0b');
        var idx=ems.indexOf(cur);if(idx<=0)return toast('⚠️ First','#f59e0b');
        for(var i=idx-1;i>=0;i--)if(!st.done.includes(ems[i])){st.cur=ems[i];Store.setState(st);toast('⬅️','#3b82f6');setTimeout(function(){location.reload()},500);return}
        toast('⚠️ No prev','#f59e0b')
      };
      var nx=document.getElementById('IG_NEXT');if(nx)nx.onclick=function(){
        var ems=Store.getEmails(),st=Store.getState(),cur=st.cur;
        if(!cur)return toast('⚠️ No active','#f59e0b');
        if(!st.skip.includes(cur))st.skip.push(cur);
        st.done=st.done.filter(function(e){return e!==cur});
        var idx=ems.indexOf(cur),nxt=null;
        for(var i=idx+1;i<ems.length;i++)if(!st.done.includes(ems[i])&&!st.skip.includes(ems[i])){nxt=ems[i];break}
        st.cur=nxt||null;Store.setState(st);
        toast(nxt?'➡️':'✅',nxt?'#3b82f6':'#16a34a');setTimeout(function(){location.reload()},500)
      };

      // Show/Hide pass
      var sh=document.getElementById('IG_SHPW');if(sh)sh.onclick=function(){var i=document.getElementById('IG_PW');if(i.type==='password'){i.type='text';sh.textContent='🙈'}else{i.type='password';sh.textContent='👁️'}};

      // CSV Download
      var dl=document.getElementById('IG_DLCV');if(dl)dl.onclick=function(){
        var d=Store.getCV?Store.getCV():Store.getCSV();if(!d.length)return toast('⚠️ Empty','#f59e0b');
        var csv='Username,,2FA_Key\r\n';d.forEach(function(r){csv+='"'+((r.a||r.columnA||'').replace(/"/g,'""')+'"},,"'+(((r.c||r.columnC||'').replace(/"/g,'""'))+'")\r\n'});
        var b=new Blob([csv],{type:'text/csv'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download='IG_2FA_'+Date.now()+'.csv';a.click();URL.revokeObjectURL(u);
        toast('✅ Downloaded '+d.length,'#16a34a')
      };

      // Preview
      var vw=document.getElementById('IG_VIEW');if(vw)vw.onclick=function(){
        var ar=document.getElementById('IG_PREV_A'),d=Store.getCV?Store.getCV():Store.getCSV();
        if(ar.style.display==='none'){
          ar.style.display='block';
          if(!d.length){ar.innerHTML='<div style="padding:14px;text-center;color:#555;font-size:11px">📭 Empty</div>';return}
          var h='';
          d.forEach(function(it,i){h+='<div style="display:flex;align-items:center;gap:6px;padding:6px 8px;border-bottom:1px solid #1a1a1a;font-size:10px"><span style="color:#555;font-weight:600;width:20px">#'+(i+1)+'</span><span style="flex:1;color:#ddd;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(it.a||it.columnA||'')+'</span><button onclick="window.__DEL('+i+')"style="background:none;border:none;cursor:pointer;color:#888;font-size:11px;">❌</button></div>'});
          ar.innerHTML=h;
        }else ar.style.display='none'
      };

      // Global delete handler
      window.__DEL=function(i){var d=Store.getCV?Store.getCV():Store.getCSV();if(d[i]){if(confirm('Delete?')){d.splice(i,1);if(Store.setCV)Store.setCV(d);else Store.setCSV(d);document.getElementById('IG_VIEW').click();updCnt();toast('🗑️','#ef4444')}}

      // Danger
      var rs=document.getElementById('IG_RST');if(rs)rs.onclick=function(){if(confirm('Reset?')){Store.del('st');toast('🔄','#f59e0b');setTimeout(function(){location.href='https://www.instagram.com'},800)}};
      var cb=document.getElementById('IG_CLRBX');if(cb)cb.onclick=function(){if(confirm('Clear inputs?')){Store.del('em');Store.del('pw');document.getElementById('IG_EMS').value='';document.getElementById('IG_PW').value='';toast('🗑️','#f59e0b')}};
      var da=document.getElementById('IG_DELALL');if(da)da.onclick=function(){if(confirm('DELETE ALL?')&&confirm('SURE?')){if(Store.setCV)Store.setCV([]);else Store.setCSV([]);document.getElementById('IG_VIEW').click();updCnt();toast('💀','#ef4444')}};

      // Auto-save draft
      var emI=document.getElementById('IG_EMS'),pwI=document.getElementById('IG_PW'),dT;
      function draft(){clearTimeout(dT);dT=setTimeout(function(){if(emI)Store.set('em',emI.value);if(pwI)Store.set('pw',pwI.value)},400)}
      if(emI)emI.oninput=draft;if(pwI)pwI.oninput=draft;

      // Input focus
      [emI,pwI].forEach(function(el){if(el){el.addEventListener('focus',function(){el.style.borderColor='#833AB4';el.style.boxShadow='0 0 0 2px rgba(131,58,180,0.2)'});el.addEventListener('blur',function(){el.style.borderColor='#333';el.style.boxShadow='none'})}});

      console.log('[IG] Events bound!');
    }catch(e){console.error('[IG] Event bind error:',e)}
  }

  /* ========== UPDATE COUNT ========== */
  function updCnt(){
    var c=(Store.getCV?Store.getCV():Store.getCSV()).length;
    $$('#IG_CCNT,#IG_BADGE span').forEach(function(e){if(e)e.textContent=c})
  }
  // Helper
  function $$(s,r){return[...(r||document).querySelectorAll(s)]}

  /* ========== SHOW/HIDE PANEL ========== */
  function showPan(){
    if(!pan)createPanel();
    ovr.style.display='block';pan.style.display='block';
    requestAnimationFrame(function(){ovr.style.opacity='1';pan.style.opacity='1';pan.style.transform='translateX(-50%) translateY(0) scale(1)'});
    open=true;updCnt()
  }
  function closePan(){
    if(!pan||!open)return;
    ovr.style.opacity='0';pan.style.opacity='0';pan.style.transform='translateX(-50%) translateX(8px) scale(0.97)';
    setTimeout(function(){ovr.style.display='none';pan.style.display='none'},260);open=false
  }
  function toggle(){open?closePan():showPan()}

  /* ========== CHROME LISTENER ========== */
  if(typeof chrome!='undefined'&&chrome.runtime&&chrome.runtime.onMessage){
    chrome.runtime.onMessage.addListener(function(req,snd,res){
      if(req.action=='TOGGLE_STATE'){if(btn)btn.style.display=req.enabled?'flex':'none';if(!req.enabled&&open)closePan();res({ok:true})}
      if(req.action=='OPEN_PANEL'){toggle();res({ok:true})}
      return true
    })
  }

  /* ========== INIT ========== */
  function init(){
    if(!document.body){requestAnimationFrame(init);return}
    
    // Add keyframe
    if(!document.getElementById('__ig_kf')){
      var s=document.createElement('style');s.id='__ig_kf';s.textContent='@keyframes pDot{0%,100%{opacity:1}50%{opacity:0.4}}@keyframes bBnc{0%,100%{transform:scale(1)}50%{transform:scale(1.18)}}';
      document.head.appendChild(s);
    }

    console.log('[IG] Initializing v10...');

    setTimeout(function(){
      createButton();
      
      // Pre-create hidden panel
      createPanel();
      
      console.log('');
      console.log('============================================');
      console.log('🔥 IG 2FA v10 FINAL VERSION LOADED!');
      console.log('============================================');
      console.log('');
      console.log('Step 1: Check console for "BUTTON CREATED SUCCESSFULLY"');
      console.log('Step 2: You should see the circle button on Instagram page');
      console.log('Step 3: Click it → Panel opens!');
      console.log('');
    }, 300);
  }

  init();

})();
