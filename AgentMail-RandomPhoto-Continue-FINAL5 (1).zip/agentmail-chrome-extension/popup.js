function decodePackedSecret(parts) {
  try { return atob(parts.join("")); } catch (error) { return ""; }
}
function getMasterTeamApiConfig() { return window.MASTER_TEAM_BACKEND_API || {}; }
function secretFromConfig(plain, parts) {
  if (plain && String(plain).trim()) return String(plain).trim();
  return decodePackedSecret(parts || []);
}
const DEFAULT_API_KEY = secretFromConfig(getMasterTeamApiConfig().toxicApiKey, getMasterTeamApiConfig().toxicApiKeyParts);
const DEFAULT_BASE_URL = getMasterTeamApiConfig().toxicBaseUrl || "https://api.agentmail.to/v0/";
const DEFAULT_BIRD_API_KEY = secretFromConfig(getMasterTeamApiConfig().babyApiKey, getMasterTeamApiConfig().babyApiKeyParts);
const DEFAULT_BIRD_BASE_URL = getMasterTeamApiConfig().babyBaseUrl || "https://us1.platform.bird.com/v1/";
const DEFAULT_PASSWORD = "FAHAD@10";
const START_URL = "http://auth.meta.com/?waterfall_id";

const STORAGE = {
  account: "agentmail_account",
  accounts: "agentmail_accounts",
  apiKey: "agentmail_api_key",
  baseUrl: "agentmail_base_url",
  mailProvider: "agentmail_mail_provider",
  birdApiKey: "agentmail_bird_api_key",
  birdBaseUrl: "agentmail_bird_base_url"
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const state = {
  account: {},
  accounts: [],
  apiKey: DEFAULT_API_KEY,
  baseUrl: DEFAULT_BASE_URL,
  mailProvider: "toxic",
  birdApiKey: DEFAULT_BIRD_API_KEY,
  birdBaseUrl: DEFAULT_BIRD_BASE_URL
};

const els = {
  miniStatus: $("#miniStatus"),
  menuButtons: $$(".menu-btn[data-panel]"),
  panels: $$(".panel"),
  startBtn: $("#startBtn"),
  toxicMailBtn: $("#toxicMailBtn"),
  babyMailBtn: $("#babyMailBtn"),
  selectedProviderLabel: $("#selectedProviderLabel"),
  selectedEmail: $("#selectedEmail"),
  selectedPassword: $("#selectedPassword"),
  copyEmailBtn: $("#copyEmailBtn"),
  copyPasswordBtn: $("#copyPasswordBtn"),
  fillEmailBtn: $("#fillEmailBtn"),
  fillPasswordBtn: $("#fillPasswordBtn"),
  passwordInput: $("#passwordInput"),
  generatePasswordBtn: $("#generatePasswordBtn"),
  savePasswordBtn: $("#savePasswordBtn"),
  accountEmail: $("#accountEmail"),
  accountPassword: $("#accountPassword"),
  accountInboxId: $("#accountInboxId"),
  accountStartUrl: $("#accountStartUrl"),
  copyAccountBtn: $("#copyAccountBtn"),
  resetAccountBtn: $("#resetAccountBtn"),
  accountList: $("#accountList"),
  accountCount: $("#accountCount"),
  copyAllAccountsBtn: $("#copyAllAccountsBtn"),
  downloadAccountsTxtBtn: $("#downloadAccountsTxtBtn"),
  clearAccountListBtn: $("#clearAccountListBtn"),
  apiKeyInput: $("#apiKeyInput"),
  baseUrlInput: $("#baseUrlInput"),
  birdApiKeyInput: $("#birdApiKeyInput"),
  birdBaseUrlInput: $("#birdBaseUrlInput"),
  saveSettingsBtn: $("#saveSettingsBtn"),
  toast: $("#toast")
};

function normalizeBaseUrl(url) {
  const clean = (url || DEFAULT_BASE_URL).trim();
  return clean.endsWith("/") ? clean : `${clean}/`;
}

function normalizeBirdBaseUrl(url) {
  const clean = (url || DEFAULT_BIRD_BASE_URL).trim();
  return clean.endsWith("/") ? clean : `${clean}/`;
}

function chromeStorageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

function chromeStorageSet(value) {
  return new Promise((resolve) => chrome.storage.local.set(value, resolve));
}

function chromeStorageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function showToast(message, type = "ok") {
  els.toast.textContent = message;
  els.toast.className = `toast show ${type}`;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    els.toast.className = "toast";
  }, 2800);
}

function setStatus(message) {
  els.miniStatus.textContent = message;
}


function setLoading(button, isLoading) {
  if (!button) return;
  button.classList.toggle("loading", isLoading);
  button.disabled = isLoading;
}

function providerLabel(provider = state.mailProvider) {
  return provider === "baby" ? "Baby mail" : "Toxic mail";
}

function maskSecret(value) {
  if (!value) return "Not set";
  if (value.length <= 8) return "•".repeat(value.length);
  return `${value.slice(0, 2)}${"•".repeat(Math.min(10, value.length - 4))}${value.slice(-2)}`;
}

function accountRecordFrom(account = {}, source = "") {
  if (!account.email) return null;
  return {
    email: account.email,
    password: account.password || state.account.password || DEFAULT_PASSWORD,
    inbox_id: account.inbox_id || account.email,
    pod_id: account.pod_id || "",
    provider: account.provider || providerLabel(account.mail_provider || state.mailProvider),
    mail_provider: account.mail_provider || state.mailProvider,
    source,
    created_at: account.created_at || account.mail_created_at || new Date().toISOString(),
    saved_at: new Date().toISOString()
  };
}

async function upsertAccountList(account = {}, source = "") {
  const record = accountRecordFrom(account, source);
  if (!record) return;

  const existingIndex = state.accounts.findIndex((item) => item.email === record.email);
  if (existingIndex >= 0) {
    state.accounts[existingIndex] = {
      ...state.accounts[existingIndex],
      ...record,
      password: record.password || state.accounts[existingIndex].password
    };
  } else {
    state.accounts.unshift(record);
  }

  state.accounts = state.accounts.slice(0, 1000);
  await chromeStorageSet({ [STORAGE.accounts]: state.accounts });
  renderAccountList();
}

function formatShortDate(value) {
  try {
    return new Date(value).toLocaleString();
  } catch (error) {
    return "";
  }
}

function renderAccountList() {
  if (!els.accountList) return;
  els.accountList.textContent = "";
  els.accountCount.textContent = String(state.accounts.length || 0);
  els.copyAllAccountsBtn.disabled = state.accounts.length === 0;
  els.downloadAccountsTxtBtn.disabled = state.accounts.length === 0;
  els.clearAccountListBtn.disabled = state.accounts.length === 0;

  if (!state.accounts.length) {
    const empty = document.createElement("div");
    empty.className = "empty-list";
    empty.textContent = "No account saved yet. LOG OUT click korle mail ekhane add hobe.";
    els.accountList.appendChild(empty);
    return;
  }

  state.accounts.forEach((account, index) => {
    const item = document.createElement("div");
    item.className = "account-item";

    const top = document.createElement("div");
    top.className = "account-item-top";

    const email = document.createElement("div");
    email.className = "account-email";
    email.textContent = account.email || "No email";

    const copy = document.createElement("button");
    copy.className = "ghost small";
    copy.type = "button";
    copy.dataset.copyAccountIndex = String(index);
    copy.textContent = "Copy";

    top.append(email, copy);

    const meta = document.createElement("div");
    meta.className = "account-meta";
    meta.textContent = `Password: ${account.password || ""} • Saved: ${formatShortDate(account.saved_at || account.created_at)}`;

    item.append(top, meta);
    els.accountList.appendChild(item);
  });
}

function render() {
  const email = state.account.email || "No mail set";
  const password = state.account.password || "No password set";

  els.selectedEmail.textContent = email;
  els.selectedPassword.textContent = state.account.password ? password : "No password set";
  els.passwordInput.value = state.account.password || "";

  if (els.accountEmail) els.accountEmail.textContent = state.account.email || "Not set";
  if (els.accountPassword) els.accountPassword.textContent = state.account.password || "Not set";
  if (els.accountInboxId) els.accountInboxId.textContent = state.account.inbox_id || state.account.mailbox_id || "Not set";
  if (els.accountStartUrl) els.accountStartUrl.textContent = START_URL;

  if (els.selectedProviderLabel) els.selectedProviderLabel.textContent = `Selected: ${providerLabel()}`;
  els.toxicMailBtn?.classList.toggle("active", state.mailProvider !== "baby");
  els.babyMailBtn?.classList.toggle("active", state.mailProvider === "baby");

  if (els.apiKeyInput) els.apiKeyInput.value = state.apiKey || "";
  if (els.baseUrlInput) els.baseUrlInput.value = state.baseUrl || DEFAULT_BASE_URL;
  if (els.birdApiKeyInput) els.birdApiKeyInput.value = state.birdApiKey || DEFAULT_BIRD_API_KEY;
  if (els.birdBaseUrlInput) els.birdBaseUrlInput.value = state.birdBaseUrl || DEFAULT_BIRD_BASE_URL;

  const hasEmail = Boolean(state.account.email);
  const hasPassword = Boolean(state.account.password);
  els.copyEmailBtn.disabled = !hasEmail;
  els.fillEmailBtn.disabled = !hasEmail;
  els.copyPasswordBtn.disabled = !hasPassword;
  els.fillPasswordBtn.disabled = !hasPassword;

  renderAccountList();

  if (hasEmail && hasPassword) setStatus("Mail + password ready");
  else if (hasEmail) setStatus("Mail ready");
  else setStatus("Ready");
}

function switchPanel(panelName) {
  els.panels.forEach((panel) => panel.classList.toggle("active", panel.id === `panel-${panelName}`));
  els.menuButtons.forEach((button) => button.classList.toggle("active", button.dataset.panel === panelName));
}

async function copyText(text, successMessage = "Copied") {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch (error) {
    const area = document.createElement("textarea");
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
  showToast(successMessage);
}

function buildAccountText(account = state.account) {
  return [
    `Mail: ${account.email || ""}`,
    `Password: ${account.password || ""}`,
    `Inbox ID: ${account.inbox_id || ""}`,
    `Start URL: ${START_URL}`
  ].join("\n");
}

function buildAllAccountsText() {
  return state.accounts
    .map((account) => account.email || "")
    .filter(Boolean)
    .join("\n");
}
function buildDownloadFileName() {
  const pad = (num) => String(num).padStart(2, "0");
  const now = new Date();
  return `agentmail-mails-${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}.txt`;
}

async function downloadAccountsTxt() {
  const text = buildAllAccountsText();
  if (!text) {
    showToast("No saved mail to download.", "error");
    return;
  }

  const fileName = buildDownloadFileName();
  const content = `${text}\n`;

  try {
    if (chrome.downloads?.download) {
      const url = `data:text/plain;charset=utf-8,${encodeURIComponent(content)}`;
      chrome.downloads.download({ url, filename: fileName, saveAs: false }, () => {
        if (chrome.runtime.lastError) {
          showToast(chrome.runtime.lastError.message || "Download failed.", "error");
          return;
        }
        showToast(`Downloaded ${state.accounts.length} mails.`);
      });
      return;
    }
  } catch (error) {
    // Fallback below.
  }

  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1200);
  showToast(`Downloaded ${state.accounts.length} mails.`);
}


function randomPassword(length = 16) {
  const lower = "abcdefghijklmnopqrstuvwxyz";
  const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const digits = "0123456789";
  const symbols = "!@#$%^&*?";
  const all = lower + upper + digits + symbols;
  const bytes = new Uint32Array(length);
  crypto.getRandomValues(bytes);

  const required = [lower, upper, digits, symbols].map((set, i) => set[bytes[i] % set.length]);
  const rest = [...bytes].slice(required.length).map((num) => all[num % all.length]);
  const combined = required.concat(rest);

  for (let i = combined.length - 1; i > 0; i--) {
    const swapIndex = bytes[i] % (i + 1);
    [combined[i], combined[swapIndex]] = [combined[swapIndex], combined[i]];
  }
  return combined.join("");
}

async function saveAccount(patch) {
  state.account = {
    ...state.account,
    ...patch,
    updated_at: new Date().toISOString()
  };
  await chromeStorageSet({ [STORAGE.account]: state.account });
  render();
}

async function createProviderMail(provider = state.mailProvider) {
  state.mailProvider = provider === "baby" ? "baby" : "toxic";
  await chromeStorageSet({
    [STORAGE.mailProvider]: state.mailProvider,
    [STORAGE.birdApiKey]: state.birdApiKey || DEFAULT_BIRD_API_KEY,
    [STORAGE.birdBaseUrl]: state.birdBaseUrl || DEFAULT_BIRD_BASE_URL
  });
  sendRuntimeMessage({ type: "AGENTMAIL_SET_MAIL_PROVIDER", provider: state.mailProvider });
  render();

  const button = state.mailProvider === "baby" ? els.babyMailBtn : els.toxicMailBtn;
  setLoading(button, true);
  setStatus(`Creating fresh ${providerLabel()}...`);

  try {
    const result = await sendRuntimeMessage({
      type: "AGENTMAIL_GET_OR_CREATE_EMAIL",
      forceNew: true,
      provider: state.mailProvider
    });

    if (!result.ok || !result.email) {
      setStatus("API error");
      showToast(result.error || `Could not create ${providerLabel()}.`, "error");
      return;
    }

    if (result.account) {
      state.account = result.account;
      await chromeStorageSet({ [STORAGE.account]: state.account });
    } else {
      await saveAccount({ email: result.email, provider: providerLabel(), mail_provider: state.mailProvider });
    }

    render();
    showToast(`Fresh ${providerLabel()} set: ${result.email}`);
    await fillActiveTab("email", result.email, { silent: true });
  } finally {
    setLoading(button, false);
    render();
  }
}

function tabCanBeInjected(tab) {
  const url = tab?.url || "";
  return url.startsWith("http://") || url.startsWith("https://");
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function sendRuntimeMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: "No response from extension." });
    });
  });
}

async function openStartWithFreshMail() {
  setLoading(els.startBtn, true);
  setStatus("Generating mail...");

  try {
    const result = await sendRuntimeMessage({
      type: "OPEN_START",
      prepareEmail: true,
      forceNewEmail: true,
      provider: state.mailProvider
    });

    if (!result.ok) {
      setStatus("API error");
      showToast(result.error || "Could not generate mail.", "error");
      return;
    }

    if (result.account) {
      state.account = result.account;
      await chromeStorageSet({ [STORAGE.account]: state.account });
    } else if (result.email) {
      await saveAccount({ email: result.email, provider: providerLabel(), mail_provider: state.mailProvider });
    }

    render();
    showToast(result.email ? `Mail generated: ${result.email}` : "Start opened.");
  } finally {
    setLoading(els.startBtn, false);
  }
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: "No response from page." });
    });
  });
}

async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch (error) {
    // Some pages block injection. The caller shows a readable message.
  }
}

async function fillActiveTab(kind, value, options = {}) {
  if (!value) return;
  const tab = await getActiveTab();

  if (!tabCanBeInjected(tab)) {
    if (!options.silent) showToast("Open a normal web page first, then fill again.", "error");
    return;
  }

  let result = await sendMessageToTab(tab.id, { type: "AGENTMAIL_FILL", kind, value });
  if (!result?.ok) {
    await ensureContentScript(tab.id);
    result = await sendMessageToTab(tab.id, { type: "AGENTMAIL_FILL", kind, value });
  }

  if (result?.ok) {
    if (!options.silent) showToast(`${kind === "email" ? "Mail" : "Password"} filled on page.`);
  } else if (!options.silent) {
    showToast(result?.message || result?.error || `Could not fill ${kind}.`, "error");
  }
}

async function saveSettings() {
  if (!els.apiKeyInput || !els.baseUrlInput || !els.birdApiKeyInput || !els.birdBaseUrlInput) return;
  state.apiKey = els.apiKeyInput.value.trim();
  state.baseUrl = normalizeBaseUrl(els.baseUrlInput.value);
  state.birdApiKey = els.birdApiKeyInput.value.trim();
  state.birdBaseUrl = normalizeBirdBaseUrl(els.birdBaseUrlInput.value || DEFAULT_BIRD_BASE_URL);
  await chromeStorageSet({
    [STORAGE.apiKey]: state.apiKey,
    [STORAGE.baseUrl]: state.baseUrl,
    [STORAGE.birdApiKey]: state.birdApiKey,
    [STORAGE.birdBaseUrl]: state.birdBaseUrl
  });
  render();
  showToast("API settings saved.");
}

async function resetAccount() {
  await chromeStorageRemove([STORAGE.account]);
  state.account = {};
  render();
  showToast("Account data reset.");
}

async function clearAccountList() {
  state.accounts = [];
  await chromeStorageSet({ [STORAGE.accounts]: state.accounts });
  renderAccountList();
  showToast("Account list cleared.");
}

function accountListClickHandler(event) {
  const button = event.target.closest?.("[data-copy-account-index]");
  if (!button) return;
  const index = Number(button.dataset.copyAccountIndex);
  const account = state.accounts[index];
  if (!account) return;
  copyText(account.email, "Mail copied.");
}

async function init() {
  const saved = await chromeStorageGet([STORAGE.account, STORAGE.accounts, STORAGE.apiKey, STORAGE.baseUrl, STORAGE.mailProvider, STORAGE.birdApiKey, STORAGE.birdBaseUrl]);
  state.account = saved[STORAGE.account] || {};
  state.accounts = Array.isArray(saved[STORAGE.accounts]) ? saved[STORAGE.accounts] : [];
  state.mailProvider = saved[STORAGE.mailProvider] || state.account.mail_provider || "toxic";
  state.birdApiKey = saved[STORAGE.birdApiKey] || DEFAULT_BIRD_API_KEY;
  state.birdBaseUrl = saved[STORAGE.birdBaseUrl] || DEFAULT_BIRD_BASE_URL;
  if (!state.account.password) {
    state.account.password = DEFAULT_PASSWORD;
    await chromeStorageSet({ [STORAGE.account]: state.account });
  }
  state.apiKey = saved[STORAGE.apiKey] || DEFAULT_API_KEY;
  state.baseUrl = normalizeBaseUrl(saved[STORAGE.baseUrl] || DEFAULT_BASE_URL);

  if (!saved[STORAGE.apiKey] && DEFAULT_API_KEY) {
    await chromeStorageSet({ [STORAGE.apiKey]: DEFAULT_API_KEY, [STORAGE.baseUrl]: DEFAULT_BASE_URL });
  }
  await chromeStorageSet({
    [STORAGE.mailProvider]: state.mailProvider,
    [STORAGE.birdApiKey]: state.birdApiKey,
    [STORAGE.birdBaseUrl]: state.birdBaseUrl
  });

  render();
}

els.menuButtons.forEach((button) => button.addEventListener("click", () => switchPanel(button.dataset.panel)));
els.startBtn.addEventListener("click", openStartWithFreshMail);
els.toxicMailBtn?.addEventListener("click", () => createProviderMail("toxic"));
els.babyMailBtn?.addEventListener("click", () => createProviderMail("baby"));
els.copyEmailBtn.addEventListener("click", () => copyText(state.account.email, "Mail copied."));
els.copyPasswordBtn.addEventListener("click", () => copyText(state.account.password, "Password copied."));
els.copyAccountBtn?.addEventListener("click", () => copyText(state.account.email, "Mail copied."));
els.copyAllAccountsBtn.addEventListener("click", () => copyText(buildAllAccountsText(), "All mails copied."));
els.downloadAccountsTxtBtn.addEventListener("click", downloadAccountsTxt);
els.clearAccountListBtn.addEventListener("click", clearAccountList);
els.accountList.addEventListener("click", accountListClickHandler);
els.fillEmailBtn.addEventListener("click", () => fillActiveTab("email", state.account.email));
els.fillPasswordBtn.addEventListener("click", () => fillActiveTab("password", state.account.password));
els.generatePasswordBtn.addEventListener("click", () => {
  els.passwordInput.value = randomPassword();
  els.passwordInput.focus();
});
els.savePasswordBtn.addEventListener("click", async () => {
  const password = els.passwordInput.value.trim();
  if (!password) {
    showToast("Type or generate a password first.", "error");
    return;
  }
  await saveAccount({ password });
  showToast("Password set.");
  await fillActiveTab("password", password, { silent: true });
});
els.saveSettingsBtn?.addEventListener("click", saveSettings);
els.resetAccountBtn?.addEventListener("click", resetAccount);

init();
