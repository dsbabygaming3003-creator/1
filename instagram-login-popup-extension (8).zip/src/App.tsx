import { useState } from 'react';

export default function App() {
  const [panelOpen, setPanelOpen] = useState(false);
  const [power, setPower] = useState(true);

  return (
    <div className="min-h-screen bg-[#050505]" style={{background: 'linear-gradient(180deg,#08080d 0%,#0a0a12 50%,#060608 100%)'}}>
      
      {/* Ambient glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-10 left-1/4 w-96 h-96 bg-pink-600/[0.04] rounded-full blur-[120px]"/>
        <div className="absolute bottom-20 right-1/3 w-96 h-96 bg-orange-600/[0.03] rounded-full blur-[120px]"/>
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">

        {/* Header */}
        <header className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-white/[0.04] border border-white/[0.08] rounded-full px-4 py-1.5 mb-4 backdrop-blur-sm">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"/>
            <span className="text-white/50 text-xs font-medium tracking-wide">v6.0 ULTRA SMOOTH</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-black text-white tracking-tight">Instagram Login Popup</h1>
          <p className="text-white/30 text-sm mt-2 max-w-xs mx-auto">Draggable Circle Button → Click for All Features • Zero Bugs</p>
        </header>

        {/* Phone Mockup */}
        <div 
          className="relative rounded-[2.5rem] border border-white/[0.08] overflow-hidden shadow-2xl shadow-black/50"
          style={{ 
            background: 'linear-gradient(180deg,#000 0%,#0c0c14 100%)',
            width: 'min(320px,90vw)',
            aspectRatio: '9/19'
          }}
        >
          {/* Status bar */}
          <div className="flex justify-between items-center px-5 pt-3 pb-1.5">
            <span className="text-white/40 text-xs font-semibold">3:12</span>
            <div className="flex items-center gap-1.5 text-white/40 text-xs">
              <span>📶</span><span>4G</span><span>🔋43</span>⚡
            </div>
          </div>

          {/* Language */}
          <div className="text-center mt-1"><span className="text-white/25 text-xs">English (US)</span></div>

          {/* IG Logo */}
          <div className="flex justify-center my-5">
            <svg width="72" height="72" viewBox="0 0 24 24" fill="none">
              <defs><linearGradient id="g" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" stopColor="#FED576"/><stop offset="25%" stopColor="#F47133"/><stop offset="50%" stopColor="#BC3081"/><stop offset="75%" stopColor="#4C63D2"/><stop offset="100%" stopColor="#00A6DC"/></linearGradient></defs>
              <rect x="2" y="2" width="20" height="20" rx="6" stroke="url(#g)" strokeWidth="1.5" fill="none"/>
              <circle cx="12" cy="12" r="5" stroke="url(#g)" strokeWidth="1.5" fill="none"/>
              <circle cx="17.5" cy="6.5" r="1.2" fill="url(#g)"/>
            </svg>
          </div>

          {/* Form mockups */}
          <div className="px-5 space-y-2.5">
            <div className="bg-white/[0.04] rounded-xl px-4 py-3 border border-white/[0.06]">
              <span className="text-white/25 text-sm">Username, email or mobile number</span>
            </div>
            <div className="bg-white/[0.04] rounded-xl px-4 py-3 border border-white/[0.06]">
              <span className="text-white/25 text-sm">Password</span>
            </div>
            <button className="w-full bg-[#0095f6] hover:bg-[#1877f2] text-white font-semibold py-2.5 rounded-xl text-sm transition-colors duration-200">
              Log in
            </button>
            <p className="text-center text-white/30 text-sm py-1">Forgot password?</p>
          </div>

          {/* === THE FLOATING BUTTON (Like Screenshot) === */}
          <button
            onClick={() => setPanelOpen(!panelOpen)}
            className="group absolute left-1/2 -translate-x-1/2 focus:outline-none"
            style={{ top: '265px' }}
          >
            <div 
              className="relative w-[54px] h-[54px] rounded-full flex items-center justify-center transition-all duration-200 group-active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #833AB4 0%, #FD1D1D 50%, #F77737 100%)',
                border: '2.5px solid rgba(255,255,255,0.92)',
                boxShadow: `0 4px 24px ${panelOpen ? 'rgba(225,48,108,0.7)' : 'rgba(225,48,108,0.45)'}, 0 0 0 1px rgba(0,0,0,0.15)`,
                animation: panelOpen ? 'none' : 'btnPulse 2.5s infinite'
              }}
            >
              <svg viewBox="0 0 24 24" fill="white" width="26" height="26"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
              
              {/* Green Badge - Screenshot style! */}
              <span 
                className="absolute -top-1 -right-1 min-w-[21px] h-[21px] rounded-[11px] flex items-center justify-center text-white text-[10px] font-extrabold"
                style={{
                  background: 'linear-gradient(135deg, #16a34a, #22c55e)',
                  border: '2px solid #111',
                  boxShadow: '0 2px 8px rgba(0,0,0,0.35)',
                  padding: '0 5px',
                  animation: 'badgeBounce 2s infinite'
                }}
              >0</span>
            </div>
            
            {/* Red circle highlight like screenshot */}
            {!panelOpen && (
              <div className="absolute -inset-3 rounded-full border-2 border-red-500/50 pointer-events-none animate-ping" style={{animationDuration:'2s'}}/>
            )}
          </button>

          {/* Bottom content */}
          <div className="px-5 mt-6 space-y-3">
            <button className="w-full border border-white/15 text-[#0095f6]/80 font-medium py-2 rounded-xl text-sm hover:bg-white/[0.03] transition-colors">
              Create new account
            </button>
            <div className="flex justify-center items-center gap-2 text-white/25 text-sm">
              <span className="font-bold text-base opacity-50">∞</span>Meta
            </div>
          </div>

          {/* Bottom nav */}
          <div className="absolute bottom-1 left-0 right-0 flex justify-around items-center py-2 border-t border-white/[0.04] px-3">
            {['🏠','📋','instagram.com/','▦','☰'].map((x,i) => (
              <span key={i} className={`text-white/30 text-base ${i===1?'relative ':' '}${i===2?'bg-white/[0.06] px-2 py-0.5 rounded-lg text-[10px] font-mono text-white/50':''}`}>
                {x}
                {i===1 && <span className="absolute -top-1 -right-2 w-4 h-4 bg-red-500 rounded-full text-[8px] text-white flex items-center justify-center">12</span>}
              </span>
            ))}
          </div>
        </div>

        {/* Feature Panel (Smooth Slide Up) */}
        {panelOpen && (
          <div 
            className="mt-5 w-full max-w-sm mx-auto rounded-2xl overflow-hidden border border-white/10 animate-in slide-in-from-bottom-4 duration-300"
            style={{ background: '#121212', animation: 'slideUp 0.28s cubic-bezier(0.4,0,0.2,1) forwards' }}
          >
            {/* Panel Header */}
            <div className="flex justify-between items-center p-4 border-b border-white/5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{background:'linear-gradient(135deg,#833AB4,#FD1D1D,#F77737)'}}>
                  <svg viewBox="0 0 24 24" fill="white" width="14" height="14"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069z"/></svg>
                </div>
                <div>
                  <div className="text-white text-sm font-bold">IG Automation Pro</div>
                  <div className="text-gray-500 text-[10px]">All features — Click button to toggle</div>
                </div>
              </div>
              <button 
                onClick={() => setPanelOpen(false)}
                className="w-7 h-7 rounded-full bg-[#222] text-gray-400 text-sm flex items-center justify-center hover:bg-red-500 hover:text-white transition-all duration-200 active:scale-90"
              >✕</button>
            </div>

            {/* Power Toggle Mini */}
            <div className="p-4" style={{background:'rgba(250,204,21,0.06)',borderBottom:'1px solid #1a1a1a'}}>
              <div className="text-[10px] text-yellow-400/80 font-bold mb-2 text-center tracking-wider">⚡ POWER CONTROL</div>
              <div className="flex justify-center">
                <button 
                  onClick={()=>setPower(!power)}
                  className="relative w-[60px] h-[30px] rounded-full transition-all duration-300"
                  style={{
                    background: power ? 'linear-gradient(to right,#16a34a,#22c55e)' : '#4b5563',
                    boxShadow: power ? '0 3px 12px rgba(34,197,94,0.3)' : 'inset 0 2px 4px rgba(0,0,0,0.2)'
                  }}
                >
                  <div 
                    className="absolute top-[2px] w-[26px] h-[26px] bg-white rounded-full shadow-md flex items-center justify-center text-[12px] font-bold transition-all duration-300"
                    style={{
                      left: power ? '31px' : '2px',
                      color: power ? '#16a34a' : '#9ca3af'
                    }}
                  >{power?'✓':'✕'}</div>
                </button>
              </div>
              <div className={`mt-2 text-center text-[10px] font-bold px-3 py-1 rounded-full inline-flex items-center gap-1.5 mx-auto block w-fit ${power?'bg-green-500/12 text-green-400':'bg-red-500/12 text-red-400'}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${power?'bg-green-400 animate-pulse':'bg-red-400'}`}/>
                {power?'AUTOMATION ACTIVE':'AUTOMATION OFF'}
              </div>
            </div>

            {/* Features Grid */}
            <div className="p-4 grid grid-cols-3 gap-1.5">
              {[
                ['⚡','Toggle'],['☝️','Click'],['✋','Drag'],
                ['📧','Emails'],['🔑','Pass'],['💾','Save'],
                ['⬅️','Prev'],['➡️','Next'],['🔐','Records'],
                ['📥','CSV'],['📋','View'],['🔄','Reset'],
                ['🗑️','Clear'],['💀','Del All'],['🎯','Mobile'],
              ].map(([icon,name],i) => (
                <div key={i} className="bg-white/[0.03] rounded-lg p-2 text-center hover:bg-white/[0.06] transition-colors cursor-default">
                  <div className="text-base mb-0.5">{icon}</div>
                  <div className="text-[9px] text-white/40 font-medium">{name}</div>
                </div>
              ))}
            </div>

            <div className="px-4 pb-3 text-center text-[9px] text-white/15">
              Ultra Smooth v6.0 • Zero Bugs • 60fps Animations
            </div>
          </div>
        )}

        {/* Info Cards */}
        <div className="mt-8 w-full max-w-sm space-y-3">
          
          {/* How it works */}
          <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl p-4">
            <h3 className="text-white font-bold text-sm mb-3">✨ How It Works</h3>
            <div className="space-y-2.5">
              {[['1','Circle button appears on login page'],['2','Drag it anywhere on screen'],['3','Click to open ALL features'],['4','Use ON/OFF + all controls']].map(([n,t],i)=>(
                <div key={i} className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-gradient-to-br from-pink-500 to-orange-400 text-white text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">{n}</span>
                  <span className="text-white/40 text-xs leading-relaxed">{t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Smooth features */}
          <div className="grid grid-cols-4 gap-2">
            {[
              ['⚡','60fps'],['🎯','Exact UI'],['🐛','Zero Bugs'],['📱','Mobile Ready']
            ].map(([icon,lbl],i)=>(
              <div key={i} className="bg-white/[0.02] rounded-xl p-3 text-center border border-white/[0.04]">
                <div className="text-lg mb-1">{icon}</div>
                <div className="text-[9px] text-white/35 font-medium">{lbl}</div>
              </div>
            ))}
          </div>

          {/* Footer CTA */}
          <div className="text-center pb-4">
            <p className="text-white/20 text-xs mb-2">Download "extension" folder → Load in Chrome via chrome://extensions/</p>
            <div className="inline-flex items-center gap-2 text-[10px] text-white/15">
              <span>Source:</span>
              <a href="https://github.com/dsbabygaming3003-creator/baby" target="_blank" rel="noreferrer" className="text-pink-500/50 hover:text-pink-400 transition-colors">GitHub</a>
              <span>•</span>
              <span>v6.0 Ultra Smooth</span>
            </div>
          </div>
        </div>
      </div>

      {/* Keyframes */}
      <style>{`
        @keyframes btnPulse {
          0%,100%{box-shadow:0 4px 20px rgba(225,48,108,0.42)}
          50%{box-shadow:0 4px 32px rgba(225,48,108,0.65),0 0 50px rgba(225,48,108,0.15)}
        }
        @keyframes badgeBounce {
          0%,100%{transform:scale(1)} 50%{transform:scale(1.18)}
        }
        @keyframes slideUp {
          from{opacity:0;transform:translateY(16px) scale(0.97)}
          to{opacity:1;transform:translateY(0) scale(1)}
        }
      `}</style>
    </div>
  );
}
