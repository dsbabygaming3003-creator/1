(() => {
  if (window.__continueAutoClicker) return;
  window.__continueAutoClicker = true;

  let running = true;
  let intervalMs = 50;
  let timer = null;

  const isContinueText = (t) => {
    t = (t || '').trim().toLowerCase();
    if (!t || t.length > 40) return false;
    return /continue/.test(t) || t.includes('এগিয়ে যান') || t.includes('চালিয়ে যান');
  };

  function findButton() {
    const els = document.querySelectorAll('button, [role="button"], a');
    let loose = null;
    for (const el of els) {
      const t = (el.textContent || '').trim();
      if (/^continue$/i.test(t) || t === 'এগিয়ে যান' || t === 'চালিয়ে যান') return el;
      if (!loose && isContinueText(t)) loose = el;
    }
    return loose;
  }

  function click(el) {
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    const base = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
    try {
      el.dispatchEvent(new PointerEvent('pointerover', base));
      el.dispatchEvent(new PointerEvent('pointerdown', Object.assign({ pointerId: 1, isPrimary: true, button: 0 }, base)));
      el.dispatchEvent(new MouseEvent('mousedown', Object.assign({ button: 0 }, base)));
      el.dispatchEvent(new PointerEvent('pointerup', Object.assign({ pointerId: 1, isPrimary: true, button: 0 }, base)));
      el.dispatchEvent(new MouseEvent('mouseup', Object.assign({ button: 0 }, base)));
    } catch (e) {}
    el.click();
  }

  function tick() {
    if (!running) return;
    const btn = findButton();
    if (btn) click(btn);
  }

  function restart() {
    if (timer) { clearInterval(timer); timer = null; }
    if (running) {
      timer = setInterval(tick, Math.max(10, intervalMs));
      tick();
    }
  }

  chrome.storage.local.get({ ac_running: true, ac_interval: 50 }, (r) => {
    running = !!r.ac_running;
    intervalMs = r.ac_interval || 50;
    restart();
  });

  chrome.storage.onChanged.addListener((ch) => {
    if (ch.ac_running) running = !!ch.ac_running.newValue;
    if (ch.ac_interval) intervalMs = ch.ac_interval.newValue || 50;
    restart();
  });

  chrome.runtime.onMessage.addListener((msg, _s, send) => {
    if (msg && msg.type === 'status') {
      send({ running: running, intervalMs: intervalMs, found: !!findButton() });
    }
    return true;
  });
})();
