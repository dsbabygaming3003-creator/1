// Popup Script - IG 2FA Automation Pro v4.0.0

document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('mainToggle');
  const statusText = document.getElementById('statusText');
  const statusBadge = document.getElementById('statusBadge');
  
  // Initialize state
  function init() {
    chrome.storage.local.get(['extensionEnabled'], (result) => {
      updateUI(result.extensionEnabled !== false);
    });
  }

  // Update UI based on state
  function updateUI(enabled) {
    if (enabled) {
      toggle.classList.add('active');
      toggle.querySelector('.toggle-emoji').textContent = '🔥';
      statusText.textContent = 'Extension is ON';
      statusText.style.color = '#86efac';
      statusBadge.className = 'status-badge badge-on';
      statusBadge.innerHTML = '<span class="dot"></span><span class="badge-label">Active</span>';
    } else {
      toggle.classList.remove('active');
      toggle.querySelector('.toggle-emoji').textContent = '💤';
      statusText.textContent = 'Extension is OFF';
      statusText.style.color = '#fca5a5';
      statusBadge.className = 'status-badge badge-off';
      statusBadge.innerHTML = '<span class="dot"></span><span class="badge-label">Inactive</span>';
    }
  }

  // Toggle click
  toggle.addEventListener('click', () => {
    chrome.storage.local.get(['extensionEnabled'], (result) => {
      const newState = result.extensionEnabled === false;
      
      chrome.storage.local.set({ extensionEnabled: newState }, () => {
        updateUI(newState);
        
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.id && tab.url && tab.url.includes('instagram.com')) {
              chrome.tabs.sendMessage(tab.id, { 
                action: 'TOGGLE_STATE', 
                enabled: newState 
              }).catch(() => {});
            }
          });
        });
      });
    });
  });

  // Open Instagram button
  document.getElementById('openInstagramBtn').addEventListener('click', () => {
    chrome.tabs.create({ 
      url: 'https://www.instagram.com/accounts/login/?next=%2F&source=mobile_nav' 
    });
  });

  // View Records button
  document.getElementById('viewRecordsBtn').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url && tabs[0].url.includes('instagram.com')) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'OPEN_PANEL' }).catch(() => {});
        window.close();
      } else {
        chrome.tabs.create({ 
          url: 'https://www.instagram.com/accounts/login/?next=%2F&source=mobile_nav' 
        });
      }
    });
  });

  // Listen for storage changes
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.extensionEnabled) {
      updateUI(changes.extensionEnabled.newValue !== false);
    }
  });

  init();
});
