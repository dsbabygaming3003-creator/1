# 🔥 IG 2FA Automation Pro v4.0.0 - Chrome Extension

A powerful Chrome extension for Instagram automation with **Sequential Step-by-Step Auto-Flow**, **2FA key extraction**, **auto-fill functionality**, and a sleek **floating UI panel**.

## ✨ Features

- 🎯 **Step 1: Unstoppable "Log in" Button Submission** - Native touch events, pointer events, synthetic click, and direct `form.requestSubmit()` fallback.
- 👤 **Step 2: Automated "Meta Horizon" Card Selection** - Robust multi-strategy detection targeting the Meta bottom-sheet card with real `TouchEvent` + `PointerEvent` coordinate dispatching.
- ⚡ **Seamless 1-Click Flow** - Automatically navigates from email paste to login submission to Meta Horizon account selection.
- 📱 **Mobile Browser Optimized** - Fully compatible with Kiwi, Lemur, and Chrome Mobile extensions.
- 🔐 **2FA Key Extraction & Save** - Automatically scans and stores 2FA secret keys.
- 📥 **CSV Export** - Export your records anytime.
- 🎨 **Draggable Floating Window** - Minimalist, modern dark-mode UI with pill minimization.
- 🌐 **100% English UI** - Clean, professional English interface across all menus, buttons, and notifications.

## 📦 Installation

### In Kiwi / Lemur / Chrome (Developer Mode)

1. Unzip `instagram-login-popup-extension-FIXED.zip`.
2. Open your browser and go to `chrome://extensions/` (or Extensions menu).
3. Enable **Developer mode**.
4. Tap **"Load unpacked"** and select the extension folder.
5. Visit Instagram Login: `https://www.instagram.com/accounts/login/?next=%2F&source=mobile_nav`

## 🎮 How the Automation Works

1. **Step 1 ("Log in"):**
   When credentials are typed or pasted, the extension detects the login button and submits the form immediately.
2. **Step 2 ("Meta Horizon"):**
   When the bottom sheet appears showing *"No Instagram account found - The login info you entered matched an existing Meta account"*, the extension detects the **Meta Horizon** card container, highlights it with an emerald glow, and dispatches native mobile touch and pointer events to open it.

---
Made with ❤️ | Version 4.0.0
