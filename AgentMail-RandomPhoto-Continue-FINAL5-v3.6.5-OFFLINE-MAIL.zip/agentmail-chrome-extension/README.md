# MasterTeam Menu — Strong Engine v3.6.5 OFFLINE MAIL

Dynamic Chrome extension menu with:

- **Mails** → **Toxic mail** / **Baby mail** provider selection.
- **Start** opens the Meta OIDC/auth link with a fresh selected-provider mail.
- **Set Password** saves/fills password.
- **Account** stores the created account (mail + pass) - saved the moment the Meta AI
  details **Confirm** is pressed, and also at the logout stage - with Copy mails and Download `.txt`.
- Floating orb on `auth.meta.com`, draggable, with total account count, CopyMails **and a live engine HUD**.
- Stuck/error handling: blank page refresh, dark stuck refresh, full error refresh, **You can't use Meta right now** page refresh.

---

## v3.6.5 — Tools panel removed

- Removed the Tools navigation item, Page Workspace panel, local page-note storage code, and page-copy actions.
- Existing themes, Compact/Motion controls, and mail/account/password UI are unchanged.
- Chrome display name remains `MasterTeam Mail Menu`; visible popup badge remains `v3.6 OFFLINE`.

---

## v3.6.3 — Digital control-center refresh

- Refined all popup panels for stronger contrast, clearer hierarchy, and a more polished digital/glass treatment.
- Added persisted **Compact** layout and **Motion on/off** controls. These affect presentation only.
- Rewrote mixed-language helper copy for consistency; existing mail/account/password actions are unchanged.
- Chrome display name and the visible version badge remain unchanged.

---

## v3.6.2 — Digital color themes

- Added five selectable popup color themes: Violet Flux, Arctic Pulse, Cyber Pulse, Emerald Grid, and Solar Flare.
- The chosen theme is saved in extension-local storage and restored when the popup reopens.
- Visual-only update: account, mail, password, and automation behavior is unchanged.
- Extension display name remains `MasterTeam Mail Menu`; popup version badge remains `v3.6 OFFLINE`.

---

## v3.6.1 LEAN SCOPE — auxiliary Continue script only loads where it can run

- `continue_content.js` already exits immediately unless the hostname is one of its five supported Meta hosts. The manifest nevertheless injected that 5.8 KB script on **every website** (`<all_urls>`), where it could never do useful work.
- Its `content_scripts.matches` is now limited to the exact HTTP/HTTPS hosts in the helper's allowlist: `auth.meta.ai`, `meta.ai`, `www.meta.ai`, `accountscenter.meta.com`, and `accountcenter.meta.com`.
- **No click/fill logic changed.** `auth.meta.com` remains excluded from the generic helper; its existing step-aware handlers are unchanged. `upload_content.js` and its matches are untouched.
- Checks: all six JS files parse, manifest JSON valid, archive/source identity checked, and Chrome popup + service-worker smoke test passes. No live signup or human-verification test was run.

---

## v3.6 OFFLINE MAIL — the screenshot's email box is filled even with no connection

- **Your new Quetta screenshot (round 15):** browser banner says **“No internet connection”**;
  the field is empty while the HUD says **“Email entry / Engine on / Mail+pass ✓”**.
- **The purple rectangle is the key clue:** that is our `flash(input)` style - the engine
  had found/focused the box, but the pipeline stopped before the email write. A replica
  with the Meta-style `autocomplete="username"` exposed why: v3.5's new wrong-box guard
  rejected `username`, even though Meta uses that attribute on its *email* field. The
  screenshot's no-internet banner was a second blocker: when a fresh mailbox API call
  failed, code returned before filling anything.
- **Now fixed (v3.6):**
  1. On a positively identified Meta **email-entry** page, `autocomplete="username"` is
     treated as an ambiguous login hint - the visible email/mobile placeholder wins. Off
     that page, the wrong-box safety filter stays in place. Name/Password/Year/DOB/OTP
     fields are still rejected; email is still barred from the Meta AI **Name (optional)**
     box.
  2. If the mail API fails because the browser is offline / a fetch has a network error,
     the extension reads the current locally prepared mailbox or newest entry in
     `agentmail_accounts` and fills **that saved email**. It does not invent a new one.
  3. **Continue waits for internet.** The address remains in the box; once connection is
     restored, the step-aware handler clicks Continue once. The separate generic
     `continue_content.js` helper is now deliberately disabled on `auth.meta.com` - it
     used to press an empty Continue button while the email field was still blank.
- **Important offline limit:** no connection means no *fresh* temporary mailbox can be
  created and no account can be submitted to Meta. This fallback reuses the latest saved
  address, which may already be used; if Meta rejects it, restore internet and start a
  new-mail flow. On a real online run, successful fresh API results still take priority.
- **A/B proof on the exact screen shape, real Chromium:** old shipped v3.5 left the input
  blank and the generic Continue helper clicked once with an empty value; v3.6 pasted the
  cached account, made **0 Continue presses while offline**, then exactly **1** after the
  test restored connectivity. `autocomplete="username"` is exercised in the fixture.
- **Battery:** **23 modes / 211 checks / 0 failures** (`tests/run_v36_full.log`); JSDOM
  smoke PASS. Idle 10 s TaskDuration **0.101 / 0.099 s**, ScriptDuration **0.040 / 0.041 s**.
- **Proof image:** `PREVIEW-v3.6-email-filled-offline.png` - the email visibly inside the
  field, purple focus outline, **No internet connection** banner, and saved-mail HUD.

---

## v3.5 STUCK — the skeleton page (no text, 3 bars, top-right menu) gets ONE press

- **Your screenshot (round 14):** `auth.meta.com` shows a nearly empty dark page -
  three skeleton bars and the **3-line menu** top-right (circled). Rule asked for:
  **if that screen is still there after 700 ms, press the circled button once.**
- **It also exposed a regression from v3.3:** that page has **no text at all**, and
  the v3.3 paint-guard ("`text.length < 24` = not painted yet") made the engine
  **blind on exactly this screen**. Paint evidence is now real evidence -
  text **or** the menu button **or** any rendered box (skeleton bars count).
- **700 ms → one press.** New `installSparseHamburgerStuckWatch()` ticks every 100 ms;
  the moment the screen has been stuck for 700 ms it presses the top-right menu
  **once** (`pressTopRightMenuOnce`: real element press; the coordinate fallback fires a
  **single point**, never the old ~56-point sweep) and then the Logout watcher opens
  the menu and finishes. A second press is allowed **only** as one verification retry
  when the menu visibly did not open; after that, silence - `sparseHamburgerRecentlyPressed()`
  (permanent for the document + a 6 s sessionStorage window) blocks every other path.
- **Double-click audit (your second request) - three real offenders found and fixed:**
  1. the legacy hamburger path pressed the same button **9x** and Log out **6x** inside
     340 ms (measured on the replica). It now defers to the 700 ms rule and
     `clickMetaHamburgerStrong` refuses this screen;
  2. "Create new account" could be pressed **up to 12 times** while the page was slow to
     navigate (`for i<12` loop) - now: **one press, then verify, at most one retry**
     (also logged: 9 real presses in v3.4's replica run, 1 in v3.5);
  3. the Logout click timestamp is stamped **before** the press, so two watchers can no
     longer pass the dedupe window and press Log out twice.
  4. plus a **global guard**: `clickStrong` refuses to press the *same element with the
     same kind* twice inside 1 s (`Skipped a duplicate press` in the log).
- **Email audit (never in the wrong box):** the email finder now **hard-rejects** any field
  whose own attributes mention password / name (incl. "Name (optional)") / username /
  year / birth / dob / code / otp - on top of the v3.3 ban on the Meta-AI-details page.
- **Proof, real Chromium (20 modes / 202 checks, 0 failures):**

| Test | old v3.4 | **new v3.5** |
|---|---|---|
| `sparse` (your screenshot; the menu really opens) | **FAIL** - first press at **91 ms** (no 700 ms rule), **4 presses**, Log out at 576 ms | **PASS** - first press **835 ms**, exactly **1 press**, Log out **exactly once** at 1,306 ms |
| `sparsenoop` (menu ignores every click) | **FAIL** - **17+ presses** in 3 s (and it kept going) | **PASS** - **2 presses total** (1 + the one retry at 1.6 s), then silence for the whole 8 s watch |
| everything else (18 earlier modes) | — | **PASS** - year/1999 order, single code-send, no reload on the code step, Name box clean, account kept |

- **Smoothness:** idle 10 s TaskDuration **0.106/0.107 s** - still lighter than v3.4;
  the watcher is a 100 ms interval that does nothing at all once the press is made.

## v3.4 SIGNUP — the meta.ai "Sign in to get started" dialog gets the right button

- **Your screenshot (round 13):** on **meta.ai** a modal shows up - flower logo,
  *"Sign in to get started"*, *"Log in or sign up to ask Meta AI anything"* - with two
  pills: **Log in** and **Sign up**. The circled target is **Sign up**, and that is
  the one the engine must press. It now does, and only that.
- **A dedicated path for this screen** (`isMetaAiSignUpDialogVisible` +
  rewritten `findMetaAiSignUpButton`):
  1. the engine first checks that the dialog is really on screen - on an ordinary
     meta.ai page **nothing is pressed at all**;
  2. the button is picked from **real interactive elements** (`button`, `a[href]`,
     `role=button`, `input[type=button]`): exact **"Sign up"** wins (+100), a phrase
     that merely *mentions* "sign up" scores +15, and any label containing
     **log in / sign in / login is hard-rejected (-200)** - so the Log in pill can
     never be hit;
  3. the press is **verified** (dialog closed / URL moved / button went busy). If it
     did not take, the engine tries again - **at most 3 real presses, ever**, so the
     button can never be hammered;
  4. waiting for the pill is **free**: a button that has not painted yet no longer
     eats the press budget (this was a real bug - the pill paints ~0.9 s late on
     some loads and the old loop gave up before it appeared).
- **Proof, real Chromium, your screenshot as three new cases (18 modes / 183 checks, 0 failures):**

| Test | old v3.3 | **new v3.4** |
|---|---|---|
| `metaai` (dialog from the first paint) | PASS (press at 249 ms - but no dialog check, the blind sweep also ran here) | **PASS** - press at **220 ms**, Log in never touched, **0 blind clicks** |
| `metaailogin` (pill paints 0.9 s late) | PASS but **5,305 ms** to press and **1 blind whole-page click** | **PASS** - press at **1,223 ms** (4 s faster), **0 blind clicks** |
| `metaailanding` (plain meta.ai page, no dialog) | **FAIL** - **1 blind whole-page click** on a page with no dialog | **PASS** - **0 presses, 0 blind clicks**, the page's own Log in button is left alone |

- **HUD:** this screen is now named **Meta AI** in the badge (it used to sit on
  "Starting…"), and the light phrase stays *Ready / Flowing / Mail+pass ✓*.
- **Nothing else changed:** the year step (1999 first, then the password), the single
  human code-send, the no-reload rule on the code step and the account keeper
  (mail + pass, saved at Meta AI Confirm) are all untouched and re-tested.

## v3.3 LUX — no email in the Name box, the account is kept, and the engine stops blind-clicking

- **Your screenshot, fixed.** On **"Edit your Meta AI details"** the **Name (optional)**
  box held the account email (`strangecountry222@agentmail.to`). Two new pieces close it:
  1. `findMetaAiDetailsNameInput()` finds that box by its own hint (`name (optional)`,
     `username` scored down, `type=email` rejected) and
     `autoCleanMetaAiDetailsName()` **replaces any email already sitting in it with a
     proper human name** before Confirm is pressed (measured: cleaned at **92-118 ms**).
  2. every email-filler is **banned on that page** - the flow can no longer write an
     address into a name field at all (`emailInName = 0`, `nameWrites` never contains
     an `@`).
- **The real reason it happened (root cause, found on the replica).** The engine's
  blind *coordinate* sweep ran on that fresh page (a not-yet-painted page passed the
  "sparse hamburger screen" test because its text was empty) and its clicks landed on
  **Confirm before the dedicated path** could press it - so the account was never saved
  and the click order was wrong. Now: the sweep never runs before the page has painted
  (`text.length < 12` bails), a 24-character floor keeps a blank shell out of the
  hamburger detector, and the details page is explicitly excluded from every blind
  sweep / menu hunt. Measured: **84-94 blind whole-page clicks in v3.2 -> exactly 0 in v3.3**.
- **The account (mail + pass) is really kept.** The save now goes out **before** the
  Confirm press - this page navigates the instant Confirm lands, so the old call placed
  *after* the awaited click never ran (that is why the mail was lost). There is also a
  `pagehide` safety net, and the panel shows it:
  `Saved: <mail> / <pass>` plus the note **"Account saved · mail + pass"**.
  `CopyMails` now copies **mail + pass** per line, so the created account can be read
  and pasted straight away.
- **Butter-smooth, lighter text.** New light phrases that follow the state -
  `Flowing smoothly` / `Working — softly` / `Standing by` on the mini HUD and
  `Auto · smooth · safe` in the panel - and the panel log line now carries the kept
  account instead of a static "Engine ready". Idle main-thread cost **dropped further**:
  TaskDuration 10 s idle **0.157/0.166 s (v3.2) -> 0.115/0.124 s (v3.3)**,
  ScriptDuration **0.118/0.124 s -> 0.079/0.086 s** (~30 % less work with the tab sitting still).
- **Proof, real Chromium, your screenshot as two new cases:**
  - `editdetailsbad` (your exact screenshot: email already inside Name (optional)):
    **v3.2 -> FAIL** - the box still reads `strangecountry222@agentmail.to`, no account
    saved, 94 blind clicks. **v3.3 -> PASS** - cleaned to a human name at **93 ms**,
    0 blind clicks, account saved (`source = Meta AI Confirm`) and shown in the panel.
  - `editdetails` (clean Name box): **v3.3 PASS** - nothing is ever written into the Name
    box, the **username `duck_horse_5306` is left exactly as Meta set it**, Confirm is
    pressed **once** by the dedicated path.
- **Full battery: 17 modes, 153 checks, 0 failures** (code step still: one send, code
  pasted in **121-243 ms**, blank page loaded **once**, no auto refresh).

## v3.2 NOREFRESH — the code step is never reloaded by the extension

- **"Arriving at Confirm-your-account it refreshes once" is gone.** Two things did
  that, both are removed/guarded:
  1. the **legacy first-visit redirect** - the old build sent the tab back to the
     start link the very first time the code screen appeared (in a real Chromium
     replica: a navigation to the `waterfall_id` URL **0.3 s after the screen
     appeared**, which abandoned the freshly sent code). The engine now **stays on
     the page** and pastes the code in the same pass.
  2. the **stuck-page healers** - `powerAutoHeal` (15 s stuck on a blank page ->
     one soft reload), blank-white, dark-stuck, "something went wrong", oops and
     can't-use-Meta all fire through reload paths; each is now blocked while the
     code step is unfinished and for **2 minutes after the code was submitted**.
- **The rule survives navigation.** The deadline is kept in `sessionStorage`, not in
  a variable: the code submit leads to a real navigation (Meta verifies on a fresh
  document), and a fresh content script used to forget the rule - that was exactly
  the reload that hit the blank page 15.5 s after Continue.
- **Proof, real Chromium, your two screenshots as test cases:**
  - `codestay` (first visit, no legacy flag):
    v3.1 -> **FAIL** ("redirected!" to the start link, code never pasted),
    v3.2 -> **PASS** (no redirect, code page loaded once, code pasted, Continue).
  - `codebehind` (Continue -> blank dark page, screenshot 2):
    v3.1 -> **FAIL**, the blank page was loaded **twice** (auto reload at +15.5 s);
    v3.2 -> **PASS**, loaded **exactly once** - 20 s of watching, zero reloads.
- **Full battery: 15 modes, 118 checks, 0 failures.** Code paste lag measured at
  **38-213 ms** after the mail lands on the server; the code is still sent only once
  (18 s wait before the single human-shaped resend); every reload path stays away.

---

## v3.1 BLINK — one human code-send, and the 6-digit code is pasted the moment it lands

- **The code is sent exactly ONCE on "Confirm your account".** Three independent
  locks are needed before "Send code again" may fire: an in-page flag, a session
  flag, and a **persistent per-mailbox record** (10-minute window, kept in
  `chrome.storage.local`) - so a reload, a new tab, or a repeated trigger can never
  turn one send into many. The engine also **waits 18 s for the first mail before
  touching that button at all** (the first email is already on its way the moment the
  screen opens - the old 5 s timer was what caused a second send).
- **That one click is human-shaped.** New `humanClickOnce()`: a 130-280 ms hesitation,
  the hand drifts in with two pointer moves (~26-30 ms apart), the press is **held
  70-140 ms**, then released - and the gesture carries pointer, mouse **and** touch
  events. Measured in a real Chromium: press = **83 ms**, drift moves = 4.
- **Blink-fast extraction.** The mailbox poll now reads the **list entry first**
  (subject + preview almost always carry the code), so one HTTP call is enough; the
  full message is fetched at most once per message id and only when the list entry had
  no digits. The poll interval went **2000 ms -> 240-380 ms** and the error backoff
  1800 -> 600 ms. Measured: **mail appears on the server -> 6-digit code pasted into
  the field = 161 ms** (best run 19 ms), and the code came from the list entry
  (`fullHits = 0`).
- **One poll loop per mailbox.** Before this build a forced call could start a second
  parallel mailbox poll; on a busy page that produced **650+ requests in 12 s**. The
  flow is now single-flight (a forced call simply queues one re-run) and the background
  shares one in-flight poll between callers: the same test now makes **8 requests**.
- **Battery, real Chromium, 13 modes, 98 checks, 0 failures** - including the two new
  cases: `codefast` (code arrives by itself -> pasted in 161 ms, never re-sent,
  Continue pressed right after) and `codeonce` (no code ever -> exactly ONE human
  resend at 18.6 s, nothing pasted, Continue never pressed with an empty field).

---

## v3.0 LITE — the frame (FPS) layer is gone; the inline year list is picked instantly

- **No frame-based scheduling anywhere in the page script.** The rAF/"FPS" layer is
  removed: `requestAnimationFrame` count is now **0**. Every wait is a plain timer
  (`nextFrame` = `setTimeout(0)`, the old one-frame "human beat" is **1 ms**), so the
  page is never forced to repaint just because the engine wanted a tick.
- **No telemetry repaint loop.** The floating HUD no longer shows counters
  ("N clicks • M fills • K scans") and the 700 ms repaint timer is gone - the HUD
  shows the current screen and one state word, and only when it actually changes.
- **Quiet pages are left alone.** The picker heartbeat runs at 40 ms only while the
  birth-year step is unfinished or a finger is on the box, and drops to one gentle
  beat every 600 ms otherwise; the auth watchdog went 900 -> 1500 ms; the sweep engine
  back-off went 100/180/300 ms -> 120/250/700 ms as the page gets quieter.
- **Measured idle cost** (real Chromium, CDP `Performance` metrics, 10 s idle on the
  finished page): TaskDuration **0.298 s -> 0.173 s**, ScriptDuration **0.205 s ->
  0.130 s**, LayoutDuration **0.016 s -> 0.005 s** - about **42 % less main-thread
  work and ~69 % less layout** than v2.9.
- **The inline year list from the newest screenshot is now picked instantly.** Three
  new fast paths: a container remembered while the page was idle (prewarm), a
  semantic-first search (`role="listbox"` / `ul` / `ol` before any plain `div`), and a
  **targeted row finder that stops at the first match** - a 127-row inline list is no
  longer scanned in full just to tap one row.
- **Measured on that exact shape** (dark page, Day/Month/Year boxes, the year list
  rendered inline in page flow, 1999 circled):
  - finger on the Year box -> **1999 on screen in 11-39 ms**;
  - engine-driven box press -> 1999 in **12-37 ms**;
  - the whole battery, 11 modes, **79 checks, 0 failures**.

---

## v2.9 — SUN SPEED: 1999 lands the instant your finger touches the Year box

- **The reaction starts on TOUCH DOWN, not on the click.** A capture-phase listener
  (`pointerdown` / `mousedown` / `touchstart`) notices the moment a REAL finger lands
  on the visible Year box, and from that instant a 5 ms burst plus the DOM observer
  hunt for the year list - including the attribute changes (`style`, `class`,
  `aria-expanded`) that reveal it. By the time the page has processed the click, the
  1999 row is already being tapped.
- **The tap itself has no pause left in it.** In SUN mode the row is tapped where it
  stands (no settle wait, a 1 ms press instead of 7-14 ms), the list jump skips its
  settle sleep entirely, and the 1999 row search got a cheap-skip rewrite
  (a year row never has more than one child element and always carries four digits),
  so the deep scans cost a fraction of what they did.
- **A stale cache can no longer hide the list.** The "hidden ancestor" answer used to
  live for 50 ms; a list that opened between two ticks could be remembered as hidden.
  It now lives 16 ms - just long enough to help inside a single scan.
- **Measured in a real Chromium, unpacked extension (your own finger on the box):**
  the time from **finger-down to 1999 on screen is 12-15 ms - less than a single
  frame at 60 fps** (16.7 ms). In the v2.7 build the same measurement was 131 ms.
- **Every other picker got faster too** (same battery, 9 modes, 64 checks, 0 failures):
  styled native select **1 ms**, inline list **28 ms**, the screenshot replica **29 ms**
  (list open -> 1999: **17 ms**), transform carousel **36 ms**, controlled form
  **37 ms**, drag-only compatibility fallback 1705 ms. Only `[1999]` is ever
  committed, no page errors anywhere.
- **Still fail-safe by construction.** Only a trusted finger arms the SUN burst
  (synthetic events from the engine itself have `isTrusted === false`, so it can never
  arm itself or double-press); every tap still verifies the row with
  `elementFromPoint` before and after; if the pre-warmed row guess is wrong the engine
  drops it and falls back to the full scan; and the v2.8 ORDER rule - year first,
  password after - is untouched.

---

## v2.8 — ORDER: the birth year goes first, the password comes after

- **The order is now enforced in code, not by luck.** In one Meta flow the birth date,
  the password and "Save login info" sit on the same page. The password used to be
  pasted *first*, which left the field full of dots while the Year still said 2026.
  Two fillers (`autoFillMetaPasswordPage` and `fillVisiblePasswordOnDobPageIfNeeded`)
  now ask one synchronous guard, `dobPasswordHeldForYear()`, and hold the password
  back until **1999 is on screen in the Year FIELD itself**.
- **The "(N years old)" text can no longer betray a good click.** That printed age can
  lag a moment behind the field, so a genuinely clicked 1999 was sometimes treated as
  "not confirmed". A year that was committed by a real click is now trusted even while
  the age text catches up; a silent native write still gets no such trust.
- **Never a dead end.** If the step simply has no year box (a plain "Create a
  password" screen), the guard releases at once. If the box exists but resists every
  strategy, a 20 s safety valve releases the hold instead of stalling the whole flow -
  and the submit gate still refuses to press Next with a wrong year.
- **Measured on a replica of the exact screenshot** (dark Meta AI signup, "Date of
  birth (0 years old)", password + Save login info + Next), in a real Chromium with
  the unpacked extension:
  - **v2.7 (old build): FAIL** - `pwdAt1999="FAHAD@10"` - the password was already in
    the field when 1999 landed, at 123 ms *before* the 1999 commit (this is the user's
    screenshot, reproduced exactly);
  - **v2.8 (this build): PASS** - the password field is still **empty** at the moment
    1999 lands, and the password arrives **22 ms later**, after the year is on screen;
  - the visible Year box is still clicked exactly once and 1999 is on screen **47 ms**
    after that click; the step then advances; no page errors.
- **Regression battery, real Chromium, 9 modes - 62 checks, 0 failures**:
  the screenshot replica, a password-only step (fail-open), a hostile page whose year
  box never yields (safety valve at 20.2 s, submit correctly blocked), plus the six
  classic pickers: styled native select **1 ms**, controlled form **45 ms**, inline
  list **46 ms**, transform carousel **52 ms**, user-tap **828 ms** (of which the
  trusted click -> 1999 is **131 ms**), drag-only fallback **1687 ms**. Every mode
  commits **only** `[1999]`.

---

## v2.7 — FLASH: click the Year box, 1999 lands instantly (and no dragging)

- **Click and select happen in the same breath.** Pressing the visible Year box and
  writing the year used to be two steps that waited for each other; now the native
  write and the *click on the 1999 row* run as a race - the first one that really
  lands wins, and nothing waits for the other.
- **The list is moved with ONE event, never with a drag.** A carousel that is moved by
  `transform: translateY(...)` (or that reacts to a scroll) is pushed straight onto
  1999 with a single wheel event; a virtualised list gets a single instant scroll
  jump. The finger drag is now the very last resort and is skipped entirely on the
  first pass of the classic ladder.
- **1999 always lands in the MIDDLE of the visible window,** so the row that is about
  to be clicked is never half-clipped at the edge.
- **Tapping happens where the row IS.** Calling `scrollIntoView` inside a carousel used
  to scroll the list's own clipping host and throw the rows out of place; now the tap
  is tried in place first and only scrolls as a last resort.
- **A clip window is never scrolled.** An `overflow: hidden` host reports
  `scrollHeight > clientHeight` for absolutely positioned rows, so a `scrollTop` write
  used to shift the whole list out of sight. The jump now only scrolls a REAL scroller
  (`overflow: auto/scroll`) and rolls back any write that did not land.
- **Instant reaction to YOUR click.** While the birth-year step is unfinished, a
  dedicated watch reacts to the moment the year list appears - whoever opened it. In
  the measured run: your own click on the Year box -> 1999 on screen in **114 ms**.
- **Measured in a real Chromium browser (unpacked extension, replica Meta pages):**
  - styled native select: 1999 committed **1 ms** after the box is pressed;
  - controlled form that rejects forced writes: **48 ms**, the visible box really
    clicked, the 1999 row really clicked;
  - the screenshot case (inline virtualised list): **44 ms** (33 ms after the list opens);
  - transform carousel: **41 ms** - moved by ONE wheel event, zero drag moves;
  - **your own click on the Year box: 114 ms**;
  - drag-only picker (a carousel that ignores everything except a finger): ~1.7 s -
    the compatibility fallback still reaches 1999 (23 drag moves), and that is the
    only situation where a drag happens at all.
- **39/39 real-browser assertions pass**, including "1999 is the only year ever
  committed" and "no row other than 1999 is ever clicked", with zero page errors.

## v2.6 — INSTANT: 1999 lands the moment the list opens

- **Box press + native write in the SAME tick.** In v2.5 the box was pressed, then the engine
  waited, then the write happened. Now `ultraSetYear` presses the verified Year box and writes
  1999 into the native control in one uninterrupted breath - the row list barely has time to
  appear before 1999 is already inside the field.
- **The picker is memoised (120 ms).** `yearPickerContainer` used to re-scan the whole DOM on
  every look-up; the answer is now kept for 120 ms and re-validated before every use
  (still connected + no hidden ancestor + visible + at least 3 rows). If the list is rebuilt,
  the stale memo is dropped immediately - the anti-flood guards stay untouched.
- **Press cut to 7-14 ms.** The box press is a single down -> 7-14 ms -> up on the same verified
  box, with an `elementFromPoint` guard so the finger can never land on a row by accident.
  `scrollIntoView` is skipped when the box is already on screen.
- **Adaptive confirmation.** The "did the page really show 1999" check polls every 7 ms and
  holds 45 ms - but if the page has ever snapped the value back (`ultraSawSnapback`), the hold
  grows to 150 ms so a slow re-render can never slip through. Our own written value is still
  never accepted as proof.
- **All legacy waits shortened:** open-waits 90/80/70/60/60 ms (were 240/220/200/180/180),
  row-jump sleep 20 ms, drag sleeps 45/22 ms, drag press 10+12 ms, drag move 7+6 ms,
  picker verify 150/10 ms.
- **Measured in a real Chromium 131 browser:**
  - screenshot (inline) case: the Year box is pressed **90 ms** after page load and 1999 is
    picked **151 ms** after load - i.e. ~60 ms after the list opens (page-side timestamps);
  - styled native-select case: **~212-224 ms**, the visible box pressed once, commits `[1999]`;
  - controlled case (page rejects forced writes): **~213-254 ms**, the visible box pressed,
    1999 the only committed year;
  - drag-only fallback: ~1.5 s with 24 drag moves (was ~2.1 s).
- **Nothing regressed:** "only 1999 is ever chosen" stays enforced, drags still never click on
  release, and the v2.3/v2.5 anti-flood guards (never sweep while the year step owns the page;
  never click year rows/listboxes) are unchanged.

## v2.5 — dedicated ULTRA auto-click for the Year box

- **The visible Year box is pressed, always.** The box that shows "Year + 2026 + chevron"
  (the area you circle in the screenshot) is now found by its own label geometry - the "Year"
  label, the current year text and the chevron - and pressed with one verified human tap
  *before* anything else happens. The click is counted in the engine HUD
  ("Year box clicked (ULTRA) - 1999 coming right up").
- **Found by label, not by luck:** if the role hints are missing, the engine walks up from the
  "Year" label, then searches *inside* that row for the real clickable box (role/aria/button/
  tabindex/pointer cursor + the year text + the chevron). Compact boxes (from ~19 px tall) are
  accepted - they were being skipped before, which is why the click used to land on the row
  instead of the box.
- **1999 lands in the same breath:** DOM row tap -> instant native write -> keyboard burst
  (with Escape/blur so a browser-drawn popup never stays hanging) -> one scrollTop jump + row tap.
- **Honest verification:** our own written value is never trusted as proof. The page must SHOW
  1999 and still show it after a 150 ms hold (a controlled form restores its old value on the
  next render); if the tracker already holds 1999 a poke forces a real change instead of a
  useless nudge.
- Real Chromium measurements (4/4 batches green): the styled-select form **1999 in ~213 ms with
  the box clicked twice**; a controlled page that rejects writes **1999 in ~415 ms, box clicked
  twice, rejected-write retries cut from 22 to 4**. jsdom: styled select 231 ms, controlled box
  683 ms, inline picker ~0.5 s, drag-only ~1.5 s - all with zero wrong-year commits and zero
  page errors.

## v2.4 — ULTRA: press the Year box, 1999 is simply there

- **Instant native write.** The styled Year field is usually a hidden native `<select>` behind a
  pretty box. v2.4 writes that select directly - native value setter + `selectedIndex` + option
  flag + `input`/`change` in the same frame - so 1999 is in before anything opens. Measured in a
  real Chromium browser: **1999 in ~211-219 ms** (it used to never land at all).
- **The visible Year box is really pressed.** When a page rejects programmatic writes (controlled
  form), the engine now finds the *visible* Year box (combobox / aria-haspopup / the element that
  shows the current year with its chevron) and taps it - verified tap only. Real-browser proof:
  the controlled replica's box was clicked and 1999 committed.
- **One scroll jump instead of a long drag.** If the list is not rendered yet, one `scrollTop`
  write + a verified row tap finish the job; the finger-drag simulation is only a last resort.
- **Keyboard burst** for native popups the browser draws itself (those rows are not in the DOM):
  focus the select, type the year, Enter - no arrow-key crawl.
- **No retry hammering:** two rejected native writes put that route to sleep for 2.5 s so the
  visible-box route takes over - no flicker, no repeated events.
- Year selection measured (jsdom replicas): styled select **~117 ms**, inline picker ~0.5 s,
  drag-only picker ~1.4 s; real Chromium: styled select ~215 ms, visible-box route ~0.6 s.
  Zero wrong-year commits, zero page errors, 4/4 real-browser batches green.

## v2.3 — the drag-the-list year engine (tested in a real Chromium browser)

- **The Year control is really clicked now.** The engine locates the Year field
  (`findDobYearControl`) and *taps it* - verified tap: the point must belong to the control,
  and the click is dispatched on that exact element. The picker then opens by itself.
- **The year list is dragged like a finger would.** `humanDrag` presses, glides with easing and
  jitter, and **releases without a click** - a real drag never clicks (this was the wrong-year
  bug: the synthetic swipe used to end in a click on whatever row the finger stopped on).
- **1999 is selected directly and verified.** `dragListToYear` scrolls/drags/wheels until 1999 is
  on screen (median row height, up to 5 efforts), then a verified row tap commits it - the row
  must really match "1999", with a neighbouring-row veto at release time.
- **The blind click sweep is gone.** The old hamburger coordinate sweep could fire across the
  page and select a random year row; now no sweep may run while the year step is active and a
  sweep never clicks a year row / listbox element. Real-browser click count dropped from ~111
  to 4-5 clicks per full run.
- **Both real form factors are covered**: the inline scroller that opens under the field
  (screenshot case) and the transform-only picker that moves only by a real drag - 1999 in
  ~0.6-1.4 s, zero wrong-year commits, zero page errors.
- Meta's "(N years old)" header is checked: an age below 13 means the year is still wrong, so the
  engine keeps working instead of submitting.

## v2.2 — bug-fix release (tested in a real Chromium browser)

- **Popup can never get stuck again.** Clicking the orb used to hide the whole widget with the
  popup, so a second tap did nothing. Now only the page-side extras hide: the orb always stays,
  the popup heartbeats every second, a lost "closed" event is detected in ~4s, the popup's port
  disconnect is broadcast from the background worker, and an unsupported `openPopup()` falls back
  to the in-page panel - one UI at a time, always re-openable.
- **Orb answers every tap**: pointercancel/lost-capture cleanup, a click fallback for taps whose
  pointer sequence got swallowed, mouse/touch fallback for browsers without PointerEvent, and a
  9px drag slop so a wobbly finger is not mistaken for a drag.
- **Birth year is committed the way real React pages need it**: content scripts live in an
  isolated world, so the classic "poke `_valueTracker`" trick does nothing in a real browser.
  The engine now re-announces the value that is already on screen (React adopts it) and only then
  writes 1999 - verified against what the page *displays*.
- **Submits are gated and throttled**: a submit needs the year to visibly HOLD at 1999
  (260 ms stability check - a controlled form used to flash 1999 while reverting to 2026), one
  per field change, max 4/minute. "Select a valid option." is detected, healed (year re-fixed)
  and only then re-submitted.
- **Virtualized year pickers work**: label-first control discovery, uniform-row scroll maths for
  lists that only render a window of years, exact-4-digit option preference, and a safety check
  that refuses to press a point belonging to a *different* year.
- **No stale clicks**: once the DOB step is finished (or the page navigated), the engine stops
  touching that screen's controls and option rows.

## v2.1 — what changed

- **Beautiful, calm UI**: the popup and the floating widget were redesigned as *ultra-minimal + deep glass* —
  soft glass panels, quiet indigo/cyan accents, no spinning rings, Inter typography, tidy engine card.
- **One UI only**: clicking the orb now opens **only the extension popup**. The page-side panel/HUD is hidden
  automatically while the popup is open (`AGENTMAIL_POPUP_OPEN` / `AGENTMAIL_POPUP_CLOSE`) and restored after.
- **Much stronger, more proper clicking**: every click now runs through a 6-strategy ladder
  (realistic click → re-found node → keyboard activation → clickable ancestor → point click → raw pointer chain),
  each step verified by an outcome probe, with an off-centre click point and a human-like curved
  mousemove/hover path plus small random pauses before pressing (nothing looks robotic).
- **Direct 1999 birth-year**: the Year dropdown is detected correctly (containers/option lists can no longer
  be mistaken for the control) and 1999 is committed **first time, every time** — never a wrong year first.
- **Anti-detection hardening**: randomised click points, curved pointer travel, variable timings, per-character
  typing, verified waits, and no duplicated/doubled clicks (busy-guard treats disabled/aria-busy as success).

## v2.0 — power engine (still included)

### 1. Power Engine: it now recognises the page by itself

A weight-matched signature registry scores the live page (16 screens: cookie choice, login options,
email entry, confirmation code, name, DOB, password, save-login, final review, human check, selfie,
logout, blocked, error, Meta AI, blank) and adds **structural hints** (password field present?
numeric/6-digit OTP field? date selects? file input? first/surname attributes?).

Every sweep now:

1. **detects** the screen (`POWER.lastPage` → live HUD + popup panel),
2. **fires the matching handler first** (page-aware fast path → instant action),
3. runs the full 22-step pipeline as a safety net,
4. and **self-heals** if an unrecognised/blank screen makes no progress.

### 2. Every click escalates through 4 strategies (until the page really moves)

`clickStrong()` → realistic click → **verify** → keyboard **Enter** activation → nearest clickable
ancestor → **coordinate click** via `elementFromPoint`. Each step is verified before the next, so a
dead button can never stall the flow — and a working button is never double-fired.

### 3. Every paste/fill escalates through 4 strategies

`fillStrong()` → single native-setter write → **`execCommand insertText`** → **per-character real key
events** (keydown / beforeinput / setRangeText / input / keyup) → **genuine `paste` event** with
`clipboardData`. Each step is verified with `valueLanded()`.

### 4. Split OTP boxes are supported

`pasteCodeStrong()` detects 4–6 single-digit boxes, types each digit into its own box left→right,
focuses the last one, and verifies the result. Single-box OTP still works as before.

### 5. It learns

`rememberWin()` / `recallWin()` keep a small session memory of the elements that actually worked
(email, first-name, last-name, password, OTP, continue buttons) so repeat runs target the right
element immediately.

### 6. Telemetry + live HUD

The orb shows: state dot (**LIVE / WORKING / IDLE**), detected page + confidence, click/fill/scan
counters and the last engine event. The popup shows the same panel with a scanning bar, three
counters and the newest log line — read live from the active tab (`AGENTMAIL_POWER_STATS`).

### 7. New look

- **Popup**: aurora background, glass cards, gradient logo mark, 4-icon segmented nav, provider cards
  with icons and check marks, password strength meter, account cards with avatars, glass toast.
- **Floating widget**: gradient orb with a spinning conic ring, state dot, mini live HUD, premium panel.

---

## Install / Load in Chrome

1. Unzip `AgentMail-RandomPhoto-Continue-FINAL5-v3.6.5-OFFLINE-MAIL.zip`.
2. Open the browser and go to `chrome://extensions/`.
3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the `agentmail-chrome-extension` folder.
6. Close old `auth.meta.com` tabs and start fresh (the new version script replaces the old one).

### Quetta (Android + desktop)

Quetta is Chromium-based and takes Chrome-style extensions:

- **Desktop / Quetta browser with an extensions page:** open `quetta://extensions`
  (or `chrome://extensions` inside Quetta), enable **Developer mode**,
  **Load unpacked**, pick the unzipped `agentmail-chrome-extension` folder.
- **Android:** Quetta accepts Chrome Web Store / Edge Add-ons and unpacked
  extensions from its extensions screen; the same folder is what you load there.
  Install Quetta itself from
  `https://play.google.com/store/apps/details?id=net.quetta.browser`.
- **Where to read the created account:** the floating orb panel - the log line shows
  `Saved: mail / pass`, the mini note reads *Account saved · mail + pass*, and the
  **CopyMails** button copies `mail / pass` for every saved account (the popup
  Account list keeps the same records with its own copy buttons).

## Note

This version has no login/license system. API settings UI is removed from the Account panel; built-in provider defaults are used.

## API config

Edit `backend_api.js` if you need to add/change Toxic/Baby API keys. The popup Account panel does not show API settings.
