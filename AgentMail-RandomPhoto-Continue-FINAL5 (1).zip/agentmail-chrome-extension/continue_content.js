function isButtonActive(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') return false;

    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    if (style.pointerEvents === 'none' || style.cursor === 'not-allowed') return false;
    
    const opacity = parseFloat(style.opacity);
    if (opacity < 0.8) return false; 

    return true;
}

function findContinueButton() {
    const elements = Array.from(document.querySelectorAll('button, a, div[role="button"], input[type="button"], input[type="submit"]'));
    return elements.find(el => {
        const text = (el.innerText || el.value || '').trim().toLowerCase();
        if ((text === 'continue' || text.includes('continue')) && text.length < 20) {
            return isButtonActive(el);
        }
        return false;
    });
}

let isProcessing = false;

function startAutoClicker() {
    if (isProcessing) return;

    const btn = findContinueButton();

    if (btn) {
        isProcessing = true;
        let seconds = 2;

        const badge = document.createElement('div');
        badge.style.cssText = `
            position: absolute;
            background: #ff4757;
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            z-index: 999999;
            pointer-events: none;
            box-shadow: 0px 2px 8px rgba(0,0,0,0.3);
            font-family: sans-serif;
        `;
        badge.innerText = `⏳ Click in ${seconds}s`;
        document.body.appendChild(badge);

        const updatePosition = () => {
            const rect = btn.getBoundingClientRect();
            badge.style.top = `${rect.top + window.scrollY - 30}px`;
            badge.style.left = `${rect.left + window.scrollX + (rect.width / 4)}px`;
        };
        updatePosition();

        const timerInterval = setInterval(() => {
            seconds--;
            if (seconds > 0) {
                badge.innerText = `⏳ Click in ${seconds}s`;
                updatePosition();
            } else {
                clearInterval(timerInterval);
                badge.remove();

                if (isButtonActive(btn)) {
                    console.log("Clicking Continue Button...");
                    btn.click();
                    setTimeout(() => { isProcessing = false; }, 1500);
                } else {
                    isProcessing = false;
                }
            }
        }, 1000);
    }
}

setInterval(startAutoClicker, 800);