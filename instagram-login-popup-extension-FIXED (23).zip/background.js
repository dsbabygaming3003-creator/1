// Background Service Worker - IG 2FA Automation Pro v4.0.0

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "GET_COOKIES") {
    try {
      chrome.cookies.getAll({ domain: "instagram.com" }, (cookies) => {
        sendResponse({ success: true, cookies: cookies || [] });
      });
    } catch(e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }
  
  if (request.action === "CLEAR_DATA") {
    try {
      chrome.cookies.getAll({ domain: "instagram.com" }, (cookies) => {
        if (cookies && cookies.length) {
          cookies.forEach((cookie) => {
            const protocol = cookie.secure ? "https:" : "http:";
            const cleanDomain = cookie.domain.replace(/^\./, "");
            const cookieUrl = `${protocol}//${cleanDomain}${cookie.path}`;
            chrome.cookies.remove({ url: cookieUrl, name: cookie.name }).catch(() => {});
          });
        }
        
        if (chrome.browsingData && chrome.browsingData.remove) {
          chrome.browsingData.remove({
            origins: [
              "https://www.instagram.com",
              "https://accountscenter.instagram.com",
              "https://accountscenter.meta.com",
              "https://auth.meta.com"
            ]
          }, {
            cookies: true,
            localStorage: true,
            sessionStorage: true,
            cacheStorage: true
          }).then(() => {
            sendResponse({ success: true });
          }).catch(() => {
            sendResponse({ success: true });
          });
        } else {
          sendResponse({ success: true });
        }
      });
    } catch(err) {
      sendResponse({ success: false, error: err.message });
    }
    return true;
  }
  
  if (request.action === "GET_STATUS") {
    chrome.storage.local.get(["extensionEnabled"], (result) => {
      sendResponse({ enabled: result.extensionEnabled !== false });
    });
    return true;
  }
  
  if (request.action === "TOGGLE_EXTENSION") {
    chrome.storage.local.get(["extensionEnabled"], (result) => {
      const newState = result.extensionEnabled === false;
      chrome.storage.local.set({ extensionEnabled: newState }, () => {
        chrome.tabs.query({}, (tabs) => {
          tabs.forEach(tab => {
            if (tab.id && tab.url && tab.url.includes("instagram.com")) {
              chrome.tabs.sendMessage(tab.id, { action: "TOGGLE_STATE", enabled: newState }).catch(() => {});
            }
          });
        });
        sendResponse({ enabled: newState });
      });
    });
    return true;
  }

  if (request.action === "SAVE_DATA") {
    chrome.storage.local.set({ [request.key]: request.data }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === "GET_DATA") {
    chrome.storage.local.get([request.key], (result) => {
      sendResponse({ data: result[request.key] || null });
    });
    return true;
  }
});

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    extensionEnabled: true,
    installTime: new Date().toISOString()
  });
  console.log("🔥 IG 2FA Automation Pro v4.0.0 Installed!");
});
