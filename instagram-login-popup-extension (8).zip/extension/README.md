# 🔥 IG 2FA Automation Pro - Chrome Extension

A powerful Chrome extension for Instagram automation with **2FA key extraction**, **auto-fill functionality**, and a beautiful **floating UI panel**.

## ✨ Features

- 🎯 **Auto-floating popup** on Instagram login page
- ⚡ **ON/OFF Toggle Button** - Simple power control
- 📧 **Email/Password Auto-fill**
- 🔐 **2FA Key Extraction & Save**
- 📥 **CSV Export** for all saved 2FA keys
- 🎨 **Draggable Floating Button**
- 💾 **Local Storage Persistence**

## 📦 Installation

### Method 1: Developer Mode (Recommended)

1. Download/Clone this extension folder
2. Open Chrome browser
3. Navigate to `chrome://extensions/`
4. Enable **Developer mode** (top-right toggle)
5. Click **"Load unpacked"**
6. Select the `extension` folder
7. Extension is now installed! 🔥

### Method 2: From Web Store (Coming Soon)

[Will be available soon on Chrome Web Store]

## 🚀 How to Use

1. **Install** the extension
2. **Visit** any Instagram page (`instagram.com`)
3. You'll see a **floating button** (Instagram gradient colored)
4. **Click** the floating button to open the control panel
5. Use the **ON/OFF toggle** to enable/disable automation
6. The button is **draggable** - drag it anywhere you want!

## 🎮 Controls

| Control | Function |
|---------|----------|
| 🔘 Main Toggle | ON/OFF automation |
| ✕ Close | Hide panel |
| Drag Button | Move anywhere |

## 🔗 Target URL

The auto-popup appears when visiting:
```
https://www.instagram.com/accounts/login/?next=%2F&source=mobile_nav
```

And works on:
- `https://www.instagram.com/*`
- `*://accountscenter.instagram.com/*`
- `*://accountscenter.meta.com/*`

## 🛠️ Tech Stack

- **Manifest V3** (Latest Chrome API)
- **Vanilla JavaScript** (No dependencies)
- **CSS3 Animations**
- **Chrome Storage API**

## 📁 File Structure

```
extension/
├── manifest.json      # Extension configuration
├── background.js      # Service worker
├── content.js         # Main injection script
├── styles.css         # UI styles
├── popup.html         # Popup page
├── popup.js           # Popup logic
├── icons/
│   ├── icon16.png     # 16x16 icon
│   ├── icon48.png     # 48x48 icon
│   └── icon128.png    # 128x128 icon
└── README.md          # This file
```

## ⚠️ Disclaimer

This tool is for educational purposes only. Use responsibly.

## 👨‍💻 Author

Based on code from: [GitHub Repository](https://github.com/dsbabygaming3003-creator/baby)

---

Made with ❤️ | v3.4.0
