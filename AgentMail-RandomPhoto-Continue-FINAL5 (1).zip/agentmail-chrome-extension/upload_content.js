(() => {
  "use strict";

  const IMAGES = [
    chrome.runtime.getURL("photo1.jpg"),
    chrome.runtime.getURL("photo2.jpg"),
    chrome.runtime.getURL("photo3.jpg"),
    chrome.runtime.getURL("photo4.jpg")
  ];

  let done = false;

  async function chooseRandomFile() {
    const url = IMAGES[Math.floor(Math.random() * IMAGES.length)];
    const response = await fetch(url);
    const blob = await response.blob();
    return new File([blob], "random-test-photo.jpg", {
      type: blob.type || "image/jpeg",
      lastModified: Date.now()
    });
  }

  async function fillInput(input) {
    if (done || !input || input.type !== "file") return;
    if (input.files && input.files.length) return;

    try {
      const file = await chooseRandomFile();
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;

      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      done = true;
      console.log("[Random Auto Upload] Image attached successfully.");
    } catch (e) {
      console.error("[Random Auto Upload]", e);
    }
  }

  function scan() {
    document.querySelectorAll('input[type="file"]').forEach(fillInput);
  }

  scan();

  new MutationObserver(scan).observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();
