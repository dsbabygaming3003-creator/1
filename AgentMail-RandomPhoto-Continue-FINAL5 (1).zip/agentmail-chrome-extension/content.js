(() => {
  const AGENTMAIL_SCRIPT_VERSION = "1.8.20";

  function clearOldAgentmailTimers() {
    // Older versions had local setInterval IDs that were not stored on window.
    // Clear timers in this extension isolated world so old click loops stop.
    try {
      const maxTimerId = setTimeout(() => {}, 0);
      clearTimeout(maxTimerId);
      const startId = Math.max(1, maxTimerId - 2500);
      for (let id = startId; id <= maxTimerId; id += 1) {
        clearTimeout(id);
        clearInterval(id);
      }
    } catch (error) {}
  }

  if (window.__agentmailDynamicMenuLoaded && window.__agentmailDynamicMenuVersion === AGENTMAIL_SCRIPT_VERSION) {
    window.__agentmailRunMetaAutomation?.(true);
    return;
  }

  // If an older content script is already injected in this tab, do not return.
  // Clear old timers/observers so the updated rules can take over immediately.
  if (window.__agentmailDynamicMenuLoaded && window.__agentmailDynamicMenuVersion !== AGENTMAIL_SCRIPT_VERSION) {
    clearOldAgentmailTimers();
    try { clearInterval(window.__agentmailNamePoller); } catch (error) {}
    try { clearInterval(window.__agentmailEmailPoller); } catch (error) {}
    try { clearInterval(window.__agentmailMetaClickLoopTimer); } catch (error) {}
    try { window.__agentmailMetaObserver?.disconnect(); } catch (error) {}
    window.__agentmailNamePoller = null;
    window.__agentmailEmailPoller = null;
    window.__agentmailMetaClickLoopTimer = null;
    window.__agentmailMetaObserver = null;
    window.__agentmailAuthStuckWatchdogStarted = false;
    window.__agentmailMetaClickLoopRunning = false;
    window.__agentmailLanguageRedirecting = false;
    window.__agentmailFloatingMiniMenuStarted = false;
    try { document.getElementById("agentmail-floating-widget-host")?.remove(); } catch (error) {}
  }

  window.__agentmailDynamicMenuLoaded = true;
  window.__agentmailDynamicMenuVersion = AGENTMAIL_SCRIPT_VERSION;

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function queryAllDeep(selector, root = document) {
    const results = [];
    try {
      results.push(...root.querySelectorAll(selector));
      const all = root.querySelectorAll("*");
      for (const el of all) {
        if (el.shadowRoot) results.push(...queryAllDeep(selector, el.shadowRoot));
      }
    } catch (error) {
      // Ignore restricted roots.
    }
    return results;
  }

  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }

  function normalizeText(text) {
    return (text || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function rectArea(el) {
    const rect = el.getBoundingClientRect();
    return rect.width * rect.height;
  }

  function isMetaAuthPage() {
    return window.location.hostname.toLowerCase() === "auth.meta.com";
  }

  const META_AI_HOME_URL = "https://www.meta.ai/";

  const CODE_PAGE_REDIRECT_URL = "http://auth.meta.com/?waterfall_id";

  const AUTH_META_START_URL = "http://auth.meta.com/?waterfall_id";

  function isMetaAccountsCenterPage() {
    const host = window.location.hostname.toLowerCase();
    return host === "accountscenter.meta.com" || host === "accountcenter.meta.com";
  }

  function isMetaAccountsCenterLandingPage() {
    if (!isMetaAccountsCenterPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      (pageText.includes("accounts centre") || pageText.includes("accounts center")) &&
      (
        pageText.includes("manage your connected experiences") ||
        pageText.includes("account settings") ||
        pageText.includes("profiles and personal details") ||
        pageText.includes("password and security") ||
        pageText.includes("manage accounts")
      )
    );
  }

  function redirectAccountsCenterToAuthStart(force = false) {
    if (!isMetaAccountsCenterPage()) return { ok: false, message: "Not Accounts Centre." };
    if (!force && window.__agentmailAccountsCenterRedirecting) {
      return { ok: true, message: "Accounts Centre redirect already queued." };
    }
    if (!force && !isMetaAccountsCenterLandingPage()) {
      return { ok: false, message: "Accounts Centre landing page not found yet." };
    }

    window.__agentmailAccountsCenterRedirecting = true;
    setTimeout(() => {
      try { window.location.replace(AUTH_META_START_URL); }
      catch (error) { window.location.href = AUTH_META_START_URL; }
    }, 350);
    return { ok: true, message: "Accounts Centre detected; going to auth.meta.com start." };
  }

  function startAccountsCenterRedirectWatcher() {
    if (!isMetaAccountsCenterPage() || window.__agentmailAccountsCenterWatcherStarted) return;
    window.__agentmailAccountsCenterWatcherStarted = true;
    redirectAccountsCenterToAuthStart(false);
    const timer = setInterval(() => {
      const result = redirectAccountsCenterToAuthStart(false);
      if (result.ok || !isMetaAccountsCenterPage()) {
        clearInterval(timer);
      }
    }, 500);
    setTimeout(() => clearInterval(timer), 30000);
  }

  function textScore(el, words) {
    const haystack = normalizeText([
      el.type,
      el.name,
      el.id,
      el.autocomplete,
      el.placeholder,
      el.getAttribute("aria-label"),
      el.getAttribute("data-testid"),
      el.getAttribute("role")
    ].filter(Boolean).join(" "));

    return words.reduce((score, word) => score + (haystack.includes(word) ? 1 : 0), 0);
  }

  function getEditableValue(el) {
    if (!el) return "";
    if (el.isContentEditable) return el.textContent || "";
    return el.value || "";
  }

  function bestInput(kind) {
    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el));

    if (kind === "password") {
      return inputs.find((el) => el.tagName === "INPUT" && el.type === "password") || null;
    }

    const emailExact = inputs.find((el) => el.tagName === "INPUT" && el.type === "email");
    if (emailExact) return emailExact;

    const emailWords = ["email", "mail", "e-mail", "username", "login", "user", "mobile", "phone"];
    const ranked = inputs
      .filter((el) => {
        if (el.isContentEditable) return true;
        const type = (el.type || "text").toLowerCase();
        return ["text", "search", "email", "tel", "url", ""].includes(type) || el.tagName === "TEXTAREA";
      })
      .map((el) => ({ el, score: textScore(el, emailWords) }))
      .sort((a, b) => b.score - a.score);

    return ranked[0]?.el || null;
  }

  function dispatchInputEvents(element, value, previousValue = "") {
    try {
      element.dispatchEvent(new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: "insertText",
        data: value
      }));
    } catch (error) {
      element.dispatchEvent(new Event("beforeinput", { bubbles: true, cancelable: true, composed: true }));
    }

    const tracker = element._valueTracker;
    if (tracker) tracker.setValue(previousValue);

    try {
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        cancelable: false,
        composed: true,
        inputType: "insertText",
        data: value
      }));
    } catch (error) {
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }

    element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key: "a", code: "KeyA" }));
    element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key: "a", code: "KeyA" }));
    element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    element.dispatchEvent(new Event("blur", { bubbles: true, composed: true }));
    element.focus?.();
  }

  function setNativeValue(element, value) {
    if (!element) return;

    if (element.isContentEditable) {
      const previous = element.textContent || "";
      element.focus?.();
      element.textContent = value;
      dispatchInputEvents(element, value, previous);
      return;
    }

    const previous = element.value || "";
    element.focus?.();
    element.click?.();

    try {
      element.select?.();
      document.execCommand?.("insertText", false, value);
    } catch (error) {
      // Continue with native setter fallback.
    }

    if ((element.value || "") !== value) {
      const prototype = Object.getPrototypeOf(element);
      const protoSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      const ownSetter = Object.getOwnPropertyDescriptor(element, "value")?.set;

      if (protoSetter && ownSetter !== protoSetter) protoSetter.call(element, value);
      else if (ownSetter) ownSetter.call(element, value);
      else element.value = value;
    }

    dispatchInputEvents(element, value, previous);

    // Some controlled mobile inputs rewrite once; force again if needed.
    if ((element.value || "") !== value) {
      element.value = value;
      dispatchInputEvents(element, value, previous);
    }
  }

  function flash(element) {
    if (!element?.style) return;
    const previousOutline = element.style.outline;
    const previousBoxShadow = element.style.boxShadow;
    element.style.outline = "2px solid #6d5dfc";
    element.style.boxShadow = "0 0 0 4px rgba(109,93,252,.18)";
    setTimeout(() => {
      element.style.outline = previousOutline;
      element.style.boxShadow = previousBoxShadow;
    }, 450);
  }

  function fill(kind, value) {
    const input = bestInput(kind);
    if (!input) {
      return { ok: false, message: `${kind} input not found on this page.` };
    }
    setNativeValue(input, value);
    flash(input);
    return {
      ok: true,
      message: `${kind} filled.`,
      matched: {
        tag: input.tagName,
        type: input.type || "",
        name: input.name || "",
        id: input.id || "",
        placeholder: input.placeholder || ""
      }
    };
  }

  function getClickableTarget(el) {
    let node = el;
    const maxArea = Math.max(rectArea(el) * 10, 200000);

    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;

      const role = (node.getAttribute("role") || "").toLowerCase();
      const tag = node.tagName;
      const style = window.getComputedStyle(node);
      const clickable =
        tag === "BUTTON" ||
        tag === "A" ||
        role === "button" ||
        node.tabIndex >= 0 ||
        style.cursor === "pointer" ||
        typeof node.onclick === "function";

      if (clickable && rectArea(node) <= maxArea) return node;
    }

    return el;
  }

  function emailChoicePhrases() {
    return [
      "use mobile number or email address",
      "use mobile number or email",
      "mobile number or email address",
      "mobile number or email"
    ];
  }

  function isBadSocialChoiceText(text) {
    return text.includes("continue with facebook") ||
      text.includes("continue with instagram") ||
      text.includes("facebook") ||
      text.includes("instagram");
  }

  function findMetaEmailChoiceButton() {
    const phrases = emailChoicePhrases();

    // IMPORTANT: return the exact email text/row only. Never return a parent
    // container that also contains Facebook/Instagram options.
    const candidates = queryAllDeep("button, a, [role='button'], div, span, p")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        const matchedPhrase = phrases.find((phrase) => text === phrase) || phrases.find((phrase) => text.includes(phrase));
        const role = (el.getAttribute("role") || "").toLowerCase();
        const tag = el.tagName;
        return {
          el,
          text,
          area: rect.width * rect.height,
          top: rect.top,
          left: rect.left,
          width: rect.width,
          height: rect.height,
          matchedPhrase,
          exact: Boolean(matchedPhrase && text === matchedPhrase),
          interactive: tag === "BUTTON" || tag === "A" || role === "button" || el.tabIndex >= 0
        };
      })
      .filter((item) => item.matchedPhrase)
      .filter((item) => !item.text.includes("edit email"))
      .filter((item) => !isBadSocialChoiceText(item.text))
      .filter((item) => item.text.length <= 95 && item.area > 25 && item.area < 190000)
      .sort((a, b) => {
        if (a.exact !== b.exact) return a.exact ? -1 : 1;
        if (a.interactive !== b.interactive) return a.interactive ? -1 : 1;
        // Prefer the lowest matching email option if text fragments duplicate.
        return a.area - b.area || b.top - a.top;
      });

    return candidates[0]?.el || null;
  }

  function getEmailChoiceRowFromLabel(labelEl) {
    if (!labelEl) return null;
    const phrases = emailChoicePhrases();
    let row = labelEl;
    const labelRect = labelEl.getBoundingClientRect();
    const labelCenterY = labelRect.top + labelRect.height / 2;

    for (let node = labelEl, depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute("aria-label"));
      if (!phrases.some((phrase) => text.includes(phrase))) break;
      if (isBadSocialChoiceText(text)) break;

      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const looksLikeOptionRow =
        rect.width >= window.innerWidth * 0.48 &&
        rect.height >= 38 && rect.height <= 170 &&
        area < 210000 &&
        labelCenterY >= rect.top && labelCenterY <= rect.bottom;

      if (looksLikeOptionRow) row = node;
    }

    const rowText = normalizeText(row.innerText || row.textContent || row.getAttribute("aria-label"));
    if (isBadSocialChoiceText(rowText) || !phrases.some((phrase) => rowText.includes(phrase))) return labelEl;
    return row;
  }

  function getMetaInitialOptionRows() {
    if (!isMetaAuthPage()) return [];
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (!pageText.includes("log in or create an account")) return [];

    const optionTexts = [
      "continue with facebook",
      "continue with instagram",
      "use mobile number or email address",
      "use mobile number or email"
    ];

    const rows = queryAllDeep("button, a, [role='button'], div")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        return { el, text, rect, area: rect.width * rect.height };
      })
      .filter((item) => optionTexts.some((phrase) => item.text.includes(phrase)))
      .filter((item) => item.rect.width >= window.innerWidth * 0.45)
      .filter((item) => item.rect.height >= 42 && item.rect.height <= 150)
      .filter((item) => item.area > 4000 && item.area < 190000)
      .sort((a, b) => (a.rect.top - b.rect.top) || (b.area - a.area));

    const unique = [];
    for (const item of rows) {
      const itemY = item.rect.top + item.rect.height / 2;
      const existing = unique.find((u) => Math.abs((u.rect.top + u.rect.height / 2) - itemY) < 18);
      if (!existing) unique.push(item);
      else if (item.rect.width > existing.rect.width) {
        unique[unique.indexOf(existing)] = item;
      }
    }
    return unique;
  }

  function findMetaInitialFirstOptionRow() {
    const unique = getMetaInitialOptionRows();
    const facebook = unique.find((item) => item.text.includes("continue with facebook"));
    return (facebook || unique[0])?.el || null;
  }

  function clickInitialFirstOptionOnly(row) {
    if (!row) return false;
    row.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    row.focus?.();
    flash(row);

    const tap = (index = 0) => {
      const rect = row.getBoundingClientRect(); // recompute after scroll
      const y = rect.top + rect.height / 2;
      const xList = [
        rect.left + rect.width * 0.48, // text area in 1st row
        rect.left + rect.width * 0.20, // icon/text-left area
        rect.right - Math.min(52, rect.width * 0.09) // right control/radio
      ];
      let x = xList[index] || xList[0];
      x = Math.max(rect.left + 12, Math.min(rect.right - 12, x));

      let target = document.elementFromPoint(x, y);
      if (!target || !(target === row || row.contains(target))) target = row;

      const mouseInit = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: window.screenX + x,
        screenY: window.screenY + y,
        button: 0,
        buttons: 1
      };
      const pointerInit = { ...mouseInit, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;
      try {
        const touch = new Touch({ identifier: 1, target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y, pageX: window.scrollX + x, pageY: window.scrollY + y, radiusX: 8, radiusY: 8, force: 0.8 });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch (error) {}
      target.dispatchEvent(new Pointer("pointerover", pointerInit));
      target.dispatchEvent(new Pointer("pointerenter", pointerInit));
      target.dispatchEvent(new Pointer("pointerdown", pointerInit));
      target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
      target.dispatchEvent(new Pointer("pointerup", { ...pointerInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...mouseInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...mouseInit, buttons: 0 }));
      try { target.click?.(); } catch (error) {}
      if (target !== row) {
        try { row.click?.(); } catch (error) {}
      }
    };

    [0, 1, 2].forEach((index) => setTimeout(() => tap(index), index * 180));
    return true;
  }

  function findMetaInitialThirdEmailOptionRow() {
    if (!isMetaAuthPage()) return null;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (!pageText.includes("log in or create an account")) return null;

    const optionTexts = [
      "continue with facebook",
      "continue with instagram",
      "use mobile number or email address",
      "use mobile number or email"
    ];

    const rows = queryAllDeep("button, a, [role='button'], div")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        return { el, text, rect, area: rect.width * rect.height };
      })
      .filter((item) => optionTexts.some((phrase) => item.text.includes(phrase)))
      .filter((item) => item.rect.width >= window.innerWidth * 0.45)
      .filter((item) => item.rect.height >= 42 && item.rect.height <= 150)
      .filter((item) => item.area > 4000 && item.area < 190000)
      .sort((a, b) => (a.rect.top - b.rect.top) || (b.area - a.area));

    // Deduplicate nested text/row elements by vertical overlap, keeping the widest row.
    const unique = [];
    for (const item of rows) {
      const existing = unique.find((u) => Math.abs((u.rect.top + u.rect.height / 2) - (item.rect.top + item.rect.height / 2)) < 18);
      if (!existing) unique.push(item);
      else if (item.rect.width > existing.rect.width) {
        const index = unique.indexOf(existing);
        unique[index] = item;
      }
    }

    const emailRow = unique.find((item) =>
      item.text.includes("use mobile number or email address") ||
      item.text.includes("use mobile number or email")
    );
    // User requested: only Use mobile number or email address, never Facebook/Instagram.
    return emailRow?.el || null;
  }

  function clickInitialThirdEmailOptionOnly(row) {
    if (!row) return false;
    let rowText = normalizeText(row.innerText || row.textContent || row.getAttribute("aria-label"));
    if (isBadSocialChoiceText(rowText) || !(rowText.includes("use mobile number or email address") || rowText.includes("use mobile number or email"))) return false;

    row.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    row.focus?.();
    flash(row);

    const tap = (index = 0) => {
      const rect = row.getBoundingClientRect(); // recompute AFTER scroll; stale coords clicked wrong rows before.
      rowText = normalizeText(row.innerText || row.textContent || row.getAttribute("aria-label"));
      if (isBadSocialChoiceText(rowText) || !(rowText.includes("use mobile number or email address") || rowText.includes("use mobile number or email"))) return;

      const y = rect.top + rect.height / 2;
      const xList = [
        rect.left + rect.width * 0.46, // text area in 3rd row
        rect.left + rect.width * 0.24, // icon/text-left area in 3rd row
        rect.right - Math.min(52, rect.width * 0.09) // right control, still inside 3rd row
      ];
      let x = xList[index] || xList[0];
      x = Math.max(rect.left + 12, Math.min(rect.right - 12, x));

      let target = document.elementFromPoint(x, y);
      if (!target || !(target === row || row.contains(target))) target = row;
      const targetText = normalizeText(target.innerText || target.textContent || target.getAttribute?.("aria-label"));
      if (isBadSocialChoiceText(targetText)) target = row;

      const mouseInit = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: window.screenX + x,
        screenY: window.screenY + y,
        button: 0,
        buttons: 1
      };
      const pointerInit = { ...mouseInit, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;
      try {
        const touch = new Touch({ identifier: 1, target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y, pageX: window.scrollX + x, pageY: window.scrollY + y, radiusX: 8, radiusY: 8, force: 0.8 });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch (error) {}
      target.dispatchEvent(new Pointer("pointerover", pointerInit));
      target.dispatchEvent(new Pointer("pointerenter", pointerInit));
      target.dispatchEvent(new Pointer("pointerdown", pointerInit));
      target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
      target.dispatchEvent(new Pointer("pointerup", { ...pointerInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...mouseInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...mouseInit, buttons: 0 }));
      try { target.click?.(); } catch (error) {}
      if (target !== row) {
        try { row.click?.(); } catch (error) {}
      }
    };

    [0, 1, 2].forEach((index) => setTimeout(() => tap(index), index * 220));
    return true;
  }

  function fireEmailChoiceClick(labelOrRow) {
    if (!labelOrRow) return false;

    const emailRow = getEmailChoiceRowFromLabel(labelOrRow) || labelOrRow;
    let rowText = normalizeText(emailRow.innerText || emailRow.textContent || emailRow.getAttribute("aria-label"));
    if (isBadSocialChoiceText(rowText)) return false;

    emailRow.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    emailRow.focus?.();
    flash(emailRow);

    let labelRect = labelOrRow.getBoundingClientRect();
    let rowRect = emailRow.getBoundingClientRect();
    let clickY = Math.max(rowRect.top + 8, Math.min(rowRect.bottom - 8, labelRect.top + labelRect.height / 2));

    const sendEvents = (target, x, y) => {
      // Clamp to the email row rectangle, so it cannot hit Facebook/Instagram rows.
      x = Math.max(rowRect.left + 8, Math.min(rowRect.right - 8, x));
      y = Math.max(rowRect.top + 8, Math.min(rowRect.bottom - 8, y));

      if (!target || !(target === emailRow || emailRow.contains(target))) target = emailRow;
      const targetText = normalizeText(target.innerText || target.textContent || target.getAttribute?.("aria-label"));
      if (isBadSocialChoiceText(targetText)) target = emailRow;

      const mouseInit = {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        clientX: x,
        clientY: y,
        screenX: window.screenX + x,
        screenY: window.screenY + y,
        button: 0,
        buttons: 1
      };
      const pointerInit = { ...mouseInit, pointerId: 1, pointerType: "touch", isPrimary: true };
      const Pointer = window.PointerEvent || window.MouseEvent;

      try {
        const touch = new Touch({ identifier: 1, target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y, pageX: window.scrollX + x, pageY: window.scrollY + y, radiusX: 8, radiusY: 8, force: 0.7 });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch (error) {}

      target.dispatchEvent(new Pointer("pointerover", pointerInit));
      target.dispatchEvent(new Pointer("pointerenter", pointerInit));
      target.dispatchEvent(new Pointer("pointerdown", pointerInit));
      target.dispatchEvent(new MouseEvent("mousedown", mouseInit));
      target.dispatchEvent(new Pointer("pointerup", { ...pointerInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("mouseup", { ...mouseInit, buttons: 0 }));
      target.dispatchEvent(new MouseEvent("click", { ...mouseInit, buttons: 0 }));
      try { target.click?.(); } catch (error) {}
    };

    // Find controls inside the email row only whose vertical center matches the email row.
    const controls = [emailRow, ...emailRow.querySelectorAll?.("input, button, [role='radio'], [role='button'], [tabindex], div, span") || []]
      .filter((el) => isVisible(el) && (el === emailRow || emailRow.contains(el)))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        return { el, rect, text, area: rect.width * rect.height };
      })
      .filter((item) => !isBadSocialChoiceText(item.text))
      .filter((item) => item.rect.top >= rowRect.top - 4 && item.rect.bottom <= rowRect.bottom + 4)
      .sort((a, b) => {
        const rightA = a.rect.left > rowRect.left + rowRect.width * 0.70 ? 0 : 1;
        const rightB = b.rect.left > rowRect.left + rowRect.width * 0.70 ? 0 : 1;
        if (rightA !== rightB) return rightA - rightB;
        const inputA = a.el.tagName === "INPUT" || (a.el.getAttribute("role") || "").toLowerCase() === "radio" ? 0 : 1;
        const inputB = b.el.tagName === "INPUT" || (b.el.getAttribute("role") || "").toLowerCase() === "radio" ? 0 : 1;
        if (inputA !== inputB) return inputA - inputB;
        return a.area - b.area;
      });

    // First click text center (safest), then row right-side radio/control inside same row.
    const labelCenterX = labelRect.left + labelRect.width / 2;
    const plans = [
      { target: labelOrRow, x: labelCenterX, y: clickY },
      { target: emailRow, x: rowRect.left + rowRect.width * 0.52, y: clickY }
    ];
    if (controls[0]) {
      const r = controls[0].rect;
      plans.push({ target: controls[0].el, x: r.left + r.width / 2, y: r.top + r.height / 2 });
    }
    plans.push({ target: emailRow, x: rowRect.right - Math.min(44, rowRect.width * 0.08), y: clickY });

    plans.forEach((plan, index) => {
      setTimeout(() => sendEvents(plan.target, plan.x, plan.y), index * 140);
    });
    return true;
  }

  function isMetaEmailEntryPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    // Confirmation page has "Edit mobile number or email address" text, but it is NOT
    // the email-entry page. Never paste a new mail or click that edit link here.
    if (
      pageText.includes("confirm your account") ||
      pageText.includes("we sent a code") ||
      pageText.includes("look for an email") ||
      pageText.includes("send code again") ||
      pageText.includes("edit mobile number or email address") ||
      pageText.includes("edit email address")
    ) {
      return false;
    }

    const looksLikeEmailText =
      pageText.includes("what's your mobile number or email address") ||
      pageText.includes("what’s your mobile number or email address") ||
      pageText.includes("enter your mobile number or email address") ||
      pageText.includes("mobile number or email address to log in") ||
      pageText.includes("mobile number or email address") ||
      pageText.includes("email address or mobile number") ||
      pageText.includes("email or mobile number") ||
      pageText.includes("phone number or email") ||
      pageText.includes("email or phone") ||
      pageText.includes("enter your email") ||
      pageText.includes("email address");

    if (looksLikeEmailText) {
      // Avoid treating later account-creation forms as the email page.
      const definitelyOtherStep =
        pageText.includes("first name") ||
        pageText.includes("surname") ||
        pageText.includes("last name") ||
        pageText.includes("date of birth") ||
        pageText.includes("create a password") ||
        pageText.includes("confirmation code") ||
        pageText.includes("confirm your account") ||
        pageText.includes("we sent a code") ||
        pageText.includes("look for an email") ||
        pageText.includes("send code again") ||
        pageText.includes("edit mobile number or email address") ||
        pageText.includes("edit email address") ||
        pageText.includes("upload a verification selfie");
      if (!definitelyOtherStep) return true;
    }

    return queryAllDeep("input, textarea, [contenteditable='true']").some((el) => {
      const nearby = normalizeText([
        el.type,
        el.name,
        el.id,
        el.autocomplete,
        el.placeholder,
        el.getAttribute("aria-label"),
        el.getAttribute("data-testid"),
        el.getAttribute("aria-describedby"),
        el.closest("label")?.innerText,
        el.parentElement?.innerText,
        el.parentElement?.parentElement?.innerText
      ].filter(Boolean).join(" "));
      return nearby.includes("mobile number or email") || nearby.includes("email address") || nearby.includes("email or mobile") || nearby.includes("email or phone");
    });
  }

  function findMetaEmailInput() {
    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el))
      .filter((el) => {
        if (el.isContentEditable) return true;
        const type = (el.type || "text").toLowerCase();
        return ["email", "text", "tel", "search", "", "url"].includes(type) || el.tagName === "TEXTAREA";
      });

    const phrases = [
      "mobile number or email address",
      "mobile number or email",
      "email address or mobile number",
      "email or mobile number",
      "phone number or email",
      "email or phone",
      "email address",
      "email",
      "mobile number"
    ];

    const pageLooksLikeEmail = isMetaEmailEntryPage();
    if (!inputs.length) return null;

    const ranked = inputs
      .map((el) => {
        const nearby = normalizeText([
          el.type,
          el.name,
          el.id,
          el.autocomplete,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.getAttribute("aria-describedby"),
          el.getAttribute("role"),
          el.closest("label")?.innerText,
          el.parentElement?.innerText,
          el.parentElement?.parentElement?.innerText
        ].filter(Boolean).join(" "));
        const matched = phrases.some((phrase) => nearby.includes(phrase));
        const type = (el.type || "text").toLowerCase();
        const rect = el.getBoundingClientRect();
        let score = 0;

        if (matched) score += 80;
        if (type === "email") score += 45;
        if (type === "tel") score += 25;
        if (pageLooksLikeEmail && ["email", "text", "tel", "search", "", "url"].includes(type)) score += 35;
        if (normalizeText(el.placeholder).includes("mobile number or email")) score += 45;
        if (normalizeText(el.getAttribute("aria-label")).includes("mobile number or email")) score += 45;
        if (rect.top > 0 && rect.top < window.innerHeight) score += 8;
        if ((el.value || "").includes("@")) score += 5;
        return { el, score, matched, rectTop: rect.top };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => (b.score - a.score) || (a.rectTop - b.rectTop));

    const best = ranked[0];
    if (best) {
      if (pageLooksLikeEmail || best.matched || best.el.type === "email") return best.el;
    }

    // Last-resort for Meta email page after cookie popup: if the visible page text
    // says email/mobile and there is only one visible editable field, use it.
    if (pageLooksLikeEmail && inputs.length === 1) return inputs[0];
    return null;
  }

  function findContinueButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "continue" || item.text.includes("continue"))
      .filter((item) => item.area > 80 && item.area < 250000)
      .sort((a, b) => a.area - b.area);

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function findMetaCreateNewAccountButton() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    const looksLikeCreatePage =
      pageText.includes("create a new meta account") ||
      pageText.includes("we can't find a meta account") ||
      pageText.includes("we can’t find a meta account");

    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "create new account" || item.text.includes("create new account"))
      .filter((item) => item.area > 80 && item.area < 250000)
      .sort((a, b) => {
        const exactA = a.text === "create new account" ? 0 : 1;
        const exactB = b.text === "create new account" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    if (!looksLikeCreatePage && candidates[0].text !== "create new account") return null;
    return getClickableTarget(candidates[0].el);
  }

  function findNextButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "next" || item.text.includes("next"))
      .filter((item) => item.area > 80 && item.area < 250000)
      .sort((a, b) => {
        const exactA = a.text === "next" ? 0 : 1;
        const exactB = b.text === "next" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  const AGENTMAIL_FIRST_NAMES = [
    "Ayan", "Rayhan", "Hasan", "Sami", "Nabil", "Rafi", "Tanvir", "Fahim",
    "Imran", "Asif", "Rohan", "Sajid", "Arman", "Naim", "Rifat", "Adnan",
    "Zayan", "Farhan", "Tuhin", "Sohan", "Mahir", "Shayan", "Rakib", "Sakib"
  ];

  const AGENTMAIL_LAST_NAMES = [
    "Ahmed", "Hasan", "Rahman", "Hossain", "Karim", "Khan", "Islam", "Chowdhury",
    "Mahmud", "Sarker", "Talukder", "Miah", "Uddin", "Kabir", "Haque", "Azad",
    "Molla", "Sheikh", "Bari", "Rashid", "Amin", "Noor", "Siddiq", "Jaman"
  ];

  function randomIndex(max) {
    const bytes = new Uint32Array(1);
    crypto.getRandomValues(bytes);
    return bytes[0] % max;
  }

  function getGeneratedMetaName() {
    if (window.__agentmailGeneratedMetaName) return window.__agentmailGeneratedMetaName;

    let first = AGENTMAIL_FIRST_NAMES[randomIndex(AGENTMAIL_FIRST_NAMES.length)];
    let last = AGENTMAIL_LAST_NAMES[randomIndex(AGENTMAIL_LAST_NAMES.length)];
    if (first === last) last = AGENTMAIL_LAST_NAMES[(randomIndex(AGENTMAIL_LAST_NAMES.length - 1) + 1) % AGENTMAIL_LAST_NAMES.length];

    window.__agentmailGeneratedMetaName = { first, last };
    try {
      sessionStorage.setItem("agentmail_meta_first_name", first);
      sessionStorage.setItem("agentmail_meta_last_name", last);
    } catch (error) {
      // Ignore storage errors.
    }
    return window.__agentmailGeneratedMetaName;
  }

  function isMetaNamePage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");

    // Mobile Meta sometimes uses curly apostrophes or renders labels outside of
    // input attributes. So detect by the visible screen text too.
    if (
      pageText.includes("your name") ||
      pageText.includes("first name") ||
      pageText.includes("surname") ||
      pageText.includes("last name") ||
      pageText.includes("name cannot contain") ||
      pageText.includes("account recovery")
    ) {
      return true;
    }

    const attrs = queryAllDeep("input, textarea, [contenteditable='true']")
      .map((el) => normalizeText([
        el.name,
        el.id,
        el.placeholder,
        el.getAttribute("aria-label"),
        el.getAttribute("data-testid"),
        el.autocomplete
      ].filter(Boolean).join(" ")))
      .join(" ");

    return attrs.includes("first") || attrs.includes("surname") || attrs.includes("family-name") || attrs.includes("given-name");
  }

  function findNameInputs() {
    if (!isMetaNamePage()) return { first: null, last: null };

    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el))
      .filter((el) => {
        if (el.isContentEditable) return true;
        const type = (el.type || "text").toLowerCase();
        return ["text", "", "search"].includes(type) || el.tagName === "TEXTAREA";
      })
      .sort((a, b) => {
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        return (ra.top - rb.top) || (ra.left - rb.left);
      });

    if (inputs.length < 2) return { first: inputs[0] || null, last: null };

    const directText = (el) => normalizeText([
      el.name,
      el.id,
      el.placeholder,
      el.getAttribute("aria-label"),
      el.getAttribute("data-testid"),
      el.autocomplete
    ].filter(Boolean).join(" "));

    const localText = (el) => {
      const label = el.closest("label")?.innerText || "";
      const parent = el.parentElement;
      const parentText = parent && parent.children.length <= 3 ? (parent.innerText || parent.textContent || "") : "";
      const text = normalizeText([label, parentText].filter(Boolean).join(" "));
      const hasFirst = text.includes("first name") || text.includes("firstname") || text.includes("given-name");
      const hasLast = text.includes("surname") || text.includes("last name") || text.includes("lastname") || text.includes("family-name");
      // If a broad container contains both labels, don't use it for matching;
      // that was causing first and last to resolve to the same input.
      if (hasFirst && hasLast) return "";
      return text;
    };

    const scoreInput = (el, kind) => {
      const direct = directText(el);
      const local = localText(el);
      let score = 0;
      if (kind === "first") {
        if (direct.includes("first name") || direct.includes("firstname") || direct.includes("given-name") || direct.includes("given")) score += 100;
        if (local.includes("first name") || local.includes("firstname") || local.includes("given-name") || local.includes("given")) score += 45;
      } else {
        if (direct.includes("surname") || direct.includes("last name") || direct.includes("lastname") || direct.includes("family-name") || direct.includes("family")) score += 100;
        if (local.includes("surname") || local.includes("last name") || local.includes("lastname") || local.includes("family-name") || local.includes("family")) score += 45;
      }
      return score;
    };

    const rankedFirst = inputs
      .map((el, index) => ({ el, index, score: scoreInput(el, "first") }))
      .sort((a, b) => (b.score - a.score) || (a.index - b.index));
    const rankedLast = inputs
      .map((el, index) => ({ el, index, score: scoreInput(el, "last") }))
      .sort((a, b) => (b.score - a.score) || (a.index - b.index));

    let first = rankedFirst[0]?.score > 0 ? rankedFirst[0].el : null;
    let last = rankedLast[0]?.score > 0 ? rankedLast[0].el : null;

    // If label matching gives the same field or is ambiguous, use visible order:
    // first visible input = First name, second visible input = Surname/last name.
    if (!first || !last || first === last) {
      first = inputs[0];
      last = inputs.find((el) => el !== first) || inputs[1] || null;
    }

    return { first, last };
  }

  function valueLooksLikeName(value) {
    return /^[A-Za-z]{2,24}$/.test((value || "").trim());
  }

  function setTypingValue(element, value, previousValue = "") {
    if (element.isContentEditable) {
      element.textContent = value;
    } else {
      const prototype = Object.getPrototypeOf(element);
      const protoSetter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (protoSetter) protoSetter.call(element, value);
      else element.value = value;
    }

    const tracker = element._valueTracker;
    if (tracker) tracker.setValue(previousValue);

    try {
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: value.slice(-1)
      }));
    } catch (error) {
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }
  }

  async function typeLikeHuman(element, textValue) {
    // Fast + stable: clear and set the final value once. No character typing and
    // no repeated rewrites, so first/last fields do not get mixed.
    element.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    element.focus?.();

    setNativeValue(element, "");
    setNativeValue(element, textValue);
    await sleep(8);

    if (getEditableValue(element).trim() !== textValue) {
      setTypingValue(element, textValue, getEditableValue(element));
      element.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    }

    flash(element);
  }

  async function clickNextAfterName() {
    for (let i = 0; i < 18; i += 1) {
      await sleep(i < 5 ? 25 : 55);
      const button = findNextButton();
      if (!button) continue;

      if (!isDisabledLike(button) || i > 4) {
        flash(button);
        await sleep(60 + randomIndex(60));
        fireRealisticClick(button);
        return true;
      }
    }
    return false;
  }

  async function autoFillMetaNamePage(force = false) {
    if (!isMetaAuthPage() || !isMetaNamePage()) return { ok: false, message: "Name page not found." };

    // Never run two name fillers at the same time. Background retries can call
    // this page many times; overlapping typing caused the glitch/rewrite issue.
    if (window.__agentmailNameAutomationRunning) {
      return { ok: true, message: "Name automation already running." };
    }

    const { first, last } = findNameInputs();
    if (!first || !last || first === last) return { ok: false, message: "Two distinct name inputs not found yet." };

    window.__agentmailNameAutomationRunning = true;
    try {
      const name = getGeneratedMetaName();
      const firstValue = getEditableValue(first).trim();
      const lastValue = getEditableValue(last).trim();
      const alreadyFilledByUs =
        window.__agentmailNameFilledOnce && firstValue === name.first && lastValue === name.last;

      if (alreadyFilledByUs && !force) {
        await clickNextAfterName();
        return { ok: true, message: "Name already filled; Next click queued." };
      }

      // If Meta/old script put both names in one box, clear and set both fields correctly.
      if (force || firstValue !== name.first || !valueLooksLikeName(firstValue) || firstValue.includes(" ")) {
        await typeLikeHuman(first, name.first);
      }

      const latestLastValue = getEditableValue(last).trim();
      if (force || latestLastValue !== name.last || !valueLooksLikeName(latestLastValue) || latestLastValue.includes(" ")) {
        await typeLikeHuman(last, name.last);
      }

      // Final exact verification before Next. Do not click Next with swapped/mixed names.
      const finalFirst = getEditableValue(first).trim();
      const finalLast = getEditableValue(last).trim();
      if (finalFirst !== name.first || finalLast !== name.last) {
        await typeLikeHuman(first, name.first);
        await typeLikeHuman(last, name.last);
      }

      window.__agentmailNameFilledOnce = true;
      await sleep(20);
      await clickNextAfterName();
      return { ok: true, message: `Name filled fast: ${name.first} ${name.last}` };
    } finally {
      window.__agentmailNameAutomationRunning = false;
    }
  }

  const MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  function isMetaDobPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("date of birth") ||
      pageText.includes("what's your date of birth") ||
      pageText.includes("what is your date of birth") ||
      pageText.includes("use your own date of birth")
    );
  }

  function getGeneratedMetaDob() {
    // User requested: Day select kora lagbe na; only Year 1999 select korbe.
    if (window.__agentmailGeneratedMetaDob) return window.__agentmailGeneratedMetaDob;

    const day = null;
    const year = 1999;

    window.__agentmailGeneratedMetaDob = { day, year };
    try {
      sessionStorage.removeItem("agentmail_meta_dob_day");
      sessionStorage.setItem("agentmail_meta_dob_year", "1999");
    } catch (error) {
      // Ignore storage errors.
    }

    return window.__agentmailGeneratedMetaDob;
  }

  function selectOptionNumbers(select) {
    return [...(select.options || [])]
      .map((option) => parseInt(normalizeText(option.textContent || option.label || option.value), 10))
      .filter((num) => Number.isFinite(num));
  }

  function findDobSelects() {
    const selects = queryAllDeep("select").filter((select) => !select.disabled);
    const result = { day: null, month: null, year: null };

    for (const select of selects) {
      const attrs = normalizeText([
        select.name,
        select.id,
        select.getAttribute("aria-label"),
        select.getAttribute("data-testid"),
        select.getAttribute("title"),
        select.closest("label")?.innerText,
        select.parentElement?.innerText
      ].filter(Boolean).join(" "));

      const numbers = selectOptionNumbers(select);
      const min = numbers.length ? Math.min(...numbers) : null;
      const max = numbers.length ? Math.max(...numbers) : null;
      const optionText = normalizeText([...(select.options || [])].slice(0, 20).map((option) => option.textContent || option.label || option.value).join(" "));
      const hasMonthNames = MONTH_NAMES.some((month) => optionText.includes(month.toLowerCase()));

      if (!result.day && (attrs.includes("day") || (numbers.length >= 28 && min >= 1 && max <= 31))) {
        result.day = select;
        continue;
      }

      if (!result.year && (attrs.includes("year") || (numbers.length >= 40 && min <= 1980 && max >= 1999))) {
        result.year = select;
        continue;
      }

      if (!result.month && (attrs.includes("month") || hasMonthNames)) {
        result.month = select;
      }
    }

    return result;
  }

  function setSelectValue(select, wantedValue) {
    if (!select) return false;
    const wanted = String(wantedValue).toLowerCase();
    const option = [...(select.options || [])].find((opt) =>
      normalizeText(opt.value) === wanted ||
      normalizeText(opt.textContent || opt.label) === wanted
    ) || [...(select.options || [])].find((opt) =>
      normalizeText(opt.textContent || opt.label || opt.value).includes(wanted)
    );

    if (!option) return false;

    const previous = select.value;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value")?.set;
    if (setter) setter.call(select, option.value);
    else select.value = option.value;
    select.selectedIndex = option.index;

    const tracker = select._valueTracker;
    if (tracker) tracker.setValue(previous);

    select.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    select.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    flash(select);
    return true;
  }

  function findDobControl(label) {
    const lowerLabel = label.toLowerCase();
    const candidates = queryAllDeep("button, [role='button'], [role='combobox'], div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text.includes(lowerLabel))
      .filter((item) => item.area > 100 && item.area < 260000)
      .sort((a, b) => a.area - b.area);

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  async function chooseDropdownOption(control, wantedValue) {
    if (!control) return false;
    const wanted = String(wantedValue).toLowerCase();
    const numericWanted = Number(wantedValue);
    const isYear = Number.isFinite(numericWanted) && numericWanted >= 1900;

    const optionSelector = "button, [role='option'], [role='button'], div, span, li";
    const getNodes = (scope = document) => {
      if (scope === document) return queryAllDeep(optionSelector);
      try { return [...scope.querySelectorAll(optionSelector)]; }
      catch (error) { return []; }
    };

    const findOption = (scope = document) => getNodes(scope)
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          el,
          text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
          area: rect.width * rect.height,
          top: rect.top,
          height: rect.height
        };
      })
      .filter((item) => item.text === wanted)
      .filter((item) => item.area > 20 && item.area < 240000)
      .sort((a, b) => a.area - b.area)[0];

    const clickFound = (scope = document) => {
      const option = findOption(scope);
      if (!option) return false;
      fireRealisticClick(getClickableTarget(option.el));
      flash(option.el);
      return true;
    };

    const sendKey = (target, key) => {
      const code = key.startsWith("Arrow") ? key : (/^\d$/.test(key) ? `Digit${key}` : key);
      target.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key, code }));
      if (/^\d$/.test(key)) target.dispatchEvent(new KeyboardEvent("keypress", { bubbles: true, composed: true, key, code }));
      target.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key, code }));
    };

    // Open dropdown and try visible/typeahead immediately.
    control.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    control.focus?.();
    fireRealisticClick(control);
    await sleep(5);
    if (clickFound()) return true;

    const active = document.activeElement || control;
    for (const char of String(wantedValue)) sendKey(active, char);
    sendKey(active, "Enter");
    await sleep(8);
    if (clickFound()) return true;

    const scrollables = () => queryAllDeep("div, ul, ol, [role='listbox']")
      .filter((el) => isVisible(el) && el.scrollHeight > el.clientHeight + 20)
      .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));

    const list = scrollables()[0];
    if (list) {
      const getVisibleNumbers = () => getNodes(list)
        .filter((el) => isVisible(el))
        .map((el) => {
          const textValue = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
          const number = Number((textValue.match(/\d{1,4}/) || [])[0]);
          const rect = el.getBoundingClientRect();
          return { el, number, top: rect.top, height: rect.height || 40, text: textValue };
        })
        .filter((item) => Number.isFinite(item.number))
        .sort((a, b) => a.top - b.top);

      if (isYear) {
        // Exact jump: estimate item height and scroll straight to 1999 instead of slow sweeping.
        for (let pass = 0; pass < 4; pass += 1) {
          const visible = getVisibleNumbers().filter((item) => item.number >= 1900 && item.number <= 2100);
          if (clickFound(list) || clickFound()) return true;
          if (visible.length) {
            const topYear = visible[0].number;
            const second = visible.find((item) => item.number !== topYear);
            const stepByRect = second ? Math.abs(second.top - visible[0].top) : 0;
            const itemHeight = Math.max(28, Math.min(72, stepByRect || visible[0].height || 44));
            // Most Meta year lists are descending, current year to older years.
            const direction = visible.length > 1 && visible[1].number > visible[0].number ? -1 : 1;
            list.scrollTop += direction * (topYear - numericWanted) * itemHeight;
          } else {
            list.scrollTop = Math.max(0, list.scrollTop + 1150);
          }
          list.dispatchEvent(new Event("scroll", { bubbles: true }));
          await sleep(12);
        }
      }

      const max = Math.max(0, list.scrollHeight - list.clientHeight);
      const positions = isYear
        ? [900, 1050, 1200, 1350, 1500, Math.floor(max * 0.22), Math.floor(max * 0.28)]
        : [0, 60, 120, 180, 240, 360];

      for (const pos of positions) {
        list.scrollTop = Math.max(0, Math.min(max, pos));
        list.dispatchEvent(new Event("scroll", { bubbles: true }));
        await sleep(6);
        if (clickFound(list) || clickFound()) return true;
      }
    } else {
      for (let attempt = 0; attempt < 5; attempt += 1) {
        window.scrollBy(0, isYear ? 520 : 160);
        await sleep(6);
        if (clickFound()) return true;
      }
    }

    return false;
  }

  function numberFromText(text, min, max) {
    const nums = String(text || "").match(/\d{1,4}/g) || [];
    for (const value of nums) {
      const num = Number(value);
      if (num >= min && num <= max) return num;
    }
    return null;
  }

  function dispatchKey(target, key) {
    const code = key.startsWith("Arrow") ? key : (/^\d$/.test(key) ? `Digit${key}` : key);
    target.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, composed: true, key, code }));
    target.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, composed: true, key, code }));
  }

  async function chooseYearKeyboardFast(control, wantedYear) {
    if (!control) return false;
    const wanted = String(wantedYear);
    const current = numberFromText(control.innerText || control.textContent || control.getAttribute("aria-label"), 1900, 2100) || 2026;
    const diff = Math.min(70, Math.abs(current - wantedYear));

    const tryDirection = async (direction) => {
      control.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      control.focus?.();
      fireRealisticClick(control);
      await sleep(4);
      const target = document.activeElement || control || document.body;
      for (const char of wanted) dispatchKey(target, char);
      dispatchKey(target, "Enter");
      await sleep(8);
      let nowText = normalizeText(control.innerText || control.textContent || control.getAttribute("aria-label"));
      if (nowText.includes(wanted)) return true;

      fireRealisticClick(control);
      await sleep(4);
      for (let i = 0; i < diff; i += 1) dispatchKey(document.activeElement || target, direction);
      dispatchKey(document.activeElement || target, "Enter");
      await sleep(16);
      nowText = normalizeText(control.innerText || control.textContent || control.getAttribute("aria-label"));
      return nowText.includes(wanted);
    };

    if (await tryDirection("ArrowDown")) return true;
    if (await tryDirection("ArrowUp")) return true;
    return false;
  }

  function getYearFromControl(control) {
    if (!control) return null;
    return numberFromText(control.innerText || control.textContent || control.getAttribute?.("aria-label") || control.value, 1900, 2100);
  }

  function findDobYearControl() {
    // Prefer the real interactive year dropdown/control, not the whole DOB page.
    const candidates = queryAllDeep("button, [role='button'], [role='combobox'], [tabindex], div, span")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const role = normalizeText(el.getAttribute("role"));
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label"));
        const parentText = normalizeText([
          el.parentElement?.innerText,
          el.parentElement?.parentElement?.innerText,
          el.closest("label")?.innerText
        ].filter(Boolean).join(" "));
        const yearNumber = numberFromText(text, 1900, 2100);
        let score = 0;
        if (text === "year" || text.includes("year")) score += 100;
        if (parentText.includes("year")) score += 60;
        if (yearNumber) score += 85;
        if (role === "combobox" || role === "button" || el.tagName === "BUTTON" || el.tabIndex >= 0) score += 35;
        if (rect.height >= 28 && rect.height <= 90) score += 25;
        if (rect.width >= 50 && rect.width <= Math.max(420, window.innerWidth * 0.9)) score += 10;
        if (text.includes("day") || text.includes("month")) score -= 80;
        if (rect.width > window.innerWidth * 0.95 || rect.height > 180) score -= 80;
        return { el, text, score, area: rect.width * rect.height, top: rect.top };
      })
      .filter((item) => item.score > 60 && item.area > 60 && item.area < 180000)
      .sort((a, b) => (b.score - a.score) || (a.area - b.area) || (a.top - b.top));

    if (!candidates.length) return findDobControl("year");
    return getClickableTarget(candidates[0].el);
  }

  async function chooseYear1999Fast() {
    const wantedYear = 1999;
    const yearControl = findDobYearControl();
    if (!yearControl) return false;

    const verify = async (wait = 45) => {
      await sleep(wait);
      return getYearFromControl(yearControl) === wantedYear;
    };

    if (getYearFromControl(yearControl) === wantedYear) return true;

    const findVisibleYearOption = () => queryAllDeep("button, [role='option'], [role='button'], div, span, li")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          el,
          text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
          area: rect.width * rect.height,
          top: rect.top
        };
      })
      .filter((item) => item.text === "1999")
      .filter((item) => item.area > 20 && item.area < 240000)
      .sort((a, b) => a.area - b.area || a.top - b.top)[0];

    const clickVisible1999 = async () => {
      const option = findVisibleYearOption();
      if (!option) return false;
      fireRealisticClick(getClickableTarget(option.el));
      flash(option.el);
      return verify(120);
    };

    const openYear = async () => {
      yearControl.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      yearControl.focus?.();
      fireRealisticClick(yearControl);
      await sleep(18);
    };

    const scrollables = () => queryAllDeep("div, ul, ol, [role='listbox']")
      .filter((el) => isVisible(el) && el.scrollHeight > el.clientHeight + 20)
      .sort((a, b) => (b.scrollHeight - b.clientHeight) - (a.scrollHeight - a.clientHeight));

    // Try exact visible option after opening.
    await openYear();
    if (await clickVisible1999()) return true;

    // Fast keyboard path: if current year is 2026, ArrowDown 27 then Enter.
    const current = getYearFromControl(yearControl) || 2026;
    const diff = Math.min(80, Math.abs(current - wantedYear));
    const primaryDirection = current > wantedYear ? "ArrowDown" : "ArrowUp";
    const secondaryDirection = primaryDirection === "ArrowDown" ? "ArrowUp" : "ArrowDown";
    for (const direction of [primaryDirection, secondaryDirection]) {
      await openYear();
      const target = document.activeElement || yearControl || document.body;
      for (let i = 0; i < diff; i += 1) {
        dispatchKey(target, direction);
        if (i % 8 === 7) await sleep(1);
      }
      dispatchKey(target, "Enter");
      if (await verify(80)) return true;
      // Re-open if the wrong year was selected.
      await openYear();
      if (await clickVisible1999()) return true;
    }

    // Scroll list directly around the 1999 position. Do not press Next unless verified.
    await openYear();
    let list = scrollables()[0];
    if (list) {
      const max = Math.max(0, list.scrollHeight - list.clientHeight);
      const positions = [
        900, 1000, 1080, 1160, 1240, 1320, 1400, 1500,
        Math.floor(max * 0.18), Math.floor(max * 0.22), Math.floor(max * 0.26), Math.floor(max * 0.30)
      ];
      for (const pos of positions) {
        list.scrollTop = Math.max(0, Math.min(max, pos));
        list.dispatchEvent(new Event("scroll", { bubbles: true }));
        await sleep(8);
        if (await clickVisible1999()) return true;
      }
    }

    // Last fallback: old generic selector.
    await openYear();
    if (await chooseDropdownOption(yearControl, wantedYear)) {
      return verify(90);
    }

    return getYearFromControl(yearControl) === wantedYear;
  }

  async function setDobCustomControls(day, year) {
    // User requested: Day touch korbo na. Sudhu Year exact 1999 select korbo.
    return await chooseYear1999Fast();
  }

  async function clickNextAfterDob() {
    for (let i = 0; i < 18; i += 1) {
      await sleep(i < 4 ? 25 : 55);
      const button = findNextButton();
      if (!button) continue;

      if (!isDisabledLike(button) || i > 3) {
        flash(button);
        await sleep(10 + randomIndex(20));
        fireRealisticClick(button);
        return true;
      }
    }
    return false;
  }

  async function fillVisiblePasswordOnDobPageIfNeeded(force = false) {
    const input = findMetaPasswordInput();
    if (!input) return false;
    const result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_PASSWORD" });
    const password = result.ok && result.password ? result.password : "FAHAD@10";
    const current = getEditableValue(input).trim();
    if (force || current !== password) {
      setNativeValue(input, "");
      await sleep(18 + randomIndex(18));
      setNativeValue(input, password);
      flash(input);
    }
    return true;
  }

  async function autoFillMetaDobPage(force = false) {
    if (!isMetaAuthPage() || !isMetaDobPage()) return { ok: false, message: "DOB page not found." };

    if (window.__agentmailDobAutomationRunning) {
      return { ok: true, message: "DOB automation already running." };
    }

    window.__agentmailDobAutomationRunning = true;
    try {
      getGeneratedMetaDob();
      const selects = findDobSelects();
      let yearOk = false;

      // User requested: Day select kora lagbe na. Sudhu Year 1999.
      if (selects.year) {
        const selectedYear = numberFromText(selects.year.options?.[selects.year.selectedIndex]?.textContent || selects.year.value, 1900, 2100);
        if (selectedYear !== 1999) setSelectValue(selects.year, 1999);
        await sleep(40);
        const afterYear = numberFromText(selects.year.options?.[selects.year.selectedIndex]?.textContent || selects.year.value, 1900, 2100);
        yearOk = afterYear === 1999;
      } else {
        yearOk = await setDobCustomControls(null, 1999);
      }

      if (!yearOk) {
        // Important: wrong/default 2026 hole Next click korbo na. Poller abar retry korbe.
        return { ok: false, message: "Year 1999 not selected yet; retrying." };
      }

      window.__agentmailDobFilledOnce = true;
      const passwordFilled = await fillVisiblePasswordOnDobPageIfNeeded(false);
      await sleep(passwordFilled ? 55 : 10);
      await clickNextAfterDob();
      return { ok: true, message: passwordFilled ? "DOB year + password filled; Next clicked." : "DOB year set exactly: 1999" };
    } finally {
      window.__agentmailDobAutomationRunning = false;
    }
  }

  function pageHasVisiblePasswordInput() {
    return queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el))
      .some((el) => {
        const text = normalizeText([
          el.type,
          el.name,
          el.id,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.autocomplete
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        return type === "password" || text.includes("password");
      });
  }

  function isMetaPasswordPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("create a password") ||
      pageText.includes("new password") ||
      pageText.includes("at least 6 characters") ||
      pageText.includes("couldn't guess") ||
      pageText.includes("couldn’t guess") ||
      // New Meta AI flow: DOB + Password + Save login info are on the same page.
      (pageText.includes("get started on meta ai") && pageHasVisiblePasswordInput()) ||
      (pageText.includes("date of birth") && pageText.includes("save login info") && pageHasVisiblePasswordInput())
    );
  }

  function findMetaPasswordInput() {
    if (!isMetaPasswordPage()) return null;

    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el));

    const ranked = inputs
      .map((el) => {
        const text = normalizeText([
          el.type,
          el.name,
          el.id,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.autocomplete
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        let score = 0;
        if (type === "password") score += 60;
        if (text.includes("password")) score += 40;
        if (text.includes("new password")) score += 40;
        return { el, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);

    return ranked[0]?.el || null;
  }

  async function clickNextAfterPassword() {
    for (let i = 0; i < 24; i += 1) {
      await sleep(i < 5 ? 60 : 110);
      const button = findNextButton();
      if (!button) continue;

      if (!isDisabledLike(button) || i > 5) {
        flash(button);
        await sleep(120 + randomIndex(80));
        fireRealisticClick(button);
        return true;
      }
    }
    return false;
  }

  async function autoFillMetaPasswordPage(force = false) {
    if (!isMetaAuthPage() || !isMetaPasswordPage()) return { ok: false, message: "Password page not found." };

    if (window.__agentmailPasswordAutomationRunning) {
      return { ok: true, message: "Password automation already running." };
    }

    const input = findMetaPasswordInput();
    if (!input) return { ok: false, message: "Password input not found yet." };

    window.__agentmailPasswordAutomationRunning = true;
    try {
      const result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_PASSWORD" });
      const password = result.ok && result.password ? result.password : "FAHAD@10";
      const current = getEditableValue(input).trim();

      if (force || current !== password) {
        setNativeValue(input, "");
        await sleep(30 + randomIndex(25));
        setNativeValue(input, password);
        flash(input);
      }

      await sleep(55 + randomIndex(40));
      await clickNextAfterPassword();
      return { ok: true, message: "Password filled; Next clicked." };
    } finally {
      window.__agentmailPasswordAutomationRunning = false;
    }
  }

  function findButtonByExactText(label) {
    const wanted = normalizeText(label);
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === wanted || item.text.includes(wanted))
      .filter((item) => item.area > 50 && item.area < 260000)
      .sort((a, b) => {
        const exactA = a.text === wanted ? 0 : 1;
        const exactB = b.text === wanted ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function isMetaSaveLoginPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("save your login info") ||
      pageText.includes("save the login info") ||
      pageText.includes("you won't need to enter it next time") ||
      pageText.includes("you won’t need to enter it next time")
    );
  }

  async function autoClickMetaNotNow(force = false) {
    if (!isMetaAuthPage() || !isMetaSaveLoginPage()) return { ok: false, message: "Save login page not found." };

    if (window.__agentmailNotNowClickRunning && !force) {
      return { ok: true, message: "Not now click already running." };
    }

    const button = findButtonByExactText("Not now");
    if (!button) return { ok: false, message: "Not now button not found yet." };

    window.__agentmailNotNowClickRunning = true;
    try {
      for (let i = 0; i < 8; i += 1) {
        const current = findButtonByExactText("Not now");
        if (!current) return { ok: true, message: "Not now clicked." };
        flash(current);
        fireRealisticClick(current);
        await sleep(120);
      }
      return { ok: true, message: "Not now click attempted." };
    } finally {
      window.__agentmailNotNowClickRunning = false;
    }
  }

  function isMetaFinalReviewPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("your meta account information isn't public") ||
      pageText.includes("your meta account information isn’t public") ||
      pageText.includes("by creating your account") ||
      pageText.includes("meta terms of service") ||
      pageText.includes("create account") && pageText.includes("date of birth") && pageText.includes("password")
    );
  }

  function isCheckedLike(el) {
    if (!el) return false;
    if (typeof el.checked === "boolean") return el.checked;
    const aria = (el.getAttribute("aria-checked") || "").toLowerCase();
    if (aria === "true") return true;
    if (aria === "mixed") return true;
    return false;
  }

  function findMetaMarketingCheckbox() {
    if (!isMetaFinalReviewPage()) return null;

    const exactCheckbox = queryAllDeep("input[type='checkbox'], [role='checkbox']")
      .filter((el) => !el.disabled && isVisible(el))
      .sort((a, b) => {
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        return (ra.top - rb.top) || (ra.left - rb.left);
      })[0];
    if (exactCheckbox) return exactCheckbox;

    const label = queryAllDeep("label, div, span, p")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) =>
        item.text.includes("i'm interested in receiving emails") ||
        item.text.includes("i’m interested in receiving emails") ||
        item.text.includes("receiving emails about apps") ||
        item.text.includes("meta quest")
      )
      .filter((item) => item.area > 80 && item.area < 350000)
      .sort((a, b) => a.area - b.area)[0]?.el;

    if (!label) return null;

    const inside = label.querySelector?.("input[type='checkbox'], [role='checkbox']");
    if (inside) return inside;

    // Fallback: click the visible label/row. On mobile Meta this often toggles
    // the checkbox even when the actual input is hidden.
    return getClickableTarget(label);
  }

  async function autoClickMetaFinalReview(force = false) {
    if (!isMetaAuthPage() || !isMetaFinalReviewPage()) return { ok: false, message: "Final review page not found." };

    if (window.__agentmailFinalReviewAutomationRunning && !force) {
      return { ok: true, message: "Final review automation already running." };
    }

    window.__agentmailFinalReviewAutomationRunning = true;
    try {
      const checkbox = findMetaMarketingCheckbox();
      if (checkbox && (!isCheckedLike(checkbox) || force) && !window.__agentmailFinalReviewCheckboxClicked) {
        flash(checkbox);
        fireRealisticClick(checkbox);
        window.__agentmailFinalReviewCheckboxClicked = true;
        await sleep(100);
      }

      for (let i = 0; i < 12; i += 1) {
        const createBtn = findButtonByExactText("Create account");
        if (!createBtn) {
          await sleep(90);
          continue;
        }

        if (!isDisabledLike(createBtn) || i > 4) {
          flash(createBtn);
          fireRealisticClick(createBtn);
          window.__agentmailFinalReviewCreateClicked = true;
          return { ok: true, message: "Final Create account clicked." };
        }
        await sleep(100);
      }

      return { ok: false, message: "Create account button not clickable yet." };
    } finally {
      window.__agentmailFinalReviewAutomationRunning = false;
    }
  }

  function isMetaAiDetailsConfirmPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("edit your meta ai details") &&
      pageText.includes("by tapping confirm") &&
      pageText.includes("confirm")
    ) || (
      pageText.includes("username") &&
      pageText.includes("name (optional)") &&
      pageText.includes("confirm") &&
      pageText.includes("terms") &&
      pageText.includes("policies")
    );
  }

  async function autoClickMetaAiDetailsConfirm(force = false) {
    if (!isMetaAuthPage() || !isMetaAiDetailsConfirmPage()) return { ok: false, message: "Meta AI details confirm page not found." };

    if (window.__agentmailMetaAiDetailsConfirmRunning && !force) {
      return { ok: true, message: "Meta AI details Confirm click already running." };
    }

    window.__agentmailMetaAiDetailsConfirmRunning = true;
    try {
      for (let i = 0; i < 12; i += 1) {
        const confirmBtn = findButtonByExactText("Confirm");
        if (!confirmBtn) {
          await sleep(90);
          continue;
        }
        if (!isDisabledLike(confirmBtn) || i > 4) {
          flash(confirmBtn);
          fireRealisticClick(confirmBtn);
          window.__agentmailMetaAiDetailsConfirmClicked = true;
          return { ok: true, message: "Meta AI details Confirm clicked." };
        }
        await sleep(100);
      }
      return { ok: false, message: "Confirm button not clickable yet." };
    } finally {
      window.__agentmailMetaAiDetailsConfirmRunning = false;
    }
  }

  function isMetaConfirmationCodePage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("enter the confirmation code") ||
      pageText.includes("confirmation code") && pageText.includes("6-digit") ||
      pageText.includes("code that was sent") ||
      pageText.includes("send code again") ||
      // New Meta AI flow screenshot: "Confirm your account" + "We sent a code to ..."
      pageText.includes("confirm your account") ||
      (pageText.includes("we sent a code to") && pageText.includes("look for an email")) ||
      (pageText.includes("we sent a code") && pageText.includes("send code again"))
    );
  }

  function findMetaConfirmationCodeInput() {
    if (!isMetaConfirmationCodePage()) return null;

    const inputs = queryAllDeep("input, textarea, [contenteditable='true']")
      .filter((el) => !el.disabled && !el.readOnly && isVisible(el));

    const ranked = inputs
      .map((el) => {
        const text = normalizeText([
          el.type,
          el.name,
          el.id,
          el.placeholder,
          el.getAttribute("aria-label"),
          el.getAttribute("data-testid"),
          el.autocomplete,
          el.inputMode
        ].filter(Boolean).join(" "));
        const type = (el.type || "text").toLowerCase();
        let score = 0;
        if (text.includes("confirmation code")) score += 80;
        if (text.includes("code")) score += 55;
        if (normalizeText(el.placeholder) === "code" || normalizeText(el.getAttribute("aria-label")) === "code") score += 65;
        if (["number", "tel", "text", ""].includes(type)) score += 12;
        if (String(el.inputMode || "").toLowerCase() === "numeric") score += 25;
        const rect = el.getBoundingClientRect();
        if (rect.top > 0 && rect.top < window.innerHeight * 0.55) score += 10;
        return { el, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);

    return ranked[0]?.el || inputs[0] || null;
  }

  function getCurrentConfirmationCodeValue() {
    const input = findMetaConfirmationCodeInput();
    if (!input) return "";
    return getEditableValue(input).replace(/\D+/g, "").slice(0, 6);
  }

  function confirmationCodeReady() {
    return /^\d{6}$/.test(getCurrentConfirmationCodeValue());
  }

  function clearPostCodeMetaAiRedirectFlag() {
    try {
      sessionStorage.removeItem("agentmail_meta_ai_after_code_pending");
      sessionStorage.removeItem("agentmail_meta_ai_after_code_started_at");
    } catch (error) {}
    window.__agentmailMetaAiAfterCodeScheduled = false;
  }

  function redirectMetaAiIfPostCodePending(force = false) {
    // User update: after OTP paste/Continue, do NOT go to https://www.meta.ai/.
    // Clean any old v1.8.18 pending redirect flag so upgraded tabs do not move.
    clearPostCodeMetaAiRedirectFlag();
    return false;
  }

  function scheduleMetaAiAfterConfirmationContinue(minDelay = 700) {
    // Kept for existing callers, but intentionally no navigation now.
    clearPostCodeMetaAiRedirectFlag();
    return false;
  }

  function findConfirmationContinueButton() {
    return findContinueButton() || findNextButton() || findButtonByExactVisibleText("Continue") || findButtonByExactVisibleText("Next");
  }

  async function clickNextAfterConfirmationCode() {
    if (!confirmationCodeReady()) return false;

    const input = findMetaConfirmationCodeInput();
    const code = getCurrentConfirmationCodeValue();
    const clickedSameInput = window.__agentmailConfirmationContinueClickedForCode === code &&
      window.__agentmailConfirmationContinueClickedInput === input;
    if (clickedSameInput) {
      scheduleMetaAiAfterConfirmationContinue(300);
      return true;
    }

    for (let i = 0; i < 16; i += 1) {
      await sleep(i < 5 ? 35 : 75);
      if (!confirmationCodeReady()) return false;
      const button = findConfirmationContinueButton();
      if (!button) continue;

      if (!isDisabledLike(button) || i > 5) {
        flash(button);
        await sleep(30 + randomIndex(30));
        fireRealisticClick(button);
        window.__agentmailConfirmationContinueClickedAt = Date.now();
        window.__agentmailConfirmationContinueClickedForCode = code;
        window.__agentmailConfirmationContinueClickedInput = input;
        scheduleMetaAiAfterConfirmationContinue();
        return true;
      }
    }
    return false;
  }

  function redirectFromConfirmationCodePage(force = false) {
    if (!isMetaAuthPage() || !isMetaConfirmationCodePage()) return { ok: false, message: "Confirmation code page not found." };
    const now = Date.now();
    const lastRedirect = Number(sessionStorage.getItem("agentmail_last_code_page_redirect") || "0");
    if (!force && now - lastRedirect < 1800) {
      return { ok: true, message: "Code page redirect already triggered recently." };
    }
    sessionStorage.setItem("agentmail_last_code_page_redirect", String(now));
    // First time code page appears: go to requested start link. If the same code UI
    // appears after that link/refresh, we will paste code instead of redirecting again.
    sessionStorage.setItem("agentmail_code_page_redirect_done", "1");
    setTimeout(() => {
      try { window.location.replace(CODE_PAGE_REDIRECT_URL); }
      catch (error) { window.location.href = CODE_PAGE_REDIRECT_URL; }
    }, 180);
    return { ok: true, message: "Code page detected; redirecting to Meta start link without pasting code." };
  }

  function findMetaConfirmationSendCodeAgainButton() {
    if (!isMetaConfirmationCodePage()) return null;
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title")),
        area: rectArea(el)
      }))
      .filter((item) => (
        item.text === "send code again" ||
        item.text.includes("send code again") ||
        item.text.includes("resend code") ||
        item.text.includes("send another code") ||
        item.text.includes("send a new code") ||
        item.text.includes("get a new code")
      ))
      .filter((item) => !item.text.includes("edit") && item.area > 25 && item.area < 260000)
      .sort((a, b) => {
        const exactA = a.text === "send code again" ? 0 : 1;
        const exactB = b.text === "send code again" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });
    return candidates[0]?.el ? getClickableTarget(candidates[0].el) : null;
  }

  function clickMetaConfirmationResendOkIfShown() {
    if (isMetaOopsModalVisible()) return false;
    const okButton = findButtonByExactVisibleText("OK") || findButtonByExactVisibleText("Okay");
    if (!okButton || isDisabledLike(okButton)) return false;
    flash(okButton);
    fireRealisticClick(okButton);
    return true;
  }

  async function clickMetaConfirmationSendCodeAgainOnce(force = false) {
    if (!isMetaAuthPage() || !isMetaConfirmationCodePage()) return false;
    if (!force && sessionStorage.getItem("agentmail_confirmation_resend_clicked_once") === "1") return false;

    for (let i = 0; i < 9; i += 1) {
      const button = findMetaConfirmationSendCodeAgainButton();
      if (button && (!isDisabledLike(button) || i > 4)) {
        sessionStorage.setItem("agentmail_confirmation_resend_clicked_once", "1");
        flash(button);
        fireRealisticClick(button);
        [350, 700, 1200, 2000, 3200].forEach((delay) => {
          setTimeout(() => clickMetaConfirmationResendOkIfShown(), delay);
        });
        return true;
      }
      await sleep(250);
    }
    return false;
  }

  async function autoFillMetaConfirmationCodePage(force = false) {
    if (!isMetaAuthPage() || !isMetaConfirmationCodePage()) return { ok: false, message: "Confirmation code page not found." };

    // First code page visit: go to requested start link. If the same code UI comes
    // again after that/Oops refresh, paste code normally.
    if (sessionStorage.getItem("agentmail_code_page_redirect_done") !== "1") {
      return redirectFromConfirmationCodePage(force);
    }

    if (window.__agentmailConfirmationCodeAutomationRunning && !force) {
      return { ok: true, message: "Confirmation code automation already running." };
    }

    const input = findMetaConfirmationCodeInput();
    if (!input) return { ok: false, message: "Confirmation code input not found yet." };

    if (window.__agentmailConfirmationActiveInput !== input) {
      window.__agentmailConfirmationActiveInput = input;
      window.__agentmailLastPastedConfirmationCode = null;
      window.__agentmailConfirmationCodeFilledAt = 0;
      window.__agentmailConfirmationContinueClickedForCode = null;
      window.__agentmailConfirmationContinueClickedInput = null;
    }

    const current = getEditableValue(input).trim();
    if (/^\d{6}$/.test(current)) {
      if (!window.__agentmailConfirmationCodeFilledAt || Date.now() - window.__agentmailConfirmationCodeFilledAt > 1200) {
        window.__agentmailConfirmationCodeFilledAt = Date.now();
      }
      const clicked = await clickNextAfterConfirmationCode();
      scheduleMetaAiAfterConfirmationContinue(clicked ? 450 : 1800);
      return { ok: true, message: "Confirmation code already filled; Continue clicked." };
    }

    window.__agentmailConfirmationCodeAutomationRunning = true;
    try {
      // Wait only 5 seconds first. If no OTP has arrived, click "Send code again"
      // one time and confirm OK, then keep polling for the fresh code.
      let result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_CONFIRMATION_CODE", timeoutMs: 5000 });
      if (!result.ok || !result.code) {
        const resent = await clickMetaConfirmationSendCodeAgainOnce(false);
        if (resent) await sleep(650);
        result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_CONFIRMATION_CODE", timeoutMs: 90000 });
      }
      if (!result.ok || !result.code) {
        return { ok: false, message: result.error || "Confirmation code not received yet." };
      }

      const code = String(result.code || "").trim();
      const currentDigitsBeforePaste = getCurrentConfirmationCodeValue();
      if (currentDigitsBeforePaste === code) {
        const clicked = await clickNextAfterConfirmationCode();
        scheduleMetaAiAfterConfirmationContinue(clicked ? 450 : 1800);
        return { ok: true, message: "Confirmation code already in field; Continue clicked." };
      }
      const sameInputRecentPaste = window.__agentmailLastPastedConfirmationCode === code &&
        window.__agentmailConfirmationActiveInput === input &&
        Date.now() - (window.__agentmailConfirmationCodeFilledAt || 0) < 700;
      if (sameInputRecentPaste && !force) {
        await sleep(250);
        await clickNextAfterConfirmationCode();
        return { ok: true, message: "Confirmation code paste already attempted; waiting." };
      }

      input.focus?.();
      setNativeValue(input, code);
      window.__agentmailLastPastedConfirmationCode = code;
      window.__agentmailConfirmationCodeFilledAt = Date.now();
      flash(input);

      // Avoid OTP field glitch: paste once and click Continue once only when 6 digits are present.
      await sleep(160);
      const clicked = await clickNextAfterConfirmationCode();
      scheduleMetaAiAfterConfirmationContinue(clicked ? 450 : 1800);
      setTimeout(() => {
        if (isMetaAuthPage() && isMetaConfirmationCodePage()) {
          scheduleMetaAiAfterConfirmationContinue(0);
        }
      }, 2600);
      return { ok: true, message: clicked ? `Confirmation code filled and Continue clicked: ${code}` : `Confirmation code filled: ${code}` };
    } finally {
      window.__agentmailConfirmationCodeAutomationRunning = false;
    }
  }

  function findButtonByExactVisibleText(label) {
    const wanted = normalizeText(label);
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === wanted)
      .filter((item) => item.area > 35 && item.area < 260000)
      .sort((a, b) => a.area - b.area);

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function isMetaOopsModalVisible() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("oops") &&
      pageText.includes("something went wrong") &&
      (pageText.includes("try again") || pageText.includes("getting this fixed"))
    );
  }

  async function autoClickMetaOopsOk(force = false) {
    if (!isMetaAuthPage() || !isMetaOopsModalVisible()) return { ok: false, message: "Oops modal not found." };

    if (window.__agentmailOopsOkClickRunning && !force) {
      return { ok: true, message: "Oops refresh already running." };
    }

    const now = Date.now();
    const lastRefresh = Number(sessionStorage.getItem("agentmail_last_oops_modal_refresh") || "0");
    if (!force && now - lastRefresh < 8000) {
      return { ok: true, message: "Oops modal already refreshed recently." };
    }

    window.__agentmailOopsOkClickRunning = true;
    try {
      sessionStorage.setItem("agentmail_last_oops_modal_refresh", String(now));
      // If Oops appears on the code page, after refresh we should paste the code,
      // not redirect again.
      if (isMetaConfirmationCodePage()) sessionStorage.setItem("agentmail_code_page_redirect_done", "1");
      setTimeout(() => reloadAuthPageOnce("oops_modal_once"), 350);
      return { ok: true, message: "Oops modal detected; refreshing once." };
    } finally {
      setTimeout(() => { window.__agentmailOopsOkClickRunning = false; }, 1200);
    }
  }

  function isMetaCreateAccountBlockedPaused() {
    try {
      return sessionStorage.getItem("agentmail_create_blocked_stop") === "1";
    } catch (error) {
      return Boolean(window.__agentmailCreateBlockedStop);
    }
  }

  function isMetaCreateAccountBlockedModal() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("something went wrong") &&
      (
        pageText.includes("can't create a new account") ||
        pageText.includes("can’t create a new account") ||
        pageText.includes("cannot create a new account") ||
        pageText.includes("you can't create a new account") ||
        pageText.includes("you can’t create a new account")
      ) &&
      pageText.includes("ok")
    );
  }

  async function autoHandleMetaCreateAccountBlocked(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    const modalVisible = isMetaCreateAccountBlockedModal();
    if (!modalVisible && !isMetaCreateAccountBlockedPaused()) {
      return { ok: false, message: "Create-account block modal not found." };
    }

    window.__agentmailCreateBlockedStop = true;
    try { sessionStorage.setItem("agentmail_create_blocked_stop", "1"); } catch (error) {}

    if (window.__agentmailCreateBlockedOkRunning && !force) {
      return { ok: true, message: "Create-account block already handled; automation paused." };
    }

    if (!modalVisible) {
      return { ok: true, message: "Create-account block detected earlier; automation paused." };
    }

    window.__agentmailCreateBlockedOkRunning = true;
    try {
      for (let i = 0; i < 10; i += 1) {
        const okButton = findButtonByExactVisibleText("OK") || findButtonByExactVisibleText("Ok");
        if (okButton) {
          flash(okButton);
          fireRealisticClick(okButton);
        }
        await sleep(180);
        if (!isMetaCreateAccountBlockedModal()) break;
      }
      return { ok: true, message: "Meta says account cannot be created now; OK clicked and automation paused." };
    } finally {
      window.__agentmailCreateBlockedOkRunning = false;
    }
  }

  function parseRgbColor(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/i);
    if (!match) return null;
    return {
      r: Number(match[1]),
      g: Number(match[2]),
      b: Number(match[3]),
      a: match[4] === undefined ? 1 : Number(match[4])
    };
  }

  function isStrongMetaBlueColor(color) {
    if (!color || color.a < 0.75) return false;
    // Active Meta blue is usually around rgb(0, 100, 224) / rgb(24, 119, 242).
    // Disabled captcha button is pale blue, with high red value. Reject that.
    return color.b >= 145 && color.g >= 70 && color.r <= 90 && color.b > color.r + 70;
  }

  function buttonLooksActiveBlue(button) {
    if (!button || !isVisible(button)) return false;

    let node = button;
    for (let depth = 0; node && node !== document.documentElement && depth < 6; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const style = window.getComputedStyle(node);
      if (Number(style.opacity || "1") < 0.72) return false;
      const bg = parseRgbColor(style.backgroundColor);
      if (isStrongMetaBlueColor(bg)) return true;
    }

    const descendants = [...button.querySelectorAll?.("div, span, button") || []].slice(0, 20);
    return descendants.some((el) => isVisible(el) && isStrongMetaBlueColor(parseRgbColor(window.getComputedStyle(el).backgroundColor)));
  }

  async function fireHumanLikeClick(target) {
    if (!target) return false;
    const rect = target.getBoundingClientRect();
    const x = rect.left + rect.width * (0.38 + randomIndex(24) / 100);
    const y = rect.top + rect.height * (0.38 + randomIndex(24) / 100);
    const base = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: window.screenX + x,
      screenY: window.screenY + y,
      button: 0,
      buttons: 1
    };

    target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    await sleep(90 + randomIndex(120));
    target.focus?.();

    const Pointer = window.PointerEvent || window.MouseEvent;
    try {
      target.dispatchEvent(new Pointer("pointerover", base));
      target.dispatchEvent(new Pointer("pointerenter", base));
      target.dispatchEvent(new Pointer("pointerdown", { ...base, pointerType: "touch", isPrimary: true }));
    } catch (error) {
      target.dispatchEvent(new MouseEvent("mousedown", base));
    }

    try {
      if (window.Touch && window.TouchEvent) {
        const touch = new Touch({ identifier: Date.now(), target, clientX: x, clientY: y, screenX: window.screenX + x, screenY: window.screenY + y });
        target.dispatchEvent(new TouchEvent("touchstart", { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
        await sleep(120 + randomIndex(160));
        target.dispatchEvent(new TouchEvent("touchend", { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } else {
        await sleep(120 + randomIndex(160));
      }
    } catch (error) {
      await sleep(120 + randomIndex(160));
    }

    try {
      target.dispatchEvent(new Pointer("pointerup", { ...base, buttons: 0, pointerType: "touch", isPrimary: true }));
    } catch (error) {
      target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
    }
    target.dispatchEvent(new MouseEvent("mousedown", base));
    target.dispatchEvent(new MouseEvent("mouseup", { ...base, buttons: 0 }));
    target.dispatchEvent(new MouseEvent("click", { ...base, buttons: 0 }));
    target.click?.();
    return true;
  }

  function isMetaHumanConfirmPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("confirm that you're human") ||
      pageText.includes("confirm that you’re human") ||
      pageText.includes("human to use your account") ||
      pageText.includes("confirm you're human") ||
      pageText.includes("confirm you’re human")
    );
  }

  function scheduleHumanContinueStuckRefresh(reason = "human_continue") {
    clearTimeout(window.__agentmailHumanContinueStuckTimer);
    window.__agentmailHumanContinueStuckTimer = setTimeout(() => {
      if (!isMetaAuthPage() || !isMetaHumanConfirmPage()) return;

      const now = Date.now();
      const lastRefresh = Number(sessionStorage.getItem("agentmail_last_human_stuck_refresh") || "0");
      if (now - lastRefresh < 12000) return;

      sessionStorage.setItem("agentmail_last_human_stuck_refresh", String(now));
      window.location.reload();
    }, 7000);
  }

  function humanCaptchaIsPresent() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (
      pageText.includes("i'm not a robot") ||
      pageText.includes("i’m not a robot") ||
      pageText.includes("not a robot") ||
      pageText.includes("recaptcha") ||
      pageText.includes("security check")
    ) return true;

    return Boolean(document.querySelector("iframe[src*='recaptcha'], iframe[src*='google.com/recaptcha'], iframe[title*='recaptcha' i], iframe[title*='captcha' i]"));
  }

  function greenishStyleValue(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return false;
    const r = Number(match[1]);
    const g = Number(match[2]);
    const b = Number(match[3]);
    return g > 120 && g > r * 1.25 && g > b * 1.15;
  }

  function elementLooksLikeSolvedCaptchaTick(el) {
    if (!el || !isVisible(el)) return false;
    const text = el.innerText || el.textContent || "";
    if (/✓|✔|✅/.test(text)) return true;

    const style = window.getComputedStyle(el);
    const green =
      greenishStyleValue(style.color) ||
      greenishStyleValue(style.backgroundColor) ||
      greenishStyleValue(style.borderColor) ||
      greenishStyleValue(style.fill) ||
      greenishStyleValue(style.stroke);
    if (!green) return false;

    const rect = el.getBoundingClientRect();
    return rect.width >= 8 && rect.width <= 90 && rect.height >= 8 && rect.height <= 90;
  }

  function visibleNotRobotSolvedIndicator() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (!pageText.includes("not a robot") && !pageText.includes("recaptcha")) return false;

    const checkedControls = queryAllDeep("input[type='checkbox'], [role='checkbox'], [aria-checked]")
      .filter((el) => isVisible(el) || (el.getAttribute("aria-checked") || "").toLowerCase() === "true")
      .filter((el) => {
        if (typeof el.checked === "boolean" && el.checked) return true;
        return (el.getAttribute("aria-checked") || "").toLowerCase() === "true";
      });
    if (checkedControls.length) return true;

    const robotTextNodes = queryAllDeep("div, span, label, p")
      .filter((el) => isVisible(el))
      .filter((el) => normalizeText(el.innerText || el.textContent || "").includes("not a robot"));

    for (const node of robotTextNodes) {
      let box = node;
      for (let depth = 0; box && depth < 5; depth += 1, box = box.parentElement) {
        const candidates = [...box.querySelectorAll("svg, path, span, div, i")];
        if (candidates.some(elementLooksLikeSolvedCaptchaTick)) return true;
      }
    }

    // Final fallback: page text itself contains a visible tick and the robot label.
    const rawText = document.body?.innerText || document.body?.textContent || "";
    return /✓|✔|✅/.test(rawText) && normalizeText(rawText).includes("not a robot");
  }

  function humanCaptchaChallengeOpen() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("select all squares") ||
      pageText.includes("if there are none") ||
      pageText.includes("click skip") ||
      pageText.includes("crosswalk") ||
      pageText.includes("traffic light") ||
      pageText.includes("bicycle") ||
      pageText.includes("bus") ||
      pageText.includes("motorcycle") ||
      pageText.includes("stairs") ||
      pageText.includes("chimney") ||
      pageText.includes("skip")
    );
  }

  function humanCaptchaLooksComplete() {
    if (!humanCaptchaIsPresent()) return true;

    // Very strict: don't trust hidden g-recaptcha-response tokens because Meta or
    // Google can create them before the visible challenge is accepted. Continue
    // only after a checked control or visible green/tick solved indicator.
    return visibleNotRobotSolvedIndicator();
  }

  async function autoClickMetaHumanContinue(force = false) {
    // CAPTCHA / human-verification screens must be handled manually.
    // Automated Continue clicks after CAPTCHA can be rejected by Meta/Google and
    // may cause the page to get stuck. So this function intentionally does not
    // click on human verification pages.
    if (!isMetaAuthPage() || !isMetaHumanConfirmPage()) {
      return { ok: false, message: "Human confirm page not found." };
    }
    return { ok: true, message: "Manual CAPTCHA step: solve it and tap Continue yourself." };
  }

  function isMetaFullPageSomethingWentWrong() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (!pageText.includes("something went wrong")) return false;
    // Modal has Oops + OK and should be handled by OK click. Full error page has
    // just "Something went wrong." and no useful button.
    if (pageText.includes("oops") && pageText.includes("ok")) return false;
    return true;
  }

  async function autoRefreshMetaSomethingWentWrong(force = false) {
    if (!isMetaAuthPage() || !isMetaFullPageSomethingWentWrong()) return { ok: false, message: "Full error page not found." };

    const now = Date.now();
    const lastRefresh = Number(sessionStorage.getItem("agentmail_last_error_refresh") || "0");
    if (!force && now - lastRefresh < 6000) {
      return { ok: true, message: "Recently refreshed for error page." };
    }

    sessionStorage.setItem("agentmail_last_error_refresh", String(now));
    setTimeout(() => window.location.reload(), 700);
    return { ok: true, message: "Something went wrong page detected; refreshing." };
  }

  function isMetaCantUseRightNowPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    const cantUse =
      pageText.includes("can't use meta right now") ||
      pageText.includes("can’t use meta right now") ||
      pageText.includes("cannot use meta right now") ||
      pageText.includes("you can't use meta right now") ||
      pageText.includes("you can’t use meta right now");
    if (!cantUse) return false;
    return (
      pageText.includes("reviewing your submission") ||
      pageText.includes("what happens next") ||
      pageText.includes("won't be able to use meta") ||
      pageText.includes("won’t be able to use meta") ||
      pageText.includes("until then")
    );
  }

  async function autoRefreshMetaCantUseRightNow(force = false) {
    if (!isMetaAuthPage() || !isMetaCantUseRightNowPage()) {
      return { ok: false, message: "Can't-use-Meta review page not found." };
    }

    const alreadyRefreshedOnce = sessionStorage.getItem("agentmail_cant_use_meta_refresh_once_done") === "1";
    if (alreadyRefreshedOnce && !force) {
      return { ok: true, message: "Can't-use-Meta page already refreshed once; not looping." };
    }

    sessionStorage.setItem("agentmail_cant_use_meta_refresh_once_done", "1");
    sessionStorage.setItem("agentmail_last_cant_use_meta_refresh", String(Date.now()));
    setTimeout(() => reloadAuthPageOnce("cant_use_meta_right_now_once"), 650);
    return { ok: true, message: "Can't-use-Meta review page detected; refreshing once." };
  }

  function isMetaSelfieUploadPage() {
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("upload a verification selfie") ||
      pageText.includes("upload a photo that clearly shows your face") ||
      pageText.includes("well-lit and isn't blurry") ||
      pageText.includes("well-lit and isn’t blurry") ||
      pageText.includes("don't include other people") ||
      pageText.includes("don’t include other people")
    );
  }

  function scheduleRedirectAfterSelfieUploadGone() {
    try {
      sessionStorage.setItem("agentmail_selfie_redirect_after_gone", "1");
      sessionStorage.setItem("agentmail_selfie_continue_clicked_at", String(Date.now()));
    } catch (error) {}

    const checkAndRedirect = () => {
      if (!isMetaAuthPage()) return false;
      try {
        if (sessionStorage.getItem("agentmail_selfie_redirect_after_gone") !== "1") return false;
        const clickedAt = Number(sessionStorage.getItem("agentmail_selfie_continue_clicked_at") || "0");
        if (clickedAt && Date.now() - clickedAt > 120000) {
          sessionStorage.removeItem("agentmail_selfie_redirect_after_gone");
          sessionStorage.removeItem("agentmail_selfie_continue_clicked_at");
          return false;
        }
      } catch (error) {}

      if (isMetaSelfieUploadPage()) return false;

      try {
        sessionStorage.removeItem("agentmail_selfie_redirect_after_gone");
        sessionStorage.removeItem("agentmail_selfie_continue_clicked_at");
      } catch (error) {}
      setTimeout(() => {
        try { window.location.replace(CODE_PAGE_REDIRECT_URL); }
        catch (error) { window.location.href = CODE_PAGE_REDIRECT_URL; }
      }, 180);
      return true;
    };

    [300, 700, 1200, 1800, 2600, 3800, 5200, 7000, 9500, 12500, 16000, 22000, 30000].forEach((delay) => {
      setTimeout(checkAndRedirect, delay);
    });
    return checkAndRedirect;
  }

  function redirectAfterSelfieUploadGoneIfNeeded() {
    try {
      if (sessionStorage.getItem("agentmail_selfie_redirect_after_gone") !== "1") return false;
    } catch (error) {
      return false;
    }
    const check = scheduleRedirectAfterSelfieUploadGone();
    return check();
  }

  async function autoClickMetaSelfieContinue(force = false) {
    if (!isMetaAuthPage() || !isMetaSelfieUploadPage()) return { ok: false, message: "Selfie upload page not found." };

    const lastClickedAt = window.__agentmailSelfieContinueClickedAt || 0;
    if (!force && Date.now() - lastClickedAt < 10000) {
      return { ok: true, message: "Selfie Continue recently clicked; waiting." };
    }

    if (window.__agentmailSelfieContinueRunning && !force) {
      return { ok: true, message: "Selfie Continue automation already running." };
    }

    if (!window.__agentmailSelfiePageSeenAt || force) {
      window.__agentmailSelfiePageSeenAt = Date.now();
    }

    window.__agentmailSelfieContinueRunning = true;
    try {
      for (let i = 0; i < 40; i += 1) {
        if (!isMetaSelfieUploadPage() && i > 1) {
          redirectAfterSelfieUploadGoneIfNeeded();
          return { ok: true, message: "Selfie page gone; redirecting to start link." };
        }

        const elapsed = Date.now() - window.__agentmailSelfiePageSeenAt;
        if (elapsed < 2000) {
          await sleep(Math.min(250, 2000 - elapsed));
          continue;
        }

        const button = findButtonByExactVisibleText("Continue") || findButtonByExactText("Continue");
        if (button && (!isDisabledLike(button) || i > 8)) {
          flash(button);
          fireRealisticClick(button);
          window.__agentmailSelfieContinueClickedAt = Date.now();
          window.__agentmailSelfiePageSeenAt = null;
          scheduleRedirectAfterSelfieUploadGone();
          setTimeout(() => {
            if (isMetaAuthPage() && isMetaSelfieUploadPage()) {
              hardReloadAuthPage("selfie_upload_still_open_after_continue");
            }
          }, 5000);
          return { ok: true, message: "Selfie Continue clicked; will redirect to start link when photo upload UI disappears." };
        }

        await sleep(150);
      }

      return { ok: false, message: "Selfie Continue button not clickable yet." };
    } finally {
      window.__agentmailSelfieContinueRunning = false;
    }
  }

  function isMetaBlankWhitePage() {
    if (!isMetaAuthPage()) return false;
    const text = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (text.length > 3) return false;

    const importantVisible = queryAllDeep("button, input, textarea, select, iframe, img, svg, canvas, video, [role='button'], [role='checkbox']")
      .filter((el) => isVisible(el));
    if (importantVisible.length > 0) return false;

    const body = document.body;
    if (!body) return false;
    const bodyRect = body.getBoundingClientRect();
    const ready = document.readyState === "complete" || document.readyState === "interactive";
    return ready && bodyRect.width > 0;
  }

  function hardReloadAuthPage(reason = "stuck") {
    try {
      chrome.runtime.sendMessage({ type: "AGENTMAIL_FORCE_RELOAD_TAB", reason }, () => {
        // If background reload fails/no response, fallback below will still run.
        chrome.runtime.lastError;
      });
    } catch (error) {
      // Ignore and use location fallback.
    }

    try {
      const url = new URL(window.location.href);
      url.searchParams.set("_agentmail_reload", String(Date.now()));
      setTimeout(() => window.location.replace(url.toString()), 800);
      setTimeout(() => window.location.reload(), 1600);
    } catch (error) {
      setTimeout(() => window.location.reload(), 800);
    }
  }

  function reloadAuthPageOnce(reason = "blank_white_once") {
    let handled = false;
    try {
      chrome.runtime.sendMessage({ type: "AGENTMAIL_FORCE_RELOAD_TAB", reason }, (response) => {
        chrome.runtime.lastError;
        handled = Boolean(response && response.ok);
        if (!handled) {
          setTimeout(() => {
            try { window.location.reload(); } catch (error) {}
          }, 120);
        }
      });
    } catch (error) {
      setTimeout(() => {
        try { window.location.reload(); } catch (innerError) {}
      }, 120);
      return;
    }

    setTimeout(() => {
      if (!handled) {
        try { window.location.reload(); } catch (error) {}
      }
    }, 900);
  }

  async function autoRefreshMetaBlankWhite(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (!isMetaBlankWhitePage()) {
      try {
        sessionStorage.removeItem("agentmail_blank_seen_at");
        sessionStorage.removeItem("agentmail_blank_refresh_once_done");
      } catch (error) {}
      return { ok: false, message: "Blank white page not found." };
    }

    const now = Date.now();
    const seenAt = Number(sessionStorage.getItem("agentmail_blank_seen_at") || "0") || now;
    if (!sessionStorage.getItem("agentmail_blank_seen_at")) {
      sessionStorage.setItem("agentmail_blank_seen_at", String(now));
    }

    const alreadyRefreshedOnce = sessionStorage.getItem("agentmail_blank_refresh_once_done") === "1";
    if (alreadyRefreshedOnce && !force) {
      return { ok: true, message: "Blank white page already refreshed once; not looping." };
    }

    const blankLongEnough = force || now - seenAt >= 1000;

    if (blankLongEnough) {
      sessionStorage.setItem("agentmail_blank_refresh_once_done", "1");
      sessionStorage.setItem("agentmail_last_blank_refresh", String(now));
      sessionStorage.removeItem("agentmail_blank_seen_at");
      reloadAuthPageOnce("blank_white_once");
      return { ok: true, message: "Blank white auth page detected; refreshing once." };
    }

    return { ok: true, message: "Blank white page detected; waiting 1 second before one refresh." };
  }


  function colorIsDark(value) {
    const match = String(value || "").match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!match) return false;
    const r = Number(match[1]);
    const g = Number(match[2]);
    const b = Number(match[3]);
    return (r + g + b) / 3 < 55;
  }

  function isMetaDarkStuckPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (pageText.length > 5) return false;

    const ready = document.readyState === "complete" || document.readyState === "interactive";
    if (!ready) return false;

    const body = document.body;
    if (!body) return false;
    const bodyRect = body.getBoundingClientRect();
    if (bodyRect.width <= 0) return false;

    const bodyStyle = window.getComputedStyle(body);
    const htmlStyle = window.getComputedStyle(document.documentElement);
    let darkBg = colorIsDark(bodyStyle.backgroundColor) || colorIsDark(htmlStyle.backgroundColor);

    if (!darkBg) {
      darkBg = queryAllDeep("body, main, div, section").some((el) => {
        if (!isVisible(el)) return false;
        const rect = el.getBoundingClientRect();
        if (rect.width < window.innerWidth * 0.6 || rect.height < window.innerHeight * 0.35) return false;
        return colorIsDark(window.getComputedStyle(el).backgroundColor);
      });
    }

    const formControls = queryAllDeep("input, textarea, select, iframe, video, [role='checkbox']").filter((el) => isVisible(el));
    if (formControls.length > 0) return false;

    // Skeleton bars on stuck page.
    const skeletons = queryAllDeep("div, span").filter((el) => {
      if (!isVisible(el)) return false;
      const rect = el.getBoundingClientRect();
      if (rect.width < 30 || rect.height < 8 || rect.height > 80) return false;
      return colorIsDark(window.getComputedStyle(el).backgroundColor);
    });

    return darkBg || skeletons.length >= 1 || pageText.length === 0;
  }

  async function autoRefreshMetaDarkStuck(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (!isMetaDarkStuckPage()) {
      try { sessionStorage.removeItem("agentmail_dark_seen_at"); } catch (error) {}
      return { ok: false, message: "Dark stuck page not found." };
    }

    const now = Date.now();
    const seenAt = Number(sessionStorage.getItem("agentmail_dark_seen_at") || "0") || now;
    if (!sessionStorage.getItem("agentmail_dark_seen_at")) {
      sessionStorage.setItem("agentmail_dark_seen_at", String(now));
    }

    const lastRefresh = Number(sessionStorage.getItem("agentmail_last_dark_refresh") || "0");
    const stuckLongEnough = force || now - seenAt >= 2500;
    const cooldownDone = force || now - lastRefresh >= 9000;

    if (stuckLongEnough && cooldownDone) {
      sessionStorage.setItem("agentmail_last_dark_refresh", String(now));
      sessionStorage.removeItem("agentmail_dark_seen_at");
      hardReloadAuthPage("dark_stuck");
      return { ok: true, message: "Dark stuck auth page detected; hard reloading." };
    }

    return { ok: true, message: "Dark stuck page detected; waiting before refresh." };
  }

  function isDisabledLike(el) {
    if (!el) return true;
    if (el.disabled) return true;
    if ((el.getAttribute("aria-disabled") || "").toLowerCase() === "true") return true;
    const style = window.getComputedStyle(el);
    if (style.pointerEvents === "none") return true;
    return false;
  }

  function fireRealisticClick(target) {
    if (!target) return false;
    const rect = target.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const eventInit = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: window.screenX + x,
      screenY: window.screenY + y,
      button: 0,
      buttons: 1
    };

    target.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
    target.focus?.();

    const Pointer = window.PointerEvent || window.MouseEvent;
    target.dispatchEvent(new Pointer("pointerover", eventInit));
    target.dispatchEvent(new Pointer("pointerenter", eventInit));
    target.dispatchEvent(new Pointer("pointerdown", eventInit));
    target.dispatchEvent(new MouseEvent("mousedown", eventInit));
    target.dispatchEvent(new Pointer("pointerup", { ...eventInit, buttons: 0 }));
    target.dispatchEvent(new MouseEvent("mouseup", { ...eventInit, buttons: 0 }));
    target.dispatchEvent(new MouseEvent("click", { ...eventInit, buttons: 0 }));
    target.click?.();
    return true;
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { ok: false, error: "No response from extension." });
      });
    });
  }

  async function clickContinueAfterEmail(email) {
    if (window.__agentmailContinueClickRunning) return;
    window.__agentmailContinueClickRunning = true;

    try {
      for (let i = 0; i < 34; i += 1) {
        await sleep(i < 5 ? 60 : 110);

        const input = findMetaEmailInput();
        if (input && email && !getEditableValue(input).includes(email)) {
          setNativeValue(input, email);
        }

        const button = findContinueButton();
        if (!button) continue;

        // Prefer enabled click, but after a few seconds try anyway in case Meta
        // uses visual-only disabled styles.
        if (!isDisabledLike(button) || i > 5) {
          flash(button);
          fireRealisticClick(button);
          return;
        }
      }
    } finally {
      window.__agentmailContinueClickRunning = false;
    }
  }

  async function autoClickMetaCreateNewAccount(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (window.__agentmailCreateAccountClickRunning && !force) {
      return { ok: true, message: "Create account click already running." };
    }

    const firstButton = findMetaCreateNewAccountButton();
    if (!firstButton) return { ok: false, message: "Create new account button not found yet." };

    window.__agentmailCreateAccountClickRunning = true;
    try {
      for (let i = 0; i < 12; i += 1) {
        const button = findMetaCreateNewAccountButton();
        if (!button) {
          if (i > 1) return { ok: true, message: "Create new account clicked." };
          await sleep(55);
          continue;
        }

        if (!isDisabledLike(button) || i > 3) {
          flash(button);
          fireRealisticClick(button);
        }

        await sleep(i < 4 ? 70 : 120);
      }

      return { ok: true, message: "Create new account click attempted." };
    } finally {
      window.__agentmailCreateAccountClickRunning = false;
    }
  }

  async function autoFillMetaEmailInput() {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    if (isMetaConfirmationCodePage()) return { ok: false, message: "Confirmation page: do not edit email; waiting for code." };

    const input = findMetaEmailInput();
    if (!input) return { ok: false, message: "Meta email input not found yet." };

    const currentValue = getEditableValue(input).trim();
    if (currentValue.includes("@")) {
      window.__agentmailAccountSavedAfterLogout = false;
      window.__agentmailNextEmailPreparedAfterLogout = false;
      try { sessionStorage.removeItem("agentmail_confirmation_resend_clicked_once"); } catch (error) {}
      clickContinueAfterEmail(currentValue);
      return { ok: true, message: "Email already filled; clicking Continue.", email: currentValue };
    }

    if (window.__agentmailEmailApiRequestRunning) {
      return { ok: true, message: "Email generation already running." };
    }

    window.__agentmailEmailApiRequestRunning = true;
    try {
      flash(input);
      let forceNewEmail = false;
      try {
        forceNewEmail = sessionStorage.getItem("agentmail_force_new_email_next") === "1";
      } catch (error) {}
      const result = await sendRuntimeMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: forceNewEmail });
      if (!result.ok || !result.email) {
        return { ok: false, message: result.error || "Could not generate MasterTeam mail." };
      }

      for (let i = 0; i < 5; i += 1) {
        setNativeValue(input, result.email);
        flash(input);
        await sleep(45);
        if (getEditableValue(input).includes(result.email)) break;
      }

      window.__agentmailAccountSavedAfterLogout = false;
      window.__agentmailNextEmailPreparedAfterLogout = false;
      try { sessionStorage.removeItem("agentmail_force_new_email_next"); } catch (error) {}
      try { sessionStorage.removeItem("agentmail_confirmation_resend_clicked_once"); } catch (error) {}
      clickContinueAfterEmail(result.email);
      return { ok: true, message: "MasterTeam mail filled; Continue click queued.", email: result.email, reused: result.reused };
    } finally {
      window.__agentmailEmailApiRequestRunning = false;
    }
  }

  function isMetaCookieChoicePage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    return (
      pageText.includes("allow all cookies") &&
      (
        pageText.includes("how we use these cookies") ||
        pageText.includes("if you allow these cookies") ||
        pageText.includes("if you don't allow these cookies") ||
        pageText.includes("if you don’t allow these cookies") ||
        pageText.includes("decline optional cookies") ||
        pageText.includes("controlling cookies with browser settings") ||
        pageText.includes("cookie choices")
      )
    );
  }

  function findMetaAllowAllCookiesButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) => item.text === "allow all cookies" || item.text.includes("allow all cookies"))
      .filter((item) => item.area > 60 && item.area < 260000)
      .sort((a, b) => {
        const exactA = a.text === "allow all cookies" ? 0 : 1;
        const exactB = b.text === "allow all cookies" ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function scheduleMetaAfterCookieConsent() {
    const now = Date.now();
    if (window.__agentmailCookieResumeScheduledAt && now - window.__agentmailCookieResumeScheduledAt < 5000) return;
    window.__agentmailCookieResumeScheduledAt = now;

    [250, 650, 1100, 1800, 2800, 4200, 6500, 9000, 12000].forEach((delay) => {
      setTimeout(() => {
        if (!isMetaAuthPage()) return;
        // Cookie page gone hole email-choice/email-input flow abar run korbe.
        clickMetaEmailChoice(false);
        autoFillMetaEmailInput();
      }, delay);
    });
  }

  async function autoClickMetaAllowAllCookies(force = false) {
    if (!isMetaAuthPage() || !isMetaCookieChoicePage()) {
      return { ok: false, message: "Cookie choice page not found." };
    }

    if (window.__agentmailAllowCookiesClickRunning && !force) {
      return { ok: true, message: "Allow cookies click already running." };
    }

    const firstButton = findMetaAllowAllCookiesButton();
    if (!firstButton) return { ok: false, message: "Allow all cookies button not found yet." };

    window.__agentmailAllowCookiesClickRunning = true;
    try {
      for (let i = 0; i < 5; i += 1) {
        if (!isMetaCookieChoicePage() && i > 0) {
          scheduleMetaAfterCookieConsent();
          return { ok: true, message: "Cookie page gone; Meta flow resumed." };
        }
        const button = findMetaAllowAllCookiesButton();
        if (!button) {
          await sleep(60);
          continue;
        }
        flash(button);
        fireRealisticClick(button);
        scheduleMetaAfterCookieConsent();
        await sleep(i < 2 ? 90 : 140);
      }
      return { ok: true, message: "Allow all cookies clicked; Meta flow resume queued." };
    } finally {
      window.__agentmailAllowCookiesClickRunning = false;
    }
  }

  function isMetaSavedAccountLoginPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    // Start korle majhe majhe direct remembered-account page ase. Header text
    // slightly different hote pare, so button text thaklei ei page dhorbo.
    return (
      pageText.includes("log in to another account") ||
      pageText.includes("login to another account") ||
      pageText.includes("log into another account") ||
      pageText.includes("use another account") ||
      (
        pageText.includes("another account") &&
        (pageText.includes("continue as") || pageText.includes("meta account") || pageText.includes("log in"))
      )
    );
  }

  function findMetaLoginAnotherAccountButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
        area: rectArea(el)
      }))
      .filter((item) =>
        item.text === "log in to another account" ||
        item.text === "login to another account" ||
        item.text === "log into another account" ||
        item.text === "use another account" ||
        item.text.includes("log in to another account") ||
        item.text.includes("login to another account") ||
        item.text.includes("log into another account") ||
        item.text.includes("use another account")
      )
      .filter((item) => item.area > 80 && item.area < 260000)
      .sort((a, b) => {
        const exactA = (a.text === "use another account" || a.text === "log in to another account" || a.text === "login to another account" || a.text === "log into another account") ? 0 : 1;
        const exactB = (b.text === "use another account" || b.text === "log in to another account" || b.text === "login to another account" || b.text === "log into another account") ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  async function autoClickMetaLoginAnotherAccount(force = false) {
    if (!isMetaAuthPage()) {
      return { ok: false, message: "Not auth.meta.com" };
    }

    const firstButton = findMetaLoginAnotherAccountButton();
    if (!isMetaSavedAccountLoginPage() && !firstButton) {
      return { ok: false, message: "Saved-account login page not found." };
    }

    if (window.__agentmailLoginAnotherAccountRunning && !force) {
      return { ok: true, message: "Another-account click already running." };
    }

    if (!firstButton) return { ok: false, message: "Log in to another account button not found yet." };

    window.__agentmailLoginAnotherAccountRunning = true;
    try {
      // Next email input must use a fresh MasterTeam inbox, not the remembered Meta account.
      try { sessionStorage.setItem("agentmail_force_new_email_next", "1"); } catch (error) {}

      const now = Date.now();
      if (window.__agentmailLoginAnotherAccountClickedAt && !force && now - window.__agentmailLoginAnotherAccountClickedAt < 3500) {
        scheduleMetaAfterLogout();
        return { ok: true, message: "Use another account already clicked recently." };
      }

      const button = findMetaLoginAnotherAccountButton();
      if (!button) return { ok: false, message: "Use another account button not found yet." };
      window.__agentmailLoginAnotherAccountClickedAt = now;
      flash(button);
      fireRealisticClick(button);

      scheduleMetaAfterLogout();
      setTimeout(() => {
        if (isMetaAuthPage() && !isMetaSavedAccountLoginPage()) {
          clickMetaEmailChoice(false);
          autoFillMetaEmailInput();
        }
      }, 700);
      return { ok: true, message: "Use another account clicked once; email-choice watcher queued." };
    } finally {
      window.__agentmailLoginAnotherAccountRunning = false;
    }
  }

  function isMetaLanguageLogoutPage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (!pageText) return false;

    // Screenshot-er page: Language + LOG OUT + Accounts Centre page.
    return (
      (pageText.includes("log out") || pageText.includes("logout")) &&
      pageText.includes("language") &&
      (
        pageText.includes("accounts centre") ||
        pageText.includes("accounts center") ||
        pageText.includes("password, security") ||
        pageText.includes("personal details") ||
        pageText.includes("connected experiences") ||
        pageText.includes("english (uk)") ||
        pageText.includes("english")
      )
    );
  }

  function findMetaLogoutButton() {
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        return {
          el,
          text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label")),
          area: rect.width * rect.height,
          top: rect.top,
          left: rect.left
        };
      })
      .filter((item) => item.text === "log out" || item.text === "logout")
      .filter((item) => item.area > 30 && item.area < 120000)
      .sort((a, b) => {
        // Prefer the small top-right LOG OUT button from the screenshot.
        const topA = a.top < 180 ? 0 : 1;
        const topB = b.top < 180 ? 0 : 1;
        if (topA !== topB) return topA - topB;
        return a.area - b.area;
      });

    if (!candidates.length) return null;
    return getClickableTarget(candidates[0].el);
  }

  function isInsideAgentmailFloatingWidget(el) {
    try {
      const root = el?.getRootNode?.();
      if (root?.host?.id === "agentmail-floating-widget-host") return true;
    } catch (error) {}
    let node = el;
    for (let depth = 0; node && depth < 8; depth += 1, node = node.parentElement) {
      if (node.id === "agentmail-floating-widget-host") return true;
    }
    return false;
  }

  function findMetaHamburgerMenuButton() {
    if (!isMetaAuthPage()) return null;
    const candidates = queryAllDeep("button, [role='button'], a, div, span, svg")
      .filter((el) => isVisible(el) && !isInsideAgentmailFloatingWidget(el))
      .map((el) => {
        const rect = el.getBoundingClientRect();
        const text = normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title"));
        const aria = normalizeText(el.getAttribute("aria-label") || el.getAttribute("title") || "");
        const area = rect.width * rect.height;
        const topRight = rect.top >= 18 && rect.top < Math.min(320, window.innerHeight * 0.52) && rect.right > window.innerWidth * 0.54;
        const sizeOk = rect.width >= 6 && rect.width <= 150 && rect.height >= 2 && rect.height <= 150;
        const menuText = aria.includes("menu") || aria.includes("more") || text === "☰" || text === "≡" || text === "menu" || text === "";
        const hasSvgOrLines = el.querySelector?.("svg, path, line, rect, div, span") || el.tagName === "svg" || text.length <= 3;
        const lineLike = text.length <= 3 && rect.width > 10 && rect.height > 1;
        const likelyClickable = ["BUTTON", "A", "SVG"].includes(el.tagName) || (el.getAttribute("role") || "").toLowerCase() === "button" || el.tabIndex >= 0 || window.getComputedStyle(el).cursor === "pointer";
        return { el, rect, text, area, topRight, sizeOk, menuText, hasSvgOrLines, lineLike, likelyClickable };
      })
      .filter((item) => item.topRight && item.sizeOk && item.area > 10 && (item.likelyClickable || item.menuText || item.hasSvgOrLines || item.lineLike))
      .sort((a, b) => {
        const clickableA = a.likelyClickable ? 0 : 1;
        const clickableB = b.likelyClickable ? 0 : 1;
        if (clickableA !== clickableB) return clickableA - clickableB;
        const menuA = a.menuText ? 0 : 1;
        const menuB = b.menuText ? 0 : 1;
        if (menuA !== menuB) return menuA - menuB;
        return (b.rect.right - a.rect.right) || (a.rect.top - b.rect.top);
      });
    return candidates[0]?.el ? getClickableTarget(candidates[0].el) : null;
  }

  function isMetaSparseHamburgerScreen() {
    if (!isMetaAuthPage()) return false;
    const text = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (text.includes("use mobile number or email") || text.includes("continue with facebook") || text.includes("continue with instagram")) return false;
    if (isMetaConfirmationCodePage() || isMetaDobPage() || isMetaPasswordPage() || isMetaHumanConfirmPage() || isMetaSelfieUploadPage()) return false;
    if (text.includes("upload") || text.includes("selfie") || text.includes("photo") || text.includes("verification") || text.includes("clearly shows your face")) return false;
    if (text.includes("log out") || text.includes("logout")) return true;

    // Do not let hidden auth iframes break the sparse-page detection. Only real
    // visible form controls should block the hamburger click.
    const controls = queryAllDeep("input, textarea, select, [role='checkbox']")
      .filter((el) => isVisible(el))
      .filter((el) => {
        const rect = el.getBoundingClientRect();
        return rect.width > 10 && rect.height > 10;
      });
    if (controls.length > 0) return false;

    const hamburger = findMetaHamburgerMenuButton();
    const skeletonBars = queryAllDeep("div, span").filter((el) => {
      if (!isVisible(el) || isInsideAgentmailFloatingWidget(el)) return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 35 && rect.width < window.innerWidth * 0.76 && rect.height > 3 && rect.height < 56 && rect.top > 55 && rect.top < 500;
    }).length;
    // Screenshot page: mostly blank auth.meta.com with only top-right 3-line menu
    // and 2-3 skeleton bars. If the 3-line element is not exposed in the DOM,
    // still use coordinate click fallback on this sparse screen.
    return Boolean(hamburger) || text.length <= 120 || skeletonBars >= 2;
  }

  function nudgeFloatingWidgetAwayFromHamburger() {
    try {
      const host = document.getElementById("agentmail-floating-widget-host");
      if (!host) return;
      const rect = host.getBoundingClientRect();
      if (rect.top < 190 && rect.right > window.innerWidth * 0.54) {
        host.style.top = "190px";
        host.style.right = "8px";
      }
    } catch (error) {}
  }

  function clickElementFromPointStrong(x, y) {
    const targets = [];
    const first = document.elementFromPoint(x, y);
    if (first) targets.push(first);
    let node = first;
    for (let depth = 0; node && depth < 7; depth += 1, node = node.parentElement) {
      if (node && !targets.includes(node)) targets.push(node);
    }
    targets.push(document.body, document.documentElement);
    let clicked = false;
    targets.forEach((target, index) => {
      if (!target || isInsideAgentmailFloatingWidget(target)) return;
      setTimeout(() => {
        try { fireRealisticClick(getClickableTarget(target) || target); } catch (error) {}
      }, index * 35);
      clicked = true;
    });
    return clicked;
  }

  function clickMetaHamburgerByCoordinates() {
    nudgeFloatingWidgetAwayFromHamburger();
    const vv = window.visualViewport;
    const width = vv?.width || window.innerWidth || document.documentElement.clientWidth || 390;
    const height = vv?.height || window.innerHeight || document.documentElement.clientHeight || 700;
    const xs = [width - 44, width - 52, width - 62, width - 74, width - 86].filter((x) => x > width * 0.55 && x < width - 4);
    const ys = [58, 70, 82, 94, 108, 124, 142, Math.min(165, height * 0.24)].filter((y) => y > 20 && y < Math.min(230, height * 0.42));
    let any = false;
    xs.forEach((x, xi) => {
      ys.forEach((y, yi) => {
        setTimeout(() => { any = clickElementFromPointStrong(x, y) || any; }, 40 + (xi * ys.length + yi) * 28);
      });
    });
    return true;
  }

  function clickMetaHamburgerStrong(menu) {
    nudgeFloatingWidgetAwayFromHamburger();
    if (!menu) return clickMetaHamburgerByCoordinates();
    const rect = menu.getBoundingClientRect();
    flash(menu);
    fireRealisticClick(menu);

    // Some Meta mobile shells attach the listener to a parent or to the element
    // under the pointer, so repeat with elementFromPoint/parent targets.
    const points = [
      { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
      { x: Math.max(4, window.innerWidth - 42), y: rect.top + rect.height / 2 },
      { x: Math.max(4, window.innerWidth - 54), y: Math.max(40, rect.top + 8) }
    ];
    points.forEach((point, index) => {
      setTimeout(() => {
        const el = document.elementFromPoint(point.x, point.y);
        if (!el || isInsideAgentmailFloatingWidget(el)) return;
        const target = getClickableTarget(el);
        if (target && isVisible(target)) fireRealisticClick(target);
      }, 90 + index * 170);
    });
    setTimeout(() => clickMetaHamburgerByCoordinates(), 240);
    return true;
  }

  function scheduleDelayedMetaLogoutClick(source = "Logout", force = false) {
    if (!isMetaAuthPage()) return false;
    if (window.__agentmailLogoutDelayTimerActive && !force) return true;

    window.__agentmailLogoutDelayTimerActive = true;
    window.__agentmailLogoutDelayedClickAt = Date.now();

    setTimeout(() => {
      try {
        if (!isMetaAuthPage()) return;
        const button = findMetaLogoutButton();
        if (!button) return;
        flash(button);
        fireRealisticClick(button);
        window.__agentmailLogoutClickedAt = Date.now();
        // Save only after LOG OUT click is actually fired.
        saveCurrentAccountAfterLogout();
        scheduleMetaAfterLogout();
      } finally {
        setTimeout(() => {
          window.__agentmailLogoutDelayTimerActive = false;
          window.__agentmailLogoutDelayedClickAt = 0;
        }, 900);
      }
    }, 2000);

    return true;
  }

  async function autoClickMetaHamburgerAndLogout(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    const logoutButton = findMetaLogoutButton();
    if (logoutButton) {
      scheduleDelayedMetaLogoutClick("menu", force);
      return { ok: true, message: "Logout click scheduled after 2 seconds." };
    }

    if (!isMetaSparseHamburgerScreen()) return { ok: false, message: "Hamburger menu screen not found." };
    const now = Date.now();
    if (!force && window.__agentmailHamburgerMenuClickedAt && now - window.__agentmailHamburgerMenuClickedAt < 2500) {
      return { ok: true, message: "Hamburger recently clicked; waiting." };
    }
    const menu = findMetaHamburgerMenuButton();
    window.__agentmailHamburgerMenuClickedAt = now;
    clickMetaHamburgerStrong(menu);
    [250, 550, 900, 1300, 2000, 3200, 4800].forEach((delay) => {
      setTimeout(() => {
        const btn = findMetaLogoutButton();
        if (btn) {
          scheduleDelayedMetaLogoutClick("hamburger-menu", false);
        }
      }, delay);
    });
    return { ok: true, message: "Hamburger menu clicked; logout watcher queued." };
  }

  function prepareNextEmailAfterLogout() {
    if (window.__agentmailNextEmailPreparedAfterLogout) return;
    window.__agentmailNextEmailPreparedAfterLogout = true;
    setTimeout(() => {
      try {
        chrome.storage.local.get(["agentmail_mail_provider"], (saved) => {
          const provider = saved.agentmail_mail_provider === "baby" ? "baby" : "toxic";
          sendRuntimeMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: true, provider });
        });
      } catch (error) {
        try { sendRuntimeMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: true }); } catch (innerError) {}
      }
    }, 250);
  }

  function saveCurrentAccountAfterLogout() {
    if (window.__agentmailAccountSavedAfterLogout) {
      prepareNextEmailAfterLogout();
      return;
    }
    window.__agentmailAccountSavedAfterLogout = true;
    try {
      sendRuntimeMessage({ type: "AGENTMAIL_SAVE_CURRENT_ACCOUNT", source: "Logout" })
        .then(() => prepareNextEmailAfterLogout())
        .catch(() => prepareNextEmailAfterLogout());
    } catch (error) {
      // Ignore; background may be waking.
      prepareNextEmailAfterLogout();
    }
  }

  function scheduleMetaAfterLogout() {
    const now = Date.now();
    if (window.__agentmailAfterLogoutResumeScheduledAt && now - window.__agentmailAfterLogoutResumeScheduledAt < 5000) return;
    window.__agentmailAfterLogoutResumeScheduledAt = now;

    // Logout-er por same page / Use mobile number or email address ashle click korbe,
    // then email input ashle fresh mail paste korbe.
    try { sessionStorage.setItem("agentmail_force_new_email_next", "1"); } catch (error) {}

    [500, 1000, 1600, 2400, 3500, 5200, 7500, 10000, 13500, 17000].forEach((delay) => {
      setTimeout(() => {
        if (!isMetaAuthPage()) return;
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) return;

        autoClickMetaProfileContinue(false);
        autoClickMetaAllowAllCookies(false);
        autoClickMetaLoginAnotherAccount(false);

        const emailOptionRow = findMetaInitialThirdEmailOptionRow();
        const choice = emailOptionRow || findMetaEmailChoiceButton();
        if (choice) {
          if (emailOptionRow) clickInitialThirdEmailOptionOnly(emailOptionRow);
          else fireEmailChoiceClick(choice);
        }

        clickMetaEmailChoice(false);
        autoFillMetaEmailInput();
      }, delay);
    });
  }

  async function redirectFromMetaLanguagePage(force = false) {
    // Kept function name for existing callers, but behavior is now: click LOG OUT,
    // not redirect to Wikipedia.
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };
    if (!isMetaLanguageLogoutPage() && !findMetaLogoutButton()) {
      return { ok: false, message: "Language/logout page not found." };
    }

    if (window.__agentmailLogoutClicking && !force) {
      return { ok: true, message: "Logout click already running." };
    }

    window.__agentmailLogoutClicking = true;
    try {
      // LOG OUT page means this mail/account reached the success/logout stage.
      // User requested: LOG OUT should be clicked after 2 seconds, not instantly.
      const scheduled = scheduleDelayedMetaLogoutClick("language-page", force);
      if (scheduled) return { ok: true, message: "LOG OUT click scheduled after 2 seconds; account will save after click." };
      return { ok: false, message: "LOG OUT button not ready for delayed click." };
    } finally {
      setTimeout(() => { window.__agentmailLogoutClicking = false; }, 2400);
    }
  }

  function targetIsSocialLoginChoice(target) {
    if (!target || !isMetaAuthPage()) return false;
    let node = target;
    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute?.("aria-label"));
      if (area > 230000 || text.length > 140) continue;
      if (text.includes("continue with facebook") || text.includes("continue with instagram")) return true;
    }
    return false;
  }

  function installSocialChoiceClickBlocker() {
    if (window.__agentmailSocialChoiceClickBlockerInstalled) return;
    window.__agentmailSocialChoiceClickBlockerInstalled = true;

    const blockIfSocial = (event) => {
      if (!isMetaAuthPage()) return;
      const emailRow = findMetaInitialThirdEmailOptionRow();
      if (!emailRow) return;
      if (!targetIsSocialLoginChoice(event.target)) return;

      // User requested: never click Continue with Facebook/Instagram on this screen.
      // Stop old/stale click loops too, then force the Use mobile/email row.
      try { event.preventDefault(); } catch (error) {}
      try { event.stopPropagation(); } catch (error) {}
      try { event.stopImmediatePropagation(); } catch (error) {}
      setTimeout(() => {
        const row = findMetaInitialThirdEmailOptionRow();
        if (row) clickInitialThirdEmailOptionOnly(row);
      }, 40);
    };

    ["touchstart", "touchend", "pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((type) => {
      try { window.addEventListener(type, blockIfSocial, { capture: true, passive: false }); } catch (error) {}
      try { document.addEventListener(type, blockIfSocial, { capture: true, passive: false }); } catch (error) {}
    });
  }

  function targetIsEditEmailAddressLink(target) {
    if (!target || !isMetaAuthPage() || !isMetaConfirmationCodePage()) return false;
    let node = target;
    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute?.("aria-label"));
      if (area > 260000 || text.length > 220) continue;
      if (
        text.includes("edit mobile number or email address") ||
        text.includes("edit email address") ||
        text.includes("edit mobile number")
      ) return true;
    }
    return false;
  }

  function installEditEmailClickBlocker() {
    if (window.__agentmailEditEmailClickBlockerInstalled) return;
    window.__agentmailEditEmailClickBlockerInstalled = true;

    const blockEditEmail = (event) => {
      if (!targetIsEditEmailAddressLink(event.target)) return;
      try { event.preventDefault(); } catch (error) {}
      try { event.stopPropagation(); } catch (error) {}
      try { event.stopImmediatePropagation(); } catch (error) {}
      setTimeout(() => autoFillMetaConfirmationCodePage(true), 60);
    };

    ["touchstart", "touchend", "pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((type) => {
      try { window.addEventListener(type, blockEditEmail, { capture: true, passive: false }); } catch (error) {}
      try { document.addEventListener(type, blockEditEmail, { capture: true, passive: false }); } catch (error) {}
    });
  }

  function targetIsConfirmationContinueButton(target) {
    if (!target || !isMetaAuthPage() || !isMetaConfirmationCodePage()) return false;
    let node = target;
    for (let depth = 0; node && node !== document.documentElement && depth < 9; depth += 1, node = node.parentElement) {
      if (!isVisible(node)) continue;
      const rect = node.getBoundingClientRect();
      const area = rect.width * rect.height;
      const text = normalizeText(node.innerText || node.textContent || node.getAttribute?.("aria-label"));
      if (area > 280000 || text.length > 120) continue;
      if (text === "continue" || text === "next") return true;
    }
    return false;
  }

  function installConfirmationContinueClickBlocker() {
    if (window.__agentmailConfirmationContinueBlockerInstalled) return;
    window.__agentmailConfirmationContinueBlockerInstalled = true;
    const blockIfCodeMissing = (event) => {
      if (!targetIsConfirmationContinueButton(event.target)) return;
      if (confirmationCodeReady()) return;
      try { event.preventDefault(); } catch (error) {}
      try { event.stopPropagation(); } catch (error) {}
      try { event.stopImmediatePropagation(); } catch (error) {}
      setTimeout(() => autoFillMetaConfirmationCodePage(true), 80);
    };
    ["touchstart", "touchend", "pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((type) => {
      try { window.addEventListener(type, blockIfCodeMissing, { capture: true, passive: false }); } catch (error) {}
      try { document.addEventListener(type, blockIfCodeMissing, { capture: true, passive: false }); } catch (error) {}
    });
  }

  function clickMetaEmailChoice(force = false) {
    if (!isMetaAuthPage()) return { ok: false, message: "Not auth.meta.com" };

    if (window.__agentmailMetaClickLoopRunning && !force && window.__agentmailMetaClickLoopTimer) {
      return { ok: true, message: "Already running" };
    }

    try { clearInterval(window.__agentmailMetaClickLoopTimer); } catch (error) {}
    window.__agentmailMetaClickLoopRunning = true;
    const startedAt = Date.now();
    const maxWaitMs = 24000;
    let attempts = 0;

    const timer = setInterval(() => {
      if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
        autoHandleMetaCreateAccountBlocked(false);
        clearInterval(timer);
        if (window.__agentmailMetaClickLoopTimer === timer) window.__agentmailMetaClickLoopTimer = null;
        window.__agentmailMetaClickLoopRunning = false;
        return;
      }
      if (isMetaConfirmationCodePage()) {
        autoFillMetaConfirmationCodePage();
        return;
      }
      autoClickMetaProfileContinue();
      redirectFromMetaLanguagePage();
      autoClickMetaHamburgerAndLogout();
      autoClickMetaAllowAllCookies();
      autoClickMetaLoginAnotherAccount();
      autoRefreshMetaBlankWhite();
      autoRefreshMetaDarkStuck();
      autoRefreshMetaSomethingWentWrong();
      autoRefreshMetaCantUseRightNow();
      autoClickMetaOopsOk();
      autoClickMetaHumanContinue();
      autoClickMetaCreateNewAccount();
      autoFillMetaNamePage();
      autoFillMetaDobPage();
      autoFillMetaPasswordPage();
      autoClickMetaNotNow();
      autoClickMetaFinalReview();
      autoClickMetaAiDetailsConfirm();
      autoFillMetaConfirmationCodePage();
      autoClickMetaSelfieContinue();
      autoFillMetaEmailInput();

      const emailOptionRow = findMetaInitialThirdEmailOptionRow();
      const target = emailOptionRow || findMetaEmailChoiceButton();
      if (target) {
        const now = Date.now();
        if (!window.__agentmailEmailChoiceLastClick || now - window.__agentmailEmailChoiceLastClick > 900) {
          window.__agentmailEmailChoiceLastClick = now;
          attempts += 1;
          if (emailOptionRow) clickInitialThirdEmailOptionOnly(emailOptionRow);
          else fireEmailChoiceClick(target);
        }
      }

      const inputAlreadyVisible = Boolean(findMetaEmailInput());
      const stillThere = Boolean(findMetaEmailChoiceButton());
      if ((inputAlreadyVisible && attempts >= 1) || (attempts >= 6 && !stillThere) || attempts >= 12 || Date.now() - startedAt > maxWaitMs) {
        clearInterval(timer);
        if (window.__agentmailMetaClickLoopTimer === timer) window.__agentmailMetaClickLoopTimer = null;
        window.__agentmailMetaClickLoopRunning = false;
      }
    }, 180);
    window.__agentmailMetaClickLoopTimer = timer;

    return { ok: true, message: "Meta automation started" };
  }

  function isMetaProfileContinuePage() {
    if (!isMetaAuthPage()) return false;
    const pageText = normalizeText(document.body?.innerText || document.body?.textContent || "");
    if (isMetaConfirmationCodePage() || isMetaDobPage() || isMetaPasswordPage() || isMetaHumanConfirmPage()) return false;
    return (
      pageText.includes("use another profile") &&
      pageText.includes("continue") &&
      !pageText.includes("confirm your account")
    ) || (
      pageText.includes("meta") &&
      pageText.includes("use another profile") &&
      findContinueButton()
    );
  }

  async function autoClickMetaProfileContinue(force = false) {
    if (!isMetaProfileContinuePage()) return { ok: false, message: "Profile continue page not found." };
    const now = Date.now();
    if (window.__agentmailMetaProfileContinueClickedAt && !force && now - window.__agentmailMetaProfileContinueClickedAt < 6000) {
      return { ok: true, message: "Profile Continue clicked recently." };
    }
    const button = findContinueButton() || findButtonByExactVisibleText("Continue");
    if (!button) return { ok: false, message: "Profile Continue button not found." };
    window.__agentmailMetaProfileContinueClickedAt = now;
    flash(button);
    fireRealisticClick(button);
    return { ok: true, message: "Profile Continue clicked." };
  }

  function isMetaAiPage() {
    const host = window.location.hostname.toLowerCase();
    return host === "www.meta.ai" || host === "meta.ai" || host === "auth.meta.ai";
  }

  function findMetaAiSignUpButton() {
    if (!isMetaAiPage()) return null;
    const candidates = queryAllDeep("button, [role='button'], a, div, span")
      .filter((el) => isVisible(el))
      .map((el) => ({
        el,
        text: normalizeText(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title")),
        area: rectArea(el)
      }))
      .filter((item) =>
        item.text === "sign up" ||
        item.text.includes("sign up") ||
        item.text === "signup" ||
        item.text.includes("create account") ||
        item.text.includes("get started")
      )
      .filter((item) => item.area > 40 && item.area < 260000)
      .sort((a, b) => {
        const exactA = (a.text === "sign up" || a.text === "signup") ? 0 : 1;
        const exactB = (b.text === "sign up" || b.text === "signup") ? 0 : 1;
        if (exactA !== exactB) return exactA - exactB;
        return a.area - b.area;
      });
    return candidates[0]?.el ? getClickableTarget(candidates[0].el) : null;
  }

  async function autoClickMetaAiSignUp(force = false) {
    if (!isMetaAiPage()) return { ok: false, message: "Not meta.ai" };
    if (window.__agentmailMetaAiSignUpClickedAt && !force && Date.now() - window.__agentmailMetaAiSignUpClickedAt < 5000) {
      return { ok: true, message: "Meta AI Sign up clicked recently." };
    }
    const button = findMetaAiSignUpButton();
    if (!button) return { ok: false, message: "Meta AI Sign up button not found." };
    window.__agentmailMetaAiSignUpClickedAt = Date.now();
    flash(button);
    fireRealisticClick(button);
    return { ok: true, message: "Meta AI Sign up clicked." };
  }

  function startMetaAiSignupWatcher() {
    if (window.__agentmailMetaAiSignupWatcherStarted) return;
    window.__agentmailMetaAiSignupWatcherStarted = true;
    if (!isMetaAiPage()) return;

    // Click Sign up as soon as it is visible on meta.ai. Mobile pages often
    // render the modal after content-script load, so use immediate tries, a
    // short fast interval, and a mutation observer.
    [0, 40, 100, 180, 300, 500, 800, 1200, 1800, 2600, 4000, 6500, 9000].forEach((delay) => {
      setTimeout(() => autoClickMetaAiSignUp(false), delay);
    });
    const fastTimer = setInterval(() => {
      if (!isMetaAiPage()) { clearInterval(fastTimer); return; }
      autoClickMetaAiSignUp(false);
    }, 120);
    setTimeout(() => clearInterval(fastTimer), 20000);
    try {
      const observer = new MutationObserver(() => autoClickMetaAiSignUp(false));
      observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
      setTimeout(() => observer.disconnect(), 25000);
    } catch (error) {}
  }

  function runMetaAutomation(force = false) {
    if (isMetaAiPage()) {
      autoClickMetaAiSignUp(force);
      startMetaAiSignupWatcher();
      return;
    }
    if (!isMetaAuthPage()) return;
    if (redirectMetaAiIfPostCodePending(false)) return;
    if (redirectAfterSelfieUploadGoneIfNeeded()) return;
    if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
      autoHandleMetaCreateAccountBlocked(force);
      return;
    }
    if (isMetaConfirmationCodePage()) {
      autoFillMetaConfirmationCodePage(force);
      return;
    }
    autoClickMetaProfileContinue(force);
    clickMetaEmailChoice(force);
    redirectFromMetaLanguagePage(false);
    autoClickMetaHamburgerAndLogout(false);
    autoClickMetaAllowAllCookies(false);
    autoClickMetaLoginAnotherAccount(false);
    autoRefreshMetaBlankWhite(false);
    autoRefreshMetaDarkStuck(false);
    autoRefreshMetaSomethingWentWrong(false);
    autoRefreshMetaCantUseRightNow(false);
    autoClickMetaOopsOk(false);
    autoClickMetaHumanContinue(false);
    autoClickMetaCreateNewAccount(force);
    autoFillMetaNamePage(false);
    autoFillMetaDobPage(false);
    autoFillMetaPasswordPage(false);
    autoClickMetaNotNow(false);
    autoClickMetaFinalReview(false);
    autoClickMetaAiDetailsConfirm(false);
    autoFillMetaConfirmationCodePage(false);
    autoClickMetaSelfieContinue(false);
    autoFillMetaEmailInput();

    if (!window.__agentmailNamePoller) {
      window.__agentmailNamePoller = setInterval(() => {
        if (!isMetaAuthPage()) return;
        if (redirectMetaAiIfPostCodePending(false)) return;
        if (redirectAfterSelfieUploadGoneIfNeeded()) return;
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
          autoHandleMetaCreateAccountBlocked(false);
          return;
        }
        if (isMetaConfirmationCodePage()) {
          autoFillMetaConfirmationCodePage(false);
          return;
        }
        autoClickMetaProfileContinue(false);
        redirectFromMetaLanguagePage(false);
        autoClickMetaHamburgerAndLogout(false);
        if (isMetaConfirmationCodePage()) {
          autoFillMetaConfirmationCodePage(false);
          return;
        }
        autoClickMetaProfileContinue(false);
        autoClickMetaAllowAllCookies(false);
        autoClickMetaLoginAnotherAccount(false);
        autoFillMetaEmailInput();
        autoRefreshMetaBlankWhite(false);
        autoRefreshMetaDarkStuck(false);
        autoRefreshMetaSomethingWentWrong(false);
        autoRefreshMetaCantUseRightNow(false);
        autoClickMetaOopsOk(false);
        autoClickMetaHumanContinue(false);
        autoFillMetaNamePage(false);
        autoFillMetaDobPage(false);
        autoFillMetaPasswordPage(false);
        autoClickMetaNotNow(false);
        autoClickMetaFinalReview(false);
        autoClickMetaAiDetailsConfirm(false);
        autoFillMetaConfirmationCodePage(false);
        autoClickMetaSelfieContinue(false);
      }, 250);
      setTimeout(() => {
        clearInterval(window.__agentmailNamePoller);
        window.__agentmailNamePoller = null;
    window.__agentmailEmailPoller = null;
    window.__agentmailMetaClickLoopTimer = null;
      }, 180000);
    }

    if (!window.__agentmailEmailPoller) {
      window.__agentmailEmailPoller = setInterval(() => {
        if (!isMetaAuthPage()) return;
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
          autoHandleMetaCreateAccountBlocked(false);
          return;
        }
        autoClickMetaProfileContinue(false);
        autoClickMetaAllowAllCookies(false);
        autoClickMetaLoginAnotherAccount(false);
        autoFillMetaEmailInput();
      }, 250);
      setTimeout(() => {
        clearInterval(window.__agentmailEmailPoller);
        window.__agentmailEmailPoller = null;
    window.__agentmailMetaClickLoopTimer = null;
      }, 180000);
    }

    if (!window.__agentmailMetaObserver) {
      window.__agentmailMetaObserver = new MutationObserver(() => {
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
          autoHandleMetaCreateAccountBlocked(false);
          return;
        }
        if (isMetaConfirmationCodePage()) {
          autoFillMetaConfirmationCodePage();
          return;
        }
        autoClickMetaProfileContinue();
        redirectFromMetaLanguagePage();
        autoClickMetaHamburgerAndLogout();
        autoClickMetaAllowAllCookies();
        autoClickMetaLoginAnotherAccount();
        autoRefreshMetaBlankWhite();
        autoRefreshMetaDarkStuck();
        autoRefreshMetaSomethingWentWrong();
        autoRefreshMetaCantUseRightNow();
        autoClickMetaOopsOk();
        autoClickMetaHumanContinue();
        autoClickMetaCreateNewAccount();
        autoFillMetaNamePage();
        autoFillMetaDobPage();
        autoFillMetaPasswordPage();
        autoClickMetaNotNow();
        autoClickMetaFinalReview();
        autoClickMetaAiDetailsConfirm();
        autoFillMetaConfirmationCodePage();
        autoClickMetaSelfieContinue();
        autoFillMetaEmailInput();
      });
      window.__agentmailMetaObserver.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      setTimeout(() => {
        window.__agentmailMetaObserver?.disconnect();
        window.__agentmailMetaObserver = null;
      }, 180000);
    }
  }

  window.__agentmailRunMetaAutomation = runMetaAutomation;
  window.__agentmailClickMetaEmailChoice = clickMetaEmailChoice;
  window.__agentmailAutoFillMetaEmailInput = autoFillMetaEmailInput;
  window.__agentmailAutoClickMetaAllowAllCookies = autoClickMetaAllowAllCookies;
  window.__agentmailAutoClickMetaLoginAnotherAccount = autoClickMetaLoginAnotherAccount;
  window.__agentmailAutoClickMetaProfileContinue = autoClickMetaProfileContinue;
  window.__agentmailAutoClickMetaCreateNewAccount = autoClickMetaCreateNewAccount;
  window.__agentmailAutoFillMetaNamePage = autoFillMetaNamePage;
  window.__agentmailAutoFillMetaDobPage = autoFillMetaDobPage;
  window.__agentmailAutoFillMetaPasswordPage = autoFillMetaPasswordPage;
  window.__agentmailAutoClickMetaNotNow = autoClickMetaNotNow;
  window.__agentmailAutoClickMetaFinalReview = autoClickMetaFinalReview;
  window.__agentmailAutoClickMetaAiDetailsConfirm = autoClickMetaAiDetailsConfirm;
  window.__agentmailAutoFillMetaConfirmationCodePage = autoFillMetaConfirmationCodePage;
  window.__agentmailAutoClickMetaAiSignUp = autoClickMetaAiSignUp;
  window.__agentmailAutoClickMetaOopsOk = autoClickMetaOopsOk;
  window.__agentmailAutoHandleMetaCreateAccountBlocked = autoHandleMetaCreateAccountBlocked;
  window.__agentmailAutoClickMetaHumanContinue = autoClickMetaHumanContinue;
  window.__agentmailAutoRefreshMetaSomethingWentWrong = autoRefreshMetaSomethingWentWrong;
  window.__agentmailAutoRefreshMetaCantUseRightNow = autoRefreshMetaCantUseRightNow;
  window.__agentmailAutoRefreshMetaBlankWhite = autoRefreshMetaBlankWhite;
  window.__agentmailAutoRefreshMetaDarkStuck = autoRefreshMetaDarkStuck;
  window.__agentmailAutoClickMetaSelfieContinue = autoClickMetaSelfieContinue;
  window.__agentmailRedirectFromMetaLanguagePage = redirectFromMetaLanguagePage;
  window.__agentmailAutoClickMetaHamburgerAndLogout = autoClickMetaHamburgerAndLogout;

  function startFloatingMiniMenu() {
    const oldHost = document.getElementById("agentmail-floating-widget-host");
    if (window.__agentmailFloatingMiniMenuStarted && oldHost?.dataset?.version === AGENTMAIL_SCRIPT_VERSION) return;
    window.__agentmailFloatingMiniMenuStarted = true;
    if (oldHost) oldHost.remove();

    const host = document.createElement("div");
    host.id = "agentmail-floating-widget-host";
    host.dataset.version = AGENTMAIL_SCRIPT_VERSION;
    host.style.position = "fixed";
    host.style.zIndex = "2147483647";
    host.style.top = "92px";
    host.style.right = "10px";
    host.style.width = "76px";
    host.style.minHeight = "92px";
    host.style.pointerEvents = "auto";
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });
    const iconUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAMuElEQVR4nG1ZWYslR3o954vIu9fWVV3daqnVLc1oGY0EHoPBLwZjMPjBD/6bfjc2fph5GrAZkNEYWRokRtJIrV6qu7a75xLf8UNkZt1qKbgk3LyZEd/+fedcnj54aGYASAIws/w1XyUB6O9zZ+WvAAxGMwJGAiCDKQIyC2ZBkiQDAUgMipQhP8xAmiQ2lBwAZTHv3guUr3llafiThVuLJLMoICEJAhNlpADdqCo6IThlIAWaTAJoFggnZAJvBOo1ztddabK1XluS2lcNBNQJSjkoMwMoKe8nhwACpu4IkRREwAgRBUhRN0KQzGe8rv7OAz8VK0uWD1P3EpzAzdMSCAqgCBlACBCSBHPBJZCgMfSq9/b4qRC7ntoVeseQNxYF8Jos+b7gkgMECYgC849uBAmjgSBA60Xpd9x11mu2eU2afD47I3VCAJC7p5RyRMvbkE0QlAAKEkRkwcjOvJLiTjS8HtT9/j/rqjbyaCAhwN3JCAJyB+CkSS4YITOTZHAgdDJnLztI7ZjMuujx1ra95X8+p7IThM6ikuhS1kndyieqVRuAuwDSb2wIZuvKEggJnl+MnRf0WkTfRFWXKrce6GSSBIgg2uSXBIk5ZW/KmEDTbnABlGAElJ1AQcm9r343RW83mNz9Ru0dC0miYO2GrcJJcpfkJCUgq5T1zx/A1UB9FIie3841AgBiH0C80fgmlHatshu47k4y0EGKXcK7kCsLxNZLlismCLrELJdTIM3AHOBAA8QcWPG10GnPds9BhNv5f0s+lxtImJhjJahVWyIt7ynBDUbBc/GRSSLdiETkNgK5kCCDdFOC2wx135Xs50shsuM9py4AQgREtHFMurt7al2O1n3ZjIBLcDlTg7a7WO/4+JoXsky3CiaZfwKQs1e9SwXkEgNACoDBbjIwRw8BOWgA3GU3sQAo758lguQS4k8zKwvXt7bsvjbVUzIy9/ZsptS9mcPNgVwAsqclIr/eKeASGbrXIXkbRaSrSc6orojsikUy+253CMkJxRBuYqhtpQAQve0aQoJTuX/KQCbQIG/TjMYuQAEgtfnqIkSk2G7u/tMWkd3X3883m6Zp5yfl4uS5CKmtZQ1o3jpKua/RkLKJlG8ntsWLMCMaIDhCLmG5dXQVqy8QfSHOMwPQxy864xF0dyNoQfJEBuaSQ0n9fhAoJANpIeWuj2zWWt4kL8wCs/XMXXEnRlsRdjs/pJScZIyh9gTJaCEEl8MVY5HAarspBgWAsqwCB1ITLJcMUxJJWiBgFoNAyBXkBigWA6PV7omKciAKil2rZW+noihijHVVJ08kj+/cGQ6Gz54/m+3NQiwibT6fT6bTvb3987Oz4XB47+1Hz398VjfVW4/eqaumCLGqa0+u5IPRyCw0dU2SCNFiqhtDAQ8k5/OrhDqE6ILDoSTd9DIAqOv66vzs6Pju6f0HwzuDv3z3HcnpbFZXXjfN4dHReDwmbe/w4Pmzp7/66JMv9Mcffvju7//xn58//bcPf/3Ru794P8TBixcvnj359qOPf7PerIsYv/ry/04fPHzw5luDweCrP305f3X5+NEHBSbDYnz+4uVX336WUgohSJAn0OLthFeIcbVanp+fHx0exhCGxfDq6nqz3u4f7ldl+cVnnz5+78OTe/eqbXn+6nz/4Dg8ffrNt39m0HQ0/u1//vt2vXr0i19+9of/unx59sEnf/3ZH37//OnTf/inf/n8s//54vNPmyY9fvThaj7//X//6ye/+tuj2dspOQh3Tw4hOJveZQIQ42AwGjdNU5dVVZaT8WQ0HpvFZVpgW6fRtExe13W9raqqurh4hZTund6rt5umqlLj73/w8ZMfv/3qy88ViuevXh49e75c1hyM1qtlEcYfvv+bZ2dPtpv1erkU/ez8uVVTuBTk3k6TcEV3N2M3i0qSQaA2223d1NvNejzdCyFuVosQl6PJZHF9HUMh+Waz2i6Wg8kw1dXl+eXvfvcfbz98/PjdDx7cf/S/f/y0brbL6/l4NKtTdXH+0jwu5hd1tY3DYr1e/dX7f9c4nzz/OjXlKE7lDtDhAGPbQmAA5A2kum4Kb5bXV6EogtKaDIrbclOUoyLE9Waz1yS55pfL68uzu/fuvXh6NpvuhSJ895dvLq+ujo7faOqmruvUSO6ems1is1lvL6+f7e0fpCat16vnyx9Ojx9fr84nw6m7uk4nOa0fsnLlA5k8NXVT1+UQvlxv66pumqapq6oqx+Pp0dGd9fVFWW6LIib3i5cvilgsl4vRcPDOo/cOD49Tuamr7WA4jEWsqk0RgxrMhocfPPqb4/23l8tyudxeL1641m+e/DIwpFTnKQqSkGI/bwEgDUBq6tFwsK7LxWJewqZFGMLKchuWV1UIozgoqzoW8fzF93EwXK2uy/Xck5/9+MNwMBS03paTvaPl4vqlngyLYbVerFcvm21aD6YNbFLYvYPTs4s/X179OB48AJF8GzmULMkN4NHd+2YWguVmtVouqDQbDOZVIzAGOxjG+WqbzKrNhgDNpodH29Xapb3ZwWa73CxXJyf3rq7O5bJgR4d3h8Xw4upFuS3vn7xzvXq1Ws5DiIIP4th9sz+cMky31eW7d9+zwd1Xi++LUEAxd4VWoDaugXK9mVLLxuNoQnq92VAKk+kgRsliCMVgkJuChZhzoa5Lyfen+yC9UVXVo9GA0Nmrl4M4mk73Yhx6lcpyTXK73WzK9eHe8eXyYrN59dH9j5tiXKZVoaJByDjypsnLJaVFVQ+msxBIBCuGg9n+pBhSBLW3NxsNB7PJ5PjoTlGE2Wzy5hv37t85LTebEO3hw8fHx3c36wVDeuvNd+8c3LWg6Xjy8PSt1KwgGTgZTU4OT0OMJ/un+9M3/nT2ddmsgwWnSIGKHZLLRESCxTgZBTN3t8BRMbZc082bzfpis54dHS83l9v1eu/4JG2333/9ZTEcK8TlejW/uqgrB3F9Pb9/Nx3MjrblQo5nT56sNuV4NEZGaYCBovanB+PRNOVR20glqUUdPeTlaDiKsVDHPeRhmQRhddLl/Krx2sLgajn3VMfh8PTB29PZvlPHd+6U82szjIYTguV2A9NoOImimU2GM1DsoI3kOa8HMeZZERIosUUdPbpg3/hp5pJ5IumiC5PxDPLNcnUwPjg4OFwuFmzSjKoEgNvFZjW/mgCj0fjyYr68eGnCwON2NY9hJCWQIAXJE9ASQpLADk5JntwAAd4BxTaeWiXkhGXah5AbYIQneXLSPDHph/lqBUZgtVi8dXp/2Khcr0DUTbOcX1bb9WJ9geSR1kgORwuNBLTwy2gQ3JOnRt5EKCM0tf4BcgchaWYuQcwMSqDgvm3Kg7HoPhkMCzb3jw8K2qIqD2P45tsv90eT6fjINPEyLbfLSaxq91RWKSQRLhkJl1wAYQDgHbDM9bAjrNpizX5qVH+nnddMaqKFg4EVaIxmTVWWNVcLDIesfZGuL2pV9eLEtSq3dyYHoj1fz989PonS3J0yQS4nQGvH2Y5i2EG6hyenpAHez/MdQ0ejSQqiEYIaNVZVI0+X4KAYXM/nxgAohCihKIrZeLpYLcu6NBrk+3uHxnBxdfbr47tVPLzyMhooy5BkB+e3Dsw4iIcnJ2TIHu0faHlPdFCynfN9vVqCYTyewr1F6ARFg9HYwj8DZBTNAGK13jSb5cmd+02MFDKLmDHlLRjqdHmjFFts0jOEJMmMkh0p9FQcKHEwmJKkKLXEEDp1HS0T1sppGYZwPBqVsK28yB2TngST5b65YyBleiv2iEfKTCUyqHCIgAPGjOSSRGOgdbg4t2MwUwhAmxQtk9lOfQI4Gg1hbKG+Z3JPgJOBmYHrcDzQkQ27iEwtsJV3UNos87ciQiYrmb8RbSZzl9Ru8zVBxo538eQ0iOgYD8Ep0UgZ2vhxZYF64NyWxw6uZ5jXw8V2gsrsFDKxkN1geS7uIaW7I8PIlorIqjYkgQBkgiD/mGFahsFCBxRv0HSPmjuqqUOkHfuUqQwHO1tDcPotIjYX4psNW1XzAw5EgJQRLiUhAoIawACPWVHcXi03qNb8zDM4+kM9E8sd98IOZ9NTolkmPdTSz1TH0nYipjY/5YIDdXdmxmUwY+Ylb+UaOq/lWbL7s6Ln725xXOo1kOCiZcuJ8taLBIDkyWhdPWyJIbbSwiUa4636dJtH68VyZP4LoZNmd3mefzNfT7qcqa0fHUFwQ+t4V/BaTrSrRi4JkmdMbUgp7bAcJNRxcr1YzHQ03Dti8Cb924kcbQfKrm6hFm/b29s92xzKSbfDS0WhyX23v9vyy6mlTEAYQ56QHCBc3nJCvQd74pqk5b80OrKkf6w7or/wZpNsHADA/wPT6rPpJoHw9wAAAABJRU5ErkJggg==";
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        * { box-sizing: border-box; font-family: Arial, sans-serif; -webkit-tap-highlight-color: transparent; }
        .wrap { position: relative; width: 76px; user-select: none; }
        .logoBtn {
          width: 58px; height: 58px; margin-left: 9px; border: 0; border-radius: 18px;
          padding: 0; background: #101727; box-shadow: 0 8px 28px rgba(0,0,0,.34);
          display: grid; place-items: center; cursor: grab; touch-action: none;
          border: 2px solid rgba(109,93,252,.9); overflow: hidden;
        }
        .logoBtn:active { cursor: grabbing; transform: scale(.98); }
        .logoPic {
          display:block; width:100%; height:100%; background-image:url("${iconUrl}");
          background-size:cover; background-position:center; background-repeat:no-repeat;
        }
        .countBadge {
          position: absolute; right: -2px; top: -8px; min-width: 25px; height: 25px; padding: 0 6px;
          border-radius: 999px; background: #00d4ff; color: #03131a; font-size: 12px;
          font-weight: 900; display: grid; place-items: center; border: 2px solid #fff;
          box-shadow: 0 4px 10px rgba(0,0,0,.25);
        }
        .copyMini {
          margin-top: 5px; width: 76px; border: 0; border-radius: 999px; padding: 7px 5px;
          font-size: 10px; font-weight: 900; color: #fff; background: linear-gradient(135deg,#6d5dfc,#8d5cff);
          box-shadow: 0 5px 18px rgba(0,0,0,.28); cursor: pointer;
        }
        .copyMini:active, .btn:active, .tab:active { transform: scale(.97); }
        .panel {
          position: absolute; top: 0; right: 84px; width: min(305px, calc(100vw - 98px)); padding: 12px; border-radius: 20px;
          color: #f7f8ff; background: rgba(9,11,22,.97); border: 1px solid rgba(255,255,255,.13);
          box-shadow: 0 18px 50px rgba(0,0,0,.45); display: none; max-height: min(78vh, 560px); overflow:auto;
        }
        .panel.open { display: block; }
        .head { display:flex; align-items:center; gap:9px; margin-bottom:10px; }
        .headLogo { width: 34px; height: 34px; border-radius: 11px; background-image:url("${iconUrl}"); background-size:cover; background-position:center; flex:0 0 auto; }
        .title { font-size: 14px; font-weight: 900; line-height: 1.15; }
        .sub { color: #9aa6c2; font-size: 11px; margin-top: 1px; }
        .stat { display:flex; justify-content:space-between; align-items:center; padding:8px 10px; border-radius: 13px; background: rgba(255,255,255,.07); margin: 8px 0; font-size: 12px; }
        .stat strong { color: #00d4ff; font-size: 17px; }
        .tabs { display:grid; grid-template-columns: repeat(4, 1fr); gap:5px; margin:9px 0; }
        .tab { border:0; border-radius: 11px; padding:8px 4px; color:#dfe6ff; background:rgba(255,255,255,.08); font-weight:900; font-size:10px; cursor:pointer; }
        .tab.active { color:#07131f; background:#00d4ff; }
        .section { display:none; }
        .section.active { display:block; }
        .grid { display:grid; grid-template-columns:1fr 1fr; gap:7px; }
        .btn { border:0; border-radius: 12px; padding: 10px 8px; cursor:pointer; color:#fff; font-weight:900; font-size:11px; background:rgba(255,255,255,.10); }
        .btn.primary { background: linear-gradient(135deg,#6d5dfc,#8d5cff); }
        .btn.primary.active { outline: 2px solid #00d4ff; }
        .btn.blue { background: rgba(0,212,255,.18); border: 1px solid rgba(0,212,255,.28); }
        .btn.danger { background: rgba(255,77,109,.18); border: 1px solid rgba(255,77,109,.28); }
        .btn.full, .input.full { grid-column: 1 / -1; }
        .input { width:100%; border:1px solid rgba(255,255,255,.14); background:rgba(255,255,255,.08); color:#fff; border-radius:12px; padding:10px; outline:none; font-size:12px; }
        .selected, .emailPreview { margin: 8px 0 0; padding: 8px; border-radius: 11px; background: rgba(0,212,255,.09); color:#dcecff; font-size:11px; word-break:break-all; }
        .hint { margin: 8px 0 0; color:#9aa6c2; font-size:11px; line-height:1.25; }
        .msg { min-height: 15px; margin-top: 8px; color: #9aa6c2; font-size: 11px; line-height:1.25; }
      </style>
      <div class="wrap">
        <button class="logoBtn" id="logoBtn" title="Open MasterTeam Mail Menu"><span class="logoPic" aria-hidden="true"></span></button>
        <div class="countBadge" id="countBadge">0</div>
        <button class="copyMini" id="copyMini" type="button">CopyMails</button>
        <div class="panel" id="panel">
          <div class="head"><span class="headLogo" aria-hidden="true"></span><div><div class="title">MasterTeam Mail Menu</div><div class="sub">Click logo to open/close</div></div></div>
          <div class="stat"><span>Total account</span><strong id="panelCount">0</strong></div>
          <div class="tabs">
            <button class="tab active" data-sec="mails" type="button">Mails</button>
            <button class="tab" data-sec="start" type="button">Start</button>
            <button class="tab" data-sec="password" type="button">Password</button>
            <button class="tab" data-sec="account" type="button">Account</button>
          </div>
          <div class="section active" id="sec-mails">
            <div class="grid">
              <button class="btn primary" id="toxicBtn" type="button">Toxic mail</button>
              <button class="btn primary" id="babyBtn" type="button">Baby mail</button>
            </div>
            <div class="selected" id="selectedProviderMini">Selected: Toxic mail</div>
            <div class="emailPreview" id="emailPreviewMini">Mail: none</div>
          </div>
          <div class="section" id="sec-start">
            <button class="btn blue full" id="startBtnMini" type="button">Start with fresh mail</button>
            <p class="hint">Selected provider diye fresh mail niye Meta flow start korbe.</p>
          </div>
          <div class="section" id="sec-password">
            <div class="grid">
              <input class="input full" id="pwdMini" type="text" autocomplete="off" placeholder="Password" />
              <button class="btn" id="genPwdMini" type="button">Generate</button>
              <button class="btn blue" id="savePwdMini" type="button">Set Password</button>
            </div>
          </div>
          <div class="section" id="sec-account">
            <button class="btn full" id="copyPanelBtn" type="button">CopyMails</button>
            <p class="hint">LOG OUT stage ashle account list-e mail save hobe. CopyMails sob saved mail one line kore copy kore.</p>
          </div>
          <div class="msg" id="msg">Drag logo to move. Click logo to open/close main menu.</div>
        </div>
      </div>
    `;

    const $s = (selector) => shadow.querySelector(selector);
    const logoBtn = $s("#logoBtn");
    const copyMini = $s("#copyMini");
    const panel = $s("#panel");
    const countBadge = $s("#countBadge");
    const panelCount = $s("#panelCount");
    const msg = $s("#msg");
    const selectedProviderMini = $s("#selectedProviderMini");
    const emailPreviewMini = $s("#emailPreviewMini");
    const pwdMini = $s("#pwdMini");
    const toxicBtn = $s("#toxicBtn");
    const babyBtn = $s("#babyBtn");

    function setMsg(value) {
      msg.textContent = value;
      clearTimeout(setMsg.timer);
      setMsg.timer = setTimeout(() => { msg.textContent = "Drag logo to move. Click logo to open/close main menu."; }, 2600);
    }

    function applySavedPosition() {
      try {
        const saved = JSON.parse(localStorage.getItem("agentmail_float_pos") || "null");
        if (saved && Number.isFinite(saved.left) && Number.isFinite(saved.top)) {
          host.style.left = `${Math.max(0, Math.min(window.innerWidth - 76, saved.left))}px`;
          host.style.top = `${Math.max(0, Math.min(window.innerHeight - 92, saved.top))}px`;
          host.style.right = "auto";
        }
      } catch (error) {}
    }

    function providerLabelMini(provider) {
      return provider === "baby" ? "Baby mail" : "Toxic mail";
    }


    function updateSnapshot() {
      chrome.storage.local.get(["agentmail_accounts", "agentmail_account", "agentmail_mail_provider"], (saved) => {
        const accounts = Array.isArray(saved.agentmail_accounts) ? saved.agentmail_accounts : [];
        const account = saved.agentmail_account || {};
        const provider = saved.agentmail_mail_provider || account.mail_provider || "toxic";
        const count = accounts.filter((item) => item && item.email).length;
        countBadge.textContent = String(count);
        panelCount.textContent = String(count);
        selectedProviderMini.textContent = `Selected: ${providerLabelMini(provider)}`;
        emailPreviewMini.textContent = account.email ? `Mail: ${account.email}` : "Mail: none";
        toxicBtn.classList.toggle("active", provider !== "baby");
        babyBtn.classList.toggle("active", provider === "baby");
        if (!pwdMini.matches(":focus")) pwdMini.value = account.password || "FAHAD@10";
      });
    }

    function copyTextFromPage(text) {
      if (!text) return Promise.resolve(false);
      if (navigator.clipboard?.writeText) {
        return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
      }
      return new Promise((resolve) => {
        try {
          const area = document.createElement("textarea");
          area.value = text;
          area.style.position = "fixed";
          area.style.left = "-9999px";
          document.body.appendChild(area);
          area.focus();
          area.select();
          const ok = document.execCommand("copy");
          area.remove();
          resolve(ok);
        } catch (error) {
          resolve(false);
        }
      });
    }

    async function copyAllMails() {
      chrome.storage.local.get(["agentmail_accounts"], async (saved) => {
        const accounts = Array.isArray(saved.agentmail_accounts) ? saved.agentmail_accounts : [];
        const mails = accounts.map((item) => item.email || "").filter(Boolean).join("\n");
        if (!mails) {
          setMsg("No saved mails yet.");
          return;
        }
        const ok = await copyTextFromPage(mails);
        setMsg(ok ? `Copied ${accounts.filter((item) => item && item.email).length} mails.` : "Copy failed.");
      });
    }

    function switchSection(name) {
      shadow.querySelectorAll(".tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.sec === name));
      shadow.querySelectorAll(".section").forEach((sec) => sec.classList.toggle("active", sec.id === `sec-${name}`));
    }

    function openMainMenu() {
      panel.classList.toggle("open");
      if (panel.classList.contains("open")) {
        updateSnapshot();
        try {
          chrome.runtime.sendMessage({ type: "AGENTMAIL_OPEN_EXTENSION_POPUP" }, () => chrome.runtime.lastError);
        } catch (error) {}
      }
    }


    function createFresh(provider) {
      switchSection("mails");
      const label = providerLabelMini(provider);
      setMsg(`Creating ${label}...`);
      chrome.runtime.sendMessage({ type: "AGENTMAIL_SET_MAIL_PROVIDER", provider }, () => {
        chrome.runtime.lastError;
        chrome.runtime.sendMessage({ type: "AGENTMAIL_GET_OR_CREATE_EMAIL", forceNew: true, provider }, (response) => {
          if (chrome.runtime.lastError || !response?.ok) {
            setMsg(response?.error || chrome.runtime.lastError?.message || `${label} failed.`);
            updateSnapshot();
            return;
          }
          setMsg(`${label}: ${response.email}`);
          updateSnapshot();
          autoFillMetaEmailInput?.();
        });
      });
    }

    function startFlow() {
      setMsg("Starting...");
      chrome.storage.local.get(["agentmail_mail_provider"], (saved) => {
        const provider = saved.agentmail_mail_provider || "toxic";
        chrome.runtime.sendMessage({ type: "OPEN_START", prepareEmail: true, forceNewEmail: true, provider }, (response) => {
          if (chrome.runtime.lastError || !response?.ok) {
            setMsg(response?.error || chrome.runtime.lastError?.message || "Start failed.");
            return;
          }
          setMsg(response.email ? `Started: ${response.email}` : "Started.");
          updateSnapshot();
        });
      });
    }

    function randomMiniPassword() {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789@#$";
      let out = "";
      for (let i = 0; i < 10; i += 1) out += chars[Math.floor(Math.random() * chars.length)];
      return `${out}@10`;
    }

    function saveMiniPassword() {
      const password = (pwdMini.value || "").trim() || "FAHAD@10";
      chrome.storage.local.get(["agentmail_account"], (saved) => {
        const account = { ...(saved.agentmail_account || {}), password };
        chrome.storage.local.set({ agentmail_account: account }, () => {
          setMsg("Password set.");
          updateSnapshot();
          try { fill("password", password); } catch (error) {}
          autoFillMetaPasswordPage?.(true);
        });
      });
    }

    let drag = null;
    logoBtn.addEventListener("pointerdown", (event) => {
      drag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        left: host.getBoundingClientRect().left,
        top: host.getBoundingClientRect().top,
        moved: false
      };
      logoBtn.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    });

    logoBtn.addEventListener("pointermove", (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const dx = event.clientX - drag.startX;
      const dy = event.clientY - drag.startY;
      if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
      const left = Math.max(0, Math.min(window.innerWidth - 76, drag.left + dx));
      const top = Math.max(0, Math.min(window.innerHeight - 92, drag.top + dy));
      host.style.left = `${left}px`;
      host.style.top = `${top}px`;
      host.style.right = "auto";
    });

    logoBtn.addEventListener("pointerup", (event) => {
      if (!drag || drag.pointerId !== event.pointerId) return;
      const wasMoved = drag.moved;
      try { logoBtn.releasePointerCapture?.(event.pointerId); } catch (error) {}
      const rect = host.getBoundingClientRect();
      try { localStorage.setItem("agentmail_float_pos", JSON.stringify({ left: rect.left, top: rect.top })); } catch (error) {}
      drag = null;
      if (!wasMoved) openMainMenu();
    });

    copyMini.addEventListener("click", (event) => { event.stopPropagation(); copyAllMails(); });
    $s("#copyPanelBtn").addEventListener("click", copyAllMails);
    toxicBtn.addEventListener("click", () => createFresh("toxic"));
    babyBtn.addEventListener("click", () => createFresh("baby"));
    $s("#startBtnMini").addEventListener("click", startFlow);
    $s("#genPwdMini").addEventListener("click", () => { pwdMini.value = randomMiniPassword(); pwdMini.focus(); });
    $s("#savePwdMini").addEventListener("click", saveMiniPassword);
    shadow.querySelectorAll(".tab").forEach((tab) => tab.addEventListener("click", () => switchSection(tab.dataset.sec)));

    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && (changes.agentmail_accounts || changes.agentmail_account || changes.agentmail_mail_provider)) updateSnapshot();
      });
    } catch (error) {}

    applySavedPosition();
    updateSnapshot();
    setInterval(updateSnapshot, 30000);
  }

  function startAuthStuckWatchdog() {
    if (window.__agentmailAuthStuckWatchdogStarted) return;
    window.__agentmailAuthStuckWatchdogStarted = true;
    setInterval(() => {
        if (!isMetaAuthPage()) return;
        if (redirectMetaAiIfPostCodePending(false)) return;
        if (redirectAfterSelfieUploadGoneIfNeeded()) return;
        if (isMetaCreateAccountBlockedModal() || isMetaCreateAccountBlockedPaused()) {
        autoHandleMetaCreateAccountBlocked(false);
        return;
      }
      autoClickMetaProfileContinue(false);
      redirectFromMetaLanguagePage(false);
      autoClickMetaHamburgerAndLogout(false);
      autoClickMetaAllowAllCookies(false);
      autoClickMetaLoginAnotherAccount(false);
      autoRefreshMetaBlankWhite(false);
      autoRefreshMetaDarkStuck(false);
      autoRefreshMetaSomethingWentWrong(false);
      autoRefreshMetaCantUseRightNow(false);
    }, 1000);
  }

  startFloatingMiniMenu();
  startMetaAiSignupWatcher();
  startAccountsCenterRedirectWatcher();
  installSocialChoiceClickBlocker();
  installEditEmailClickBlocker();
  installConfirmationContinueClickBlocker();
  startAuthStuckWatchdog();

  runMetaAutomation();

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message !== "object") return false;

    if (message.type === "AGENTMAIL_FILL") {
      const result = fill(message.kind, message.value);
      sendResponse(result);
      return false;
    }

    if (message.type === "AGENTMAIL_CLICK_META_EMAIL_CHOICE" || message.type === "AGENTMAIL_RUN_META_AUTOMATION") {
      runMetaAutomation(Boolean(message.force));
      sendResponse({ ok: true, message: "Meta automation triggered" });
      return false;
    }

    if (message.type === "AGENTMAIL_REDIRECT_ACCOUNTS_CENTER") {
      Promise.resolve(redirectAccountsCenterToAuthStart(Boolean(message.force))).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_EMAIL") {
      autoFillMetaEmailInput().then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_PROFILE_CONTINUE") {
      autoClickMetaProfileContinue(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_ALLOW_ALL_COOKIES") {
      autoClickMetaAllowAllCookies(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_LOGIN_ANOTHER_ACCOUNT") {
      autoClickMetaLoginAnotherAccount(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_CREATE_NEW_ACCOUNT") {
      autoClickMetaCreateNewAccount(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_NAME") {
      autoFillMetaNamePage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_DOB") {
      autoFillMetaDobPage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_PASSWORD") {
      autoFillMetaPasswordPage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_NOT_NOW") {
      autoClickMetaNotNow(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_FINAL_REVIEW") {
      autoClickMetaFinalReview(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_AI_DETAILS_CONFIRM") {
      autoClickMetaAiDetailsConfirm(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_AI_SIGN_UP") {
      autoClickMetaAiSignUp(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_FILL_META_CONFIRMATION_CODE") {
      autoFillMetaConfirmationCodePage(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_OOPS_OK") {
      autoClickMetaOopsOk(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_HANDLE_CREATE_BLOCKED") {
      autoHandleMetaCreateAccountBlocked(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_HUMAN_CONTINUE") {
      autoClickMetaHumanContinue(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_SOMETHING_WENT_WRONG") {
      autoRefreshMetaSomethingWentWrong(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_CANT_USE_RIGHT_NOW") {
      autoRefreshMetaCantUseRightNow(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_BLANK_WHITE") {
      autoRefreshMetaBlankWhite(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REFRESH_META_DARK_STUCK") {
      autoRefreshMetaDarkStuck(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_SELFIE_CONTINUE") {
      autoClickMetaSelfieContinue(Boolean(message.force)).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_CLICK_META_HAMBURGER_LOGOUT") {
      Promise.resolve(autoClickMetaHamburgerAndLogout(Boolean(message.force))).then(sendResponse);
      return true;
    }

    if (message.type === "AGENTMAIL_REDIRECT_META_LANGUAGE_PAGE") {
      Promise.resolve(redirectFromMetaLanguagePage(Boolean(message.force))).then(sendResponse);
      return true;
    }

    return false;
  });
})();
