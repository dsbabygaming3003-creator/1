// Butter-smooth Continue helper (v1.9.1)
// - single instance per page (no loop stacking)
// - only runs on Meta pages instead of every site
// - clicks the instant the button is usable (was a hard 2s countdown)
(() => {
  "use strict";

  const VERSION = "1.9.1";
  if (window.__agentmailContinueScriptVersion === VERSION) return;
  window.__agentmailContinueScriptVersion = VERSION;
  try { clearInterval(window.__agentmailContinueTimer); } catch (error) {}

  const HOSTS = [
    // auth.meta.com is deliberately excluded: content.js owns its step-aware
    // Continue clicks (email/code/profile). A generic clicker here can submit an
    // empty email or double-press the same button while the page is offline.
    "auth.meta.ai",
    "meta.ai",
    "www.meta.ai",
    "accountscenter.meta.com",
    "accountcenter.meta.com"
  ];

  function isSupportedPage() {
    try { return HOSTS.includes(window.location.hostname.toLowerCase()); } catch (error) { return false; }
  }

  function isHiddenView() {
    try { return document.visibilityState === "hidden"; } catch (error) { return false; }
  }

  function isButtonActive(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;

    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    if (style.pointerEvents === "none" || style.cursor === "not-allowed") return false;

    const opacity = parseFloat(style.opacity);
    if (opacity < 0.8) return false;

    return true;
  }

  function findContinueButton() {
    const elements = Array.from(document.querySelectorAll(
      'button, a, div[role="button"], input[type="button"], input[type="submit"]'
    ));
    return elements.find((el) => {
      const text = (el.innerText || el.value || "").trim().toLowerCase();
      if ((text === "continue" || text.includes("continue")) && text.length < 20) {
        return isButtonActive(el);
      }
      return false;
    });
  }

  let busy = false;
  let badge = null;
  let badgeTimer = null;

  function removeBadge() {
    try { clearInterval(badgeTimer); } catch (error) {}
    badgeTimer = null;
    try { badge?.remove(); } catch (error) {}
    badge = null;
  }

  function clickContinue(btn) {
    // Realistic single activation - no double click, no dead sleeps.
    const rect = btn.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: window.screenX + x,
      screenY: window.screenY + y,
      button: 0,
      buttons: 1
    };
    const Pointer = window.PointerEvent || window.MouseEvent;
    try {
      btn.focus?.({ preventScroll: true });
      btn.dispatchEvent(new Pointer("pointerover", init));
      btn.dispatchEvent(new Pointer("pointerdown", init));
      btn.dispatchEvent(new MouseEvent("mousedown", init));
      btn.dispatchEvent(new Pointer("pointerup", { ...init, buttons: 0 }));
      btn.dispatchEvent(new MouseEvent("mouseup", { ...init, buttons: 0 }));
      btn.dispatchEvent(new MouseEvent("click", { ...init, buttons: 0 }));
    } catch (error) {
      try { btn.click(); } catch (inner) {}
    }
  }

  function armClick(btn) {
    if (busy || btn.__agentmailContinueArmed) return;
    btn.__agentmailContinueArmed = true;
    busy = true;

    const doClick = () => {
      btn.__agentmailContinueArmed = false;
      removeBadge();
      try { if (isButtonActive(btn)) clickContinue(btn); } catch (error) {}
      setTimeout(() => { busy = false; }, 800);
    };

    // Hidden tab: click straight away (nobody is watching, keep it instant).
    if (isHiddenView()) { doClick(); return; }

    // Visible: one soft beat so the eye can follow (was a 2 second countdown).
    badge = document.createElement("div");
    badge.textContent = "\u23f3 Clicking\u2026";
    badge.style.cssText = [
      "position:fixed",
      "background:#ff4757",
      "color:#fff",
      "padding:4px 10px",
      "border-radius:12px",
      "font-size:12px",
      "font-weight:bold",
      "z-index:2147483647",
      "pointer-events:none",
      "box-shadow:0 2px 8px rgba(0,0,0,.3)",
      "font-family:sans-serif"
    ].join(";");

    const place = () => {
      if (!badge) return;
      const r = btn.getBoundingClientRect();
      badge.style.top = `${Math.max(4, r.top - 30)}px`;
      badge.style.left = `${Math.max(4, r.left)}px`;
    };
    place();
    try { document.body.appendChild(badge); } catch (error) {}
    badgeTimer = setInterval(place, 120);
    setTimeout(doClick, 350);
  }

  function startAutoClicker() {
    if (busy || !isSupportedPage()) return;
    const btn = findContinueButton();
    if (btn) armClick(btn);
  }

  function boot() {
    if (!isSupportedPage()) return;
    startAutoClicker();

    window.__agentmailContinueTimer = setInterval(startAutoClicker, 400);

    // Catch the button the moment it renders instead of waiting for a tick.
    try {
      const observer = new MutationObserver(() => { if (!busy) startAutoClicker(); });
      observer.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { try { observer.disconnect(); } catch (error) {} }, 120000);
    } catch (error) {}

    setTimeout(() => {
      try { clearInterval(window.__agentmailContinueTimer); } catch (error) {}
      removeBadge();
    }, 120000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
