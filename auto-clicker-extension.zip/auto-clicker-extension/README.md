# Continue Auto Clicker — Chrome Extension

auth.meta.com পেজের নীল **Continue** বাটন অটোমেটিক ক্লিক করার এক্সটেনশন।
ডিফল্ট স্পিড: **50ms = সেকেন্ডে ২০ বার ক্লিক** (popup থেকে 10ms পর্যন্ত নামানো যায় = সেকেন্ডে ১০০ ক্লিক)।

## ইনস্টল করার নিয়ম (Desktop Chrome)

1. `auto-clicker-extension.zip` ডাউনলোড করে কম্পিউটারে এক্সট্র্যাক্ট করুন
   (অথবা `auto-clicker-extension` ফোল্ডারটা কপি করুন)।
2. Chrome-এ `chrome://extensions` লিখে Enter চাপুন।
3. উপরে ডান পাশে **Developer mode** অন করুন।
4. **Load unpacked** বাটনে ক্লিক করে `auto-clicker-extension` ফোল্ডার সিলেক্ট করুন।
5. ব্যস! এখন auth.meta.com পেজ খুললেই এক্সটেনশন নিজে থেকে Continue বাটনে ফাস্ট ক্লিক করা শুরু করবে।

## ব্যবহার

- টুলবারে এক্সটেনশনের আইকনে ক্লিক করলে popup খুলবে:
  - **STOP / START** — ক্লিকিং চালু/বন্ধ।
  - **Speed slider** — কত ms পরপর ক্লিক হবে (10–1000ms)।
  - **Button: detected ✓** — পেজে Continue বাটন পাওয়া গেছে কি না।
- পেজ আগে থেকে খোলা থাকলে (এক্সটেনশন ইনস্টলের আগে) popup-এর **Inject into this page** বাটন চাপুন, নাহয় পেজ রিফ্রেশ করুন।

## নোট

- Chrome extension মোবাইলে ইনস্টল হয় না — ডেস্কটপ Chrome লাগবে।
- এই এক্সটেনশন শুধু Continue বাটনটা ক্লিক করে; এর পরের কোনো ভেরিফিকেশন
  (OTP / ক্যাপচা ইত্যাদি) থাকলে সেটা নিজে করতে হবে।
